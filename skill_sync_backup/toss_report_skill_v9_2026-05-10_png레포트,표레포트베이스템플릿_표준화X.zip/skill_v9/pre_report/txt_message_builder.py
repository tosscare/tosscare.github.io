"""txt문구 빌더 — 명령어·변수 적용 양식

본 파일은 pre_report_gen.render_message 함수의 단순화 본문 (단일 파일).
customer dict → txt 메시지 산출.

사용 양식:
    from txt_message_builder import render_message
    msg = render_message(customer)
    print(msg)

customer dict 본문 본질:
    {
        "이름": "강선영",
        "labels": {"실손": "적정", "암": "과잉", "뇌": "빈약", "심장": "빈약", "수술": "과잉"},
        "has_renewal": True,
        "total_remaining_premium": 84104692,
        "결론_본문": "으로 핵심 의료보장이 완성되지 않았습니다.",  # (옵션)
        "연령대비": {"label": "보통"},  # (옵션 — 결론_본문 ❌ 시 fallback)
    }
"""

# ===== 결론 본문 매핑 (5종 평균 라벨 + has_bad 기준 + 카드 ③ 5단계 라벨 호환) =====
CONCLUSION_TEXT_BY_LEVEL = {
    # 카드 ③ 5단계 라벨
    "매우과잉":            "으로 핵심 의료보장이 지나치게 과잉상태입니다.",
    "높은편":              "으로 핵심 의료보장이 완성된 상태입니다.",
    "보통":                "으로 핵심 의료보장이 완성되지 않았습니다.",
    "낮음":                "으로 핵심 의료보장이 빈약한 상태입니다.",
    "미확인 (또는 0원)":   "으로 핵심 의료보장이 전무한 상태입니다.",
    "미확인":              "으로 핵심 의료보장이 전무한 상태입니다.",
    # 5종 라벨 (카드 ③ 라벨 ❌인 경우 매핑)
    "과잉":                "으로 핵심 의료보장이 지나치게 과잉상태입니다.",
    "적정":                "으로 핵심 의료보장이 완성된 상태입니다.",
    "빈약":                "으로 핵심 의료보장이 빈약한 상태입니다.",
    "부재":                "으로 핵심 의료보장이 전무한 상태입니다.",
}

# ===== 1번 항목 분기 변수 본문 =====
# 갱신형 ✅ 시 라벨 무관 ① + ④ 무조건 노출
RENEWAL_MESSAGE_LINE_1 = "❌ 보험료가 계속 인상되는 갱신형보험이 구성되어 보험료가 낭비를 넘어 크게 새고 있습니다."
RENEWAL_REMAINING_LINE = "❌ 이후 납입할 {amount:,}원에 더해 갱신형보험 인상분으로 보험료가 크게 낭비되게 됩니다."

# 갱신형 ❌ + 카드 ③ 라벨 ∈ {매우과잉, 높은편} → ②
PREMIUM_OVERAGE_LINE = "❌ 기납입보험료 외에도 {amount:,}원이나 되는 보험료를 낭비하게 됩니다."

# 갱신형 ❌ + 카드 ③ 라벨 ∈ {보통, 낮음} → ③
PREMIUM_NORMAL_LINE = "⭕ 잔여보험료가 {amount:,}원으로 일반적인 수준입니다."

# 갱신형 ❌ + 미확인 (또는 0원) → ②·③ 둘 다 미노출 (잔여 0원 추정)


def render_message(customer):
    """customer dict → txt 메시지 산출.

    1번 항목 분기:
    - 갱신형 ✅ + 라벨 무관          → ① + ④ 무조건
    - 갱신형 ❌ + 매우과잉·높은편    → ② "낭비"
    - 갱신형 ❌ + 보통·낮음          → ③ "일반적 수준"
    - 갱신형 ❌ + 미확인 (또는 0원)  → ②·③ 둘 다 미노출

    2번 항목 결론 본문:
    - customer["결론_본문"] ✅ 본문 우선 (5종 평균 라벨 + has_bad 기준)
    - customer["연령대비"]["label"] fallback (카드 ③ 5단계 라벨 기준)
    """
    name = customer["이름"]
    labels = customer["labels"]
    has_renewal = customer.get("has_renewal", False)
    total_remaining = customer.get("total_remaining_premium", 0)

    # 결론 본문 (5종 평균 + has_bad 본문 우선)
    if customer.get("결론_본문"):
        headline_close = customer["결론_본문"]
    else:
        level_label = customer.get("연령대비", {}).get("label", "미확인 (또는 0원)")
        headline_close = CONCLUSION_TEXT_BY_LEVEL.get(
            level_label,
            CONCLUSION_TEXT_BY_LEVEL["미확인 (또는 0원)"]
        )

    # 1번 항목 분기 변수 조립
    sub_lines = []
    if has_renewal:
        # 갱신형 ✅ → ① + ④ 무조건
        sub_lines.append(RENEWAL_MESSAGE_LINE_1)
        sub_lines.append(RENEWAL_REMAINING_LINE.format(amount=total_remaining))
    else:
        # 갱신형 ❌ → 카드 ③ 라벨 분기
        level_label = customer.get("연령대비", {}).get("label", "미확인 (또는 0원)")
        if level_label in ("매우과잉", "높은편"):
            sub_lines.append(PREMIUM_OVERAGE_LINE.format(amount=total_remaining))
        elif level_label in ("보통", "낮음"):
            sub_lines.append(PREMIUM_NORMAL_LINE.format(amount=total_remaining))
        # "미확인 (또는 0원)": ②/③ 둘 다 미노출

    # 빈 줄 1행 추가 룰 — 각 sub_line 위에 빈 줄 삽입
    line_1_parts = [f"1. {name}님의 보험은,"]
    for sl in sub_lines:
        line_1_parts.append("")
        line_1_parts.append(sl)
    line_1 = "\n".join(line_1_parts)

    # 메시지 본문 조립
    msg = f"""{name}님 안녕하세요.
토스 보험분석 어드바이저입니다.

토스앱으로 보험 점검 신청을 주셔서 토스 본사 소속 상담사가 연락드렸습니다.

{line_1}

2. 필수보장을 기준으로,
- 실손의료비 : {labels["실손"]}
- 암보장 : {labels["암"]}
- 뇌혈관보장 : {labels["뇌"]}
- 심장보장 : {labels["심장"]}
- 수술보장 : {labels["수술"]}
{headline_close}

3. 보험은 치료/사고 후에는 효율적으로 가입하기 어렵습니다.
올바르게 준비되어 있는지 꼭 점검해 보시기를 바랍니다.

❗궁금하신점은 [보험검토요청] 등으로 남겨주세요.
❗본사 상담사가 순차적으로 안내드릴 예정입니다.

✅ 본사 상담사 재직정보 확인 > https://service.tossinsu.com/insulink/vO03jJGuLG
"""
    return msg


# ===== 사용 예시 (강선영 본문) =====
if __name__ == "__main__":
    customer_kang = {
        "이름": "강선영",
        "labels": {
            "실손": "적정",
            "암": "과잉",
            "뇌": "빈약",
            "심장": "빈약",
            "수술": "과잉",
        },
        "has_renewal": True,
        "total_remaining_premium": 84104692,
        "결론_본문": "으로 핵심 의료보장이 완성되지 않았습니다.",
    }
    msg = render_message(customer_kang)
    print(msg)
