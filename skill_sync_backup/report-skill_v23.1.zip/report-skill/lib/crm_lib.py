# -*- coding: utf-8 -*-
"""
crm_lib.py — CRM레포트(트리거 4) v23 빌더 라이브러리
=====================================================

[용도]
    build_full(spec)   : 전체 레포트 1장 (crm_report/base_crm_full.html 앵커 교체 · 상품 N열 · 4건 초과 시 가로폭 확장)
    build_detail(spec) : 보험별 세부 레포트 N장 (crm_report/base_crm_detail.html · PAGES JSON · 갱신 예시표 전치형)
    premium_calc(...)  : 기납/잔여/총보험료 산출 (입력에 없을 때)
    shot(html, out, mode): Chromium PNG (lib/shot.js) — mode 'pages' = 보험별 / '' = 전체
    규격·문안 단일 출처 = references/crm_report.md (v23 추가분 §7) + references/opinion_phrases.md

[주의]
    1. 라이브러리. 실행은 examples/spec_crm_*.py 참조.
    2. 전체레포트 열 규격 = 김재욱 확정본(앞 영역 390px · 상품열 152.5px · 셀 여백 12px · 폰트 원형). 건수 > 4 → body 폭 = 1080 + (N−4)×152.5. 세로 분할·폭 축소·폰트 축소 ❌
    3. PAGES 스키마(보험별): {'no':'1번.','name','co','badges':[[t,cls]],'pay':'85,240 원 | 월납','opinion':[...],'info':[[k,v]x5],
       'cats':[[카테고리, 전체음영bool, [[담보명, 금액, 납기, 기간, hl(, blue)],...]]], 'tall':bool, 'renewProduct':bool, 'noRenew':bool, 'renew':[title, rows, avg]}
"""
import os, json, subprocess
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__)); SKILL = os.path.dirname(HERE)
BASE_FULL = os.path.join(SKILL, 'crm_report', 'base_crm_full.html'); BASE_DETAIL = os.path.join(SKILL, 'crm_report', 'base_crm_detail.html')
LOGO = os.path.join(SKILL, 'crm_report', 'toss_logo.png')
COL_W = 152.5          # 김재욱 확정본 상품열 폭
RESIDUAL = ['이성훈', '로얄연금', 'HighFive', '60,161', '3,609,660', '21,367,872', '24,977,532', '20214991', '고*순']

def rep(h, old, new, exp=1):
    c = h.count(old); assert c == exp, (c, exp, old[:80]); return h.replace(old, new)
def won(v): return f'{v:,}'

# ─────────────── 보험료 산출 ───────────────
def premium_calc(policies, today=None):
    """policies = [(계약일 'YYYY-MM-DD', 납입기간년, 월보험료, kind), ...] kind: 'm'(월납·납입중) / 'done'(납입완료) / 'once'(일시납)
       → [(기납, 잔여, 총), ...]  경과월 = 계약일~오늘(해당일 도래 시 +1), 총 = 월납×기간×12"""
    T = today or date.today(); out = []
    for d, y, p, k in policies:
        yy, mm, dd = map(int, d.split('-'))
        if k == 'once': out.append((p, 0, p)); continue
        n = y * 12; e = (T.year - yy) * 12 + (T.month - mm) + (1 if T.day >= dd else 0); e = min(max(e, 0), n)
        if k == 'done': e = n
        out.append((p * e, p * n - p * e, p * n))
    return out

LEVELS = {'낮음': ('active-warning', 1, '#F97316'), '보통': ('active-neutral', 2, '#191F28'), '높은편': ('active-good', 3, '#15803D'), '매우과잉': ('active-rich', 4, '#DB2777')}
def spend_level(monthly, age_band_limit):
    """월보험료 / 연령대 적정(20대 10만·30대 15만·40대 18만·50대 25만·60대+ 40만) → 낮음(<51%) 보통(51~89) 높은편(90~129) 매우과잉(≥130)"""
    r = monthly / age_band_limit * 100
    return '낮음' if r < 51 else '보통' if r < 90 else '높은편' if r < 130 else '매우과잉'

# ─────────────── 전체 레포트 ───────────────
def build_full(S):
    """S = {'name', 'n', 'monthly', 'sub':{'보장성':(n,amt),'기타':(n,amt),'저축':(n,amt)}, 'paid','remain','total'(원, int|None→'-'),
            'level':'높은편', 'completion':30, 'products':{'NAMES','보험사명','계약일','갱신'(html),'계약자','증권번호','납입'(html),'납입기간','만기','종료','월납','기납','잔여','총'},
            'rows': {소분류: [총액, 상품1..N]}, 'out':'x_full.html', 'comment':'// 열 설명'}"""
    h = open(S.get('base', BASE_FULL), encoding='utf-8').read(); N = S['n']; name = S['name']
    h = rep(h, '이성훈님의 보장분석', f'{name}님의 보장분석', 2); h = rep(h, '본 파일은 이성훈님 케이스', '본 파일은 확정 케이스')
    h = rep(h, '// [대분류, [소분류, 총액, KB실손, KB닥터, 로얄연금, iM]]', S.get('comment', f'// {N}열: [소분류, 총액, 상품1..{N}] — 전부 검정'))
    # stats-box
    h = rep(h, '<td class="stats-label">보험 개수</td><td class="stats-val">3 개</td>', f'<td class="stats-label">보험 개수</td><td class="stats-val">{N} 개</td>')
    h = rep(h, '<strong>60,161 원</strong>', f'<strong>{won(S["monthly"])} 원</strong>')
    sub = S['sub']
    h = rep(h, '<div class="stats-sub">- 보장성보험료 합계 2건 60,161원</div>', f'<div class="stats-sub">- 보장성보험료 합계 {sub["보장성"][0]}건 {won(sub["보장성"][1])}원</div>')
    h = rep(h, '<div class="stats-sub">- 기타보험료 합계 0건 0원</div>', f'<div class="stats-sub">- 기타보험료 합계 {sub.get("기타", (0, 0))[0]}건 {won(sub.get("기타", (0, 0))[1])}원</div>')
    h = rep(h, '<div class="stats-sub">- 저축보험료 합계 1건 0원</div>', f'<div class="stats-sub">- 저축보험료 합계 {sub.get("저축", (0, 0))[0]}건 {won(sub.get("저축", (0, 0))[1])}원</div>')
    v = lambda x: (won(x) + ' 원') if isinstance(x, int) else '-'
    h = rep(h, '<td class="stats-val amt-black"><strong>3,609,660 원</strong></td>', f'<td class="stats-val amt-black"><strong>{v(S["paid"])}</strong></td>')
    h = rep(h, '<td class="stats-val amt-red"><strong>21,367,872 원</strong></td>', f'<td class="stats-val amt-red"><strong>{v(S["remain"])}</strong></td>')
    h = rep(h, '<td class="stats-val amt-blue"><strong>24,977,532 원</strong></td>', f'<td class="stats-val amt-blue"><strong>{v(S["total"])}</strong></td>')
    lv = S['level']; cls, k, color = LEVELS[lv]
    h = rep(h, '<div class="stats-card3-level-label val-빈약">낮음</div>', f'<div class="stats-card3-level-label val-{lv}">{lv}</div>')
    h = rep(h, '<div class="level-bar"><div class="level-seg active-warning"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div></div>',
            '<div class="level-bar">' + f'<div class="level-seg {cls}"></div>' * k + '<div class="level-seg"></div>' * (4 - k) + '</div>')
    comp = S['completion']
    h = rep(h, '<div class="stats-card3-completion-value">30%</div>', f'<div class="stats-card3-completion-value">{comp}%</div>')
    h = rep(h, '<div class="completion-bar-fill fill-빈약" style="width:30%;"></div>', f'<div class="completion-bar-fill fill-빈약" style="width:{comp}%;"></div>')
    h = rep(h, '.completion-bar-fill.fill-빈약{background:#F97316;}', '.completion-bar-fill.fill-빈약{background:#F97316;}\n' + f'.level-seg.{cls}{{background:{color};}}\n.val-{lv}{{color:{color};}}')
    # 열 규격: colgroup 열 수 + 폭 확장 (건수 > 4)
    if N != 4:
        if N > 4: h = rep(h, 'width:1080px;', f'width:{int(1080 + (N - 4) * COL_W)}px;')
        h = rep(h, '<colgroup><col style="width:130px"><col><col><col><col></colgroup>', '<colgroup><col style="width:130px">' + '<col>' * N + '</colgroup>')
        h = rep(h, '<colgroup><col style="width:100px"><col style="width:160px"><col style="width:130px"><col><col><col><col></colgroup>', '<colgroup><col style="width:100px"><col style="width:160px"><col style="width:130px">' + '<col>' * N + '</colgroup>', 5)
    # 섹션1
    P = S['products']; t0 = h.find('<tr><th>보험명</th>'); t1 = h.find('</tbody>', t0)
    def row(th, cells): return '<tr><th>' + th + '</th>' + ''.join('<td' + (' class="dash"' if c in ('- / -', '-') else '') + '>' + c + '</td>' for c in cells) + '</tr>'
    g = lambda k, d=None: P.get(k, d if d is not None else ['-'] * N)
    rows = ['<tr><th>보험명</th>' + ''.join(f'<td class="pname"><span class="clamp3">{n}</span></td>' for n in P['NAMES']) + '</tr>',
     row('보험사명', g('보험사명')), row('계약일', g('계약일')), '<tr><th>계약상태</th>' + ''.join(f'<td>{c}</td>' for c in g('계약상태', ['<span class="b-green">정상</span>'] * N)) + '</tr>',
     '<tr><th>갱신 유무</th>' + ''.join(f'<td>{c}</td>' for c in g('갱신')) + '</tr>', row('계약자/피보험자', g('계약자')), row('증권번호', g('증권번호')),
     '<tr><th>납입 여부</th>' + ''.join(f'<td>{c}</td>' for c in g('납입')) + '</tr>', row('납입주기/납입기간', g('납입기간')), row('보장만기/만기연령', g('만기')), row('납입종료일/종료연령', g('종료', ['- / -'] * N)),
     '<tr><th>월납보험료</th>' + ''.join(f'<td><span class="money-b">{v} 원</span></td>' for v in g('월납')) + '</tr>',
     row('기납보험료', g('기납')), row('잔여보험료', g('잔여')), row('총보험료', g('총')),
     '<tr><th>매니저 의견</th><td class="mgr-empty"></td>' + '<td></td>' * (N - 1) + '</tr>', '<tr><th>매니저 코멘트</th><td class="mgr-empty"></td>' + '<td></td>' * (N - 1) + '</tr>']
    h = h[:t0] + '\n        '.join(rows) + '\n      ' + h[t1:]
    # 섹션2
    d0 = h.find('var HEAD = ['); d1 = h.find('function amt(')
    CATS1 = [['실비', ['질병입원의료비', '질병외래의료비', '질병처방조제료', '상해입원의료비', '상해외래의료비', '상해처방조제료']], ['3대진단', ['일반암진단', '소액암(유사암)진단', '고액암진단', '뇌혈관질환진단', '뇌졸중질환진단', '뇌출혈질환진단', '허혈성심장질환진단', '급성심근경색진단']], ['수술비', ['질병수술', '상해수술', '암수술', '뇌혈관질환수술', '허혈성심장질환수술']], ['입원일당', ['질병입원', '상해입원']], ['사망', ['질병사망', '상해사망']], ['후유장해', ['질병80%이상후유장해', '질병80%미만후유장해', '상해80%이상후유장해', '상해80%미만후유장해']]]
    CATS2 = [['골절화상', ['골절진단', '화상진단']], ['생활배상책임', ['가족생활배상책임담보', '일상생활배상책임담보']], ['운전자', ['교통사고처리지원금', '벌금(대물)', '벌금(대인)', '변호사선임비용', '자동차부상치료비']], ['화재', ['화재벌금']], ['치아', ['보존치료', '보철치료']]]
    ROWS = {k: S['rows'].get(k, [''] * (N + 1)) for c in CATS1 + CATS2 for k in c[1]}
    for k, v in ROWS.items(): assert len(v) == N + 1, (k, len(v))
    DATA = ('var HEAD = ' + json.dumps(['대분류', '소분류', '보험명'] + P['NAMES'], ensure_ascii=False) + ';\nvar ROWS = ' + json.dumps(ROWS, ensure_ascii=False) + ';\n'
            'var CATS1 = ' + json.dumps(CATS1, ensure_ascii=False) + ';\nvar CATS2 = ' + json.dumps(CATS2, ensure_ascii=False) + ';\n'
            'function mk(cats){ return cats.map(function(c){ return [c[0], c[1].map(function(n){ return [n].concat(ROWS[n]); })]; }); }\nvar DATA1 = mk(CATS1), DATA2 = mk(CATS2);\n')
    h = h[:d0] + DATA + h[d1:]
    h = rep(h, "  var parts = v.split(' ');", "  var m = v.match(/^(.*?)\\s*(만원)?$/); var parts = [m[1].replace(/\\s+$/,''), m[2]||''];")
    h = rep(h, "      h += td('', amt(r[2], true));\n      h += td('', amt(r[3], true));\n      h += td('', amt(r[4], true));\n      h += td('', amt(r[5], false, true), true);",
            ''.join(f"      h += td('', amt(r[{i}], false, true){', true' if i == N + 1 else ''});\n" for i in range(2, N + 2)).rstrip('\n'))
    for k in RESIDUAL + list(S.get('residual', [])): assert k not in h, k
    out = S.get('out', 'crm_full.html'); open(out, 'w', encoding='utf-8').write(h); print('full ok', out); return out

# ─────────────── 보험별 세부 레포트 ───────────────
RENEW_JS = """  if(p.renew){
    var rw = p.renew;
    html+='<div class="renewal-wrap"><div class="rn-t"># 기간경과에 따른 보험료 갱신(인상) 안내</div><div class="rn-s">[NAME님] '+rw[0]+'</div><table class="rn-tbl"><thead><tr><th style="text-align:center;width:16%;">구분</th>';
    rw[1].forEach(function(r){ html+='<th style="text-align:center;">'+r[0]+'</th>'; });
    html+='<th style="text-align:center;background:#F1F3F5;">월평균</th></tr></thead><tbody>';
    html+='<tr><td style="font-weight:800;text-align:center;background:#F9FAFB;">월보험료</td>'; rw[1].forEach(function(r){ html+='<td style="text-align:center;">'+r[1]+'</td>'; }); html+='<td style="text-align:center;font-weight:700;background:#F9FAFB;">'+rw[2][0]+'</td></tr>';
    html+='<tr><td style="font-weight:800;text-align:center;background:#F9FAFB;">누적보험료</td>'; rw[1].forEach(function(r){ html+='<td style="text-align:center;">'+r[2]+'</td>'; }); html+='<td style="text-align:center;color:#E04848;font-weight:800;background:#F9FAFB;">'+rw[2][1]+'</td></tr></tbody></table><div class="rn-f"><span style="color:#E04848;font-weight:800;">'+(rw[3]||'유효보장 : 암진단 3천')+'</span><br><span style="color:#3182F6;font-weight:800;">'+(rw[4]||'내는돈 &gt; 받는돈')+'</span></div></div>';
  }"""
RENEW_CSS = '.expert{margin-top:52px;}\n.renewal-wrap{margin-top:40px;border:1px solid #E5E8EB;border-radius:10px;overflow:hidden;background:#fff;}\n.rn-t{padding:12px 14px 3px;font-size:14.5px;font-weight:800;color:#191F28;}\n.rn-s{padding:0 14px 10px;font-size:12px;color:#6B7684;font-weight:600;}\n.rn-tbl{border-left:none;border-right:none;}\n.rn-tbl th,.rn-tbl td{font-size:12.5px;padding:8px 10px;}\n.rn-f{padding:11px 14px;border-top:1px solid #E5E8EB;font-size:13.5px;line-height:1.8;text-align:center;}'
def R(name, amt, pay, period, hl=False, blue=False): return [name, amt, pay, period, hl, blue]
def build_detail(S):
    """S = {'name', 'pages': PAGES, 'out': 'crm_detail.html', 'residual': [...]}"""
    h = open(S.get('base', BASE_DETAIL), encoding='utf-8').read(); name = S['name']
    h = rep(h, '이성훈님의 보장분석 — 보험별 세부내용', f'{name}님의 보장분석 — 보험별 세부내용'); h = rep(h, '본 파일은 이성훈님 케이스', '본 파일은 확정 케이스')
    h = rep(h, '.expert-b strong{color:#E04848;}', '.expert-b strong{color:#E04848;font-weight:800;}\n.page.tall{height:auto;min-height:1920px;}')
    h = rep(h, "html+='<tr'+(hl?' class=\"hl\"':'')+'><td>'+nm+'</td>", "html+='<tr'+((hl||r[4])?' class=\"hl\"':'')+(r[5]?' style=\"color:#1E5FCC;\"':'')+'><td>'+nm+'</td>")
    h = rep(h, "if(/갱신/.test(nm)){ nm = '<span class=\"rnw\">'+nm+(/갱신형/.test(nm)?'':'(갱신형)')+'</span>'; }", "if(!p.noRenew && /갱신/.test(nm)){ nm = '<span class=\"rnw\">'+nm+(/갱신형/.test(nm)?'':'(갱신형)')+'</span>'; }")
    h = rep(h, "html+='<div class=\"page\" id=\"pg'+p.no[0]+'\">';", "html+='<div class=\"page'+(p.tall?' tall':'')+'\" id=\"pg'+p.no[0]+'\">';")
    h = rep(h, "document.body.insertAdjacentHTML('beforeend', html);", "document.body.insertAdjacentHTML('beforeend', html);\ndocument.querySelectorAll('.page.tall').forEach(function(e){ e.style.height=Math.ceil(e.getBoundingClientRect().height)+'px'; });")
    h = rep(h, "    html+='<div class=\"expert\"><div class=\"expert-t\">[전문가의견]</div><div class=\"expert-b\">'+items+'</div></div>';\n  }", "    html+='<div class=\"expert\"><div class=\"expert-t\">[전문가의견]</div><div class=\"expert-b\">'+items+'</div></div>';\n  }\n" + RENEW_JS.replace('NAME', name))
    h = rep(h, '.expert{margin-top:52px;}', RENEW_CSS)
    p0 = h.find('var PAGES = ['); p1 = h.find('];', p0) + 2
    h = h[:p0] + 'var PAGES = ' + json.dumps(S['pages'], ensure_ascii=False) + ';' + h[p1:]
    for k in RESIDUAL + list(S.get('residual', [])): assert k not in h, k
    out = S.get('out', 'crm_detail.html'); open(out, 'w', encoding='utf-8').write(h)
    print('detail ok', len(S['pages']), [sum(len(c[2]) for c in p['cats']) for p in S['pages']]); return out

_FONT_OK = False
def ensure_fonts():
    """Pretendard 미설치 환경(새 대화창) 자동 등록 — lib/setup_fonts.sh (스킬 동봉 fonts/ → npm 순)"""
    global _FONT_OK
    if _FONT_OK: return
    r = subprocess.run(['bash', os.path.join(HERE, 'setup_fonts.sh')], capture_output=True, text=True); print(r.stdout.strip()[:200]); _FONT_OK = True
def shot(html, out, mode='', width=1080):
    """Chromium PNG — 전체: out='CRM레포트_{name}.png' / 보험별: mode='pages', out='CRM레포트_{name}_%.png'(% → 01..NN)"""
    js = os.path.join(HERE, 'shot.js'); cwd = os.path.dirname(os.path.abspath(html)) or '.'
    ensure_fonts()
    if not os.path.exists(os.path.join(cwd, 'toss_logo.png')): subprocess.run(['cp', LOGO, cwd])
    r = subprocess.run(['node', js, os.path.abspath(html), os.path.abspath(out), mode, str(width)], capture_output=True, text=True, cwd=cwd)
    print(r.stdout.strip(), r.stderr.strip()[:300]); return out
