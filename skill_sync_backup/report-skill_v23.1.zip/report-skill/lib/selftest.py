# -*- coding: utf-8 -*-
"""selftest.py — 새 대화창 동기화 확인용 자가 테스트 (첨부 자료 불필요 · `python3 lib/selftest.py`)
    ① SKILL.md §2 파일 29개 존재 전수 대조 + MANIFEST.sha256 검증
    ② lib import · Pretendard 등록
    ③ 상담자료 모듈 전부를 베이스 위에서 실제 실행 (케이스별: 메리츠 3탭 / 2탭 추가할인 / KB 10년고지 / 기존보험 없음 / 간편 유형표 / 운전자 교체·신규·삭제 / 실손 전환·신규 / 갱신표 / 실효 리스트 / 현황표 6·11·12열)
    ④ CRM 예시(spec_crm_khj) 실제 실행 → PNG 9장 산출 + 규격(전체 3380px 폭·세부 2160×3840) 확인
    ⑤ 상담자료 산출물 render_check (PC 1080 + 모바일 420 · JS 오류 0)
    결과: 항목별 OK/FAIL — FAIL 1건이라도 있으면 작업 전 mr.와이 보고."""
import os, sys, re, json, subprocess, hashlib, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); SKILL = os.path.dirname(HERE); sys.path.insert(0, HERE)
R = []
def ok(name, cond, info=''): R.append((name, bool(cond), info)); print(('OK   ' if cond else 'FAIL ') + name + (f'  — {info}' if info else ''))

# ① 파일 전수
EXPECT = ['SKILL.md', 'MANIFEST.sha256', 'lib/report_lib.py', 'lib/crm_lib.py', 'lib/pdf_tools.py', 'lib/img_tools.py', 'lib/shot.js', 'lib/render_check.js', 'lib/setup_fonts.sh', 'lib/selftest.py',
          'templates/base_report_10yr.html', 'crm_report/base_crm_full.html', 'crm_report/base_crm_detail.html', 'crm_report/toss_logo.png',
          'references/report_conditions.md', 'references/opinion_phrases.md', 'references/crm_report.md',
          'examples/spec_report_khj.py', 'examples/spec_report_pjm.py', 'examples/spec_report_hong.py', 'examples/spec_report_jwc.py', 'examples/spec_crm_khj.py',
          'examples/khj_pages.json', 'examples/pjm_pages.json', 'examples/hong_pages.json', 'examples/khj_cancel.json'] + [f'fonts/Pretendard-{w}.otf' for w in ['Regular', 'Medium', 'SemiBold', 'Bold', 'ExtraBold']]
miss = [p for p in EXPECT if not os.path.exists(os.path.join(SKILL, p))]
ok(f'① 파일 전수 대조 ({len(EXPECT)}개)', not miss, f'누락: {miss}' if miss else '전부 존재')
try:
    bad = []
    for line in open(os.path.join(SKILL, 'MANIFEST.sha256'), encoding='utf-8'):
        h, p = line.split(maxsplit=1); p = p.strip().lstrip('./')
        if p == 'MANIFEST.sha256' or p == 'lib/selftest.py': continue
        if hashlib.sha256(open(os.path.join(SKILL, p), 'rb').read()).hexdigest() != h: bad.append(p)
    ok('① MANIFEST.sha256 검증', not bad, f'불일치: {bad}' if bad else '전부 일치')
except Exception as e: ok('① MANIFEST.sha256 검증', False, repr(e))

# ② import · 폰트
try:
    import report_lib as RL, crm_lib as CL, pdf_tools as PT, img_tools as IT; ok('② lib import', True, 'report_lib · crm_lib · pdf_tools · img_tools')
except Exception as e: ok('② lib import', False, repr(e)); print('\n'.join(f'{n}: {"OK" if c else "FAIL"}' for n, c, _ in R)); sys.exit(1)
r = subprocess.run(['bash', os.path.join(HERE, 'setup_fonts.sh')], capture_output=True, text=True); fc = subprocess.run(['fc-list'], capture_output=True, text=True).stdout
ok('② Pretendard 폰트 등록', 'retendard' in fc, r.stdout.strip().splitlines()[0] if r.stdout.strip() else r.stderr[:100])

# ③ 상담자료 모듈 — 베이스 위에서 실행 (더미 값 · 산출 파일은 임시 폴더)
TMP = tempfile.mkdtemp(prefix='selftest_'); os.chdir(TMP)
from PIL import Image
Image.new('RGB', (400, 200), (255, 255, 255)).save('dummy.png')
# 더미 PDF 1p (PDF_PAGES 렌더 경로 확인)
import pymupdf; d = pymupdf.open(); d.new_page(); d.save('dummy.pdf')
base = open(RL.BASE_10YR, encoding='utf-8').read()
EX = os.path.join(SKILL, 'examples'); PAGES = json.load(open(os.path.join(EX, 'khj_pages.json'), encoding='utf-8')); CK = json.load(open(os.path.join(EX, 'khj_cancel.json'), encoding='utf-8'))['rows']
def hw(n_exi, n_plan, sect=None):
    vals = n_exi + n_plan
    return dict(name='테스트', n_exi=n_exi, n_plan=n_plan, title='기존 보장성보험 비효율에 대한 보험료/보장항목 현황 및 조정 안내', prod_html='현재 보장성보험 1건', sect_head=sect,
                exi_head=''.join(f'<th class="hwang-exi">기존{i}</th>' for i in range(n_exi)), plan_head=''.join(f'<th class="hwang-p{i+1}">플랜{i+1}</th>' for i in range(n_plan)),
                need_row='<th>구분</th>' * vals, price_row='<th>월</th>' * vals, price2_row='<th>차액</th>' * vals,
                groups=[('3대질병 진단비', [('일반암', 1, *(['1,000만원'] * vals)), ('뇌혈관', 0, *([RL.bl('2,000만원')] * vals))])], n_rows=2)
ADEQ = dict(rows=[('실손<br>의료비', 1, [('질병입원의료비', 1, 'ok', '5,000만', '5,000만')]), ('암 진단', 1, [('일반암', 1, 'none', '1억', '0')])], note='※ 테스트')
PC = dict(t1=[('메리츠화재', 'A', '100,000'), ('KB라이프', 'B', '110,000')], t2=[('롯데손해', 'C', '120,000')], t1_title='1순위', t2_title='2순위', order_text='메리츠,KB', chosen='메리츠화재')
SIL = dict(gen='1세대', old_co='삼성', new_co='삼성', old='85,240', new='20,452', diff='64,788', save='1년에 75만원', title_co='삼성')
def common(**kw):
    sp = dict(name='테스트', birth8='19900101', hero='남성 · 만 36세 (1990.01.01년생 · 보험나이 37세)<br>보험기간 ~2080-01-01 (90세 만기 · 20년납)',
              chips={'mid': ['+A'], 'max': ['★B']}, coverage={'min': None, 'mid': RL.EMPTY_COV, 'max': RL.EMPTY_COV}, panels={},
              existing=dict(pages=PAGES, grp_title='본인 테스트님 보험 : 총 8건'), adequacy=ADEQ, pcmp=PC,
              sec3=dict(product_hl='메리츠화재<br>테스트 상품', product_sub='(테스트)', plans=[('안심보장플랜', '110,000', None, '26,400,000'), ('full보장플랜', '135,000', None, '32,400,000')]),
              hwang=hw(1, 3), modal_img='dummy.png', hl=[('최대 3,000만원', '암 진단 시'), ('최대 6,000만원/년', '암 치료 시'), ('최대 2,000만원', '뇌·심 진단 시'), ('최대 3,000만원', '순환계 치료 시')],
              driver='delete', pdf_pages={'min': None, 'mid': ('dummy.pdf', 1), 'max': ('dummy.pdf', 1)}, residual=[], residual_allow=['주부'], out='t.html')
    sp.update(kw); return sp
CASES = {
 '③-1 메리츠 3탭(기본·운전자 삭제·현황표 6열)': common(tabs=dict(count=3, rec='max', price={'min': '38,000', 'mid': '110,000', 'max': '135,000'})),
 '③-2 2탭·추가할인·실손 전환·갱신표·실효 리스트·현황표 12열': common(
    tabs=dict(count=2, rec='mid', price={'min': '0', 'mid': '110,000', 'max': '135,000'}, discount_last={'mid': '90,000', 'max': '100,000'}),
    existing=dict(pages=PAGES, grp_title='본인 테스트님 보험 : 총 8건', blocks={'1번.': [RL.sil_block(SIL)], '2번.': [RL.renew_block('테스트', '갱신형 (15년단위)', [('1~15년', '19,257원', '3,466,260원'), ('16~30년', '81,165원', '14,609,731원')], ('50,211원', '9,037,995원'))]},
                  tail=RL.cancel_block('2건', CK[:2], '2026-10-27')),
    sec3=dict(product_hl='메리츠화재<br>테스트', product_sub='(테스트)', plans=[('안심보장플랜', '110,000', None, '26,400,000'), ('full보장플랜', '135,000', None, '32,400,000')],
              discount={'title': '메리츠 보장성보험 (보험료 추가할인)', 'heads': ['가입시점', '1년후', '2년후'], 'rows': [('안심보장플랜', ['110,000', '100,000', '90,000'], '26,400,000', '100,000')]}),
    hwang=hw(7, 3)),
 '③-3 KB 10년고지(카드 빌더·waiver·hl5·sect_head·현황표 11열·강조=KB)': common(
    tabs=dict(count=3, rec='mid', price={'min': '90,832', 'mid': '156,452', 'max': '174,972'}, cover={'mid': '필요보장 70% 구성', 'max': '필요한 보장 완성 (90%)'}, min_cover='필요보장 30% 구성', fill={'min': 30}, min_diff='기존대비 −69,398원'),
    panels={'max': lambda s: RL.replace_cards(s, 'max', RL.card('cancer', '암', '진단비', '3,000만원', '통합암', [RL.sc('암 진단 시', '3,000만원', '테스트')], [], 'max', after=RL.tongap_table('통합암 31개', ['갑상선암'] * 31, '3,000만원', note='※ 테스트')) + RL.card('surgery', '수술', '수술', '1,000만원', '1~5종', [], [], 'max', after=RL.surg_tail(s)) + RL.card('injury', '기타', '기타', '30만원', '골절', [], [], 'max'))},
    pcmp=dict(PC, chosen='KB라이프'), waiver=['암 진단 확정 시', '뇌혈관질환 진단 확정 시'], hl5='재해·골절 수술 시', hwang=hw(6, 3, sect='<th>1. 기존보험</th><th colspan="3">2. 보완 플랜</th>')),
 '③-4 기존보험 없음(실손 신규·운전자 신규·현황표 sect 없음)': common(
    tabs=dict(count=3, rec='mid', price={'min': '38,000', 'mid': '110,000', 'max': '135,000'}),
    existing=dict(pages=[], grp_title='본인 테스트님 보험 : 유효 계약 0건', tail=RL.cancel_block('3건', CK[:1] * 3, '2026-10-27')),
    sec3=dict(product_hl='메리츠화재<br>테스트', product_sub='(테스트)', plans=[('안심보장플랜', '110,000', None, '26,400,000')], before_product_html=RL.sil_block(dict(SIL, mode='new'))),
    driver=dict(mode='new', intro='테스트님은 현재 운전자보험이 없어 최신기준 운전자보험 <strong>1건 신규 가입</strong>을 안내드립니다.', new_price='13,670원')),
 '③-5 간편보험(유형표 3610·적용 뱃지) + 운전자 교체(급수표)': common(
    tabs=dict(count=3, rec=None, price={'min': '38,000', 'mid': '110,000', 'max': '135,000'}), ganpyeon={'applied': '3610'},
    driver=dict(intro='테스트님은 운전자보험 <strong>1건</strong> 교체 안내', old_price='14,860원(1건)', new_price='13,670원', grade=[('벌금', 1, [('대인', ('3,000만', RL.GY), ('2,000만', RL.GW), ('2,000만', RL.GW), ('2,000만', RL.GW))])])),
}
outs = []
for name, sp in CASES.items():
    try:
        sp['out'] = f'{len(outs)}.html'; RL.build_report(sp); s = open(sp['out'], encoding='utf-8').read(); outs.append(sp['out'])
        chk = ['심은정' not in s, (('간편보험 유형 비교 (고지 기준)' in s) == bool(sp.get('ganpyeon'))), (('실손보험 신규가입 안내' in s) == ('before_product_html' in sp['sec3']))]
        ok(name, all(chk), f'{len(s):,} bytes')
    except Exception as e: ok(name, False, repr(e)[:160])
for k in ['3610', '355', '345', '335', '325']:
    try: RL.ganpyeon_type_block(k); ok(f'③ 간편 유형 {k}', True)
    except Exception as e: ok(f'③ 간편 유형 {k}', False, repr(e))
try: ok('③ pdf_tools 파서 함수', all(callable(getattr(PT, f)) for f in ['parse_meritz', 'to_coverage', 'parse_kb', 'kb_norm', 'kb_coverage', 'remove_blank_rows', 'redact_text']))
except Exception as e: ok('③ pdf_tools 파서 함수', False, repr(e))

# ④ CRM 예시 실제 실행
try:
    r = subprocess.run([sys.executable, os.path.join(EX, 'spec_crm_khj.py')], capture_output=True, text=True, cwd=TMP, timeout=900)
    pngs = sorted(f for f in os.listdir(TMP) if f.startswith('CRM레포트_김형준'))
    sz = {f: Image.open(f).size for f in pngs}
    full_ok = sz.get('CRM레포트_김형준.png', (0, 0))[0] == 3380; det_ok = all(v == (2160, 3840) for k, v in sz.items() if k != 'CRM레포트_김형준.png')
    ok('④ CRM 예시 실행(전체 1 + 세부 8)', len(pngs) == 9 and full_ok and det_ok, f'{len(pngs)}장 · 전체 폭 {sz.get("CRM레포트_김형준.png")} · 세부 2160×3840 {det_ok}' + ('' if r.returncode == 0 else ' · ' + r.stderr[-200:]))
except Exception as e: ok('④ CRM 예시 실행', False, repr(e)[:200])

# ⑤ render_check (③-2 산출물)
try:
    r = subprocess.run(['node', os.path.join(HERE, 'render_check.js'), os.path.join(TMP, outs[1]), os.path.join(TMP, 'rc')], capture_output=True, text=True, timeout=600)
    lines = [l for l in r.stdout.splitlines() if l.startswith('W=')]
    ok('⑤ render_check PC 1080 + 모바일 420', len(lines) == 2 and all('jsErrors=0' in l for l in lines), ' / '.join(lines) or r.stderr[-200:])
except Exception as e: ok('⑤ render_check', False, repr(e)[:200])

shutil.rmtree(TMP, ignore_errors=True)
n_fail = sum(1 for _, c, _ in R if not c)
print('\n' + '=' * 60 + f'\nselftest 결과: {len(R) - n_fail}/{len(R)} OK' + (f' — FAIL {n_fail}건 → 작업 전 mr.와이 보고' if n_fail else ' — 전 항목 정상, 작업 진행 가능'))
sys.exit(1 if n_fail else 0)
