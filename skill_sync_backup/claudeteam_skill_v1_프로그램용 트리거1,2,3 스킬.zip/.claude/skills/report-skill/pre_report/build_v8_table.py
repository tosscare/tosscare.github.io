"""
build_v8_table.py — v8 png표레포트 산출 (양주미 본인 + 가족1)

양식 (직전 합의 본문 본질):
- 헤더: 본인 = "양주미님의 보장분석" / 가족 = "이*호님의 보장분석 - 양주미님의 가족"
- 가입보험 표 5개열 강제 (보험 ≤5 시 빈칸) / 13행
- 매트릭스 11 카테고리 (사망보장 3종·후유장해 4종·주택화재보험 4종·치아보장 3종)
- 큰 박스 4영역 (암·뇌·심·수술 색깔채움) + 진단비 선 박스
- 결론 영역 (보장항목 기준 진단결과) + 노란 자동산출 박스 + ⚠ 중요 + ▶ 보강방향
- 어드바이저 안내 (본인 6번까지·가족 4·5·6 삭제)
- 가로폭: 본인 보험 개수×165px·가족 동일

v8 PNG 색상 (5종 평균 라벨):
- 과잉: 핑크 #DB2777
- 적정: 녹색 #15803D
- 보통: 검정 #191F28
- 빈약: 오렌지 #F97316
- 부재: 빨간 #F04452
"""

from pathlib import Path
import sys, shutil
sys.path.insert(0, str(Path(__file__).parent))
from playwright.sync_api import sync_playwright

# ===== v8 본문 통일 매핑 (5종 평균 라벨) =====
LABEL_COLOR = {
    "과잉": "#DB2777",   # 핑크
    "적정": "#15803D",   # 녹색
    "보통": "#191F28",   # 검정
    "빈약": "#F97316",   # 오렌지
    "부재": "#F04452",   # 빨간
}

LABEL_HEADLINE = {
    "과잉": "핵심 의료보장이 지나치게 과잉상태입니다.",
    "적정": "핵심 의료보장이 완성된 상태입니다.",
    "보통": "핵심 의료보장이 완성되지 않았습니다.",
    "빈약": "핵심 의료보장이 빈약한 상태입니다.",
    "부재": "핵심 의료보장이 전무한 상태입니다.",
}

LABEL_DETAIL = {
    "과잉": "필요 이상 과다 가입으로 보험료 낭비 위험",
    "적정": "권장 수준에 부합하는 적정 보장",
    "보통": "보통 수준으로 추가 보강 검토 권장",
    "빈약": "기본보장에 미달하여 보강 필요",
    "부재": "보장 미보유로 즉시 보강 필요",
}

# 매트릭스 11 카테고리 (v8 — 단일 출처)
MATRIX_CATS = [
    ("실비", ["질병입원의료비", "질병외래의료비", "상해입원의료비", "상해외래의료비"]),
    ("3대진단", ["일반암진단", "통합암진단", "뇌혈관질환진단", "허혈성심장진단", "부정맥진단",
                 "암주요치료비", "암특정치료비", "고액항암(표적항암)",
                 "2대질병주요치료비", "특정순환계주요치료비"]),
    ("수술비", ["질병수술", "상해수술", "암수술"]),
    ("입원일당", ["질병입원", "상해입원"]),
    ("사망보장", ["일반사망", "질병사망", "상해사망"]),
    ("후유장해", ["질병50%이상후유장해", "상해50%이상후유장해", "질병3%이상후유장해", "상해3%이상후유장해"]),
    ("골절화상", ["골절진단", "화상진단"]),
    ("생활배상책임", ["일상생활배상책임"]),
    ("운전자", ["교통사고처리지원금", "벌금(대물)", "벌금(대인)", "변호사선임비용", "자동차부상치료비"]),
    ("주택화재보험", ["화재벌금", "화재폭발배상책임", "붕괴·침강", "누수(급배수)"]),
    ("치아보장", ["충치치료", "크라운치료", "임플란트"]),
]


def truncate(s, n):
    return s[:n] if s and len(s) > n else (s or "")


def build_html(title, subtitle, insurances, matrix_data, avg_label, completion_pct,
               renewal_count, has_renewal, conclusion_lines, advisor_notes, family_label_text=""):
    """png표레포트 HTML 생성

    Args:
        title: "양주미님의 보장분석" 또는 "이*호님의 보장분석 - 양주미님의 가족"
        insurances: list of dict { 보험사, 보험명, 갱신, 계약자_피보험자, 납입주기_기간,
                                    보장만기_연령, 월납, 기납, 잔여, 총, 납입중 (bool) }
        matrix_data: { 소분류: [bool×N건] } 또는 { 소분류: [금액×N건] }
        avg_label: 5종 평균 라벨
        completion_pct: 보장 완성도 % (0/20/40/60/80/100)
        conclusion_lines: ["실손 - 멘트", "암 - 멘트", "뇌 - 멘트", "심장 - 멘트", "수술 - 멘트"]
        advisor_notes: 본인=6 / 가족=3 (또는 4)
    """
    color = LABEL_COLOR[avg_label]
    headline = LABEL_HEADLINE[avg_label]

    # 5개열 강제 — 보험 부족 시 빈칸 채우기
    n_real = len(insurances)
    n_cols = max(5, n_real)
    insurances_padded = list(insurances) + [None] * (n_cols - n_real)

    page_w = 540 + n_cols * 165  # left 540 + 보험열 165px
    page_h = 1900  # 세로 고정 (대략)

    # 가입보험 표 13행 헤더
    table_rows = [
        ("보험사", "보험사"),
        ("보험명", "보험명"),
        ("갱신유무", "갱신유무"),
        ("계약자", "계약자"),
        ("피보험자", "피보험자"),
        ("납입주기", "납입주기"),
        ("납입기간", "납입기간"),
        ("보장만기", "보장만기"),
        ("만기연령", "만기연령"),
        ("월납보험료", "월납보험료"),
        ("기납입보험료", "기납입보험료"),
        ("잔여보험료", "잔여보험료"),
        ("총보험료", "총보험료"),
    ]

    # 가입보험 표 HTML
    ins_thead = "<tr><th class='lbl'></th>"
    for i, ins in enumerate(insurances_padded):
        if ins is None:
            ins_thead += "<th class='ins-col empty'></th>"
        else:
            ins_thead += f"<th class='ins-col'>보험{i+1}</th>"
    ins_thead += "</tr>"

    ins_body_rows = []
    for label, key in table_rows:
        cells = f"<th class='lbl'>{label}</th>"
        for ins in insurances_padded:
            if ins is None:
                cells += "<td class='ins-cell empty'></td>"
            else:
                val = ins.get(key, "—")
                if key == "보험사":
                    val = truncate(val, 7)
                if key == "갱신유무":
                    if ins.get("갱신") in ("갱신형 특약", "갱신형 보험"):
                        val = "<span class='renewal-tag'>갱신형</span>"
                    else:
                        val = ""
                if key == "월납보험료":
                    if ins.get("납입중"):
                        val = f"<span class='paid-active'>{val}</span>"
                    else:
                        val = f"<span class='paid-end'>{val}</span>"
                cls = "ins-cell"
                if key == "보험명":
                    cls += " name-cell"
                cells += f"<td class='{cls}'>{val}</td>"
        ins_body_rows.append(f"<tr>{cells}</tr>")
    ins_body_rows_html = "\n".join(ins_body_rows)

    # 매트릭스 HTML
    matrix_rows = []
    for cat_name, sub_list in MATRIX_CATS:
        # 카테고리 색상 분류
        cat_class = "cat-default"
        if cat_name == "3대진단":
            cat_class = "cat-cancer"   # 암(노랑)·뇌(파랑)·심장(빨간) 통합
        elif cat_name == "수술비":
            cat_class = "cat-surg"
        elif cat_name == "사망보장":
            cat_class = "cat-grey"
        elif cat_name == "후유장해":
            cat_class = "cat-grey"
        elif cat_name == "입원일당":
            cat_class = "cat-grey"
        elif cat_name == "골절화상":
            cat_class = "cat-grey"
        elif cat_name == "생활배상책임":
            cat_class = "cat-grey"
        elif cat_name == "운전자":
            cat_class = "cat-driver"
        elif cat_name == "주택화재보험":
            cat_class = "cat-fire"
        elif cat_name == "치아보장":
            cat_class = "cat-tooth"

        # 카테고리 헤더 row (rowspan = 소분류 개수)
        rowspan = len(sub_list)
        for sub_idx, sub in enumerate(sub_list):
            cells = ""
            if sub_idx == 0:
                cells += f"<td class='cat-col {cat_class}' rowspan='{rowspan}'>{cat_name}</td>"
            cells += f"<td class='sub-col'>{sub}</td>"

            # 소분류별 보험 노출
            sub_data = matrix_data.get(sub, [None] * n_cols)
            total = 0
            for i in range(n_cols):
                if i < len(sub_data) and sub_data[i] is not None:
                    val = sub_data[i]
                    if isinstance(val, (int, float)) and val > 0:
                        cells += f"<td class='val'>{val:,}</td>"
                        total += val
                    else:
                        cells += "<td class='val empty'>—</td>"
                else:
                    cells += "<td class='val empty'></td>"
            cells += f"<td class='total-col'>{total:,}</td>" if total > 0 else "<td class='total-col empty'>—</td>"

            matrix_rows.append(f"<tr>{cells}</tr>")
    matrix_rows_html = "\n".join(matrix_rows)

    # 결론 영역 — 노란박스 + ⚠ + ▶
    yellow_lines = [headline]
    if has_renewal:
        yellow_lines.append("❌ 보험료가 계속 인상되는 갱신형보험이 구성되어 있어, 보험료가 낭비되고 있습니다.")
    yellow_lines.append(f"{title.split('님')[0]}님 보험의 보장은 {avg_label}{family_label_text}하여 보강이 필요합니다.")
    yellow_html = "<br>".join(yellow_lines)

    conclusion_html = "".join(f"<li>{ln}</li>" for ln in conclusion_lines)

    # 어드바이저 안내
    advisor_html = "".join(f"<li>{n}</li>" for n in advisor_notes)

    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: 'Pretendard', 'Apple SD Gothic Neo', sans-serif;
       background: #fff; color: #191F28; padding: 24px; width: {page_w}px; }}
.header {{ font-size: 28px; font-weight: 800; padding-bottom: 8px;
          border-bottom: 3px solid #191F28; margin-bottom: 16px; }}
.subtitle {{ font-size: 13px; color: #555; margin-bottom: 24px; }}
.section-title {{ font-size: 17px; font-weight: 700; margin: 20px 0 8px;
                 padding-left: 8px; border-left: 4px solid {color}; }}
.section-title small {{ font-size: 12px; font-weight: 400; color: #777; margin-left: 8px; }}
table {{ border-collapse: collapse; width: 100%; font-size: 11px; }}
th, td {{ border: 1px solid #ddd; padding: 4px 6px; text-align: center; vertical-align: middle; }}
th.lbl {{ background: #F4F6F9; font-weight: 700; width: 100px; text-align: center; white-space: pre-line; }}
.ins-col {{ width: 165px; background: #F4F6F9; font-weight: 700; }}
.ins-cell {{ width: 165px; height: 36px; }}
.ins-cell.empty {{ background: #FAFBFC; }}
.name-cell {{ font-size: 10px; line-height: 1.3;
              display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
              max-height: 39px; }}
.renewal-tag {{ background: #F04452; color: #fff; padding: 2px 6px; border-radius: 3px;
                font-size: 10px; font-weight: 700; }}
.paid-active {{ color: #2563EB; font-weight: 700; }}
.paid-end {{ color: #191F28; }}
.cat-col {{ width: 100px; font-weight: 800; font-size: 12px; vertical-align: middle; }}
.sub-col {{ width: 200px; background: #FAFBFC; text-align: left; padding-left: 8px; font-size: 10px; }}
.val {{ width: 165px; height: 28px; }}
.val.empty {{ color: #BBB; }}
.total-col {{ width: 130px; background: #FFF8E1; font-weight: 700; }}
.total-col.empty {{ background: #FAFBFC; color: #BBB; }}
.cat-cancer {{ background: #FFE4D6; }}     /* 암 노랑계 */
.cat-surg {{ background: #FCE4EC; }}        /* 수술 핑크 */
.cat-grey {{ background: #ECEEF0; }}        /* 입원·사망·후유·골절·생활배상 */
.cat-driver {{ background: #DDEBFB; }}      /* 운전자 파랑 */
.cat-fire {{ background: #FFE4D6; }}        /* 화재 주황 */
.cat-tooth {{ background: #E0F2F1; }}       /* 치아 청록 */
.warning-box {{ background: #FFF; border: 2px solid {color}; padding: 12px;
                 margin: 16px 0; font-size: 13px; }}
.warning-box .warn-msg {{ color: #F04452; font-weight: 700; }}
.yellow-box {{ background: #FFF8E1; border: 2px solid #FFC107; padding: 14px;
               margin: 16px 0; font-size: 14px; line-height: 1.7; font-weight: 600; }}
.conclusion {{ background: #F4F6F9; padding: 16px; margin: 16px 0; }}
.conclusion h3 {{ font-size: 15px; margin-bottom: 8px; color: #191F28; }}
.conclusion ul {{ list-style: none; padding-left: 0; }}
.conclusion li {{ padding: 4px 0; font-size: 13px; }}
.advisor {{ background: #fff; border: 1px solid #ddd; padding: 16px; margin-top: 24px; }}
.advisor h3 {{ font-size: 14px; margin-bottom: 8px; color: #2563EB; }}
.advisor ol {{ padding-left: 20px; font-size: 12px; line-height: 1.7; }}
.completion {{ display: inline-block; padding: 2px 8px; background: {color};
               color: #fff; font-weight: 700; font-size: 12px; border-radius: 4px; margin-left: 8px; }}
</style></head>
<body>

<div class="header">{title}</div>
<div class="subtitle">{subtitle}</div>

<div class="section-title">가입보험 현황 <small>(보장순 5개열 강제표시)</small></div>
<table>
<thead>{ins_thead}</thead>
<tbody>{ins_body_rows_html}</tbody>
</table>

<div class="section-title">보장 매트릭스 (11 카테고리) <span class="completion">완성도 {completion_pct}%</span></div>
<table>
<thead><tr><th class='lbl'>대분류</th><th class='lbl'>소분류</th>
{"".join(f"<th class='ins-col'>보험{i+1}</th>" for i in range(n_cols))}
<th class='lbl'>합계</th></tr></thead>
<tbody>{matrix_rows_html}</tbody>
</table>

<div class="yellow-box">{yellow_html}</div>

<div class="conclusion">
<h3>▶ 보장항목 기준 진단결과</h3>
<ul>{conclusion_html}</ul>
</div>

<div class="warning-box">
<span class="warn-msg">⚠ 중요</span> 보장의 부족한 부분은 시간이 지날수록 보강 비용이 커집니다.
지체 없는 검토를 권장드립니다.
</div>

<div class="advisor">
<h3>토스 보험분석 어드바이저 안내</h3>
<ol>{advisor_html}</ol>
</div>

</body></html>"""


def html_to_png(html, png_path, work_dir, width):
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)
    html_path = work_path / "table.html"
    html_path.write_text(html, encoding="utf-8")
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": width, "height": 2200}, device_scale_factor=2)
        page.goto(f"file://{html_path.absolute()}")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(png_path), full_page=True, type="png")
        browser.close()


# ===== 양주미 본인 데이터 =====

YANGJUMI_INSURANCES = [
    # 본인 보험 9건 (피보험자 양주미) — 매트릭스 #1·#2·#3·#4·#5·#6·#7·#9·#10
    {"보험사": "메리츠화재", "보험명": "(무)메리츠 The좋은 알뜰한보장보험2404",
     "갱신": "비갱신형", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "20년납", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "55,070원", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
    {"보험사": "한화생명", "보험명": "한화 시그니처 여성 건강보험2.0 무배당 2404",
     "갱신": "갱신형 특약", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "30년납", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "82,005원", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
    {"보험사": "KB손해보험", "보험명": "KB 닥터실속 건강보험Ⅱ(무배당)(24.05)",
     "갱신": "갱신형 특약", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "20년납", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "118,460원", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
    {"보험사": "교보생명", "보험명": "통합올인원CI보험(無)빈틈없이든든하게_프라임",
     "갱신": "갱신형 특약", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "20년납", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "94,510원", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
    {"보험사": "교보생명", "보험명": "(무)Standby유니버셜저축보험",
     "갱신": "비갱신형", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "—", "보장만기": "—", "만기연령": "—",
     "월납보험료": "납입종료", "기납입보험료": "추가확인필요", "잔여보험료": "—",
     "총보험료": "—", "납입중": False},
    {"보험사": "한화손해보험", "보험명": "(무)참좋은건강보험",
     "갱신": "비갱신형", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "—", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "납입종료", "기납입보험료": "추가확인필요", "잔여보험료": "0",
     "총보험료": "추가확인필요", "납입중": False},
    {"보험사": "한화손해보험", "보험명": "무배당참좋은암보험",
     "갱신": "비갱신형", "계약자": "양주미", "피보험자": "본인",
     "납입주기": "월납", "납입기간": "—", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "납입종료", "기납입보험료": "추가확인필요", "잔여보험료": "0",
     "총보험료": "추가확인필요", "납입중": False},
    {"보험사": "교보생명", "보험명": "홈닥터플러스보험(가족만기환급)",
     "갱신": "비갱신형", "계약자": "이*호", "피보험자": "양주미",
     "납입주기": "월납", "납입기간": "추가확인필요", "보장만기": "추가확인필요", "만기연령": "추가확인필요",
     "월납보험료": "추가확인필요", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
    {"보험사": "교보생명", "보험명": "(무)그랑프리",
     "갱신": "비갱신형", "계약자": "이*호", "피보험자": "양주미",
     "납입주기": "월납", "납입기간": "추가확인필요", "보장만기": "추가확인필요", "만기연령": "추가확인필요",
     "월납보험료": "추가확인필요", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
]

# 양주미 본인 매트릭스 데이터 (만원 단위)
YANGJUMI_MATRIX = {
    # 실비 (CI = idx 3)
    "질병입원의료비": [None, None, None, 5000, None, None, None, None, None],
    "질병외래의료비": [None, None, None, 30, None, None, None, None, None],
    "상해입원의료비": [None, None, None, 5000, None, None, None, None, None],
    "상해외래의료비": [None, None, None, 30, None, None, None, None, None],
    # 3대진단
    "일반암진단": [5000, None, None, None, None, None, 2000, None, None],
    "통합암진단": [None, None, None, None, None, None, None, None, None],
    "뇌혈관질환진단": [None, 2000, None, None, None, None, None, None, None],
    "허혈성심장진단": [None, 1000, None, None, None, None, None, None, None],
    "부정맥진단": [None, None, None, None, None, None, None, None, None],
    "암주요치료비": [None, None, None, None, None, None, None, None, None],
    "암특정치료비": [None, None, None, None, None, None, None, None, None],
    "고액항암(표적항암)": [None, None, 7000, None, None, None, None, None, None],
    "2대질병주요치료비": [None, None, None, None, None, None, None, None, None],
    "특정순환계주요치료비": [None, None, None, None, None, None, None, None, None],
    # 수술비 (KB 일반+5종, 참좋은건강 일반)
    "질병수술": [None, None, 530, None, None, None, None, None, None],
    "상해수술": [None, None, 600, None, None, 10, None, None, None],
    "암수술": [None, None, None, None, None, None, None, None, None],
    # 입원일당
    "질병입원": [None, None, None, None, None, None, None, None, None],
    "상해입원": [None, None, None, None, None, None, None, None, None],
    # 사망보장 (메리츠 일반상해사망)
    "일반사망": [None, None, None, None, None, None, None, None, None],
    "질병사망": [None, None, None, None, None, None, None, None, None],
    "상해사망": [None, None, None, None, None, None, None, None, None],
    # 후유장해 (50%·3% 명시 ❌, 80% 단독 표기는 row 적용 ❌)
    "질병50%이상후유장해": [None]*9,
    "상해50%이상후유장해": [None]*9,
    "질병3%이상후유장해": [None]*9,
    "상해3%이상후유장해": [None]*9,
    # 골절화상
    "골절진단": [None]*9,
    "화상진단": [None]*9,
    # 생활배상책임
    "일상생활배상책임": [None]*9,
    # 운전자
    "교통사고처리지원금": [None]*9, "벌금(대물)": [None]*9, "벌금(대인)": [None]*9,
    "변호사선임비용": [None]*9, "자동차부상치료비": [None]*9,
    # 주택화재보험
    "화재벌금": [None]*9, "화재폭발배상책임": [None]*9, "붕괴·침강": [None]*9, "누수(급배수)": [None]*9,
    # 치아보장
    "충치치료": [None]*9, "크라운치료": [None]*9, "임플란트": [None]*9,
}


# ===== 가족1 (이*호) 데이터 =====
LEEHO_INSURANCES = [
    {"보험사": "동양생명", "보험명": "(무) 사랑&굿프라이스통합보험",
     "갱신": "갱신형 특약", "계약자": "이*호", "피보험자": "이*호",
     "납입주기": "월납", "납입기간": "20년납", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "120,359원", "기납입보험료": "추가확인필요", "잔여보험료": "추가확인필요",
     "총보험료": "추가확인필요", "납입중": True},
    {"보험사": "한화손해보험", "보험명": "(무)참좋은건강보험",
     "갱신": "비갱신형", "계약자": "양주미", "피보험자": "이*호",
     "납입주기": "월납", "납입기간": "—", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "납입종료", "기납입보험료": "추가확인필요", "잔여보험료": "0",
     "총보험료": "추가확인필요", "납입중": False},
    {"보험사": "한화손해보험", "보험명": "무배당참좋은암보험",
     "갱신": "비갱신형", "계약자": "양주미", "피보험자": "이*호",
     "납입주기": "월납", "납입기간": "—", "보장만기": "100세", "만기연령": "100세",
     "월납보험료": "납입종료", "기납입보험료": "추가확인필요", "잔여보험료": "0",
     "총보험료": "추가확인필요", "납입중": False},
]

LEEHO_MATRIX = {
    "질병입원의료비": [5000, None, None],
    "질병외래의료비": [30, None, None],
    "상해입원의료비": [5000, None, None],
    "상해외래의료비": [30, None, None],
    "일반암진단": [1000, None, None],
    "통합암진단": [None]*3, "뇌혈관질환진단": [None]*3, "허혈성심장진단": [None]*3, "부정맥진단": [None]*3,
    "암주요치료비": [None]*3, "암특정치료비": [None]*3, "고액항암(표적항암)": [None]*3,
    "2대질병주요치료비": [None]*3, "특정순환계주요치료비": [None]*3,
    "질병수술": [None]*3, "상해수술": [None]*3, "암수술": [None]*3,
    "질병입원": [None]*3, "상해입원": [None]*3,
    "일반사망": [None]*3, "질병사망": [None]*3, "상해사망": [None]*3,
    "질병50%이상후유장해": [None]*3, "상해50%이상후유장해": [None]*3,
    "질병3%이상후유장해": [None]*3, "상해3%이상후유장해": [None]*3,
    "골절진단": [None]*3, "화상진단": [None]*3, "일상생활배상책임": [None]*3,
    "교통사고처리지원금": [None]*3, "벌금(대물)": [None]*3, "벌금(대인)": [None]*3,
    "변호사선임비용": [None]*3, "자동차부상치료비": [None]*3,
    "화재벌금": [None]*3, "화재폭발배상책임": [None]*3, "붕괴·침강": [None]*3, "누수(급배수)": [None]*3,
    "충치치료": [None]*3, "크라운치료": [None]*3, "임플란트": [None]*3,
}


# ===== 결론 라인 =====
def make_conclusion_lines(labels):
    return [
        f"실손의료비 - {LABEL_DETAIL[labels['실손']]} ({labels['실손']})",
        f"3대질병 - 암: {LABEL_DETAIL[labels['암']]} ({labels['암']}) / 뇌: {LABEL_DETAIL[labels['뇌']]} ({labels['뇌']}) / 심장: {LABEL_DETAIL[labels['심장']]} ({labels['심장']})",
        f"수술보장 - {LABEL_DETAIL[labels['수술']]} ({labels['수술']})",
    ]


# ===== 양주미 산출 =====
YANGJUMI_LABELS = {"실손": "적정", "암": "보통", "뇌": "빈약", "심장": "빈약", "수술": "적정"}
YANGJUMI_AVG = "보통"
YANGJUMI_PCT = 40

YANGJUMI_ADVISOR = [
    "본 레포트는 필수보장의 구성이 올바르게 되어 있는지 확인하시도록 작성되어 있습니다.",
    "기존보험 중 보유되어 있는 보장항목이라고 하더라도 실질적인 효율이 없는 보장항목은 제외되어 있을 수 있으며, 제외된 보장항목이 많을수록 내 보험료의 낭비가 큰 요인이 많은 상태로 보셔야 합니다.",
    "보험료의 낭비 요인이 클수록 지체없이 보험의 올바른 보완에 대한 추가검토를 하셔야 합니다. 시간이 지날수록 보험료 낭비금액이 커지게 됩니다.",
    "레포트를 받으시고 1~3일 후, 토스 보험분석 어드바이저가 추가안내를 드릴 예정입니다.",
    "본 레포트를 받으시고 궁금하시거나 추가로 요청하실 부분이 있으신 경우 미리 메시지로 남겨주세요. 추가안내시 말씀주신 내용을 반영하여 안내드리도록 하겠습니다.",
    "추가로 가족분(이*호님)의 보험이 조회되었으며, 가족분 보험은 추가안내시 다시 안내드리겠습니다.",
]

OUT = Path(__file__).parent / "output"
OUT.mkdir(exist_ok=True)

html_yj = build_html(
    title="양주미님의 보장분석",
    subtitle="여성 · 보험나이 58세 · 거주지 추가확인필요 · 1968-02-06",
    insurances=YANGJUMI_INSURANCES,
    matrix_data=YANGJUMI_MATRIX,
    avg_label=YANGJUMI_AVG,
    completion_pct=YANGJUMI_PCT,
    renewal_count=3,
    has_renewal=True,
    conclusion_lines=make_conclusion_lines(YANGJUMI_LABELS),
    advisor_notes=YANGJUMI_ADVISOR,
    family_label_text=" 수준이며, 뇌·심장 보장이 빈약",
)
(OUT / "양주미_본인_표레포트.html").write_text(html_yj, encoding="utf-8")
n_cols_yj = max(5, len(YANGJUMI_INSURANCES))
html_to_png(html_yj, str(OUT / "양주미_본인_표레포트.png"), str(OUT / "_work_yj_table"),
            width=540 + n_cols_yj * 165 + 60)


# ===== 가족1 산출 =====
LEEHO_LABELS = {"실손": "적정", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"}
LEEHO_AVG = "빈약"
LEEHO_PCT = 20

LEEHO_ADVISOR = [
    "본 레포트는 필수보장의 구성이 올바르게 되어 있는지 확인하시도록 작성되어 있습니다.",
    "기존보험 중 보유되어 있는 보장항목이라고 하더라도 실질적인 효율이 없는 보장항목은 제외되어 있을 수 있으며, 제외된 보장항목이 많을수록 내 보험료의 낭비가 큰 요인이 많은 상태로 보셔야 합니다.",
    "보험료의 낭비 요인이 클수록 지체없이 보험의 올바른 보완에 대한 추가검토를 하셔야 합니다. 시간이 지날수록 보험료 낭비금액이 커지게 됩니다.",
]

html_lh = build_html(
    title="이*호님의 보장분석 - 양주미님의 가족",
    subtitle="성별/나이 추가확인필요 · 거주지 추가확인필요",
    insurances=LEEHO_INSURANCES,
    matrix_data=LEEHO_MATRIX,
    avg_label=LEEHO_AVG,
    completion_pct=LEEHO_PCT,
    renewal_count=1,
    has_renewal=True,
    conclusion_lines=make_conclusion_lines(LEEHO_LABELS),
    advisor_notes=LEEHO_ADVISOR,
    family_label_text=" 수준이며, 암·뇌·심장·수술 보장 모두 부재",
)
(OUT / "가족1_이호_표레포트.html").write_text(html_lh, encoding="utf-8")
n_cols_lh = max(5, len(LEEHO_INSURANCES))
html_to_png(html_lh, str(OUT / "가족1_이호_표레포트.png"), str(OUT / "_work_lh_table"),
            width=540 + n_cols_lh * 165 + 60)

print("표레포트 산출 완료")
print(f"본인: 보험 {len(YANGJUMI_INSURANCES)}건 / 5종 평균 {YANGJUMI_AVG} / 완성도 {YANGJUMI_PCT}%")
print(f"가족1: 보험 {len(LEEHO_INSURANCES)}건 / 5종 평균 {LEEHO_AVG} / 완성도 {LEEHO_PCT}%")
