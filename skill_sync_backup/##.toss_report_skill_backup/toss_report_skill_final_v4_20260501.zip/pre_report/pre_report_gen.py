"""
pre_report_gen.py — 사전상담 자료 생성 스크립트

역할:
1. 고객 데이터 입력받아 → 변수 치환된 HTML 생성
2. HTML → PNG 변환 (Playwright)
3. message.txt 생성
4. 다수 고객 → zip 패키징 (고객별 폴더)

사용법:
  from pre_report_gen import generate_reports
  
  customers = [
      {
          "이름": "유태수",
          "성별": "남",
          "보험나이": 45,
          "거주": "경기도 고양시",
          "labels": {
              "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
          },
          "current_values": {
              "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
              "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
          },
          "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
          "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
          "헤드라인_main": "핵심 의료보장이 <span class=\"accent\">전부 부재한 상태</span>입니다.",
          "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
      }
  ]
  generate_reports(customers, output_zip="report_20260427.zip")
"""

import os
import re
import zipfile
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright


# ===== 라벨 매핑 =====

HEADLINE_BY_LEVEL = {
    "부재": "핵심 의료보장이 <span class=\"accent\">전부 부재한 상태</span>입니다.",
    "사실상 부재": "핵심 의료보장이 <span class=\"accent\">사실상 부재한 상태</span>입니다.",
    "매우 취약": "핵심 의료보장이 <span class=\"accent\">매우 취약한 상태</span>입니다.",
    "빈약": "핵심 의료보장이 <span class=\"accent\">빈약한 상태</span>입니다.",
    "보통": "핵심 의료보장이 보통 수준입니다.",
    "적정": "핵심 의료보장이 적정 수준입니다.",
    "과잉": "핵심 의료보장이 과잉 수준입니다.",
}

# 갱신형 감지 룰 (rules.json renewal_handling 박제)
RENEWAL_KEYWORD = "갱신"
# 메시지 ① 변수 본문 (트리거 3 룰 변경 — 2026-05-01)
RENEWAL_MESSAGE_LINE_1 = "❌ 보험료가 계속 인상되는 갱신형보험이 구성되어 보험료가 낭비를 넘어 크게 새고 있습니다."
# 메시지 ② 변수 본문 (3번째 탭 라벨 = "과잉"·"적정"일 때)
PREMIUM_OVERAGE_LINE = "❌ 기납입보험료 외에도 {amount:,}원이나 되는 보험료를 낭비하게 됩니다."
# 메시지 ③ 변수 본문 (3번째 탭 라벨 = "과잉"·"적정"이 아닐 때, "부재"·"—" 제외)
PREMIUM_NORMAL_LINE = "⭕ 잔여보험료가 {amount:,}원으로 일반적인 수준입니다."
# PNG 갱신형 버튼 본문 (빨간 배경 + 노란 굵은 글씨 — 2026-05-01)
RENEWAL_REPORT_HTML = (
    '<div class="renewal-warning">'
    '갱신형보험이 구성되어 보험료 누수가 발생한 상태입니다!'
    '</div>'
)


def detect_renewal(raw_customer_text):
    """고객정보 원문 텍스트에 갱신형 보험·특약이 실제로 있는지 정확 검증.

    이전 룰(`"갱신" in text`)의 결함 정정 — 본문 헤더 "갱신 유무"의
    "갱신" 단어로 비갱신형/보험 ❌ 케이스도 잘못 트리거되는 영역 차단.

    정확한 트리거 키워드:
    - "갱신형 특약" — 일부 갱신형 보험 (특약 단위 갱신)
    - "갱신형 보험" — 전체 갱신형 보험

    "비갱신형"은 명시적으로 트리거 ❌ (위 두 키워드와 별개 영역).
    """
    if not raw_customer_text:
        return False
    return ("갱신형 특약" in raw_customer_text) or ("갱신형 보험" in raw_customer_text)

LEVEL_BAR_HTML = {
    "부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "사실상 부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "매우 취약": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "빈약": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "보통": '<div class="level-seg active-warning"></div><div class="level-seg active-warning"></div><div class="level-seg"></div>',
    "적정": '<div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg active-good"></div>',
    "과잉": '<div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div>',
}

# 라벨 → CSS class용 (공백·특수문자 제거)
def label_to_class(label):
    return label.replace(" ", "").replace("·", "")


# ===== HTML 변수 치환 =====

def render_html(template_path, customer):
    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    labels = customer["labels"]
    current = customer["current_values"]
    premium = customer["월보험료"]
    level = customer["연령대비"]

    replacements = {
        "{{CUSTOMER_NAME}}": customer["이름"],
        "{{GENDER}}": customer["성별"],
        "{{AGE}}": str(customer["보험나이"]),
        "{{REGION}}": customer["거주"],

        "{{HEADLINE_MAIN}}": customer.get("헤드라인_main", HEADLINE_BY_LEVEL.get(level["label"], HEADLINE_BY_LEVEL["부재"])),
        "{{HEADLINE_SUB}}": customer.get("헤드라인_sub", ""),

        "{{LABEL_실손}}": labels["실손"],
        "{{LABEL_실손_CLASS}}": label_to_class(labels["실손"]),
        "{{LABEL_암}}": labels["암"],
        "{{LABEL_암_CLASS}}": label_to_class(labels["암"]),
        "{{LABEL_뇌}}": labels["뇌"],
        "{{LABEL_뇌_CLASS}}": label_to_class(labels["뇌"]),
        "{{LABEL_심장}}": labels["심장"],
        "{{LABEL_심장_CLASS}}": label_to_class(labels["심장"]),
        "{{LABEL_수술}}": labels["수술"],
        "{{LABEL_수술_CLASS}}": label_to_class(labels["수술"]),

        "{{CURRENT_실손}}": current["실손"],
        "{{CURRENT_암}}": current["암"],
        "{{CURRENT_뇌}}": current["뇌"],
        "{{CURRENT_심장}}": current["심장"],
        "{{CURRENT_수술}}": current["수술"],
        "{{CURRENT_상해수술}}": current["상해수술"],

        "{{TOTAL_PREMIUM}}": premium["합계"],
        "{{PREMIUM_PROTECTION}}": premium["보장"],
        "{{PREMIUM_SAVINGS}}": premium["저축"],

        "{{LABEL_LEVEL}}": level["label"],
        "{{LABEL_LEVEL_CLASS}}": label_to_class(level["label"]),
        "{{LEVEL_BAR_HTML}}": LEVEL_BAR_HTML.get(level["label"], LEVEL_BAR_HTML["부재"]),
        "{{LEVEL_PERCENT}}": str(level["percent"]),
        "{{AGE_GROUP}}": level["age_group"],
        "{{RENEWAL_WARNING_BLOCK}}": RENEWAL_REPORT_HTML if customer.get("has_renewal") else "",
    }

    for key, val in replacements.items():
        html = html.replace(key, val)

    return html


# ===== 메시지 생성 =====

def render_message(customer):
    """메시지 본문 생성.

    1번 항목 본문에 다음 분기 변수 적용 (2026-05-01 트리거 3 룰 변경):
    - ① 변수: 갱신형 1건 이상 → 무조건 노출 (제일 윗줄)
    - ② 변수: 3번째 탭 라벨 ∈ {"과잉", "적정"} → "낭비" 메시지 노출
    - ③ 변수: ②가 아닌 일반 라벨(보통·빈약 등) → "일반적 수준" 메시지 노출
    - 라벨 부재("부재"·"—") 시 ②/③ 모두 미노출
    - ②/③ 동시 노출 ❌ (택1)
    - ① 노출 시 ① 직전·② 또는 ③ 직전에 빈 줄 1행 추가
    """
    name = customer["이름"]
    labels = customer["labels"]
    level_label = customer["연령대비"]["label"]
    has_renewal = customer.get("has_renewal", False)
    # 잔여보험료합계액 (정수 — 원 단위, 갱신형 포함/제외 영역 ❌ 단순 전체 합계)
    total_remaining = customer.get("total_remaining_premium", 0)

    # 헤드라인 텍스트 (2번 항목 마무리 — 갱신형 영향 ❌)
    headline_text_map = {
        "부재": "핵심 의료보장이 전부 부재한 상태입니다.",
        "사실상 부재": "핵심 의료보장이 사실상 부재한 상태입니다.",
        "매우 취약": "핵심 의료보장이 매우 취약한 상태입니다.",
        "빈약": "핵심 의료보장이 빈약한 상태입니다.",
        "보통": "핵심 의료보장이 보통 수준입니다.",
        "적정": "핵심 의료보장이 적정 수준입니다.",
        "과잉": "핵심 의료보장이 과잉 수준입니다.",
    }
    headline_close = headline_text_map.get(level_label, headline_text_map["부재"])

    # 1번 항목 분기 변수 조립
    sub_lines = []
    # ① 갱신형 — has_renewal 시 무조건 노출 (제일 윗줄)
    if has_renewal:
        sub_lines.append(RENEWAL_MESSAGE_LINE_1)
    # ②/③ 라벨 분기 — "부재"·"—" 시 미노출
    if level_label in ("과잉", "적정"):
        sub_lines.append(PREMIUM_OVERAGE_LINE.format(amount=total_remaining))
    elif level_label not in ("부재", "—"):
        sub_lines.append(PREMIUM_NORMAL_LINE.format(amount=total_remaining))
    # else: 라벨 부재 → ②/③ 둘 다 미노출

    # 빈 줄 1행 추가 룰 — 각 sub_line 위에 빈 줄 삽입
    line_1_parts = [f"1. {name}님의 보험은,"]
    for sl in sub_lines:
        line_1_parts.append("")  # 빈 줄 1행
        line_1_parts.append(sl)
    line_1 = "\n".join(line_1_parts)

    msg = f"""{name}님 안녕하세요.
토스 보험분석 어드바이저입니다.

토스앱으로 보험 점검 신청을 주셔서 토스 본사 소속 상담사가 연락드렸습니다.

{line_1}

2. 필수보장을 기준으로,
- 실손의료비 : {labels["실손"]}
- 암보장 : {labels["암"]}
- 뇌혈관보장 : {labels["뇌"]}
- 심장보장 : {labels["심장"]}
- 수술보장 : {labels["수술"]}
으로 {headline_close}

3. 보험은 치료/사고 후에는 효율적으로 가입하기 어렵습니다.
올바르게 준비되어 있는지 꼭 점검해 보시기를 바랍니다.

❗궁금하신점은 [보험검토요청] 등으로 남겨주세요.
❗본사 상담사가 순차적으로 안내드릴 예정입니다.

✅ 본사 상담사 재직정보 확인 > https://service.tossinsu.com/insulink/vO03jJGuLG
"""
    return msg


# ===== HTML → PNG 변환 =====

def html_to_png(html_content, png_path, work_dir):
    """work_dir에 임시 HTML + 로고 복사 → PNG 변환"""
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)

    # 로고 복사
    logo_src = Path(__file__).parent / "toss_logo.png"
    logo_dst = work_path / "toss_logo.png"
    if not logo_dst.exists():
        shutil.copy(logo_src, logo_dst)

    # HTML 임시 저장
    html_path = work_path / "temp_report.html"
    html_path.write_text(html_content, encoding="utf-8")

    # PNG 변환
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 720, "height": 1280}, device_scale_factor=2)
        page.goto(f"file://{html_path.absolute()}")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(png_path), full_page=True, type="png")
        browser.close()


# ===== 가족 피보험자 헬퍼 =====

def build_family_member(premium_str, has_renewal=False):
    """가족 피보험자 PNG 데이터 생성 — 모든 식별정보 '—' 표기, 5종 모두 부재.

    피보험자가 본인이 아닌 가족인 경우 그 가족 기준 PNG를 생성하기 위한 데이터.
    CRM 데이터에는 가족 피보험자의 생년월일·성별 정보 없음 → 모두 '—'로 처리.
    헤드라인 sub에 '세부정보 확인필요' 명시.

    Args:
        premium_str: 가족 피보험자 보험의 월보험료 합계 표시 문자열 (예: '513,314원')
        has_renewal: 가족 피보험자 보험 중 갱신형 포함 여부

    Returns:
        family_member dict — customer dict와 동일 구조
    """
    return {
        "이름": "—",
        "성별": "—",
        "보험나이": "—",
        "거주": "—",
        "labels": {"실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"},
        "current_values": {
            "실손": "없음 (0원)",
            "암": "없음 (0원)",
            "뇌": "없음 (0원)",
            "심장": "없음 (0원)",
            "수술": "없음 (0원)",
            "상해수술": "0원"
        },
        "월보험료": {"보장": premium_str, "저축": "0원", "합계": premium_str},
        "연령대비": {"label": "—", "percent": "—", "age_group": "—"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": (
            "<span class=\"yellow\">세부정보 확인필요</span> — 가족 피보험자별 "
            "<span class=\"yellow\">생년월일·성별·보장 상세 데이터</span>는<br>"
            "<span class=\"red\">별도 조회가 필요</span>합니다."
        ),
        "has_renewal": has_renewal,
    }


# ===== 메인 함수 =====

def generate_reports(customers, output_zip, template_path=None, work_root="/tmp/pre_report_work"):
    """
    v2 폴더 평탄화 + NN.고객명 파일명 (2026-05-01 박제 ㉑ 정합).

    customers: list of customer dicts.
        각 customer dict는 옵셔널 키 'family_members' (list of dict) 가질 수 있음.
        family_members 정렬은 호출자가 보험료 많은 순 → 건수 많은 순 → 랜덤 순으로 미리 정렬.
    output_zip: 결과 zip 파일 경로
    template_path: HTML 템플릿 경로 (기본: 같은 폴더의 pre_report_template.html)

    산출물 구조 (v2 — 폴더 평탄화):
        zip 안 모든 파일 평탄 저장 (고객별 폴더 ❌)
        본인 PNG : {NN}.{고객명}.png (NN = 입력 순서, zfill 2자리)
        본인 메시지 : {NN}.{고객명}.txt
        가족 PNG : {NN}.{고객명}{NN_가족}.png (본인과 동일 NN)
    """
    if template_path is None:
        template_path = Path(__file__).parent / "pre_report_template.html"

    work_root = Path(work_root)
    if work_root.exists():
        shutil.rmtree(work_root)
    work_root.mkdir(parents=True, exist_ok=True)

    # 각 고객별 처리 — 단일 폴더에 평탄 저장 (NN.고객명 파일명)
    for nn, customer in enumerate(customers, start=1):
        name = customer["이름"]
        nn_str = f"{nn:02d}"  # zfill 2자리

        # 본인 PNG : {NN}.{고객명}.png
        html_content = render_html(template_path, customer)
        png_path = work_root / f"{nn_str}.{name}.png"
        html_to_png(html_content, png_path, work_root)

        # 가족 피보험자 PNG : {NN}.{고객명}{NN_가족}.png (본인과 동일 NN)
        for fam_idx, family in enumerate(customer.get("family_members", []), start=1):
            family_html = render_html(template_path, family)
            family_png_path = work_root / f"{nn_str}.{name}{fam_idx:02d}.png"
            html_to_png(family_html, family_png_path, work_root)

        # 메시지 (본인 1개만 — 가족 메시지 ❌) : {NN}.{고객명}.txt
        msg = render_message(customer)
        msg_path = work_root / f"{nn_str}.{name}.txt"
        msg_path.write_text(msg, encoding="utf-8")

    # 임시 HTML·로고 정리
    for f in ["temp_report.html", "toss_logo.png"]:
        fp = work_root / f
        if fp.exists():
            fp.unlink()

    # zip 패키징 (Python zipfile — UTF-8 한글 호환, 디렉토리 엔트리 ❌, 평탄 저장)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work_root.iterdir()):
            if f.is_file():
                zf.write(f, f.name)  # arcname = 파일명만 (폴더 ❌)

    return output_zip



if __name__ == "__main__":
    # 테스트: 유태수 케이스
    test_customer = {
        "이름": "유태수",
        "성별": "남",
        "보험나이": 45,
        "거주": "경기도 고양시",
        "labels": {
            "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
        },
        "current_values": {
            "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
            "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
        },
        "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
        "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
    }

    out = generate_reports([test_customer], "/tmp/test_report.zip")
    print(f"Generated: {out}")
