#!/usr/bin/env python3
"""
PreToolUse Hook — 8 확정 원본 + SKILL.md + references + mappings 변경 차단
Edit/Write/MultiEdit 시도 시 보호 영역 감지 → exit 2 (즉시 차단)

본 Hook은 본 클로드 자체 단순화 본능 (절대 룰 2번 위반 시도) 직접 차단 본질.
"""
import json
import sys
import os

# 보호 영역 — 한 글자 변경 ❌
PROTECTED_PATHS = [
    ".claude/skills/report-skill/SKILL.md",
    ".claude/skills/report-skill/CODING_GUIDELINES.md",
    ".claude/skills/report-skill/base_template.html",
    ".claude/skills/report-skill/skin_preview_gen.py",
    ".claude/skills/report-skill/skin_preview_template.html",
    ".claude/skills/report-skill/replace_jeonansu_reference.py",
    ".claude/skills/report-skill/verify.py",
    ".claude/skills/report-skill/pre_report/build_v8_main.py",
    ".claude/skills/report-skill/pre_report/build_v8_table.py",
    ".claude/skills/report-skill/pre_report/pre_report_gen.py",
    ".claude/skills/report-skill/pre_report/pre_report_template.html",
    ".claude/skills/report-skill/pre_report/rules.json",
    ".claude/skills/report-skill/pre_report/toss_logo.png",
]

# 보호 폴더 — 하위 영역 일체 변경 ❌
PROTECTED_DIRS = [
    ".claude/skills/report-skill/references/",
    ".claude/skills/report-skill/mappings/",
]


def normalize(path):
    return path.replace("\\", "/").lstrip("./").lower()


def is_protected(path):
    norm = normalize(path)
    for protected in PROTECTED_PATHS:
        if norm.endswith(normalize(protected)):
            return True
    for protected_dir in PROTECTED_DIRS:
        if normalize(protected_dir) in norm:
            return True
    return False


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    tool_input = data.get("tool_input", {})
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("path")
        or tool_input.get("filename")
        or ""
    )
    if not file_path:
        sys.exit(0)

    if is_protected(file_path):
        msg = (
            f"BLOCKED: 보호 영역 변경 시도 — {file_path}\n"
            "절대 룰 2번 위반: 8 확정 원본·SKILL.md·references·mappings 한 글자 변경 ❌.\n"
            "exec·import·python3 직접 호출만 의무. 함수 본문 추출·재작성·\"양식만 복사\" ❌."
        )
        print(msg, file=sys.stderr)
        sys.exit(2)

    sys.exit(0)


if __name__ == "__main__":
    main()
