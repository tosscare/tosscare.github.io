# -*- coding: utf-8 -*-
"""
pdf_tools.py — 설계안 PDF 파서 + 공란 행 제거 (v23)
=====================================================

[용도]
    ① parse_meritz(pdf)  : 메리츠 가입제안서 "가입담보리스트" → [[코드, 담보명, 가입금액, 보험료, 납기/만기], ...]
    ② parse_kb(pdf)      : KB라이프 가입설계서 특약표(헤더 x좌표 기반) → [{'no','name','amt','per','prem'}, ...]
    ③ remove_blank_rows(src, dst, pages=(1,2)) : 담보표 공란 행(선만 있고 글자 없는 띠)을 제거하고 아래 내용을 당겨 재조판
    ④ redact_text(src, dst, page, old, new)    : 요약표/세부표 수치 불일치 시 세부표 숫자 교체 (글꼴·위치 유지)
    ⑤ to_coverage(rows)  : 파서 결과 → getCoverageData JSON — 카테고리 = 담보명 키워드(classify) 판정 (코드번호 ❌)

[주의]
    - pymupdf 사용. 실행: python3 -I pdf_tools.py meritz a.pdf b.pdf  → a.json b.json
    - 파서 결과는 PDF 원형 그대로(담보명 90% 이상 유지). 금액 정규화는 to_coverage의 norm_amt에서만.
    - 상품(메리츠/KB) 판독은 1페이지 텍스트의 상품명으로 자동 — 판독 불가 시 mr.와이 확인.
"""
import re, json, sys
import pymupdf

AMT = re.compile(r'^\d+(천\d?백?|백)?만원$|^\d+억원$')

def detect_insurer(pdf):
    t = pymupdf.open(pdf)[0].get_text()
    if '메리츠' in t: return 'meritz'
    if 'KB라이프' in t or 'KB 딱좋은' in t: return 'kb'
    return None

# ─────────────── ① 메리츠 가입담보리스트 (좌표 기반) ───────────────
def parse_meritz(pdf):
    """각 페이지의 헤더(가입담보/가입금액/보험료(원)/납기/만기) x좌표로 열을 나누고, 코드번호(담보명 열 왼쪽 2~3자리 숫자) 행을 y순으로 수집.
       → [[코드, 담보명(줄바꿈 공백 결합), 가입금액, 보험료('' 허용), 납기/만기(갱신종료 포함)], ...]"""
    rows = []
    for page in pymupdf.open(pdf):
        ws = page.get_text('words')
        hx = {w[4]: w for w in ws if w[4] in ('가입담보', '가입금액', '보험료(원)', '납기/만기')}
        if len(hx) < 4: continue
        XA = hx['가입금액'][0] - 8; XP = hx['보험료(원)'][0] - 8; XR = hx['납기/만기'][0] - 14; XC0 = hx['가입담보'][0] - 130
        ytop = hx['가입담보'][3] + 2
        body = [w for w in ws if w[1] > ytop]
        codes = sorted([w for w in body if XC0 <= w[0] < XC0 + 40 and re.fullmatch(r'\d{1,3}', w[4])], key=lambda w: w[1])
        for k, cw in enumerate(codes):
            y0 = cw[1] - 8; y1 = min(codes[k + 1][1] - 8 if k + 1 < len(codes) else 9999, cw[1] + 22)   # 납기/만기 2행(3년 / 3년 ↑ · 갱신종료 ↓) 포함 · 행 높이 상한 22pt(꼬리말·제도성특약 제외)
            band = [w for w in body if y0 <= w[1] < y1 and w[0] >= XC0 + 20]
            col = lambda lo, hi: [w[4] for w in sorted([w for w in band if lo <= w[0] < hi], key=lambda w: (round(w[1]), w[0]))]
            name = ' '.join(t for t in col(cw[2] + 1, XA) if t not in ('지정대리청구서비스특약', '보험료자동납입특약')); amt = ''.join(col(XA, XP)); prem = ''.join(col(XP, XR)); per = ' '.join(col(XR, 9999))
            per = re.sub(r'\s*/\s*', ' / ', per, count=1)
            if not AMT.match(amt): continue                      # 금액 열이 없는 행(제도성 특약 등) 제외
            if name.startswith('지정대리') or '자동납입' in name: continue
            rows.append([int(cw[4]), name, amt, prem, per])
    return rows

# ─────────────── ② KB라이프 특약표 ───────────────
def _hlines(p):
    ys = set()
    for dr in p.get_drawings():
        for it in dr['items']:
            if it[0] == 'l' and abs(it[1].y - it[2].y) < 0.5 and abs(it[1].x - it[2].x) > 60: ys.add(it[1].y)
            elif it[0] == 're' and it[1].width > 60 and it[1].height < 2: ys.add(it[1].y0)
    return sorted(ys)
def parse_kb(pdf):
    d = pymupdf.open(pdf); items = []
    for p in d:
        ws = p.get_text('words')
        if not any(w[4] == '특약(주계약)명' for w in ws): continue
        L = _hlines(p)
        hx = {w[4]: w for w in ws if w[4] in ('가입금액', '보험|납입기간', '보험료') and w[1] < 140}
        XA = hx['가입금액'][0] - 10; XP = hx['보험|납입기간'][0] - 6; XR = hx['보험료'][0] - 10; XR1 = hx['보험료'][2] + 6
        lines = {}
        for w in ws:
            if w[1] < 100 or w[1] > 775: continue
            lines.setdefault(round(w[1]), []).append(w)
        ys = sorted(lines); tot = [w[1] for w in ws if w[4] == '합계']; ycap = tot[0] - 1 if tot else 9999
        heads = [(y, int(sorted(lines[y], key=lambda w: w[0])[0][4][:-1])) for y in ys if (lambda Lw: Lw and Lw[0][0] < 60 and re.fullmatch(r'\d+\.', Lw[0][4]))(sorted(lines[y], key=lambda w: w[0]))]
        for k, (y0, no) in enumerate(heads):
            y1 = heads[k + 1][0] if k + 1 < len(heads) else 9999
            lo = max([l for l in L if l <= y0 + 1] or [y0])
            name_words = []
            for y in ys:
                if y >= y1: break
                if y0 <= y:
                    Lw = sorted([w for w in lines[y] if w[0] < XA], key=lambda w: w[0])
                    if not Lw: continue
                    txt = ' '.join(w[4] for w in Lw)
                    if y == y0: name_words.append(txt.split(' ', 1)[1] if ' ' in txt else '')
                    elif y - y0 < 20 and not re.match(r'(보험기간|①|②|※|\(|보장)', txt) and not name_words[-1].endswith('특약'): name_words.append(txt)
                    else: break
            name = ' '.join(name_words).strip()
            nlo = max([l for l in L if l <= y1 + 1] or [9999]) if y1 < 9999 else ycap
            rw = [w for w in ws if lo - 1 <= w[1] < nlo - 1 and w[0] >= XA and w[1] > 100]
            amt = ' '.join(w[4] for w in sorted([w for w in rw if XA <= w[0] < XP], key=lambda w: (round(w[1]), w[0])))
            per = [w[4] for w in sorted([w for w in rw if XP <= w[0] < XR], key=lambda w: (round(w[1]), w[0]))]
            prem = [w[4] for w in sorted([w for w in rw if XR <= w[0] and w[2] <= XR1 and re.fullmatch(r'[\d,]+', w[4])], key=lambda w: (round(w[1]), w[0]))]
            items.append({'no': no, 'name': name, 'amt': amt.replace(' 만 원', ' 만원'), 'per': ' '.join(per), 'prem': ''.join(prem)})
    return items

# ─────────────── ③ 공란 행 제거 ───────────────
def blank_bands(page, min_h=9, col_x=(90, 400), min_w=150):
    """담보명 열(col_x 범위에서 시작하는 가로선) 기준 행 띠 중, 그 열 오른쪽(x ≥ col_x[0])에 글자가 없는 띠 = 공란 행."""
    ys = sorted({round(y, 1) for y in _hlines_w(page, min_w, col_x)})
    words = [w for w in page.get_text('words') if w[0] >= col_x[0]]; bands = []
    for a, b in zip(ys, ys[1:]):
        if b - a < min_h or b - a > 40: continue
        if not any(a + 1 < (w[1] + w[3]) / 2 < b - 1 for w in words): bands.append((a, b))
    return bands
def _hlines_w(p, min_w, col_x=(0, 9999)):
    out = []
    for dr in p.get_drawings():
        for it in dr['items']:
            if it[0] == 'l' and abs(it[1].y - it[2].y) < 0.5:
                x0, x1 = min(it[1].x, it[2].x), max(it[1].x, it[2].x)
                if x1 - x0 > min_w and col_x[0] <= x0 <= col_x[1]: out.append(it[1].y)
            elif it[0] == 're' and it[1].width > min_w and it[1].height < 2 and col_x[0] <= it[1].x0 <= col_x[1]: out.append(it[1].y0)
    return out
def remove_blank_rows(src, dst, pages=(1, 2), min_h=9):
    """pages = 1-base 페이지 번호. 공란 띠를 잘라내고 아래 내용을 위로 당긴다(show_pdf_page clip 재조판)."""
    S = pymupdf.open(src); D = pymupdf.open()
    for pno in range(len(S)):
        sp = S[pno]; W, Hh = sp.rect.width, sp.rect.height
        bands = blank_bands(sp, min_h) if (pno + 1) in pages else []
        np_ = D.new_page(width=W, height=Hh)
        if not bands: np_.show_pdf_page(np_.rect, S, pno); continue
        cuts = [0.0]
        for a, b in bands: cuts += [a, b]
        cuts.append(Hh); y = 0.0
        for a, b in zip(cuts[0::2], cuts[1::2]):
            h = b - a
            if h <= 0: continue
            np_.show_pdf_page(pymupdf.Rect(0, y, W, y + h), S, pno, clip=pymupdf.Rect(0, a, W, b)); y += h
    D.save(dst); return [(p + 1, blank_bands(S[p], min_h)) for p in range(len(S)) if (p + 1) in pages]

# ─────────────── ④ 숫자 교체 (redact) ───────────────
def redact_text(src, dst, page, old, new, fontsize=None):
    """page(1-base)의 old 텍스트를 new로 교체. 같은 위치·크기로 재삽입."""
    d = pymupdf.open(src); p = d[page - 1]
    hits = p.search_for(old); assert hits, f'not found: {old}'
    for r in hits: p.add_redact_annot(r, fill=(1, 1, 1))
    p.apply_redactions()
    for r in hits:
        fs = fontsize or (r.height * 0.78)
        p.insert_text((r.x1 - pymupdf.get_text_length(new, fontname='helv', fontsize=fs), r.y1 - r.height * 0.22), new, fontsize=fs, fontname='helv')
    d.save(dst)

# ─────────────── ⑤ JSON 변환 ───────────────
AMT_MAP = {'1백만': '100만', '2백만': '200만', '3백만': '300만', '4백만': '400만', '5백만': '500만', '6백만': '600만', '7백만': '700만', '1천만': '1,000만', '1천5백만': '1,500만', '2천만': '2,000만', '2천5백만': '2,500만', '3천만': '3,000만', '4천만': '4,000만', '5천만': '5,000만', '6천만': '6,000만', '1억': '1억'}
def norm_amt(a):
    a = a.replace('원', ''); return AMT_MAP.get(a, a) + '원'
def norm_per(p):
    if '갱신' in p: return p.split(' ')[0] + '갱신/90세'
    return '20년납/90세'
def norm_name(n): return re.sub(r'\(건강가\s?입\)|\(건강 가입\)|\(건\s?강가입\)', '', n).replace('약물허가 치료', '약물허가치료').replace('약물허 가치료', '약물허가치료').replace('(연 간1회한)', '(연간1회한)').replace('(상급종합병 원 포함)', '(상급종합병원 포함)').replace(' 지정대리청구서비스특약', '').strip()
# 카테고리 판정 = 담보명 키워드 (코드번호는 설계 버전마다 달라 사용 ❌)
def classify(name):
    """→ ['cancer'] / ['brain'] / ['heart'] / ['brain','heart'](순환계 공통) / ['surgery'] / ['injury']"""
    n = name
    if '순환계' in n: return ['brain', 'heart']
    if '뇌' in n: return ['brain']
    if '심장' in n or '심근' in n: return ['heart']
    if '암' in n: return ['cancer']
    if '골절' in n or '화상' in n: return ['injury']          # 골절·화상 수술비 = 골절·상해·기타 카드
    if '수술' in n: return ['surgery']
    return ['injury']
def to_coverage(rows):
    """rows = parse_meritz 결과 → getCoverageData 형식 {'cancer':[[명칭, 납기/만기, '', 금액],...], ...}  (순환계 통합치료비 = 뇌·심 양쪽)"""
    C = {k: [] for k in ['cancer', 'brain', 'heart', 'surgery', 'injury', 'care']}
    for code, name, amt, prem, per in rows:
        row = [norm_name(name), norm_per(per), '', norm_amt(amt)]
        for k in classify(norm_name(name)): C[k].append(row)
    for k in ['brain', 'heart']: C[k].sort(key=lambda r: 0 if '진단비' in r[0] else 1)
    return C

def kb_norm(items, per_short=('20년납/20년', '20년납/90세')):
    """parse_kb 결과 정규화 — 설계사명 꼬리 제거 · 금액 공백 제거 · 납기 표기 축약 (조원오·홍희정 확정)"""
    out = []
    for x in items:
        y = dict(x); y['amt'] = re.sub(r'[가-힣]+드림', '', y['amt']).replace(' 만원', '만원').replace(' ', '')
        y['per'] = per_short[0] if '20년만기' in y['per'] else per_short[1]; out.append(y)
    return out
def kb_classify(n):
    """KB라이프 딱좋은0540 담보명 → 카테고리(복수). 뇌/심장 수술 담보는 수술 카드에도 병기."""
    if n.startswith('KB 딱좋은') or '납입면제사유' in n or '재해골절' in n or '깁스' in n or '중환자실' in n or '독감' in n or '갑상선기능' in n: return ['injury']
    if '1~5종' in n or '재해수술' in n or '질병수술' in n: return ['surgery']
    if '순환계질환' in n or '혈전용해' in n: return ['brain', 'heart']
    if '뇌혈관' in n or '양성뇌종양' in n: return ['brain'] + (['surgery'] if '수술' in n else [])
    if '심장' in n or '부정맥' in n: return ['heart'] + (['surgery'] if '수술' in n else [])
    if '암' in n: return ['cancer']
    raise Exception('uncat ' + n)
def kb_coverage(items):
    """kb_norm 결과 → getCoverageData 형식"""
    C = {k: [] for k in ['cancer', 'brain', 'heart', 'surgery', 'injury', 'care']}
    for x in items:
        row = [x['name'], x['per'], '', x['amt']]
        for k in kb_classify(x['name']): C[k].append(row)
    return C

if __name__ == '__main__':
    mode = sys.argv[1]
    for f in sys.argv[2:]:
        if mode == 'meritz':
            r = parse_meritz(f); tot = sum(int(x[3].replace(',', '') or 0) for x in r)
            print(f, len(r), f'{tot:,}'); json.dump(r, open(f.replace('.pdf', '.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        elif mode == 'kb':
            r = parse_kb(f); tot = sum(int(x['prem'].replace(',', '') or 0) for x in r)
            print(f, len(r), f'{tot:,}'); json.dump(r, open(f.replace('.pdf', '.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        elif mode == 'blank':
            print(remove_blank_rows(f, f.replace('.pdf', '_fixed.pdf')))
