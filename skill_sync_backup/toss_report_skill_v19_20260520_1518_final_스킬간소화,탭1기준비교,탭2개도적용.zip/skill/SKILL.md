---
name: report-skill
description: "Toss 보험 분석 레포트 자동생성 스킬 v19 (2026-05-21) — 추천 자동 선택 제거 / 탭1 고정 / Python 결정론 빌더 (build_trigger1·3.py) + LLM 룰 슬림화"
---

> **⚠️ 스킬 파일 수정 전 필독:** 본 스킬의 어떤 파일이든 수정하기 전 같은 폴더의 `CODING_GUIDELINES.md`를 먼저 read하라. (트리거 구동 시에는 무관 — 적용 안 됨)

# Toss 보험 분석 레포트 자동생성 스킬 (v19)

> **본 SKILL.md는 LLM이 참조하는 룰만 담는다. 빌드·검증·산출 영역은 Python 스크립트가 결정론적으로 처리한다.**

---

## §1. 트리거 정의

| 트리거 발화 | 진입점 | 산출 |
|---|---|---|
| "상담자료 교체" | LLM이 PDF 분석 → 새 `replace.py` 작성 (참조 양식: `replace_jeonansu_reference.py`) → 실행 | `toss_insureport_{고객명}님_{생년월일}.html` (메인 HTML 레포트) |
| 트리거 1 (보험분석) | `python3 build_trigger1.py --raw {고객명.txt} --output-dir /mnt/user-data/outputs --nn {NN}` | `{NN}.{고객명}.png` (PNG 본인+공통 1장) |
| 트리거 2 (표레포트) | `python3 pre_report/pre_report_gen.py` (16건 batch) | PNG 테이블 (본인 + 가족 구성원별) |
| 트리거 3 (메시지) | `python3 build_trigger3.py --raw {고객명.txt} --output-dir /mnt/user-data/outputs --nn {NN}` | `{NN}.{고객명}.txt` (TXT 메시지 1종) |

### 박제 룰 (절대 위반 ❌)
1. **LLM 책임 = PDF → 데이터 파싱만**. Python 스크립트는 본 SKILL.md에 명시된 진입점으로만 호출. 자체 커맨드 생성 ❌.
2. wrapper 외 인자 변경 ❌ (`--raw`·`--output-dir`·`--nn`).
3. 트리거 1·3은 단일 고객 1건. 16건 batch는 `pre_report_gen.py` 단독.

---

## §2. 스킬 구성 파일 (변경 영향 영역)

| 파일 | 본문 | 변경 영향 |
|---|---|---|
| `base_template.html` | 메인 HTML 레포트 양식 (v19 — 추천 영역 제거, 탭 가변, 플랜 라벨 칩) | 상담자료 교체 산출에 직접 영향 |
| `replace_jeonansu_reference.py` | LLM이 새 `replace.py` 작성 시 참조하는 빌더 양식 (v19 정합) | 새 replace.py 작성 시 참조 |
| `verify.py` | 산출 HTML 자동 검증 (12 카테고리) | 산출 후 정합 검증 |
| `build_trigger1.py` / `build_trigger3.py` | 트리거 1·3 단일 고객 진입점 wrapper | 트리거 1·3 호출 |
| `pre_report/` | 트리거 1·2·3 결정론 빌더 (PNG·TXT 양식·rules.json·references/*.md) | 트리거 1·2·3 산출 본문 |
| `skin_preview_gen.py` / `skin_preview_template.html` | 스킨 5종 미리보기 | 상담자료 교체 시 스킨 선택 |
| `mappings/` | 보험사·라벨·카테고리 본문 (categories·meta·labels·care_rules·insurers/) | 트리거 1·2·3 분류 |
| `references/` | 5종 라벨 산출 룰 (cancer·brain·heart·surgery·silson·premium_label·renewal 등) | 트리거 1·2·3 라벨 산출 |

---

## §3. v19 박제 룰 (상담자료 교체 트리거)

### 핵심 변경 (v18 → v19)
1. **추천 자동 선택 ❌** — 탭 기본 = 무조건 탭1 (panel-min·tab-min)
2. **비교 기준 = 직전 탭** — 탭2 = 탭1 대비 / 탭3 = 탭2 대비
3. **차액 표시 = 모든 탭 "최소대비 +XX,XXX원"** 통일
4. **라벨 색상** — 추가(빨강+"+") / 강화(초록+"★")
5. **탭 가변** — 탭3 PDF 미존재 시 `{{TAB_COUNT}}='2'` + `{{TAB3_HIDE}}='display:none;'`

### v19 신규 placeholder (60개 中 v19 추가)
| 변수 | 값 | 비고 |
|---|---|---|
| `{{TAB_COUNT}}` | `'2'` / `'3'` | 탭 가변 |
| `{{TAB3_HIDE}}` | `''` / `'display:none;'` | 탭3 미존재 시 숨김 |
| `{{TAB1~3_PLAN_LABEL_CHIPS}}` | 탭1=카테고리(색❌) / 탭2·3=add·enhance 칩 | 플랜 라벨 칩 |
| `{{TAB1~3_COVERAGE_JSON}}` | dict → JSON 문자열 | applyV19 함수 소비 |

### 플랜설명 라벨 칩 룰
| 탭 | sub타이틀 | 라벨 칩 |
|---|---|---|
| 탭1 | `주요보장 최소구성` | 주요보장 카테고리명 (색상 ❌) |
| 탭2 | `{탭1 플랜명} 대비 보강된 항목` | add(빨강+"+") / enhance(초록+"★") |
| 탭3 | `{탭2 플랜명} 대비 보강된 항목` | add(빨강+"+") / enhance(초록+"★") |

### 보장카드 본문
- **5개 카테고리** (보장시나리오카드 합산): 암 / 뇌혈관 / 심장질환 / 수술 / 상해·기타
- **6번째** (설계내용상세확인 모달): 간병 (위 5개와 별개 노출)
- **합산금액 포맷**: `최대 5,000만원` (한글 단위)

### 펼침 상세리스트
- 담보금액 우측 정렬 + 라벨 좌측
- `+추가` 빨강 / `★강화` 초록

### 설계내용상세확인 모달
- 라벨 ❌, **금액 텍스트 색상만** (추가=빨강·강화=초록 — `pdf-amt-add`·`pdf-amt-enhance` 클래스)

---

## §4. JSON 스키마 — LLM ↔ Python 인터페이스

### 4.1. 고객명.txt (LLM 산출 → parse_customer 입력)
```
[고객명] 홍길동
[생년월일] 1985-03-15
[성별] 남
[직업] 사무직(1급)

[보험 #1]
보험사: 삼성화재
상품명: 건강보험 New내돈내삼1640
가입일: 2020-05-10
피보험자: 홍길동
월보험료: 95,000
[담보]
암진단비: 3000만원
뇌혈관진단비: 2000만원
...
```
세부 양식은 `pre_report/parse.py` 본문 참조 (수정 ❌).

### 4.2. plan_label_chips (탭별)
```python
[{"name": str, "type": "cat"|"add"|"enhance"}, ...]
# type 3종만 허용:
#   "cat"     → 카테고리 (색상 ❌) — 탭1 기본
#   "add"     → 추가 (빨강+"+")     — 탭2·3
#   "enhance" → 강화 (초록+"★")    — 탭2·3
```

### 4.3. coverage_json (탭별 — applyV19 함수 소비)
```python
[{"name": str, "amount": str, "type": None|"add"|"enhance"}, ...]
```

---

## §5. 상담자료 교체 워크플로우 (LLM 영역)

### 5.1. 트리거 발화
"상담자료 교체" + 첨부 자료(PDF 3종 — 탭1·2·3 / 고객 정보 / 명함)

### 5.2. LLM 절대 순서
1. 첨부 자료 전수 분석 — PDF에서 담보·보험료·완성도·플랜명 추출
2. `replace_jeonansu_reference.py` 참조 → 새 `replace.py` 작성
   - 메인 처리부의 placeholder 치환값 (고객·상품·탭별 데이터) → 실제 값으로 교체
   - 빌더 함수 호출 (build_cancer_sc·build_brain_sc·build_heart_sc·build_surgery_sc·build_injury_sc·build_cov_card·build_row·build_tab_cov_list)
   - `tab1~3_chip_items`·`tab1~3_coverage` 데이터 구조 채움
3. `python3 replace.py` 실행 → 산출 HTML
4. `python3 verify.py {산출HTML}` 실행 → 12 카테고리 자동 검증
5. mr.와이께 산출물 보고

### 5.3. LLM 임의 변경 ❌ 영역 (변수 ❌)
- `base_template.html` 마크업·CSS — 변경 ❌
- `verify.py`·`pre_report/*`·`mappings/*`·`references/*` — 변경 ❌
- mr.와이 본인 정보 박제 (송영종 / 01099038702 / 토스인슈어런스 본사 직영총괄본부 / 명함 / 관리번호 25-101-C-08673) — 변경 ❌
- 빌더 함수 시그니처 — 변경 ❌

### 5.4. 빌더 함수 시그니처 (replace.py 작성 시 참조)
`replace_jeonansu_reference.py` 본문 참조. 핵심:
- `build_cancer_sc(ilban_diag, yusa_diag, tongham_unit, tongham_note='')`
- `build_brain_sc(diag, surg, icu, gwanhyeol, bigwanhyeol, ...)`
- `build_heart_sc(diag, bujeongmaek, surg, icu, gwanhyeol, ...)`
- `build_surgery_sc(disease_min, disease_max, injury_min, injury_max, ...)`
- `build_injury_sc(goljeol_diag, daegoljeol_diag, ...)`
- `build_row(name, amount, pill=None|'add'|'enhance', sub_detail=None)`
- `build_cov_card(icon, category, sub, max_v, max_l, sc_html, rows, repeat_notice=False, surgery_table=False)`
- `build_tab_cov_list(cards)` — 5개 or 6개 cov-card 순서: 암→뇌→심→수→상[→간병]
- `build_plan_label_chips(items, tab_index)`
- `build_coverage_json(rows)`

### 5.5. v15 pcmp (보험료비교 섹션) — 박제 본문
- `{{PREMIUM_COMPARE_HTML}}` placeholder
- 강조 행: mr.와이가 이미지에 박스 친 보험사 행에만 `pcmp-row-hl` 적용. 자체 판단 ❌ — 박스 위치를 데이터로 사용
- `{{PLAN_LIST_HTML}}` — 탭1·2·3 플랜명·월보험료 — 총보험료 = 월 × 240 (자동 계산)

---

## §6. 트리거 1·2·3 워크플로우 (Python 결정론 — LLM 자체 커맨드 ❌)

### 6.1. 트리거 1 (보험분석 PNG)
- 진입점: `python3 build_trigger1.py --raw {고객명.txt} --output-dir /mnt/user-data/outputs --nn {NN}`
- 산출: `{NN}.{고객명}.png` (본인 + 공통 보험 1장)
- 16건 batch 시: `pre_report/pre_report_gen.py`

### 6.2. 트리거 2 (표레포트 PNG)
- 진입점: `pre_report/pre_report_gen.py` batch 內 자동 산출
- 산출: 본인 PNG 테이블 + 가족 구성원별 PNG 테이블

### 6.3. 트리거 3 (TXT 메시지)
- 진입점: `python3 build_trigger3.py --raw {고객명.txt} --output-dir /mnt/user-data/outputs --nn {NN}`
- 산출: `{NN}.{고객명}.txt` (TXT 메시지 1종)

### 6.4. 5종 라벨 산출 룰 (references/*.md 정합)
- 실손 (silson.md) — 적정/빈약/부재
- 암 (cancer.md) — 진단비+치료비 합산 → 과잉/적정/보통/빈약/부재
- 뇌혈관·심장 (brain.md·heart.md) — 진단비+치료비 합산
- 수술 (surgery.md) — 1-5종 분류
- 갱신·후유장해·치아·화재 (renewal·disability·dental·fire.md)

### 6.5. 트리거 3 명세 7종 (2026-05-16 박제 — 변경 ❌)
- 후유장해 재집계
- 심혈관 부정맥
- 불필요 특약
- 기타 5종 (references/*.md 본문 참조)

---

## §7. verify.py 12 카테고리 (산출 후 자동 검증)

| # | 카테고리 | 본문 |
|---|---|---|
| 1 | 플레이스홀더 | `{{...}}` 잔존 0 |
| 2 | 개수 정합 | cov-card 15 / panel 3 / tab-btn 3 / ico 각 3 |
| 3 | 탭 active (v19) | panel.active = tab-btn.active = 탭1(min) |
| 4 | v19 신규 (v19) | TAB_COUNT·PLAN_LABEL_CHIPS 잔존 0 / applyV19 1회 / pdf-amt-* 클래스 존재 |
| 5 | cov-card 순서 | 암→뇌→심→수→상[→간병] |
| 6 | 데이터 등장 | 고객명·회사명·가격 |
| 7 | 하드코딩 유지 | guarantee-info·안내카드·매회지급·1-5종 분류표 |
| 8 | footer·보장개시일 | COV_ONSET_*·Footer·WAIVER_ITEMS 치환 |
| 9 | JSON 무결성 | cancer·brain·heart·surgery·injury 키 각 3회 |
| 10 | 빌더 함수 흔적 | sc-title·sc-amt 구조 일관 |
| 11 | 에지 케이스 | active 중복·panel 누락 ❌ |
| 12 | 신규/기존보험 섹션 | EXISTING_INSURANCE_SECTION 본인/가족 분류·형광펜 |

---

## §8. 스킨 5종 (상담자료 교체 시)

| # | 이름 | 메인 | 배경 |
|---|---|---|---|
| 1 | 토스블루 (기본) | `#3182F6` | `#F9FAFB` |
| 2 | 베이지 | `#B08D57` | `#FAF5EC` |
| 3 | 스카이블루 | `#4DA8DA` | `#F0F8FC` |
| 4 | 핑크 | `#E8849E` | `#FDF6F8` |
| 5 | 다크 | `#6BA6FF` | `#0F1419` |

적용: `<body data-skin="N">` (N=1~5)

---

## §9. 산출 파일명 양식

| 트리거 | 양식 |
|---|---|
| 상담자료 교체 | `toss_insureport_{고객명}님_{생년월일}.html` |
| 트리거 1 | `{NN}.{고객명}.png` |
| 트리거 2 | `{NN}.{고객명}_table.png` / `{NN}.{고객명}{ff_str}_table.png` (가족) |
| 트리거 3 | `{NN}.{고객명}.txt` |

---

## §10. 중요 규칙 (절대 위반 ❌)

1. **LLM 자체 커맨드 생성 ❌** — wrapper·진입점으로만 호출 (16건 병렬 결함 사례 박제)
2. **base_template.html·verify.py·pre_report·mappings·references 변경 ❌**
3. **빌더 함수 시그니처 변경 ❌**
4. **mr.와이 본인 정보·관리번호 박제 변경 ❌**
5. **v15 pcmp 섹션 마크업·디자인 변경 ❌**
6. **trigger3 명세 7종 변경 ❌**
7. **추천 자동 선택 로직 부활 ❌** — 탭 기본 = 무조건 탭1
8. **PDF 담보명 원형 90% 이상 유지** — 임의 축약·변형 ❌

---

## §11. 박제 정의 영역

### 재직정보 (고정)
- mr.와이: 송영종 / 01099038702 / 토스인슈어런스 본사 직영총괄본부 / 관리번호 25-101-C-08673

### 명함 이미지
- base_template.html 라인 1209·1217·2523·2549 영역에 base64 박제 (변경 ❌)

### v19 박제 룰 (본 §3 정합)
- 추천 자동 선택 ❌ / 탭1 고정 / 비교 기준 = 직전 탭

---

**SKILL.md 끝.**

본 SKILL.md는 LLM 룰 중심으로 재구성되었다 (v19 — 빌드 룰은 Python 스크립트 결정론 영역으로 이전). 빌더 함수 본문·검증 본문·png 표레포트 양식 본문 등은 Python 스크립트(`replace_jeonansu_reference.py`·`verify.py`·`pre_report/*`·`build_trigger1.py`·`build_trigger3.py`)에 박제되어 있다.
