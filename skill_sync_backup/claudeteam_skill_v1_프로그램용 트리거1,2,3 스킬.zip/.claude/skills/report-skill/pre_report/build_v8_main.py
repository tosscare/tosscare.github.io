"""
build_v8_main.py — v8 양주미 케이스 산출 (txt + png레포트)

v8 룰 적용:
- 5종 평균 라벨 산출 (점수 평균 + 반올림: 과잉5/적정4/보통3/빈약2/부재1)
- 헤드라인·결론 본문 = 5종 평균 라벨 기준
- 보장 완성도 = 5종 라벨 적정+과잉 비율 (1/5씩)
"""

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))

from pre_report_gen import (
    render_html, render_message, html_to_png,
    build_family_summary, classify_premium_level_v7,
    cancer_label_v7, brain_heart_label_v7, surgery_label_v7, silson_label_v7,
)


# ===== v8 5종 평균 라벨 산출 룰 =====
# 점수: 과잉 5 / 적정 4 / 보통 3 / 빈약 2 / 부재 1
# 평균 → 반올림: ≥4.5 과잉 / 3.5~4.4 적정 / 2.5~3.4 보통 / 1.5~2.4 빈약 / <1.5 부재
LABEL_SCORE = {"과잉": 5, "적정": 4, "보통": 3, "빈약": 2, "부재": 1}

def compute_avg_label(labels):
    scores = [LABEL_SCORE.get(labels.get(k, "부재"), 1) for k in ["실손", "암", "뇌", "심장", "수술"]]
    avg = sum(scores) / len(scores)
    if avg >= 4.5: return "과잉"
    if avg >= 3.5: return "적정"
    if avg >= 2.5: return "보통"
    if avg >= 1.5: return "빈약"
    return "부재"


def compute_completion_pct(labels):
    """5종 라벨 중 적정+과잉 비율 → % (0/20/40/60/80/100)"""
    cnt = sum(1 for k in ["실손", "암", "뇌", "심장", "수술"]
              if labels.get(k) in ("적정", "과잉"))
    return cnt * 20


# ===== 양주미 본인 데이터 =====

YANGJUMI_LABELS = {
    "실손": silson_label_v7(5000, 30),                           # 적정
    "암":   cancer_label_v7(5000 + 2000),                        # 7,000만 → 보통
    "뇌":   brain_heart_label_v7(2000),                          # 빈약
    "심장": brain_heart_label_v7(1000),                          # 빈약
    "수술": surgery_label_v7(530 + 610),                         # 1,140만 → 적정
}

YANGJUMI = {
    "이름": "양주미",
    "성별": "여성",
    "보험나이": 58,
    "거주": "거주지 추가확인필요",
    "월보험료": {"합계": "350,045원"},
    "연령대비": {"label": classify_premium_level_v7(350045, 58)},  # 매우과잉 (140%)
    "labels": YANGJUMI_LABELS,
    "평균_라벨": compute_avg_label(YANGJUMI_LABELS),
    "완성도_pct": compute_completion_pct(YANGJUMI_LABELS),
    "current_values": {
        "실손": "5,000만 / 30만",
        "암":   "7,000만 (진단비)",
        "뇌":   "2,000만 (진단비)",
        "심장": "1,000만 (진단비)",
        "수술": "1,140만",
    },
    "insurance_count": 9,           # 본인 보험 (피보험자 양주미) — 매트릭스 #1·#2·#3·#4·#5·#6·#7·#9·#10
    "premium_self": "350,045원",
    "premium_family": "120,359원",
    "has_renewal": True,             # 갱신형 ≥1건 (한화시그·KB닥터·CI)
    "total_remaining_premium": 0,    # 잔여보험료 추정 — 미확인 (㉧ 모호 영역)
    "is_family": False,
    # 가족 요약 (본인 PNG 안 통합 표)
    "family_summaries": [],
}


# ===== 가족1 (이*호) 데이터 =====
LEEHO_LABELS = {
    "실손": silson_label_v7(5000, 30),    # 적정 (사랑굿프 실손)
    "암":   cancer_label_v7(1000),         # 부재 (<2,000)
    "뇌":   brain_heart_label_v7(0),       # 부재
    "심장": brain_heart_label_v7(0),       # 부재
    "수술": surgery_label_v7(0),           # 부재
}

LEEHO = {
    "이름": "이*호",
    "성별": "성별/나이 추가확인필요",
    "보험나이": 0,
    "거주": "거주지 추가확인필요",
    "월보험료": {"합계": "120,359원"},
    "연령대비": {"label": "미확인 (또는 0원)"},
    "labels": LEEHO_LABELS,
    "평균_라벨": compute_avg_label(LEEHO_LABELS),
    "완성도_pct": compute_completion_pct(LEEHO_LABELS),
    "current_values": {
        "실손": "5,000만 / 30만",
        "암":   "1,000만",
        "뇌":   "0",
        "심장": "0",
        "수술": "0",
    },
    "insurance_count": 3,
    "premium_self": "120,359원",
    "premium_family": "0원",
    "has_renewal": True,             # 사랑굿프 갱신형 특약
    "total_remaining_premium": 0,
    "is_family": True,
    "family_summaries": [],
}


# 본인 PNG에 가족 요약 표 통합
YANGJUMI["family_summaries"] = [
    build_family_summary(
        family_name="이*호",
        premium_str="120,359원",
        count=3,
        labels=LEEHO_LABELS,
        has_renewal=True,
    )
]


# ===== 산출 =====
OUT = Path(__file__).parent / "output"
OUT.mkdir(exist_ok=True)
TEMPLATE = Path(__file__).parent / "pre_report_template.html"

# 1. 양주미 본인 png레포트
html = render_html(str(TEMPLATE), YANGJUMI)
(OUT / "양주미_본인.html").write_text(html, encoding="utf-8")
html_to_png(html, str(OUT / "양주미_본인_png레포트.png"), str(OUT / "_work_yj"))

# 2. 양주미 본인 txt 문구
msg = render_message(YANGJUMI)
(OUT / "양주미_본인_문구.txt").write_text(msg, encoding="utf-8")

# 3. 가족1 png레포트 (별도 발송용 — 본 시점 본인 PNG에 통합되었으나 가족용 별도 산출)
html_fam = render_html(str(TEMPLATE), LEEHO)
(OUT / "가족1_이호.html").write_text(html_fam, encoding="utf-8")
html_to_png(html_fam, str(OUT / "가족1_이호_png레포트.png"), str(OUT / "_work_lh"))

print(f"본인 평균 라벨: {YANGJUMI['평균_라벨']} (완성도 {YANGJUMI['완성도_pct']}%)")
print(f"가족1 평균 라벨: {LEEHO['평균_라벨']} (완성도 {LEEHO['완성도_pct']}%)")
print(f"본인 카드 ③: {YANGJUMI['연령대비']['label']}")
print(f"산출 완료: {OUT}")
