---
name: report-skill
description: "보험설계안 안내용 스킬"
---

보장요약 HTML 템플릿을 새 고객 정보로 교체하는 스킬.
상담사 고정값: 송영종 / 010-9903-8702

> **⚠️ 스킬 파일 수정 전 필독:** 본 스킬의 어떤 파일이든 수정하기 전 같은 폴더의 `CODING_GUIDELINES.md`를 먼저 read하라. (트리거 구동 시에는 무관 — 적용 안 됨)

## 용어·파일명·경로 정의 (소통 일관성 기준)

### 스킬 구성 파일 8개
| 파일명 | 역할 | 약칭 |
|---|---|---|
| `SKILL.md` | 스킬 지침서 (본 문서) | — |
| `base_template.html` | 베이스 마스터 HTML (변수 포함) | **베이스템플릿** |
| `replace_jeonansu_reference.py` | 빌더 함수 참조 (A·D작업) | reference.py |
| `verify.py` | 자동 검증 (B작업, 11개 카테고리) | — |
| `skin_preview_template.html` | 스킨 선택 Artifact 템플릿 | — |
| `skin_preview_gen.py` | 스킨 선택 Artifact 생성기 | — |
| `toss_insureport_jeonansu_19930430_file1.html` | 화면 검증 기준 (변수화 미적용) | **1번파일** |
| `toss_insureport_jeonansu_19930430_file2.html` | 변수화 구조 기준 (100% 변수 적용) | **2번파일** |

### 산출물 파일명 규칙
| 종류 | 규칙 | 예시 |
|---|---|---|
| 고객 리포트 | `toss_insureport_{고객명}님_{생년월일YYYYMMDD}.html` | `toss_insureport_김리아님_19870320.html` |
| 수정본 | 위 규칙 + `_01.html`, `_02.html` … | `toss_insureport_김리아님_19870320_01.html` |
| 스킨 프리뷰 (임시) | `skin_preview_{고객명}님.html` | `skin_preview_김리아님.html` |
| 스킬 배포 zip | `toss_report_skill_final_{YYYYMMDD}.zip` | `toss_report_skill_final_20260424.zip` |

**주의**: "insu"와 "report" 사이 언더스코어 **없음**. "님"은 고객명 뒤 고정.

### 작업 단위 용어
| 용어 | 의미 |
|---|---|
| **A작업** | 빌더 함수 시그니처 (sc-wrap 5개: cancer/brain/heart/surgery/injury) |
| **B작업** | verify.py 자동 검증 (11개 카테고리) |
| **C작업** | base_template 구조 요약 (변수 목록·예외 구조) |
| **D작업** | cov-card·row 빌더 함수 (build_row / build_cov_card / build_tab_cov_list) |
| **1번작업** | 탭1 PDF 처리 |
| **2번작업** | 탭2 PDF 처리 |
| **3번작업** | 탭3 PDF 처리 |
| **교차검증** | 3번작업 완료 후 탭1·2·3 데이터 비교 |
| **새보험분석** | **"상담자료 교체" 스킬의 정확도·속도를 높이기 위한 사전준비작업.** PDF의 담보명을 분석해 참조표(카테고리 매핑·표준 라벨·상품 특이사항)를 확장하고 SKILL.md·terms.html을 업데이트한 뒤 zip 재패키징만 수행. HTML 리포트 생성·베이스템플릿 치환·빌더 실행·verify·스킨 선택은 모두 하지 않음. 산출물은 **업데이트된 스킬 zip 1개뿐**. |

### 변수 명명 규칙 (base_template 내)
| 카테고리 | 변수 패턴 |
|---|---|
| 고객 정보 | `{{CUSTOMER_NAME/AGE/GENDER/BIRTH}}` |
| 탭 정보 | `{{TAB1~3_PLAN_NAME/PRICE/DESC/OPINION/COMPLETE}}` |
| 완성도 진행바 | `{{TAB1~3_PROG_WIDTH}}` |
| 추천탭 ID | `{{TAB_REC}}` — 값: `min` / `mid` / `max` |
| 패널 active 제어 | `{{REC_PANEL_MIN/MID/MAX}}` |
| 탭버튼 active 제어 | `{{REC_TAB_ACTIVE_MIN/MID/MAX}}` |
| 비추천 탭 diff-title | `{{NON_REC_TITLE_MIN/MID/MAX}}` |
| 스킨 제어 | `<body data-skin="N">` — N은 1~5 |

### 스킨 5종
| 번호 | 이름 | 메인 색상 | 배경 |
|---|---|---|---|
| 1 | 토스블루 (기본) | `#3182F6` | `#F9FAFB` |
| 2 | 베이지 | `#B08D57` | `#FAF5EC` (크림) |
| 3 | 스카이블루 | `#4DA8DA` | `#F0F8FC` |
| 4 | 핑크 | `#E8849E` | `#FDF6F8` |
| 5 | 다크 | `#6BA6FF` (포인트) | `#0F1419` (차콜) |

### 경로 약속
| 경로 | 용도 |
|---|---|
| `/mnt/skills/user/report-skill/` | 스킬 폴더 (실제 구동 파일 위치) |
| `/home/claude/` | 작업 공간 (Claude 임시 편집 영역) |
| `/mnt/user-data/uploads/` | 사용자 업로드 파일 (PDF 등) |
| `/mnt/user-data/outputs/` | 최종 산출물 (사용자 다운로드용) |

### 고정 상수
| 항목 | 값 |
|---|---|
| 상담사 | 송영종 |
| 휴대폰 | 010-9903-8702 |
| 사무실 | 02-6308-6932 |
| 스킬 트리거 문구 (리포트 생성) | **"상담자료 교체"** |
| 새보험분석 트리거 문구 (사전준비) | **"새보험분석"** (및 유사 표현 — ⑧ 표현 매핑 참조) |
| 사전레포트 트리거 문구 (사전상담 자료) | **"레포트"** 또는 **"레포트작성"** (정확 일치) |
| 기본 스킨 | 1번 (토스블루) |

### 사용자 대화 시 자주 쓰는 표현 매핑
| mr.와이 표현 | 의미 |
|---|---|
| "베이스템플릿" | `base_template.html` |
| "1번파일" / "2번파일" | 위 테이블의 file1.html / file2.html |
| "최신버전 스킬파일" | 가장 최근 패키징된 `toss_report_skill_final_*.zip` |
| "스킬 구동" | 트리거 문구 "상담자료 교체" 입력 후 워크플로우 실행 |
| "상담자료 교체" | 리포트 생성 트리거 (고정) |
| "새보험분석" / "새로운 보험 분석해줘" / "새로운보험분석" / "다른 보험 분석해줘" / "다른 보험분석" / "다른 회사 보험 분석" / "처음 보는 보험 분석" / "새 보험 분석" / "이 보험 분석해줘" / "보험상품 분석" | 모두 **새보험분석 트리거** (동일 처리). 매칭 룰: "새"·"새로운"·"다른"·"처음"·"이" + "보험" + "분석" 키워드 유연 조합 감지 |
| **"레포트"** 또는 **"레포트작성"** | **사전레포트 트리거** (사전상담 자료 생성). 정확 일치만 매칭 (다른 표현 ❌) |

### 용어 업데이트 규칙 (사용자 요청 처리)

사용자가 대화 중 새 용어를 합의한 뒤 **"오늘 통일한 용어를 스킬파일에 적용해줘"** (또는 유사 표현)를 요청하면 Claude는 아래 절차대로 처리한다.

**1. 대상 용어 수집 기준 — 명시적 합의만 포함**

- ✅ 포함: 아래 패턴 중 하나로 명확히 선언된 용어
  - "X를 Y로 부르자", "X를 Y로 통일하자"
  - "앞으로 X는 Y", "지금부터 X를 Y라 하자"
  - "용어 통일: X → Y"
  - "X의 새 이름은 Y"
- ❌ 제외: 일상 대화 중 은연중에 쓴 표현, 일회성 언급, 비공식 제안
- 📌 모호할 경우: 사용자에게 "아래 용어들을 반영하면 될까요?" 라고 **목록 확인 후 진행**

**2. SKILL.md 업데이트**

- "용어·파일명·경로 정의" 섹션의 적절한 하위 섹션에 추가 또는 수정
  - 파일명 규칙 → ② 섹션
  - 작업 단위 용어 → ③ 섹션
  - 변수 규칙 → ④ 섹션
  - 스킨 관련 → ⑤ 섹션
  - 경로 → ⑥ 섹션
  - 고정 상수 → ⑦ 섹션
  - 표현 매핑 → ⑧ 섹션
- 어느 섹션인지 모호하면 사용자에게 확인

**3. terms.html 동기화 (필수)**

- SKILL.md와 동일한 내용으로 terms.html도 업데이트
- 두 파일의 용어 정보는 **항상 일치해야 함**

**4. 파일 배포**

- 스킬 폴더(`/mnt/skills/user/report-skill/`) 즉시 교체
- zip 재패키징 (`toss_report_skill_final_{오늘날짜YYYYMMDD}.zip`)
- `/mnt/user-data/outputs/`에 저장 후 `present_files`로 전달

**5. 변경 내역 요약 보고**

- 어떤 용어를 어느 섹션에 추가·수정했는지 표로 정리하여 사용자에게 보고
- 다른 섹션에 미친 영향 있으면 함께 안내

**주의**: 이 절차는 **새 대화창에서도 동일하게 작동**한다. 단, Claude는 해당 대화창 안에서 합의된 용어만 알 수 있으므로, 다른 대화창에서 합의된 용어는 반영 불가(사용자가 다시 알려줘야 함).

---

## ★ 원본 파일 재view 금지 규칙 (반드시 준수)

**토큰·시간 절감의 핵심.** 본 SKILL.md에 A작업(빌더 함수 시그니처)·C작업(base_template 구조 요약)이 내장되어 있으므로, **원본 파일 전체를 매번 view하지 않는다.**

### 금지 대상
- `base_template.html` 전체 view (4MB — 토큰 대량 소모)
- `replace_jeonansu_reference.py` 전체 view (A작업 내장으로 대체)

### 허용되는 예외 (제한적)
1. B작업 verify.py가 특정 라인 오류를 지적한 경우 → 해당 섹션만 **부분 view**
2. 사용자가 구체적인 코드 위치·변수를 지목한 경우 → 해당 부분만 **부분 view**
3. 하드코딩 유지 항목 문자열 확인이 필요한 경우 → 해당 함수만 **부분 view**

### 위반 시 손실
- 불필요한 파일 재탐색으로 세션당 약 30,000~50,000 토큰 낭비
- 작업 시간 2배 이상 증가

---

## ★ 새보험분석 워크플로우 (사전준비작업 — "상담자료 교체" 구동 정확도·속도 향상용)

**본질**: "상담자료 교체" 본 작업 전에 새 보험사·상품 PDF를 미리 분석해 참조표를 확장하는 **학습 루틴**. HTML 리포트·베이스템플릿·빌더·verify·스킨 전부 건드리지 않음. 산출물은 **업데이트된 스킬 zip 하나**.

### 트리거 감지

아래 표현 중 하나 감지 시 본 워크플로우 실행:
- "새보험분석" / "새로운 보험 분석해줘" / "새로운보험분석"
- "다른 보험 분석해줘" / "다른 보험분석" / "다른 회사 보험 분석"
- "처음 보는 보험 분석" / "새 보험 분석" / "이 보험 분석해줘"
- "보험상품 분석"
- **매칭 룰**: ("새"·"새로운"·"다른"·"처음"·"이") + "보험" + "분석" 키워드 유연 조합

### 워크플로우 (절대 순서)

**1단계: PDF 첨부 확인**
- PDF 없음 → "분석할 보험상품 PDF를 첨부해주세요"라고 요청 후 대기
- PDF 있음 → 다음 단계 (개수 무관: 1개·2개·3개·다수 모두 허용)

**2단계: PDF 담보 추출**
- 각 PDF의 전체 담보명·금액·납입기간·만기 추출
- 상품 기본 정보(보험사·상품명·고객 기본정보·월납) 추출
- PDF 개수에 따른 플랜별 분리 인식 (예: 3개면 min/mid/max 플랜, 1개면 단독 상품)

**3단계: 현 참조표와 대조 (담보명 기준)**
- 이미 매핑된 담보 → 확인만
- **새 담보명**: 카테고리 추정 → 사용자 확인 요청
- **기존 담보의 다른 표기(별칭)**: 참조표 별칭에 병기 추가 제안
- **상품 고유 특이사항** (납입면제·할인·보장개시일 등): 보험사·상품 계열별 특이사항 섹션에 누적 제안

**4단계: 사용자 확인·교정**
- 매핑 결과를 구조화해서 제시 (카테고리별 담보 목록 + 새 매핑·별칭 제안 목록)
- 사용자 지적 시 교정 반영 (이번 한화 케이스처럼 반복 교정 가능)
- 확정 후 다음 단계

**5단계: SKILL.md 업데이트**
- "[내장] 보험상품 담보명 매핑 참조표" 섹션의 해당 테이블에 추가
  - 카테고리 매핑 테이블 (새 담보·별칭)
  - 표준 라벨 매핑 테이블 (새 라벨 쌍)
  - 보험사·상품별 특이사항 섹션 (해당 계열 추가)

**6단계: terms.html 동기화 (필수)**
- SKILL.md와 동일한 내용으로 ⑨ 참조표 섹션 업데이트
- 두 파일 내용 항상 일치

**7단계: 스킬 폴더 교체 + zip 재패키징**
- `/mnt/skills/user/report-skill/` 즉시 교체 (SKILL.md·terms.html 2개 파일만)
- 기능 파일(빌더·verify·템플릿·스킨) 일절 건드리지 않음
- zip 재패키징: `toss_report_skill_final_{오늘날짜YYYYMMDD}.zip`
- `/mnt/user-data/outputs/`에 저장

**8단계: present_files로 전달**
- 업데이트된 스킬 zip 1개만 전달
- 변경 요약 보고 (어떤 담보·별칭·특이사항이 어느 테이블에 추가됐는지 표로)
- **여기서 워크플로우 종료 — HTML 리포트 생성·고객 파일 산출 없음**

### ⚠️ 새보험분석이 절대 하지 않는 것 (상담자료 교체와의 차이)

| 작업 | 상담자료 교체 | 새보험분석 |
|---|---|---|
| HTML 리포트 생성 | ✅ | ❌ |
| 베이스템플릿 데이터 치환 | ✅ | ❌ |
| 빌더 함수 실행 (sc-wrap·cov-card·row) | ✅ | ❌ |
| verify.py 11개 검증 | ✅ | ❌ |
| 스킨 선택 Artifact | ✅ | ❌ |
| 고객 HTML 파일 산출 | ✅ | ❌ |
| SKILL.md·terms.html 업데이트 | ❌ | ✅ |
| zip 재패키징 | ❌ | ✅ |
| 최신버전 스킬파일 전달 | ❌ | ✅ |

### 권장 사용 흐름

```
새 보험사·상품 접수
  ↓
① "새보험분석" + PDF 첨부 → 스킬 학습·업데이트 (사전준비)
  ↓
② "상담자료 교체" + PDF 3개 → 고객 리포트 생성 (본 작업, 1차 정확도 상승)
```

같은 상품 계열이 반복적으로 들어올 때는 ①을 건너뛰고 ②만 실행해도 됨. 처음 보는 보험사·상품이거나 매핑 오류가 의심되는 경우에만 ① 먼저 실행.

---

## ★ 사전레포트 워크플로우 ("레포트" / "레포트작성" 트리거)

**본질**: 본 상담 전에 고객에게 전달하는 **사전상담 자료**. 고객이 본인의 보장 부족 상태를 인지하고 상담 동기를 갖도록 유도. 산출물은 **{NN}.{고객명}.png + {NN}.{고객명}.txt** (zip 안에 평탄 저장 — 고객별 폴더 ❌).

### 트리거 감지

- "레포트" 또는 "레포트작성" 정확 일치
- 다른 표현(예: "리포트", "레포트해줘") ❌

### 워크플로우 (절대 순서)

**1단계: 트리거 감지 → 안내 응답**
- 트리거 감지 시 다음 응답: "자료를 올려주세요."
- 그 외 다른 안내·질문 ❌ (mr.와이가 즉시 데이터 입력하도록)

**2단계: 입력 종료 확인 룰 (무한 반복)**
- mr.와이가 정보 입력 → "고객정보 입력이 종료되셨나요?" 확인
- mr.와이가 추가 정보 입력 (오케이 신호 ❌) → 다시 "고객정보 입력이 종료되셨나요?" 재확인
- "오케이"·"작업해줘"·"끝" 등 종료 신호 받기 전까지 무한 반복

**3단계: 다수 고객 분리**
- 빈 줄 2개 이상 = 새 고객 시작 구분자
- 각 고객 데이터를 분리하여 개별 처리

**4단계: 데이터 검증 — 라벨링 가능 여부 확인**
- 가입 보험 정보만으로는 5종 카드 라벨링 ❌
- **보장분석 상세보기(담보별 금액)** 데이터가 함께 있어야 함
- 미충족 시 mr.와이께 추가 데이터 요청

**5단계: 보험 분류 + 월보험료 합산**

| 분류 | 룰 |
|---|---|
| 자동차·해외여행·단체보험 | 합산 ❌ |
| 상품명에 "연금" 또는 "저축" | 저축성 분류 |
| 그 외 (정상 + 납입중 + 월보험료 가용) | 보장성 분류 — 합산 |

월보험료 합산 = 보장성 + 저축성 (자동차 등 제외)

**6단계: 5종 보장 라벨링**

핵심 5종 카드 = 실손의료비 / 암 진단비 / 뇌혈관질환 진단비 / 심장질환 진단비 / 수술비(질병)

| 카테고리 | 적용 담보 | 권장 | 라벨 임계값 |
|---|---|---|---|
| 실손의료비 | 질병·상해 입원/외래/처방 6종 (각 카테고리에서 높은 금액 1개 적용) | 입원 5,000만 / 통원 25만 | 6단계 (적정 90%↑ / 보통 51~89 / 빈약 31~50 / 매우 취약 21~30 / 사실상 부재 1~20 / 부재 0) |
| 암 진단비 | 암·암진단비·통합암진단비만 (치료비 계열·유사암·소액암·남성암·여성암·전이암·고액암·N대암 제외) | 5,000만↑ | 과잉 5,100만↑ / 적정 5,000~5,099만 / 보통 3,000~4,900만 / 빈약 ~3,000만 / 부재 0 |
| 뇌혈관질환 진단비 | 뇌혈관질환진단비만 (뇌졸중·뇌출혈·뇌경색 등 ❌) | 3,000만↑ | 과잉 3,060만↑ / 적정 3,000~3,059만 / 보통 1,800~2,940만 / 빈약 ~1,800만 / 부재 0 |
| 심장질환 진단비 | 허혈성심장질환진단비 + 부정맥진단비 (합산) | 3,000만↑ | 동일 |
| 수술비 (질병) | 질병수술비 + 질병1종수술비 + 질병5종수술비 / 표기: 최소(질병+1종) ~ 최대(5종) / 라벨 계산 = 최대(5종) 기준 / 상해수술비는 작은 글씨 합산 표기 | 1,000만↑ (5종 기준) | 과잉 1,500만↑ / 적정 1,000만↑ / 보통 501~999만 / 빈약 ~500만 / 부재 0 |

**중복 합산 룰**: 같은 보장이 여러 보험에 있으면 합산.

**7단계: 같은 연령대의 적정 대비 라벨**

| 연령대 | 월 적정 보험료 |
|---|---|
| 20대 | 100,000원 |
| 30대 | 150,000원 (20대의 150%) |
| 40대 | 180,000원 (20대의 180%) |
| 50대 | 250,000원 (20대의 250%) |
| 60대+ | 400,000원 (20대의 400%) |

비율(%) = (현재 보장성+저축성 월보험료 / 연령대 적정) × 100

라벨 임계값 (5단계):
- 과잉 ≥ 130%
- 적정 90~129%
- 보통 51~89%
- 빈약 31~50%
- 매우 취약 21~30%
- 사실상 부재 1~20%
- 부재 0%

**8단계: 헤드라인 자동 매핑** (같은 연령대의 적정 대비 라벨 기준)

| 라벨 | 헤드라인 |
|---|---|
| 부재 | 핵심 의료보장이 전부 부재한 상태입니다. |
| 사실상 부재 | 핵심 의료보장이 사실상 부재한 상태입니다. |
| 매우 취약 | 핵심 의료보장이 매우 취약한 상태입니다. |
| 빈약 | 핵심 의료보장이 빈약한 상태입니다. |
| 보통 | 핵심 의료보장이 보통 수준입니다. |
| 적정 | 핵심 의료보장이 적정 수준입니다. |
| 과잉 | 핵심 의료보장이 과잉 수준입니다. |

**8-1단계: 갱신형 감지 (우선 조건)**

| 항목 | 룰 |
|---|---|
| 감지 키워드 | "갱신" — 고객정보 텍스트 어디든 포함 시 무조건 트리거 (갱신 유무 행 / 담보명 / 어디든) |
| 메시지 1번 분기 | 갱신형 감지 시 → "{고객명}님의 보험은, 보험의 일부(또는 전부)가 갱신형으로 구성되어 보험료가 크게 높아질 수 있습니다." (라벨 무관 무조건 교체) |
| 메시지 2번 마무리 | 갱신형 영향 ❌ — 라벨 매핑 그대로 |
| 레포트 추가 표시 | 섹션 타이틀 "필수보장(권장) vs 현재보장상태" 바로 아래에 빨간 한 줄 추가:<br>`※ 보험의 일부(또는 전부)가 갱신형으로 구성되어 보험료가 크게 높아질 수 있습니다.` |
| 표현 고정 | "일부(또는 전부)"는 판단 ❌ 그대로 출력 |
| 마침표 | 1개 |

**9단계: HTML 변수 치환 + PNG 변환**
- 템플릿: `pre_report/pre_report_template.html`
- 변환 스크립트: `pre_report/pre_report_gen.py`
- 720px 폭 / device_scale_factor 2 / Playwright Chromium full_page

**10단계: 메시지 텍스트 생성**

템플릿 (변수 치환):
```
{고객명}님 안녕하세요.
토스 보험분석 어드바이저입니다.

토스앱으로 보험 점검 신청을 주셔서 토스 본사 소속 상담사가 연락드렸습니다.

1. {고객명}님의 보험은, {헤드라인}

2. 필수보장을 기준으로,
- 실손의료비 : {실손_라벨}
- 암보장 : {암_라벨}
- 뇌혈관보장 : {뇌_라벨}
- 심장보장 : {심장_라벨}
- 수술보장 : {수술_라벨}
으로 {헤드라인}

3. 보험은 올바르게 가입하지 않으면 질병 발병, 사고 후에는 가입이 어렵습니다.
올바르게 준비되어 있는지 꼭 점검해 보시기를 바랍니다.

❗궁금하신 점은 메시지 남겨주세요.
❗본사  상담사가 순차적으로 안내드릴 예정입니다.

✅ 본사 상담사 재직정보 확인 > https://service.tossinsu.com/insulink/vO03jJGuLG
```

**10.5단계: 작업 종료 확인 룰 (zip 압축 직전 게이트)** ⭐

PNG·txt 생성 완료 후, **zip 압축 직전에 자동으로 다음 질문 출력**:

> **"레포트작성이 끝나셨나요?"**

| mr.와이 응답 | 동작 |
|---|---|
| "응"·"끝났어"·"완료" 등 긍정 | 11단계 진행 (zip 압축·전달) |
| "아니"·"더 있어"·"추가" 등 부정 | "자료를 올려주세요" → 추가 고객정보 §2 루프 진입 → 분석·PNG·txt 생성 → **다시 10.5단계 회귀** |

**기존 산출물 보관 룰 (필수)**:
- 분석 완료된 산출물(`{NN}.{고객명}.png + {NN}.{고객명}.txt` [+ 가족 시 `{NN}.{고객명}{NN_가족}.png`])은 작업공간에 **그대로 보관**
- 추가 고객 분석 시 **새 폴더만 추가 생성** (기존 산출물 재분석 ❌·재생성 ❌)
- 최종 "응" 시 누적된 모든 폴더를 **한 번에 zip 압축**

**§2와의 명확한 구분**:

| 질문 | 시점 | 의미 |
|---|---|---|
| "고객정보 입력이 종료되셨나요?" (§2) | mr.와이 자료 붙여넣기 직후 | 이번 분석에 추가할 고객이 더 있는지 |
| "레포트작성이 끝나셨나요?" (10.5) | PNG·txt 생성 완료 후 | 동일 zip에 묶을 다음 작업이 더 있는지 |

두 질문은 시점·기능·산출물 모두 분리된 별개 안전망. **어휘 통일 ❌, 의미 중복 ❌.**

**도입 목적**: 실무 운영 시 1회 트리거당 10~20명+ 처리 필요. 매번 zip 다운로드·압축해제 부담 제거. mr.와이가 "응" 응답 직후 즉시 zip 전달 가능 (대기 ❌).

---

### ★ 피보험자 기준 합산 룰 ⭐ 신규

본인 5종 라벨링 시 **피보험자 = 본인인 보험만 합산**한다. 계약자는 무관.

| 케이스 | 처리 |
|---|---|
| 계약자 ≠ 본인 + 피보험자 = 본인 (예: 부모님 계약, 본인 피보험) | ✅ 합산 (본인 보장이므로) |
| 계약자 = 본인 + 피보험자 ≠ 본인 (예: 본인이 자녀·부모님 보험 가입) | ❌ 제외 (가족 보장이므로) |
| 계약자 = 본인 + 피보험자 = 본인 | ✅ 합산 |
| 계약자 ≠ 본인 + 피보험자 ≠ 본인 | ❌ 제외 |
| "본인,가족" 공통 피보험자 | ✅ 본인 보장에 포함 (시스템 분류 그대로) |

**도메인 원칙**: 보장 분석 = 누가 보장 받는가(피보험자) ≠ 누가 보험료 내는가(계약자)

**일반 운영**: CRM 시스템 보장분석 상세표는 이미 본인 피보험자 보험만 합산함. 별도 처리 ❌. 단 "온가족" 보험 등 시스템 분류 모호 케이스는 데이터 신뢰.

---

### ★ 가족 피보험자 PNG 추가 생성 룰 ⭐ 신규

**단독 가족 피보험자 보험**(계약자=본인+피보험자=가족)이 있는 경우 **그 가족 기준 PNG 추가 생성**.

| 항목 | 룰 |
|---|---|
| 생성 조건 | 단독 가족 피보험자 보험 1건 이상 (공통 피보험자 "본인,가족"은 본인 케이스에 이미 포함되므로 추가 ❌) |
| 가족 1명당 | PNG 1개 |
| 메시지 (txt) | 가족별 ❌ — **본인 1개만 생성** |
| 폴더 구조 | **고객별 폴더 ❌ — zip 안에 모든 파일 평탄 저장** (v2 변경) |
| 파일명 규칙 | 본인 = `{NN}.{고객명}.png` + `{NN}.{고객명}.txt` / 가족 = `{NN}.{고객명}01.png`·`{NN}.{고객명}02.png` ... |
| NN 부여 | 고객 입력 순서대로 `01`·`02`·... (본인·가족 동일 NN, 같은 본인 그룹 식별) |
| 정렬 룰 | ① 본인 → ② 보험료 많은 순 → ③ 동순위면 보험 건수 많은 순 → ④ 그래도 동일하면 랜덤 |

**가족 PNG 헤더 표기 룰**:
- 이름·생년월일·성별·거주 모두 **"—" 표기** (CRM에 가족 식별정보 없음)
- 헤드라인 main: `HEADLINE_BY_LEVEL["부재"]` (5종 모두 부재이므로)
- 헤드라인 sub: **"세부정보 확인필요"** 명시

**5종 라벨링 (가족 케이스)**:
- CRM이 본인 페이지만 제공하므로 가족 피보험자별 보장 상세 데이터 없음
- 5종 라벨 **모두 부재**로 표기
- 월보험료 = 본인이 계약자로 낸 가족 보험의 보험료 합계
- 연령대비 박스 = 모두 "—" 표기 (가족 나이 정보 없음)

**도입 목적**: 본인 보장 외에 가족(자녀·부모님) 보험 누수 시각화. 보험 효율성 컨설팅 시 가족 피보험자 보험료 비중 파악 → 정리·재설계 단서 제공.

**11단계: zip 패키징 + 전달**
- 폴더 구조: `report_{YYYYMMDD}.zip` 안에 모든 파일이 **평탄 저장** (고객별 폴더 ❌)
- 본인: `{NN}.{고객명}.png` + `{NN}.{고객명}.txt` / 가족: `{NN}.{고객명}01.png`·`{NN}.{고객명}02.png` ...
- 다수 고객이면 NN 순서대로 입력 순 부여 (10.5단계 누적분 모두 포함)
- 압축 도구: **Python `zipfile.ZipFile` 사용** (UTF-8 한글 호환). bash `zip` 명령 ❌ (Windows·Mac에서 한글 폴더명 깨질 위험)
- present_files로 zip 1개만 전달

### 사전레포트가 절대 하지 않는 것

| 작업 | 사전레포트 |
|---|---|
| 베이스템플릿(`base_template.html`) 사용 | ❌ (전용 템플릿 사용) |
| verify.py 검증 | ❌ |
| 스킨 선택 | ❌ |
| SKILL.md·terms.html 업데이트 | ❌ |
| 본 상담용 리포트 생성 | ❌ |

### 데이터·룰 박제 위치

- **rules.json**: `pre_report/rules.json` — 모든 룰·임계값·매핑 박제
- **HTML 템플릿**: `pre_report/pre_report_template.html`
- **생성 스크립트**: `pre_report/pre_report_gen.py`
- **로고**: `pre_report/toss_logo.png`

### 재직정보 (고정)

| 항목 | 값 |
|---|---|
| 이름 | 토스인슈어런스 송영종 어드바이저 |
| 역할 | 토스인슈어런스 Pro Coach (사내강사) |
| 등록번호 | 20080479060011 |
| Mail | i2309006@tossinsu-advisor.com |
| Mobile | 010-9903-8702 |
| Fax | 0504-474-4937 |
| 재직정보 링크 | https://service.tossinsu.com/insulink/vO03jJGuLG |

---

## ★ 스킬 구동 시 전체 워크플로우 (반드시 이 순서대로 실행)

### 사전 준비 (스킬 구동 전 반드시 확인)
스킬 폴더에 아래 파일들이 모두 존재하는지 확인:
- `base_template.html` — 최신 베이스템플릿
- `SKILL.md` — 본 지침 파일
- `replace_jeonansu_reference.py` — 빌더 함수 참조 스크립트 (A작업·D작업 함수 포함)
- `verify.py` — B작업 자동 검증 스크립트
- `skin_preview_template.html` — 6단계 스킨 선택 Artifact 템플릿 (축약 목업 + 스와이프 카드)
- `skin_preview_gen.py` — 6단계 스킨 선택 Artifact 생성기
- `terms.html` — "용어를 보여줘" 보조 트리거 응답용 정적 HTML
- `toss_insureport_jeonansu_19930430_file1.html` — 화면 검증 기준 파일
- `toss_insureport_jeonansu_19930430_file2.html` — 변수화 구조 기준 파일

### 1단계: 기준 파일 확인 (간소화 — 원본 재view 금지)
본 SKILL.md의 A작업(빌더 시그니처)·C작업(템플릿 구조 요약)·D작업(cov-card 빌더) 내장 내용을 참고한다. 원본 파일은 위 예외 경우에만 부분 view.

### 2단계: PDF 정밀 분석 (순차 처리 + 교차검증)

**PDF 3개를 한번에 받아도 내부적으로 1번작업 → 2번작업 → 3번작업 순차 처리한다.**

**순차 처리 이유**: 고객/상품/담보가 탭마다 다를 수 있어 1개씩 집중 처리해야 혼용·누락 실수가 줄고, 교차검증 시 각 탭 데이터가 정리된 상태로 비교 가능.

**각 작업(1번·2번·3번) 공통 처리 내용**:
- 해당 탭 PDF의 전체 담보 목록, 금액, 납입기간, 만기 정밀 추출
- 담보를 cancer/brain/heart/surgery/injury 5개 카테고리로 분류
- 월납 보험료 추출 · 내부 저장

**PDF 자동 매핑**: PDF 3개의 상품명·플랜명과 양식의 탭1·탭2·탭3 플랜명을 대조하여 자동 매핑. 불확실하면 사용자 확인 요청.

**3번작업 완료 후 교차검증**:
- 탭1·탭2·탭3 담보 금액 차이·누락 여부 교차 비교
- 추천탭(TAB_REC) 기준 pill(★추천/▼빈약/▲강화) 적용 여부 확인
- 1번파일 기준 화면 구조 검증 + 2번파일 기준 변수화 구조 검증
- 빌더 함수 반영 100% 적용 확인

### 3단계: replace.py 작성 (D작업 활용)
- `replace_jeonansu_reference.py`의 빌더 함수 **8개 시그니처 전체**를 그대로 복사하여 사용:
  - sc-wrap 빌더 5개 (cancer/brain/heart/surgery/injury)
  - cov-card·row 빌더 3개 (build_row / build_cov_card / build_tab_cov_list)
- **cov-card HTML 직접 작성 금지** — 반드시 `build_cov_card()` 호출로 생성
- **row HTML 직접 작성 금지** — 반드시 `build_row()` 호출로 생성
- PDF 데이터는 빌더 함수 **인자로만** 전달. 함수 내부 로직 수정 금지.
- TAB_REC 값은 '(추천)' 표기 탭 기준으로 설정 (min/mid/max)

### 4단계: HTML 생성
- base_template.html을 로드하여 replace.py 실행
- 파일명 규칙: `toss_insureport_{고객명}님_{생년월일YYYYMMDD}.html`
- 수정 시: `_01.html`, `_02.html` … 순번 증가

### 5단계: B작업 자동 검증 (생성 후 반드시 실행, 생략 금지)
```bash
python3 verify.py <HTML파일경로>
```
- 11개 카테고리 전체 자동 체크
- 실패 항목 있으면 수정 후 재검증 (최대 3회)
- 3회 연속 실패 시 사용자에게 상황 보고
- **모든 항목 통과 전 다음 단계 진행 금지**

### 6단계: 스킨 5종 Artifact 미리보기 제시 및 선택 받기

**조건**: 5단계 verify.py 11/11 통과 후에만 진행

**핵심 방식**: HTML Artifact 파일을 채팅창에 스와이프 카드형으로 렌더링 (다운로드 불필요, 채팅창 내 표시). 사용자는 카드를 좌우로 넘겨보고 **숫자 1~5를 채팅 입력창에 타이핑**하여 선택.

**절차**:
1. **스킨 선택 Artifact HTML 생성**:
   - [내장] 스킨 시스템 섹션의 "Artifact 스와이프 카드 템플릿" 코드를 사용
   - 실제 고객명·추천 플랜 데이터(플랜명·가격·완성도 등)를 템플릿 변수에 삽입
   - 파일 확장자: `.html`
   - 경로: `/mnt/user-data/outputs/skin_preview_{고객명}님.html`

2. **Artifact로 제시**:
   - `create_file` 툴로 HTML 생성
   - `present_files`로 렌더링 (Artifact 방식 — 채팅창 내 직접 표시)

3. **사용자에게 안내 메시지**:
   - "좌우로 카드를 넘겨보시고, 적용할 스킨 번호(1~5)를 채팅창에 입력해주세요"

4. **사용자 답변 대기**

**주의**:
- Artifact에는 축약 목업만 포함 (실제 리포트 전체 HTML은 4MB라 너무 큼)
- Artifact는 "선택용 미리보기" 전용 — 실제 최종 파일은 7단계에서 풀 버전으로 전달
- `wkhtmltoimage`/PIL 사용 금지 (구버전 방식, 제거됨)

**스킨 5종 정보**:
| 스킨 | 콘셉트 | 메인 색상 |
|---|---|---|
| 1 | 토스블루 (기본) | `#3182F6` |
| 2 | 베이지 | `#B08D57` |
| 3 | 스카이블루 | `#4DA8DA` |
| 4 | 핑크 | `#E8849E` |
| 5 | 다크 | `#0F1419` 배경 + `#6BA6FF` 포인트 |

### 7단계: 선택된 스킨 적용 및 최종 파일 전달

**조건**: 6단계에서 사용자가 스킨 번호(1~5) 선택 직후

**절차**:
1. 선택 번호가 1이면 그대로, 2~5면 원본 HTML의 `<body data-skin="1">`을 `<body data-skin="N">`으로 치환
2. outputs 폴더에 저장 (파일명은 스킨 번호 미포함)
   - `toss_insureport_{고객명}님_{생년월일YYYYMMDD}.html`
3. `present_files`로 즉시 사용자에게 전달
4. **재검증 금지** — 스킨은 CSS만 변경되므로 구조·데이터 무관. verify.py 재실행은 불필요·낭비
5. **Artifact 미리보기 파일은 삭제 권장** (임시 파일이므로)

**속도 우선 원칙**: 스킨 선택 후에는 지연 없이 바로 파일 전달. 추가 검증·분석 금지.

---

## ★ replace.py 작성 필수 규칙 (절대 임의 변경 금지)

1. **빌더 함수 필수 사용**: `replace_jeonansu_reference.py`의 빌더 함수 8개를 그대로 복사하여 사용.
   - sc-wrap 5개: build_cancer_sc / build_brain_sc / build_heart_sc / build_surgery_sc / build_injury_sc
   - cov-card·row 3개 (D작업): build_row / build_cov_card / build_tab_cov_list

2. **HTML 하드코딩 절대 금지**
   - sc-wrap: sc-wrap 빌더 5개로만 생성
   - cov-card: `build_cov_card()`로만 생성
   - row: `build_row()`로만 생성

3. **PDF 데이터는 인자로만 전달**. 함수 내부 로직 수정 금지.

4. **하드코딩 유지 항목** (빌더 함수 내부에 고정, 변경 금지):
   - `※ 질병·상해 수술 발생 시마다 매회 지급` (`build_cov_card(repeat_notice=True)`)
   - 질병수술비 1–5종 분류표 (`build_cov_card(surgery_table=True)`)
   - 치료방식 안내카드 (암/뇌혈관/심장 — 빌더 내부)
   - guarantee-info 블록 (암/뇌혈관/심장 — 빌더 내부)

5. **추천탭·탭버튼 active 일관 처리**: TAB_REC에 따라 `{{REC_PANEL_*}}`와 `{{REC_TAB_ACTIVE_*}}`를 동일 `_panel_map` 패턴으로 치환. → 구체 코드는 **A작업 매핑 섹션 참조**. verify.py #3에서 최종 검증.

6. **2번파일이 최종 기준**: 결과물은 2번파일과 동일한 변수화 구조 유지. 화면 올바름은 1번파일 기준 검증.

7. **생성 후 verify.py 실행**: → 워크플로우 5단계 참조

[트리거] 사용자가 "상담자료 교체"라고 입력했을 때만 이 스킬의 메인 워크플로우를 실행한다.
다른 어떤 문구에도 워크플로우로 반응하지 않는다.

[보조 트리거] 사용자가 **"용어를 보여줘"** 라고 입력한 경우 (정확히 이 문구 또는 "용어 보여줘", "용어보여줘"):
- 스킬 폴더의 `terms.html` 파일을 `/mnt/user-data/outputs/`로 복사
- `present_files` 툴로 사용자에게 제시
- 추가 설명 없이 짧게 "용어 정의입니다" 수준만 첨언
- 이 트리거는 스킬 메인 워크플로우와 무관. 단순 조회용이므로 양식 출력·PDF 요청·검증 등 어떤 작업도 수행하지 않음

```bash
# "용어를 보여줘" 트리거 처리 예시
cp /mnt/skills/user/report-skill/terms.html /mnt/user-data/outputs/terms.html
# 이후 present_files로 출력
```

[즉시 실행] 아래 양식을 출력하고 입력을 요청한다.

고객: [이름], [생년월일], [성별]
상품: [보험사명] [상품명]  ← 띄어쓰기 기준으로 첫 단어=COMPANY_NAME, 나머지 전체=PRODUCT_NAME
탭1 / 특이사항1: [플랜명] / 특이사항2: [완성도] / 특이사항3: [한줄요약] / 특이사항4: [추천의견]
탭2 / 특이사항1: [플랜명](추천) / 특이사항2: [완성도] / 특이사항3: [한줄요약] / 특이사항4: [추천의견]
탭3 / 특이사항1: [플랜명] / 특이사항2: [완성도] / 특이사항3: [한줄요약] / 특이사항4: [추천의견]
첨부: PDF 3개 한번에 첨부 (순서 무관)

※ 추천 뱃지는 특이사항1에 '(추천)'을 표기한 탭에 적용. 탭1/2/3 중 어느 탭이든 가능.
※ PDF는 순서 무관하게 3개를 한번에 첨부. Claude가 양식의 플랜명과 PDF 내용을 대조하여 탭1·탭2·탭3에 자동 매핑.

[양식+PDF 수신 후 실행 순서]

→ 워크플로우 2단계 참조 (PDF 3개 순차 처리 + 교차검증)

---

## [내장] A작업 — 빌더 함수 시그니처

replace.py 작성 시 아래 시그니처를 그대로 사용. 함수 내부 로직은 `replace_jeonansu_reference.py`에서 복사.

### sc-wrap 빌더 5개

```python
def fmt_amt(man_won):
    # 만원 단위 → 억원/만원 문자열 변환
    # 예: 2000 → '2,000만원', 20000 → '2억원'

def build_cancer_sc(
    tongham_unit=0, tongham_cnt=0,  # 통합암진단비: 부위별 단가, 개수
    ilban_diag=0,                    # 일반암진단비
    yusa_diag=0,                     # 유사암진단비
    hiclass_tx=0,                    # 하이클래스 암주요치료비
    hiclass_chemo=0,                 # 하이클래스 항암약물치료비
    jungipja=0,                      # 항암 중입자방사선치료비
    pyokjeok=0,                      # 표적항암약물허가 치료비
    sep='·',                         # sc-card3 구분자
    tongham_note='',                 # 통합암 sc-detail 앞 메모
)

def build_brain_sc(diag=0, surg=0, icu=0, gwanhyeol=0, bigwanhyeol=0,
                   neuro_surg=0, hyeoljeon=0, note='')
# diag: 뇌혈관질환진단비 / surg: 상급종합 순환계 특정치료비(수술)
# icu: 중환자실 / gwanhyeol/bigwanhyeol: 2대주요기관 관혈/비관혈
# neuro_surg: 뇌혈관질환수술비 / hyeoljeon: 혈전용해(합산 제외, 별도 표기)

def build_heart_sc(diag=0, bujeongmaek=0, surg=0, icu=0, gwanhyeol=0,
                   bigwanhyeol=0, heart_surg=0, hyeoljeon=0, note='')
# diag: 허혈성심장진단비 / bujeongmaek: 심장부정맥
# heart_surg: 허혈성심장질환수술비 / hyeoljeon: 혈전용해(별도 표기)

def build_surgery_sc(disease_min=0, disease_max=0, injury_min=0, injury_max=0,
                     disease_detail='', injury_detail='')

def build_injury_sc(goljeol_diag=0, daegoljeol_diag=0, goljeol_surg=0, daegoljeol_surg=0,
                    gips=0, hwasang_diag=0, hwasang_surg=0, icu_amt=0)
# icu_amt: 상해중환자실(sc-amt 제외, 별도 표기)
```

### 흔한 실수 경고
- **pyokjeok 중복 텍스트**: pyokjeok 인자에 부위별 합산액 전달 시 "전액본인부담 ~" 텍스트가 중복 노출됨. 부위별 표시는 row 담보상세로 넘기고 pyokjeok=0으로 두는 것이 안전.
- **뇌/심 공용 담보**: 특정순환계질환주요치료비는 뇌·심장 양쪽에 적용됨. `build_brain_sc(surg=X)` + `build_heart_sc(surg=X)` 동일값 전달.
- **tongham vs ilban**: 둘 다 전달하면 tongham 우선 적용됨. 택1하여 사용.

### TAB_REC 동적 패널·탭버튼 매핑 (replace.py 필수 포함)

panel과 tab-btn 모두 동일한 `_panel_map` 패턴으로 일관 처리:

```python
_panel_map = {'min': ('active','',''), 'mid': ('','active',''), 'max': ('','','active')}
_p = _panel_map.get(TAB_REC, ('','active',''))

# panel active (3개)
html = html.replace('{{REC_PANEL_MIN}}', _p[0])
html = html.replace('{{REC_PANEL_MID}}', _p[1])
html = html.replace('{{REC_PANEL_MAX}}', _p[2])

# tab-btn active (3개) — 동일 패턴
html = html.replace('{{REC_TAB_ACTIVE_MIN}}', _p[0])
html = html.replace('{{REC_TAB_ACTIVE_MID}}', _p[1])
html = html.replace('{{REC_TAB_ACTIVE_MAX}}', _p[2])
```

### 추천탭이 mid가 아닌 경우 diff-title 처리
```python
# panel-mid의 "REC_PLAN_NAME을 추천하는 이유" 텍스트는 panel-mid 고정
# TAB_REC='max'인 경우 panel-mid는 비추천탭이므로 텍스트 교체 필요
if TAB_REC == 'max':
    html = html.replace(
        f'{REC_PLAN_NAME}을 추천하는 이유',
        f'{REC_PLAN_NAME}(추천) 대비 줄어든 항목'
    )
elif TAB_REC == 'min':
    html = html.replace(
        f'{REC_PLAN_NAME}을 추천하는 이유',
        f'{REC_PLAN_NAME}(추천) 대비 강화된 항목'
    )
```

---

## [내장] B작업 — 자동 검증 (verify.py)

### 사용법
```bash
python3 verify.py <HTML파일>
python3 verify.py <HTML파일> --json  # JSON 리포트도 저장
```

### 11개 체크 카테고리
| # | 카테고리 | 체크 내용 |
|---|---|---|
| 1 | 플레이스홀더 정합성 | `{{...}}` 잔존 0개 |
| 2 | 개수 정합성 | cov-card 15 / panel 3 / tab-btn 3 / ico 각 3 / sc-wrap 3~15 |
| 3 | **탭 active 정합성** ⭐ | panel.active 1개 + tab-btn.active 1개 + JS recTab 모두 동일 탭 |
| 4 | 추천탭 매핑 | 추천탭 "추천하는 이유" / 비추천탭 "대비 ..." |
| 5 | cov-card 순서 | 암→뇌→심→수→상 (ico-c,b,h,s,i) |
| 6 | 데이터 등장 | 고객명 3회+ / 회사명 / 가격 / 생년월일 |
| 7 | 하드코딩 유지 항목 | guarantee-info 3종×3 / 안내카드 / 매회지급 / 1-5종분류표 |
| 8 | footer·보장개시일 | COV_ONSET_*, Footer 변수, WAIVER_ITEMS 치환 |
| 9 | JSON 무결성 | cancer/brain/heart/surgery/injury 키 각 3회 |
| 10 | 빌더 함수 사용 흔적 | sc-title/sc-amt 구조 일관 (하드코딩 방지) |
| 11 | 특이 구조 재발 방지 | tab-btn/panel active 중복 없음, panel 내용 존재 |

### 오류 메시지 형식
```
❌ [#3 탭 active 정합성]
   기대값: panel.active 1개 = tab-btn.active 1개 = JS recTab
   실제값: panel.active=panel-max vs tab-btn.active=tab-mid (불일치)
   💡 수정가이드: replace.py에서 TAB_REC 기반 active 동기화 로직 확인.
```

### 실패 시 워크플로우
1. 검증 실패 → 수정가이드 참고해 replace.py 수정
2. HTML 재생성 → verify.py 재실행
3. 3회 연속 실패 시 사용자에게 보고 (임의 우회 금지)

---

## [내장] C작업 — base_template 구조 요약

`base_template.html` 전체를 view하지 않아도 아래만 알면 대부분의 작업 가능.

### 변수 목록 (카테고리별)

**패널/추천탭**
- `{{REC_PANEL_MIN/MID/MAX}}` — TAB_REC에 따라 'active' 또는 '' (panel 3개)
- `{{REC_TAB_ACTIVE_MIN/MID/MAX}}` — TAB_REC에 따라 'active' 또는 '' (tab-btn 3개, panel과 동일 패턴)
- `{{TAB_REC}}`, `{{REC_PLAN_NAME}}`, `{{REC_CHIPS}}`
- `{{NON_REC_TITLE_MIN/MAX}}`, `{{NON_REC_CHIPS_MIN/MAX}}`

**고객 정보** (6개)
- `{{CUSTOMER_NAME}}` `{{CUSTOMER_BIRTH}}` `{{CUSTOMER_GENDER}}` `{{CUSTOMER_AGE}}` `{{CUSTOMER_JOB}}` `{{COVERAGE_END_DATE}}`

**상품 정보** (2개)
- `{{COMPANY_NAME}}` `{{PRODUCT_NAME}}`

**탭 정보** (15개 + 진행 바 3개)
- `{{TAB1~3_PLAN_NAME/PRICE/DESC/OPINION/COMPLETE}}`
- `{{TAB1~3_PROG_WIDTH}}` — 완성도 진행 바 너비 (예: "25%", "80%", "100%"). TAB_COMPLETE 문구와 시각적 일치 필수.

**보장 내용** (6개)
- `{{TAB1~3_COV_LIST}}` `{{TAB1~3_COVERAGE_JSON}}`

**보장개시일** (12개)
- `{{COV_ONSET_CANCER_VAL/SUB}}` `{{COV_ONSET_CANCER_TX_VAL/SUB}}`
- `{{COV_ONSET_BRAIN_HEART_VAL/SUB}}` `{{COV_ONSET_CIRC_VAL/SUB}}`
- `{{COV_ONSET_SURG_VAL/SUB}}` `{{COV_ONSET_INJ_VAL/SUB}}`

**하단 안내** (4개)
- `{{WAIVER_ITEMS}}` `{{NOTICE_HEALTH_DISCOUNT}}` `{{NOTICE_EXTRA_DISCOUNT}}` `{{NOTICE_EXTRA}}`

**푸터** (4개)
- `{{COMPANY_CS_NUMBER}}` `{{DISPUTE_ORG}}` `{{DISPUTE_NUMBER}}` `{{ISSUE_DATE}}`

### ★ 예외 구조 — 반드시 숙지 (변수 목록 외 별도 처리)

#### A. panel-mid diff-title 하드코딩 (line 1067)
```html
<div class="diff-title" id="diff-title-mid">{{REC_PLAN_NAME}}을 추천하는 이유</div>
```
- 텍스트 "을 추천하는 이유"가 panel-mid에 **고정 문자열**로 있음
- TAB_REC != 'mid'인 경우 panel-mid는 비추천탭 → 텍스트 교체 필요
- 예:
  ```python
  if TAB_REC == 'max':
      html = html.replace(f'{REC_PLAN_NAME}을 추천하는 이유',
                          f'{REC_PLAN_NAME}(추천) 대비 줄어든 항목')
  elif TAB_REC == 'min':
      html = html.replace(f'{REC_PLAN_NAME}을 추천하는 이유',
                          f'{REC_PLAN_NAME}(추천) 대비 강화된 항목')
  ```

#### B. 하드코딩 유지 항목 (빌더 함수 내부에 위치)
- guarantee-info cancer/brain/heart-guarantee → 각 sc-wrap 빌더에 내장
- 치료방식 안내카드 → sc-wrap 빌더에 내장
- 1-5종 분류표 → `build_cov_card(surgery_table=True)` 옵션
- 매회 지급 문구 → `build_cov_card(repeat_notice=True)` 옵션

#### C. JS 영역 (2000+번 라인)
- `var recTab = '{{TAB_REC}}'` — 3회 등장, 모두 치환됨
- `applyRecTab()` 함수가 rec 클래스·pill·badge·게이지 색상 동적 적용

#### D. body data-skin 속성 (line 1034)
```html
<body data-skin="1">
```
- 기본 스킨1 (토스블루)로 하드코딩되어 배포됨
- 7단계에서 사용자가 2~5 선택 시 str.replace로 값만 변경
- 스킨 CSS는 `:root` 변수 오버라이드 방식 — 레이아웃·구조·JS 영향 없음

---

## [내장] 스킨 시스템 (5종)

### 스킨 적용 방식
```html
<body data-skin="1">   <!-- 스킨1: 토스블루 (기본) -->
<body data-skin="2">   <!-- 스킨2: 베이지 -->
<body data-skin="3">   <!-- 스킨3: 스카이블루 -->
<body data-skin="4">   <!-- 스킨4: 핑크 -->
<body data-skin="5">   <!-- 스킨5: 다크 -->
```

속성값 1자리만 변경하면 스킨 전환. CSS는 `base_template.html`의 `:root` 바로 뒤 블록에 `[data-skin="N"]` 선택자로 오버라이드 정의됨.

### 스킨 변환 파이썬 스니펫 (7단계 사용)
```python
# 원본 HTML 로드
with open(source_path, 'r', encoding='utf-8') as f:
    html = f.read()

# 선택된 스킨 번호(N)로 치환 (N: 사용자 입력 1~5)
if selected_skin != 1:
    html = html.replace('<body data-skin="1">', f'<body data-skin="{selected_skin}">', 1)

# 최종 경로에 저장
with open(output_path, 'w', encoding='utf-8') as f:
    f.write(html)
```

### 스킨 선택 Artifact 생성 명령 (6단계 사용)

**방식**: 축약 목업을 담은 HTML 파일을 Artifact로 렌더링. 다운로드 불필요·채팅창 내 표시·스와이프 카드·좌우 화살표·터치 스와이프 지원. 사용자는 번호(1~5)를 채팅에 입력.

```bash
python3 /mnt/skills/user/report-skill/skin_preview_gen.py \
  --customer "{고객명}" \
  --cust-info "{성별} · 만 {나이}세 · {연도}년생" \
  --rec-plan "{추천플랜명}" \
  --rec-price "{추천플랜가격_쉼표포함}" \
  --rec-complete "{추천플랜완성도문구}" \
  --tab1-name "{탭1플랜명}" --tab1-price "{탭1가격}원" \
  --tab2-name "{탭2플랜명}" --tab2-price "{탭2가격}원" \
  --tab3-name "{탭3플랜명}" --tab3-price "{탭3가격}원" \
  --tab-rec {1|2|3} \
  --output "/mnt/user-data/outputs/skin_preview_{고객명}님.html"
```

**예시 (김리아님, 탭3 추천)**:
```bash
python3 /mnt/skills/user/report-skill/skin_preview_gen.py \
  --customer "김리아" \
  --cust-info "여성 · 만 39세 · 1987년생" \
  --rec-plan "보장완성플랜" \
  --rec-price "156,012" \
  --rec-complete "필요한 보장 완성 (100%)" \
  --tab1-name "기존보장비교" --tab1-price "99,072원" \
  --tab2-name "부족보장추가플랜" --tab2-price "62,459원" \
  --tab3-name "보장완성플랜" --tab3-price "156,012원" \
  --tab-rec 3 \
  --output "/mnt/user-data/outputs/skin_preview_김리아님.html"
```

**생성 후 처리**:
1. `present_files`로 생성된 HTML 파일 제시 (Artifact 렌더링)
2. 안내 메시지: "좌우로 넘겨보시고 1~5 중 번호를 입력해주세요"
3. 사용자 응답 대기 → 7단계로

**축약 목업 구성 요소**: 헤더 · 고객명 카드 · 3탭 비교 (추천탭 강조) · 추천 플랜 카드 (가격·완성도·진행바) · 담보 3종 (암·뇌·심 아이콘). 실제 리포트는 아님 — 선택용 시각 참조.

### 스킨별 상세
| 스킨 | 콘셉트 | 메인 색상 | 배경 | 분위기 |
|---|---|---|---|---|
| 1 | 토스블루 (기본) | `#3182F6` | `#F9FAFB` | 신뢰·정통 |
| 2 | 베이지 | `#B08D57` | `#FAF5EC` (크림) | 따뜻·차분 |
| 3 | 스카이블루 | `#4DA8DA` | `#F0F8FC` | 청량·시원 |
| 4 | 핑크 | `#E8849E` | `#FDF6F8` | 부드러움·친근 |
| 5 | 다크 | `#6BA6FF` (포인트) | `#0F1419` (차콜) | 프리미엄·모던 |

**중요**:
- 스킨 적용 후 verify.py **재검증 금지** (낭비)
- 스킨은 CSS만 바뀌며 PDF 데이터·구조·JS에 영향 없음
- 7단계는 "선택 → 즉시 파일 전달" 원칙

---

## [내장] D작업 — cov-card·row 빌더 함수

### 함수 시그니처 (간병 카드 추가로 5종)

```python
def build_row(name, amount, pill=None, sub_detail=None):
    """단일 담보 row HTML 생성
    pill: None / 'rec'(★추천) / 'r'(▼빈약) / 'blue'(▲강화) / 'add'(✚보장추가)
    sub_detail: row 아래 추가 설명
    """

def build_cov_card(icon, category, sub, max_v, max_l,
                   sc_html='', rows=None,
                   repeat_notice=False, surgery_table=False):
    """카테고리별 cov-card 전체 HTML 생성
    icon: ICON_CANCER/BRAIN/HEART/SURGERY/INJURY/CARE 상수 사용
    sc_html: sc-wrap 빌더(build_cancer_sc 등) 반환값
    rows: build_row() 결과 리스트
    repeat_notice: 매회 지급 문구 포함 (주로 surgery)
    surgery_table: 1-5종 분류표 포함 (surgery만 True)
    """

def build_tab_cov_list(cards):
    """5개 또는 6개 cov-card를 받아 탭 COV_LIST 변수값 생성
    - 5개: cancer → brain → heart → surgery → injury (기본)
    - 6개: cancer → brain → heart → surgery → injury → care (간병 포함)
    순서 자동 검증
    """

def classify_care_group(name, amount_man):
    """간병 담보의 그룹 분류 (1/2/3)
    amount_man: 가입금액 (만원 단위 정수)
    우선순위: 그룹3 예외(5만원+간호/통합) → 그룹1(15만원 or 상급종합/종합) → 그룹2(5/3/6) → 그룹3(7/10)
    """

def is_care_181plus(name):
    """담보명이 181일이상인지 판별 (True면 중요보장 합산 제외)"""

def build_care_card(care_rows_180, care_rows_181=None, tab_type='rec'):
    """간병 cov-card 전체 HTML 생성
    care_rows_180: 180일한도 담보 (dict 리스트, keys: name/amount/amount_man/pill/sub_detail)
    care_rows_181: 181일이상 담보 (동일 형식, 합산 제외·나열만)
    - 그룹 1/2/3 자동 분류
    - 그룹1 내부 정렬: 15만원 먼저 → 상급종합/종합병원 담보
    - 대표금액(max_v): 180일한도 그룹1 최대값
    """

# 아이콘 상수
ICON_CANCER  = ('ico-c',    '🎗️')
ICON_BRAIN   = ('ico-b',    '🧠')
ICON_HEART   = ('ico-h',    '❤️')
ICON_SURGERY = ('ico-s',    '🔬')
ICON_INJURY  = ('ico-i',    '🛡️')
ICON_CARE    = ('ico-care', '🏥')
```

### 사용 예시 (간병 카드 포함)
```python
tab3_cancer_card = build_cov_card(
    icon=ICON_CANCER,
    category='암 관련 보장',
    sub='진단비 + 전이암 + 치료비 완성',
    max_v='3,000만원',
    max_l='일반암 진단',
    sc_html=sc_cancer_tab3,
    rows=[
        build_row('일반암 진단비', '3,000만원', pill='rec'),
        build_row('유사암 진단비(갑상선암 등)', '600만원'),
        build_row('표적항암약물허가 치료비 4종', '각 3,000만원', pill='rec'),
    ]
)

tab3_surgery_card = build_cov_card(
    icon=ICON_SURGERY,
    category='수술 관련',
    sub='1~5종 수술비 + 입원·통원',
    max_v='500만원', max_l='5종 수술',
    sc_html=sc_surgery_tab3,
    rows=[...],
    repeat_notice=True,      # 수술 카드 필수
    surgery_table=True,       # 수술 카드 필수
)

# 간병 카드 (간병 담보 존재 시에만 생성)
tab3_care_card = build_care_card(
    care_rows_180=[
        {'name': '간병인사용입원생활비(요양병원제외,연간180일한도)', 'amount': '15만원', 'amount_man': 15, 'pill': 'rec'},
        {'name': '간병인사용입원생활비(요양병원,연간180일한도)', 'amount': '5만원', 'amount_man': 5},
        {'name': '간병인사용입원생활비(상급종합병원,연간180일한도)', 'amount': '5만원', 'amount_man': 5},
        {'name': '간호간병통합서비스입원생활비(요양병원제외,연간180일한도)', 'amount': '7만원', 'amount_man': 7},
    ],
    care_rows_181=[
        {'name': '간병인사용입원생활비(요양,정신,한방병원제외,연간181일이상)', 'amount': '15만원', 'amount_man': 15},
        {'name': '간병인사용입원생활비(요양병원,연간181일이상)', 'amount': '3만원', 'amount_man': 3},
        {'name': '간호간병통합서비스입원생활비(요양,정신,한방병원제외,연간181일이상)', 'amount': '7만원', 'amount_man': 7},
    ],
    tab_type='rec'
)

# 5개(기본) 또는 6개(간병 포함) 전달
tab3_cov_list = build_tab_cov_list([
    tab3_cancer_card, tab3_brain_card, tab3_heart_card,
    tab3_surgery_card, tab3_injury_card, tab3_care_card  # 간병 카드는 선택
])
html = html.replace('{{TAB3_COV_LIST}}', tab3_cov_list)
```

### 카테고리별 row 개수 권장 범위
| 카테고리 | 일반 | 보장제외 탭 | 비고 |
|---|---|---|---|
| cancer | 15~30개 | 5~15개 | 통합암·전이암·표적항암 세분화로 많음 |
| brain | 3~6개 | 2~4개 | 진단비·수술비·혈전용해·순환계 |
| heart | 3~7개 | 2~4개 | 진단비·부정맥·수술비·혈전용해 |
| surgery | 6~10개 | 5~7개 | 1~5종 + 입원통원 + 상해 |
| injury (상해.기타) | 4~15개 | 3~4개 | 골절·중환자실·상해사망·후유장해 + **입원비 담보들** (180일한도 입원비도 포함) |
| care (간병) | 3~7개 | 0~3개 | 간병인·간호간병통합 × (180일한도/181일이상). **상품에 간병 담보 없으면 카드 생성 안 함** |

### pill 사용 규칙 (필수)
| 상황 | pill 값 | 색상 |
|---|---|---|
| 추천탭의 핵심 담보 | `'rec'` | 기본색 + ★추천 |
| 비추천탭(저렴)의 보장 없는 항목 | `'r'` | 빨강 + ▼빈약 |
| 비추천탭(저렴)의 약한 항목 | `'r'` | 빨강 + ▼빈약 |
| 비추천탭(비쌈)의 강화 항목 | `'blue'` | 파랑 + ▲강화 |
| 비추천탭(비쌈)의 새로 추가된 항목 | `'add'` | 파랑강조 + ✚보장추가 |
| 동일 금액 | `None` | 기본 |

### row 담보명 표기 규칙
- PDF 담보명 원형 **90% 이상** 유지 (임의 축약·변형 금지)
- 괄호 주석 `(진단후10년, 연1회)` 등은 유지
- 단, 너무 긴 경우 말단 「(간편할인형Ⅱ)」 등 제거 가능

---

## 하단 섹션 변수 상세

- `{{WAIVER_ITEMS}}`: `<div class="waiver-item"><div class="w-dot"></div>[사유]</div>` (PDF 납입면제 사유 전체)
- `{{NOTICE_HEALTH_DISCOUNT}}`: 건강고지형 할인 내용 (없으면 간편심사형 설명)
- `{{NOTICE_EXTRA_DISCOUNT}}`: 추가할인 (없으면 "별도 추가할인 없음")
- `{{NOTICE_EXTRA}}`: 갱신형·무해지형·주의사항 안내

## 보장개시일 변수
| 변수 | 대상 |
|---|---|
| COV_ONSET_CANCER_VAL/SUB | 암 진단비 보장개시/면책 |
| COV_ONSET_CANCER_TX_VAL/SUB | 암치료비 보장개시/감액 |
| COV_ONSET_BRAIN_HEART_VAL/SUB | 뇌혈관·심장 진단비 개시 |
| COV_ONSET_CIRC_VAL/SUB | 2대순환계치료비 개시 |
| COV_ONSET_SURG_VAL/SUB | 질병수술비 개시 |
| COV_ONSET_INJ_VAL/SUB | 상해수술비 개시 (면책없으면 "즉시보장") |

## Footer 변수
- `{{COMPANY_CS_NUMBER}}`: 고객센터 대표번호
- `{{DISPUTE_ORG}}` / `{{DISPUTE_NUMBER}}`: 생명보험협회(02-2262-6600) or 손해보험협회(02-3702-8500)
- `{{ISSUE_DATE}}`: 발행일 (YYYY.MM.DD)

## 비추천 탭 칩 규칙
- 저렴탭(▼): `<span class="chip chip-r">▼ [보장명] [금액] ([감소율]% 감소)</span>` / 없음: `▼ [보장명] (보장제외)`
- 비쌈탭(▲): `<span class="chip chip-g">▲ [보장명] [금액] ([증가율]% 보강)</span>`
- 추가: `<span class="chip chip-g" style="background:var(--toss-blue);color:white;font-weight:800;">✚ [보장명] [금액] (보장추가)</span>`
- 동일: `<span class="chip chip-gray">= [보장명] 동일</span>`

## [참조표 위치] 외부 mappings/ 폴더 분리 — v2 변경 ⭐

**v2부터 참조표는 SKILL.md 본문에서 분리되어 별도 폴더로 이동했습니다.** 누적되어도 SKILL.md 자체 크기는 변하지 않으며, 작업 시 필요한 보험사 파일만 선택적으로 읽어 속도 일정 유지.

### 참조표 폴더 구조
```
/mnt/skills/user/report-skill/mappings/
├── meta.json         ← 카테고리 체계·매핑 우선순위·미정의 처리 규칙 (고정)
├── categories.json   ← 담보명 → 카테고리 매핑 테이블 (누적)
├── labels.json       ← 표준 라벨 매핑 (누적)
├── care_rules.json   ← 간병 카테고리 구성 규칙 (고정)
└── insurers/         ← 보험사별 특이사항 (누적)
    └── hanwha.json   ← 한화손해보험 (3계열)
```

### 작업별 읽기 규칙

| 작업 | 읽어야 할 파일 |
|---|---|
| 새보험분석 (PDF 분석) | meta.json + categories.json + labels.json + 해당 보험사 insurers/{보험사}.json (없으면 신규 생성 대상) |
| 상담자료 교체 (리포트 생성) | meta.json + categories.json + labels.json + care_rules.json (간병 담보 시) + 해당 보험사 insurers/{보험사}.json |
| 일반 (전체 참조 필요 시) | mappings/ 전체 |

**원칙**: 작업 대상 보험사에 해당하는 insurers/{보험사}.json 만 읽음. 다른 보험사 파일은 읽지 않음 (속도 유지).

### 참조표 갱신 절차

새보험분석·상담자료 교체 작업 중 참조표 갱신이 필요한 경우:

1. 새 담보명 별칭 발견 → categories.json 또는 labels.json 의 해당 항목 names 배열에 추가
2. 새 카테고리 매핑 필요 → categories.json mappings 배열에 항목 추가
3. 새 보험사·상품 계열 → insurers/ 폴더에 새 JSON 파일 생성 (예: samsung.json) 또는 기존 파일에 product_lines 항목 추가
4. terms.html 의 참조표 섹션도 동일 내용으로 동기화 (필수 — 두 파일 항상 일치)

### 미정의 담보 처리 규칙

새보험분석·상담자료 교체 작업 중 참조표에 **없는 담보명**을 발견한 경우 — meta.json 의 `undefined_coverage_rule` 섹션 참조. 핵심 절차:
1. Claude가 1차 카테고리 추정
2. 사용자에게 매핑 제안 + 확인 요청
3. 사용자 확정 후 해당 JSON 파일에 추가
4. 자동 매핑 예외 2가지: "간병" 키워드 → care / 종합병원·중환자실 + 입원 조합 → injury

### 적용 범위 (간략)

- 모든 보험사 건강보험 상품 (한화·삼성·현대·DB·메리츠·KB·흥국·롯데 등)
- 상품 버전 무관 (YYMM 코드와 독립적으로 작동)
- 운전자·종신·어린이·실손 등 타 상품군은 자연 미적용

### 빌더 함수 (변경 없음)

- `build_care_card()` — `replace_jeonansu_reference.py`에 정의 (간병 카테고리 빌더, care_rules.json 기반)
- `classify_care_group()` — 간병 그룹 분류 보조 함수

---


## 중요 규칙
- 상담사 정보(송영종/010-9903-8702)는 절대 변경 금지
- 추천탭은 '(추천)' 표기 탭 기준 — 탭1/2/3 어느 탭이든 가능
- 모든 sc-wrap/cov-card/row 내용은 빌더 함수로만 생성 — **하드코딩 금지**
- PDF 담보명이 정확히 일치하지 않아도 유사하면 동일 담보로 판단
- PDF 월납 보험료 추출 불가 시 사용자 확인 요청
- getCoverageData JSON은 반드시 PDF 실제 데이터로 교체 (기본값 금지)
- 기존 HTML의 JavaScript 함수·CSS 스타일은 그대로 유지
