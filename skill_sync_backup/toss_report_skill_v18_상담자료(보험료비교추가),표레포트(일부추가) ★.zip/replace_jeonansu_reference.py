# -*- coding: utf-8 -*-
"""
replace_jeonansu_reference.py — 보장요약리포트 빌더 함수 참조 스크립트
====================================================================

[용도]
    "상담자료 교체" 트리거 구동 시, Claude가 새 고객용 replace.py를 작성할 때
    참조하는 빌더 함수 모음 (A작업·D작업의 함수 시그니처·구현 예시).

[주의 — 다른 클로드가 이 파일을 수정·실행할 때 반드시 확인]
    1. 이것은 "참조용" 스크립트다. 그대로 실행하지 말 것.
    2. 본 파일은 참조 양식 — 박제된 데이터는 placeholder([고객명]·[가입금액] 등)로 교체됨
       빌더 함수 사용 예시 + 변수 치환 예시 역할을 한다.
    3. 새 고객 작업 시 새 replace.py를 별도로 작성한다.
       (이 파일의 빌더 함수 시그니처·구현 패턴만 참조)
    4. 경로·고객 데이터·상품 데이터는 모두 예시값 — 새 케이스에서 교체 필수.
    5. 빌더 함수 시그니처·구현 패턴·자료구조는 임의로 변경 금지.
       변경 시 SKILL.md의 D작업 시그니처와 충돌 발생.

[수정 규칙]
    - 빌더 함수 추가·수정 → SKILL.md "[내장] D작업" 섹션 동시 동기화 필수
    - 새 보험사·상품 추가 → mappings/insurers/{보험사}.json 갱신
    - 본 파일의 양식 본문(빌더·HTML 구조·placeholder) 자체는 변경하지 않는 것 권장
      (변경 필요 시 새 reference 파일을 만들고 SKILL.md 갱신)
"""
import re

# 다른 클로드 사용 시: 실제 베이스템플릿 경로로 교체할 것
# 기본 경로: /mnt/skills/user/report-skill/base_template.html
# 작업 임시 경로: /home/claude/base_template.html (작업 폴더 복사 후 사용)
with open('/home/claude/base_template.html', 'r', encoding='utf-8') as f:
    html = f.read()

# ─────────────────────────────────────────────────────────────
# 추천 탭 설정 (TAB_REC: 'min' / 'mid' / 'max')
# ─────────────────────────────────────────────────────────────
TAB_REC = 'mid'  # 예시값 — 실제 작업 시 PDF 분석·고객 상담 결과로 결정

# ─────────────────────────────────────────────────────────────
# 고객/상품 기본 정보
# ─────────────────────────────────────────────────────────────
html = html.replace('{{CUSTOMER_NAME}}', '[고객명]')
html = html.replace('{{CUSTOMER_BIRTH}}', '[출생년도]')
html = html.replace('{{CUSTOMER_GENDER}}', '[성별]')
html = html.replace('{{CUSTOMER_AGE}}', '[보험나이]')
html = html.replace('{{CUSTOMER_JOB}}', '[직업·상해급수]')
html = html.replace('{{COVERAGE_END_DATE}}', '[보장만기일]')
html = html.replace('{{COMPANY_NAME}}', '삼성화재')
html = html.replace('{{PRODUCT_NAME}}', '건강보험 New내돈내삼1640 (10년고지형)')

# ─────────────────────────────────────────────────────────────
# 탭 기본 정보
# ─────────────────────────────────────────────────────────────
html = html.replace('{{TAB1_PLAN_NAME}}', '기존보험비교')
html = html.replace('{{TAB2_PLAN_NAME}}', '안심보장플랜')
html = html.replace('{{TAB3_PLAN_NAME}}', '프리미엄플랜')
html = html.replace('{{TAB1_PRICE}}', '[탭1_보험료]')
html = html.replace('{{TAB2_PRICE}}', '[탭2_보험료]')
html = html.replace('{{TAB3_PRICE}}', '[탭3_보험료]')
html = html.replace('{{TAB1_COMPLETE}}', '암진단비 2천만원 외 보장 전무')
html = html.replace('{{TAB2_COMPLETE}}', '필요보장 80% 구성')
html = html.replace('{{TAB3_COMPLETE}}', '필요한 보장 완성 (100%)')
html = html.replace('{{TAB1_DESC}}', '기존보험과 동일한 보장으로 구성 / 보험료 50% 이상 절감')
html = html.replace('{{TAB2_DESC}}', '핵심보장 완성 / 균형잡힌 보장 구성')
html = html.replace('{{TAB3_DESC}}', '완벽한 보장 완성 / 동일보장 보험료 최소 지출')
html = html.replace('{{TAB1_OPINION}}', '기존보험과 동일 / 필요보장이 사실상 전무하여 보험효율 매우 낮음')
html = html.replace('{{TAB2_OPINION}}', '대부분의 치료상황에서 충분한 보장을 받을 수 있는 기본 플랜')
html = html.replace('{{TAB3_OPINION}}', '필요한 보장이 100% 완성될 수 있는 플랜 / 향후 보험의 추가가입 불필요')
html = html.replace("'{{TAB_REC}}'", f"'{TAB_REC}'")
html = html.replace('{{TAB_REC}}', TAB_REC)

# 추천 탭 패널 active 클래스 동적 적용
_panel_map = {'min': ('active', '', ''), 'mid': ('', 'active', ''), 'max': ('', '', 'active')}
_p = _panel_map.get(TAB_REC, ('', 'active', ''))
html = html.replace('{{REC_PANEL_MIN}}', _p[0])
html = html.replace('{{REC_PANEL_MID}}', _p[1])
html = html.replace('{{REC_PANEL_MAX}}', _p[2])
html = html.replace('{{REC_PLAN_NAME}}', '안심보장플랜')

# ─────────────────────────────────────────────────────────────
# DIFF 제목
# ─────────────────────────────────────────────────────────────
html = html.replace('{{NON_REC_TITLE_MIN}}', '기존보험비교 대비 줄어든 항목')
html = html.replace('{{NON_REC_TITLE_MAX}}', '프리미엄플랜 대비 강화된 항목')

# ─────────────────────────────────────────────────────────────
# REC_CHIPS (탭2 추천 플랜 핵심보장)
# ─────────────────────────────────────────────────────────────
rec_chips = """<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>"""
html = html.replace('{{REC_CHIPS}}', rec_chips)

# ─────────────────────────────────────────────────────────────
# NON_REC_CHIPS_MIN (탭1 - 추천보다 저렴, 빨간칩)
# ─────────────────────────────────────────────────────────────
non_rec_chips_min = """<span class="chip chip-r">[칩본문]</span>
<span class="chip chip-r">[칩본문]</span>
<span class="chip chip-r">[칩본문]</span>
<span class="chip chip-r">[칩본문]</span>
<span class="chip chip-r">[칩본문]</span>
<span class="chip chip-r">[칩본문]</span>"""
html = html.replace('{{NON_REC_CHIPS_MIN}}', non_rec_chips_min)

# ─────────────────────────────────────────────────────────────
# NON_REC_CHIPS_MAX (탭3 - 추천보다 비쌈, 초록칩)
# ─────────────────────────────────────────────────────────────
non_rec_chips_max = """<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>
<span class="chip chip-g">[칩본문]</span>"""
html = html.replace('{{NON_REC_CHIPS_MAX}}', non_rec_chips_max)

# ═════════════════════════════════════════════════════════════
# SC-WRAP 빌더 함수들 (PDF 데이터 → sc-wrap HTML 동적 생성)
# 모든 함수는 인자로 받은 담보 데이터만 사용 (하드코딩 없음)
# ═════════════════════════════════════════════════════════════

def fmt_amt(man_won):
    """만원 단위 숫자를 억원/만원 단위 문자열로 변환"""
    if man_won >= 10000:
        uk = man_won // 10000
        rem = man_won % 10000
        return f'{uk}억원' if rem == 0 else f'{uk}억 {rem:,}만원'
    return f'{man_won:,}만원'

def build_cancer_sc(
    tongham_unit=0, tongham_cnt=0,
    ilban_diag=0,
    yusa_diag=0,
    hiclass_tx=0,
    hiclass_chemo=0,
    jungipja=0,
    pyokjeok=0,
    rec_tab='',
    this_tab='',
    sep='·',
    tongham_note='',                 # 통합암 sc-detail 앞에 추가할 메모 (예: '추천플랜 대비 1,000만원 추가. ')
):
    """암 관련 sc-wrap HTML 생성"""
    cards = ''

    # ── sc-card 1: 진단비
    if tongham_unit > 0 and tongham_cnt > 0:
        total = tongham_unit * tongham_cnt
        amt = f'최대 {fmt_amt(tongham_unit)}'
        detail = f'부위별 통합암진단비. 전이 포함 보장. {tongham_note}· {tongham_cnt}개 부위 합산 최대 {fmt_amt(total)}'
        # 추천탭 대비 비교 메모 (최대탭인 경우)
        if rec_tab and this_tab and rec_tab != this_tab:
            rec_unit = tongham_unit  # 기본값
            # 추천보다 높으면 추가 표시
        cards += f'      <div class="sc-card"><div class="sc-title">일반암 진단 시</div><div class="sc-amt">{amt}</div><div class="sc-detail">{detail}</div></div>\n'
    elif ilban_diag > 0:
        detail = f'유사암(갑상선암·기타피부암 등)은 {fmt_amt(yusa_diag)} 지급' if yusa_diag > 0 else ''
        cards += f'      <div class="sc-card"><div class="sc-title">일반암 진단 시</div><div class="sc-amt">{fmt_amt(ilban_diag)}</div><div class="sc-detail">{detail}</div></div>\n'

    # ── sc-card 2: 치료비 (하이클래스)
    tx_total = hiclass_tx + hiclass_chemo
    if tx_total > 0:
        detail = f'하이클래스 암특정치료비 {fmt_amt(hiclass_tx)} + 하이클래스 항암약물치료비 {fmt_amt(hiclass_chemo)} (각 연 1회)'
        cards += f'      <div class="sc-card"><div class="sc-title">암 치료 중 (진단 후 10년간)</div><div class="sc-amt">최대 {fmt_amt(tx_total)}/년</div><div class="sc-detail">{detail}</div></div>\n'

    # ── sc-card 3: 중입자/표적 (하나라도 있으면)
    if jungipja > 0 or pyokjeok > 0:
        j_part = f'항암 중입자방사선 치료비 {fmt_amt(jungipja)} (최초 1회)' if jungipja > 0 else ''
        p_part = f'표적항암약물허가 치료비 {fmt_amt(pyokjeok)} {sep} 전액본인부담 표적항암약물허가 치료비 {fmt_amt(pyokjeok)} (각 최초 1회, 갱신형)' if pyokjeok > 0 else ''
        parts = [x for x in [j_part, p_part] if x]
        detail = f' {sep} '.join(parts)
        j_str = f'중입자 {fmt_amt(jungipja)}' if jungipja > 0 else ''
        p_str = f'표적 {fmt_amt(pyokjeok)}' if pyokjeok > 0 else ''
        amt_parts = [x for x in [j_str, p_str] if x]
        cards += f'      <div class="sc-card"><div class="sc-title">항암 중입자방사선 {sep} 표적항암약물 치료</div><div class="sc-amt">{f" {sep} ".join(amt_parts)}</div><div class="sc-detail">{detail}</div></div>\n'

    if not cards:
        return ''

    # ── 치료방식 notice (항상 노출)
    notice = '      <div class="sc-card" style="background:rgba(49,130,246,0.05);"><div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 상이</div><div class="sc-detail">항암방사선·항암약물·표적항암·CAR-T 등 치료방식에 따라 추가 보장금액이 달라질 수 있습니다.</div></div>\n'

    # ── guarantee-info
    has_tx = tx_total > 0 or tongham_cnt > 0
    if has_tx:
        gi = (
            '      <div class="guarantee-info cancer-guarantee">\n'
            '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
            '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">암보장을 받은 후에도, 2번째·3번째 암도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
            '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">암 보장을 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
            '      </div>'
        )
    else:
        gi = (
            '      <div class="guarantee-info cancer-guarantee">\n'
            '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">암 보장을 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
            '      </div>'
        )

    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'


def build_brain_sc(diag=0, surg=0, icu=0, gwanhyeol=0, bigwanhyeol=0,
                   neuro_surg=0, hyeoljeon=0, note=''):
    """뇌혈관질환 sc-wrap HTML 생성"""
    cards = ''
    if diag > 0:
        cards += (f'      <div class="sc-card"><div class="sc-title">뇌혈관질환 진단 시</div>'
                  f'<div class="sc-amt">{fmt_amt(diag)}</div>'
                  f'<div class="sc-detail">뇌졸중 포함 모든 뇌혈관질환 진단 확정 시 지급 (최초 1회){note}</div></div>\n')
    tx_total = surg + icu + gwanhyeol + bigwanhyeol + neuro_surg
    if tx_total > 0:
        parts = []
        if surg > 0:         parts.append(f'상급종합병원 순환계질환 특정치료비(수술) {fmt_amt(surg)}')
        if icu > 0:          parts.append(f'중환자실 {fmt_amt(icu)}')
        if gwanhyeol > 0:    parts.append(f'2대주요기관 관혈수술비 {fmt_amt(gwanhyeol)}')
        if bigwanhyeol > 0:  parts.append(f'2대주요기관 비관혈수술비 {fmt_amt(bigwanhyeol)}')
        if neuro_surg > 0:   parts.append(f'뇌혈관질환수술비 {fmt_amt(neuro_surg)}')
        tx_detail = ' + '.join(parts)
        if hyeoljeon > 0:    tx_detail += f' / 혈전용해치료비(뇌경색증) {fmt_amt(hyeoljeon)} 별도'
        cards += (f'      <div class="sc-card"><div class="sc-title">뇌혈관질환 치료 중 (진단 후)</div>'
                  f'<div class="sc-amt">최대 {fmt_amt(tx_total)}</div>'
                  f'<div class="sc-detail">{tx_detail}</div></div>\n')
    notice = ('      <div class="sc-card" style="background:rgba(49,130,246,0.05);">'
              '<div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 보장금액 상이</div>'
              '<div class="sc-detail">수술 여부, 혈전용해치료 적용 여부 등 치료 방식에 따라 실제 수령 금액이 달라질 수 있습니다.</div></div>\n') if tx_total > 0 else ''
    if tx_total > 0:
        gi = ('      <div class="guarantee-info brain-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">뇌혈관 치료에 대한 보장을 받은 후에도, 2번째 3번째 질환으로도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">뇌혈관 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    else:
        gi = ('      <div class="guarantee-info brain-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">뇌혈관 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'


def build_heart_sc(diag=0, bujeongmaek=0, surg=0, icu=0, gwanhyeol=0,
                   bigwanhyeol=0, heart_surg=0, hyeoljeon=0, note=''):
    """심장질환 sc-wrap HTML 생성"""
    cards = ''
    if diag > 0:
        bj = f' / 심장부정맥 진단비 {fmt_amt(bujeongmaek)} 포함' if bujeongmaek > 0 else ''
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 진단 시</div>'
                  f'<div class="sc-amt">{fmt_amt(diag)}</div>'
                  f'<div class="sc-detail">허혈성심장질환 진단 확정 시 지급 (최초 1회){bj}{note}</div></div>\n')
    tx_total = surg + icu + gwanhyeol + bigwanhyeol + heart_surg
    if tx_total > 0:
        parts = []
        if surg > 0:         parts.append(f'상급종합병원 순환계질환 특정치료비(수술) {fmt_amt(surg)}')
        if icu > 0:          parts.append(f'중환자실 {fmt_amt(icu)}')
        if gwanhyeol > 0:    parts.append(f'2대주요기관 관혈수술비 {fmt_amt(gwanhyeol)}')
        if bigwanhyeol > 0:  parts.append(f'2대주요기관 비관혈수술비 {fmt_amt(bigwanhyeol)}')
        if heart_surg > 0:   parts.append(f'허혈성심장질환수술비 {fmt_amt(heart_surg)}')
        tx_detail = ' + '.join(parts)
        if hyeoljeon > 0:    tx_detail += f' / 혈전용해치료비(급성심근경색증) {fmt_amt(hyeoljeon)} 별도'
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 치료 중 (진단 후)</div>'
                  f'<div class="sc-amt">최대 {fmt_amt(tx_total)}</div>'
                  f'<div class="sc-detail">{tx_detail}</div></div>\n')
    notice = ('      <div class="sc-card" style="background:rgba(49,130,246,0.05);">'
              '<div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 보장금액 상이</div>'
              '<div class="sc-detail">수술 여부, 혈전용해치료 적용 여부 등 치료 방식에 따라 실제 수령 금액이 달라질 수 있습니다.</div></div>\n') if tx_total > 0 else ''
    if tx_total > 0:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">심장질환 치료에 대한 보장을 받은 후에도, 2번째 3번째 질환으로도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    else:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'
    if diag > 0:
        bj = f' / 심장부정맥 진단비 {fmt_amt(bujeongmaek)} 포함' if bujeongmaek > 0 else ''
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 진단 시</div>'
                  f'<div class="sc-amt">{fmt_amt(diag)}</div>'
                  f'<div class="sc-detail">허혈성심장질환 진단 확정 시 지급 (최초 1회){bj}{note}</div></div>\n')
    tx_total = surg + icu + gwanhyeol + bigwanhyeol + heart_surg
    if tx_total > 0:
        parts = []
        if surg > 0:         parts.append(f'상급종합병원 순환계질환 특정치료비(수술) {fmt_amt(surg)}')
        if icu > 0:          parts.append(f'중환자실 {fmt_amt(icu)}')
        if gwanhyeol > 0:    parts.append(f'2대주요기관 관혈수술비 {fmt_amt(gwanhyeol)}')
        if bigwanhyeol > 0:  parts.append(f'2대주요기관 비관혈수술비 {fmt_amt(bigwanhyeol)}')
        if heart_surg > 0:   parts.append(f'허혈성심장질환수술비 {fmt_amt(heart_surg)}')
        tx_detail = ' + '.join(parts)
        if hyeoljeon > 0:    tx_detail += f' / 혈전용해치료비(급성심근경색증) {fmt_amt(hyeoljeon)} 별도'
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 치료 중 (진단 후)</div>'
                  f'<div class="sc-amt">최대 {fmt_amt(tx_total)}</div>'
                  f'<div class="sc-detail">{tx_detail}</div></div>\n')
    notice = ('      <div class="sc-card" style="background:rgba(49,130,246,0.05);">'
              '<div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 보장금액 상이</div>'
              '<div class="sc-detail">수술 여부, 혈전용해치료 적용 여부 등 치료 방식에 따라 실제 수령 금액이 달라질 수 있습니다.</div></div>\n') if tx_total > 0 else ''
    has_tx = tx_total > 0
    if has_tx:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">심장질환 치료에 대한 보장을 받은 후에도, 2번째 3번째 질환으로도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    else:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'


def build_surgery_sc(disease_min=0, disease_max=0, injury_min=0, injury_max=0,
                     disease_detail='', injury_detail=''):
    """수술 sc-wrap HTML 생성"""
    cards = ''
    if disease_max > 0:
        amt = f'{fmt_amt(disease_min)} ~ 최대 {fmt_amt(disease_max)}' if disease_min < disease_max else f'최대 {fmt_amt(disease_max)}'
        cards += (f'      <div class="sc-card"><div class="sc-title">질병으로 수술을 받는 경우</div>'
                  f'<div class="sc-amt">{amt}</div>'
                  f'<div class="sc-detail">{disease_detail}</div></div>\n')
    if injury_max > 0:
        amt = f'{fmt_amt(injury_min)} ~ 최대 {fmt_amt(injury_max)}' if injury_min < injury_max else f'최대 {fmt_amt(injury_max)}'
        cards += (f'      <div class="sc-card"><div class="sc-title">사고(상해)로 수술을 받는 경우</div>'
                  f'<div class="sc-amt">{amt}</div>'
                  f'<div class="sc-detail">{injury_detail}</div></div>\n')
    if not cards:
        return ''
    return f'    <div class="sc-wrap">\n{cards}    </div>\n'


def build_injury_sc(goljeol_diag=0, daegoljeol_diag=0, goljeol_surg=0, daegoljeol_surg=0,
                    gips=0, hwasang_diag=0, hwasang_surg=0, icu_amt=0):
    """상해·기타 sc-wrap HTML 생성"""
    items = []
    if goljeol_diag > 0:    items.append(('골절 진단비', goljeol_diag))
    if daegoljeol_diag > 0: items.append(('5대골절 진단비', daegoljeol_diag))
    if goljeol_surg > 0:    items.append(('골절 수술비', goljeol_surg))
    if daegoljeol_surg > 0: items.append(('5대골절 수술비', daegoljeol_surg))
    if gips > 0:            items.append(('깁스치료비', gips))
    if hwasang_diag > 0:    items.append(('화상 진단비', hwasang_diag))
    if hwasang_surg > 0:    items.append(('화상 수술비', hwasang_surg))
    if not items:
        return ''
    amts = [a for _, a in items]
    mn, mx = min(amts), max(amts)
    amt_str = f'{fmt_amt(mn)} ~ 최대 {fmt_amt(mx)}' if mn < mx else f'최대 {fmt_amt(mx)}'
    detail = ' / '.join([f'{n} {fmt_amt(a)}' for n, a in items])
    if icu_amt > 0:
        detail += f' (상해 중환자실 입원일당 {fmt_amt(icu_amt)}/일 별도)'
    card = (f'      <div class="sc-card"><div class="sc-title">골절 · 화상 보장</div>'
            f'<div class="sc-amt">{amt_str}</div>'
            f'<div class="sc-detail">{detail}</div></div>\n')
    return f'    <div class="sc-wrap">\n{card}    </div>\n'


# ═════════════════════════════════════════════════════════════
# D작업 - cov-card·row 빌더 함수 (replace.py HTML 직접 작성 대체)
# ═════════════════════════════════════════════════════════════

# 1-5종 분류표 (하드코딩 고정, surgery cov-card에서만 사용)
_SURGERY_TABLE_HTML = '''    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>'''


def build_row(name, amount, pill=None, sub_detail=None):
    """단일 담보 row HTML 생성

    Args:
        name: 담보명 (PDF 원형 유지 권장)
        amount: 가입금액 문자열 (예: '3,000만원', '미가입', '10만원/일')
        pill: None / 'rec' (★추천) / 'r' (▼빈약) / 'blue' (▲강화) / 'add' (✚보장추가)
        sub_detail: row 아래 추가 설명 문자열 (선택)

    Returns:
        <div class="row">...</div> HTML 문자열
    """
    # pill별 스타일 결정
    pill_html = ''
    name_color = ''
    val_color = ''

    if pill == 'rec':
        pill_html = '<span class="pill pill-rec">★추천</span>'
    elif pill == 'r':
        pill_html = '<span class="pill pill-r">▼빈약</span>'
        name_color = ' style="color:var(--toss-red);"'
        val_color = ' style="color:var(--toss-red);"'
    elif pill == 'blue':
        pill_html = '<span class="pill pill-blue">▲강화</span>'
        name_color = ' style="color:var(--toss-blue);"'
        val_color = ' style="color:var(--toss-blue);"'
    elif pill == 'add':
        pill_html = '<span class="pill pill-blue" style="background:var(--toss-blue);color:white;font-weight:800;">✚보장추가</span>'
        name_color = ' style="color:var(--toss-blue);"'
        val_color = ' style="color:var(--toss-blue);"'

    html = (f'    <div class="row">'
            f'<span class="row-name"{name_color}>[보장명]</span>'
            f'<div class="row-right">'
            f'<span class="row-val"{val_color}>[가입금액]</span>'
            f'{pill_html}'
            f'</div></div>')

    if sub_detail:
        html += f'\n    <div class="row-sub" style="font-size:11px;color:var(--gray-500);margin-top:-8px;margin-bottom:8px;padding-left:12px;">※ {sub_detail}</div>'

    return html + '\n'


def build_cov_card(icon, category, sub, max_v, max_l, sc_html='', rows=None,
                   repeat_notice=False, surgery_table=False):
    """카테고리별 cov-card 전체 HTML 생성

    Args:
        icon: ('ico-c','🎗️') 등 튜플 — 5종: ico-c/ico-b/ico-h/ico-s/ico-i
        category: "암 관련 보장" 등 카테고리명
        sub: cov-sub 서브타이틀
        max_v: cov-max-v (우측 상단 대표 금액, 예: '3,000만원')
        max_l: cov-max-l (라벨, 예: '일반암 진단' / '보장제외')
        sc_html: sc-wrap 빌더(build_cancer_sc 등)의 반환값
        rows: build_row() 결과 리스트
        repeat_notice: "매회 지급" 문구 포함 여부 (주로 surgery cov-card)
        surgery_table: 1-5종 분류표 포함 여부 (surgery cov-card만 True)

    Returns:
        <div class="cov-card reveal">...</div> HTML 문자열
    """
    if rows is None:
        rows = []
    icon_class, icon_emoji = icon

    rows_html = ''.join(rows)
    repeat_html = ''
    if repeat_notice:
        repeat_html = '    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>\n'
    table_html = ''
    if surgery_table:
        table_html = _SURGERY_TABLE_HTML + '\n'

    return (f'<div class="cov-card reveal">\n'
            f'  <div class="cov-hd ripple-host" onclick="tog(this)">\n'
            f'    <div class="cov-ico {icon_class}">{icon_emoji}</div>\n'
            f'    <div class="cov-hd-info"><div class="cov-cat">{category}</div><div class="cov-sub">[서브본문]</div></div>\n'
            f'    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>\n'
            f'    <div class="tog">▼</div>\n'
            f'  </div>\n'
            f'  <div class="cov-detail">\n'
            f'{sc_html}'
            f'    <div class="items-title">담보 상세 내역</div>\n'
            f'{rows_html}'
            f'{repeat_html}'
            f'{table_html}'
            f'  </div>\n'
            f'</div>\n')


def build_tab_cov_list(cards):
    """5개 또는 6개 cov-card를 받아 탭 COV_LIST 변수값 생성 (순서 검증 포함)

    Args:
        cards: build_cov_card() 결과 리스트
               - 5개: cancer → brain → heart → surgery → injury (간병 담보 없을 때)
               - 6개: cancer → brain → heart → surgery → injury → care (간병 담보 있을 때)

    Returns:
        cov-card들을 연결한 HTML 문자열

    Raises:
        ValueError: cov-card 순서가 잘못됐거나 개수가 5/6이 아닐 때
    """
    if len(cards) not in (5, 6):
        raise ValueError(f'cov-card는 반드시 5개(기본) 또는 6개(간병 포함)여야 합니다 (현재 {len(cards)}개). '
                         f'순서: cancer → brain → heart → surgery → injury [→ care]')

    expected_icons_base = ['ico-c', 'ico-b', 'ico-h', 'ico-s', 'ico-i']
    expected_icons = expected_icons_base + (['ico-care'] if len(cards) == 6 else [])
    icon_names = ['cancer', 'brain', 'heart', 'surgery', 'injury', 'care']

    for i, (card, expected) in enumerate(zip(cards, expected_icons)):
        if f'class="cov-ico {expected}"' not in card:
            raise ValueError(f'cov-card #{i+1}에 {expected} 아이콘이 없습니다. '
                             f'순서: ' + ' → '.join(
                                 f'{icon_names[j]}({expected_icons[j]})'
                                 for j in range(len(expected_icons))
                             ))

    return ''.join(cards)


# 아이콘 상수 (빈번히 사용)
ICON_CANCER  = ('ico-c', '🎗️')
ICON_BRAIN   = ('ico-b', '🧠')
ICON_HEART   = ('ico-h', '❤️')
ICON_SURGERY = ('ico-s', '🔬')
ICON_INJURY  = ('ico-i', '🛡️')
ICON_CARE    = ('ico-care', '🏥')


# ═════════════════════════════════════════════════════════════
# 간병 카드 전용 빌더 (신규)
# ═════════════════════════════════════════════════════════════

def classify_care_group(name, amount_man):
    """간병 담보의 그룹 분류 (1/2/3)

    Args:
        name: 담보명 문자열
        amount_man: 가입금액 (만원 단위 정수, 예: 15만원이면 15)

    Returns:
        1, 2, 3 중 하나

    분류 규칙 (우선순위 순):
        - 그룹 3 예외: 5만원 + 담보명에 "간호" 또는 "통합" 포함 → 그룹 3
        - 그룹 1: 15만원 OR 담보명에 "상급종합병원" 또는 "종합병원" 포함
        - 그룹 2: 5만원 / 3만원 / 6만원
        - 그룹 3: 7만원 / 10만원
    """
    has_care_keyword = ('간호' in name) or ('통합' in name)

    # 그룹 3 예외 규칙 먼저 체크 (5만원 + 간호/통합)
    if amount_man == 5 and has_care_keyword:
        return 3

    # 그룹 1: 15만원 OR 상급종합병원/종합병원 포함
    if amount_man == 15 or '상급종합병원' in name or '종합병원' in name:
        return 1

    # 그룹 2: 5만원 / 3만원 / 6만원
    if amount_man in (3, 5, 6):
        return 2

    # 그룹 3: 7만원 / 10만원
    if amount_man in (7, 10):
        return 3

    # 정의되지 않은 금액 — 사용자 확인 필요
    return None


def is_care_181plus(name):
    """담보명이 181일이상(연간 181일 이상) 담보인지 판별

    Returns: True이면 181일이상 (합산 제외, 나열만),
             False이면 180일한도 (중요보장 합산 포함)
    """
    return '181일이상' in name or '181일 이상' in name


def build_care_card(care_rows_180, care_rows_181=None, tab_type='rec'):
    """간병 cov-card 전체 HTML 생성

    Args:
        care_rows_180: 180일한도 담보 리스트, 각 원소는 dict:
                       {'name': str, 'amount': str (예: '15만원'), 'amount_man': int,
                        'pill': str or None, 'sub_detail': str or None}
        care_rows_181: 181일이상 담보 리스트 (동일 형식). None이면 빈 리스트.
        tab_type: 'rec' / 'low' / 'high' (탭 성격에 따른 pill 배치 참고용)

    Returns:
        간병 cov-card HTML 문자열

    동작:
        1. 180일한도 담보를 그룹1/2/3으로 분류
        2. 그룹1 → 그룹2 → 그룹3 순으로 row 생성 (중요보장 합산 포함)
        3. 181일이상 담보는 동일한 그룹 순서로 나열만 (합산 제외)
        4. 대표 금액(max_v) = 그룹1 최대 담보금액
    """
    if care_rows_181 is None:
        care_rows_181 = []

    # 1. 180일한도 담보 그룹 분류
    groups_180 = {1: [], 2: [], 3: []}
    for r in care_rows_180:
        g = classify_care_group(r['name'], r['amount_man'])
        if g is None:
            raise ValueError(f"간병 담보 '{r['name']}' (금액 {r['amount_man']}만원)의 "
                             f"그룹을 결정할 수 없습니다. 사용자 확인 필요.")
        groups_180[g].append(r)

    # 2. 그룹 1 내부 정렬: 15만원 먼저 → 상급종합병원/종합병원 담보
    def sort_group1(rows):
        g1_15 = [r for r in rows if r['amount_man'] == 15]
        g1_rest = [r for r in rows if r['amount_man'] != 15]
        return g1_15 + g1_rest

    groups_180[1] = sort_group1(groups_180[1])

    # 3. 181일이상도 동일 그룹 분류 (합산은 제외, 나열 순서만)
    groups_181 = {1: [], 2: [], 3: []}
    for r in care_rows_181:
        g = classify_care_group(r['name'], r['amount_man'])
        if g is None:
            raise ValueError(f"간병 담보(181일이상) '{r['name']}' (금액 {r['amount_man']}만원)의 "
                             f"그룹을 결정할 수 없습니다. 사용자 확인 필요.")
        groups_181[g].append(r)
    groups_181[1] = sort_group1(groups_181[1])

    # 4. row HTML 생성 (180일한도 먼저, 그룹 1 → 2 → 3 순)
    rows_html = []
    for g in (1, 2, 3):
        for r in groups_180[g]:
            rows_html.append(build_row(
                name=r['name'],
                amount=r['amount'],
                pill=r.get('pill'),
                sub_detail=r.get('sub_detail')
            ))

    # 5. 181일이상 담보 나열 (합산 제외 — row에 '나열만' 표시 권장)
    for g in (1, 2, 3):
        for r in groups_181[g]:
            sub = r.get('sub_detail') or ''
            sub_with_flag = (sub + ' · ' if sub else '') + '※ 연간 181일이상 담보 (합산 제외)'
            rows_html.append(build_row(
                name=r['name'],
                amount=r['amount'],
                pill=r.get('pill'),
                sub_detail=sub_with_flag
            ))

    # 6. 대표 금액 = 그룹1 최대 담보금액 (180일한도 기준)
    if groups_180[1]:
        max_r = max(groups_180[1], key=lambda x: x['amount_man'])
        max_v = max_r['amount']
        max_l = '간병 대표'
    else:
        # 그룹1이 없으면 그룹2에서 최대
        all_180 = groups_180[2] + groups_180[3]
        if all_180:
            max_r = max(all_180, key=lambda x: x['amount_man'])
            max_v = max_r['amount']
            max_l = '간병 대표'
        else:
            max_v = '-'
            max_l = '간병 없음'

    return build_cov_card(
        icon=ICON_CARE,
        category='간병 보장',
        sub='간병인 사용 + 간호간병통합서비스',
        max_v=max_v,
        max_l=max_l,
        sc_html='',  # 간병은 sc-wrap 별도 없음
        rows=rows_html,
        repeat_notice=False,
        surgery_table=False,
    )


# ═════════════════════════════════════════════════════════════
# D작업 함수 사용 예시 (주석, 실행되지 않음)
# ═════════════════════════════════════════════════════════════
"""
사용 예시 — 탭3(추천) 암 cov-card:

tab3_cancer_card = build_cov_card(
    icon=ICON_CANCER,
    category='암 관련 보장',
    sub='진단비 + 전이암 + 치료비 완성',
    max_v='3,000만원',
    max_l='일반암 진단',
    sc_html=sc_cancer_tab3,
    rows=[
        build_row('일반암 진단비', '3,000만원', pill='rec'),
        build_row('유사암 진단비(갑상선암·기타피부암 등)', '600만원'),
        build_row('표적항암약물허가 치료비 4종', '각 3,000만원', pill='rec'),
        # ... 이하 row 반복
    ]
)

# surgery cov-card는 repeat_notice=True, surgery_table=True 옵션 필수:
tab3_surgery_card = build_cov_card(
    icon=ICON_SURGERY,
    category='수술 관련',
    sub='1~5종 수술비 + 입원·통원',
    max_v='500만원',
    max_l='5종 수술',
    sc_html=sc_surgery_tab3,
    rows=[
        build_row('질병수술비Ⅱ(5종)', '500만원', pill='rec'),
        # ...
    ],
    repeat_notice=True,
    surgery_table=True
)

# 최종 탭 COV_LIST:
tab3_cov_list = build_tab_cov_list([
    tab3_cancer_card,  # ico-c
    tab3_brain_card,   # ico-b
    tab3_heart_card,   # ico-h
    tab3_surgery_card, # ico-s
    tab3_injury_card,  # ico-i
])
html = html.replace('{{TAB3_COV_LIST}}', tab3_cov_list)
"""


# ─────────────────────────────────────────────────────────────
# PDF 데이터 기반 sc-wrap 생성 (각 탭 PDF 본문 기반 인자 적용 의무)
# ─────────────────────────────────────────────────────────────
TAB_REC = 'mid'  # ← 스킬 구동 시 추천 탭에 맞게 변경

# ── 암
sc_cancer_tab1 = build_cancer_sc(ilban_diag=[탭1_일반암_가입금액(만원)], yusa_diag=[탭1_유사암_가입금액(만원)])
sc_cancer_tab2 = build_cancer_sc(tongham_unit=[탭2_통합암_부위별_가입금액(만원)], tongham_cnt=[탭2_통합암_부위별_갯수], hiclass_tx=[탭2_하이클래스_특정치료_가입금액(만원)], hiclass_chemo=[탭2_하이클래스_항암약물_가입금액(만원)], jungipja=[탭2_중입자_가입금액(만원)], pyokjeok=[탭2_표적항암_가입금액(만원)])
sc_cancer_tab3 = build_cancer_sc(tongham_unit=[탭3_통합암_부위별_가입금액(만원)], tongham_cnt=[탭3_통합암_부위별_갯수], hiclass_tx=[탭3_하이클래스_특정치료_가입금액(만원)], hiclass_chemo=[탭3_하이클래스_항암약물_가입금액(만원)], jungipja=[탭3_중입자_가입금액(만원)], pyokjeok=[탭3_표적항암_가입금액(만원)], sep='/', tongham_note='[탭3_본문]')

# ── 뇌혈관
sc_brain_tab1 = build_brain_sc()  # PDF에 본 항목 ❌ 시 양식. ✅ 시: build_brain_sc(diag=[가입금액(만원)], ...)
sc_brain_tab2 = build_brain_sc(diag=[탭2_뇌혈관진단_가입금액(만원)], surg=[탭2_뇌혈관수술_가입금액(만원)], icu=[탭2_뇌혈관ICU_가입금액(만원)], gwanhyeol=[탭2_관혈수술_가입금액(만원)], bigwanhyeol=[탭2_비관혈수술_가입금액(만원)], hyeoljeon=[탭2_혈전용해_가입금액(만원)])
sc_brain_tab3 = build_brain_sc(diag=[탭3_뇌혈관진단_가입금액(만원)], surg=[탭3_뇌혈관수술_가입금액(만원)], icu=[탭3_뇌혈관ICU_가입금액(만원)], gwanhyeol=[탭3_관혈수술_가입금액(만원)], bigwanhyeol=[탭3_비관혈수술_가입금액(만원)], hyeoljeon=[탭3_혈전용해_가입금액(만원)], note='[탭3_본문]')

# ── 심장
sc_heart_tab1 = build_heart_sc()  # PDF에 본 항목 ❌ 시 양식. ✅ 시: build_heart_sc(diag=[가입금액(만원)], ...)
sc_heart_tab2 = build_heart_sc(diag=[탭2_허혈성심장진단_가입금액(만원)], bujeongmaek=[탭2_부정맥_가입금액(만원)], surg=[탭2_심장수술_가입금액(만원)], icu=[탭2_심장ICU_가입금액(만원)], gwanhyeol=[탭2_관혈수술_가입금액(만원)], bigwanhyeol=[탭2_비관혈수술_가입금액(만원)], hyeoljeon=[탭2_혈전용해_가입금액(만원)])
sc_heart_tab3 = build_heart_sc(diag=[탭3_허혈성심장진단_가입금액(만원)], bujeongmaek=[탭3_부정맥_가입금액(만원)], surg=[탭3_심장수술_가입금액(만원)], icu=[탭3_심장ICU_가입금액(만원)], gwanhyeol=[탭3_관혈수술_가입금액(만원)], bigwanhyeol=[탭3_비관혈수술_가입금액(만원)], hyeoljeon=[탭3_혈전용해_가입금액(만원)])

# ── 수술
sc_surgery_tab1 = build_surgery_sc(
    disease_min=[탭1_질병수술_최소(만원)], disease_max=[탭1_질병수술_최대(만원)], injury_min=[탭1_상해수술_최소(만원)], injury_max=[탭1_상해수술_최대(만원)],
    disease_detail='[탭1_질병수술_본문]',
    injury_detail='[탭1_상해수술_본문]'
)
sc_surgery_tab2 = build_surgery_sc(
    disease_min=[탭2_질병수술_최소(만원)], disease_max=[탭2_질병수술_최대(만원)], injury_min=[탭2_상해수술_최소(만원)], injury_max=[탭2_상해수술_최대(만원)],
    disease_detail='[탭2_질병수술_본문]',
    injury_detail='[탭2_상해수술_본문]'
)
sc_surgery_tab3 = build_surgery_sc(
    disease_min=[탭3_질병수술_최소(만원)], disease_max=[탭3_질병수술_최대(만원)], injury_min=[탭3_상해수술_최소(만원)], injury_max=[탭3_상해수술_최대(만원)],
    disease_detail='[탭3_질병수술_본문]',
    injury_detail='[탭3_상해수술_본문]'
)

# ── 상해·기타
sc_injury_tab1 = build_injury_sc()  # PDF에 본 항목 ❌ 시 양식. ✅ 시: build_injury_sc(goljeol_diag=[가입금액(만원)], ...)
sc_injury_tab2 = build_injury_sc(goljeol_diag=[탭2_골절진단_가입금액(만원)], daegoljeol_diag=[탭2_5대골절진단_가입금액(만원)], goljeol_surg=[탭2_골절수술_가입금액(만원)], daegoljeol_surg=[탭2_5대골절수술_가입금액(만원)], gips=[탭2_깁스_가입금액(만원)], hwasang_diag=[탭2_화상진단_가입금액(만원)], hwasang_surg=[탭2_화상수술_가입금액(만원)], icu_amt=[탭2_ICU_가입금액(만원)])
sc_injury_tab3 = build_injury_sc(goljeol_diag=[탭3_골절진단_가입금액(만원)], daegoljeol_diag=[탭3_5대골절진단_가입금액(만원)], goljeol_surg=[탭3_골절수술_가입금액(만원)], daegoljeol_surg=[탭3_5대골절수술_가입금액(만원)], gips=[탭3_깁스_가입금액(만원)], hwasang_diag=[탭3_화상진단_가입금액(만원)], hwasang_surg=[탭3_화상수술_가입금액(만원)], icu_amt=[탭3_ICU_가입금액(만원)])

# ─────────────────────────────────────────────────────────────
# TAB1 COV LIST (기존보험비교 - 매우 제한적 보장)
# ─────────────────────────────────────────────────────────────
tab1_cov_list = """<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-c">🎗️</div>
    <div class="cov-hd-info"><div class="cov-cat">암 관련 보장</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_cancer_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-b">🧠</div>
    <div class="cov-hd-info"><div class="cov-cat">뇌혈관 질환</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_brain_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-h">❤️</div>
    <div class="cov-hd-info"><div class="cov-cat">심장 질환</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_heart_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-s">🔬</div>
    <div class="cov-hd-info"><div class="cov-cat">수술 관련</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_surgery_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>
    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-i">🛡️</div>
    <div class="cov-hd-info"><div class="cov-cat">상해·기타</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">[가입금액]</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>"""
html = html.replace('{{TAB1_COV_LIST}}', tab1_cov_list)

# ─────────────────────────────────────────────────────────────
# TAB2 COV LIST (안심보장플랜 - 추천)
# ─────────────────────────────────────────────────────────────
tab2_cov_list = """<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-c">🎗️</div>
    <div class="cov-hd-info"><div class="cov-cat">암 관련 보장</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_cancer_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-b">🧠</div>
    <div class="cov-hd-info"><div class="cov-cat">뇌혈관 질환</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_brain_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-h">❤️</div>
    <div class="cov-hd-info"><div class="cov-cat">심장 질환</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_heart_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-s">🔬</div>
    <div class="cov-hd-info"><div class="cov-cat">수술 관련</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_surgery_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>
    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-i">🛡️</div>
    <div class="cov-hd-info"><div class="cov-cat">상해·기타</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_injury_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span><span class="pill pill-rec">★추천</span></div></div>
  </div>
</div>"""
html = html.replace('{{TAB2_COV_LIST}}', tab2_cov_list)

# ─────────────────────────────────────────────────────────────
# TAB3 COV LIST (프리미엄플랜 - 탭2 대비 강화 항목 표시)
# ─────────────────────────────────────────────────────────────
tab3_cov_list = """<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-c">🎗️</div>
    <div class="cov-hd-info"><div class="cov-cat">암 관련 보장</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_cancer_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">[가입금액]</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">[가입금액]</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">[가입금액]</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">[가입금액]</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-b">🧠</div>
    <div class="cov-hd-info"><div class="cov-cat">뇌혈관 질환</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_brain_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">[보장명]</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">[가입금액]</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-h">❤️</div>
    <div class="cov-hd-info"><div class="cov-cat">심장 질환</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_heart_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-s">🔬</div>
    <div class="cov-hd-info"><div class="cov-cat">수술 관련</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_surgery_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>
    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-i">🛡️</div>
    <div class="cov-hd-info"><div class="cov-cat">상해·기타</div><div class="cov-sub">[서브본문]</div></div>
    <div class="cov-max"><div class="cov-max-v">[대표가입금액]</div><span class="cov-max-l">[대표본문]</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_injury_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
    <div class="row"><span class="row-name">[보장명]</span><div class="row-right"><span class="row-val">[가입금액]</span></div></div>
  </div>
</div>"""
html = html.replace('{{TAB3_COV_LIST}}', tab3_cov_list)

# ─────────────────────────────────────────────────────────────
# 보장개시일 변수
# ─────────────────────────────────────────────────────────────
html = html.replace('{{COV_ONSET_CANCER_VAL}}', '90일 후')
html = html.replace('{{COV_ONSET_CANCER_SUB}}', '계약일로부터 90일 경과 후 보장개시. 90일 이내 진단 시 보험금 미지급.')
html = html.replace('{{COV_ONSET_CANCER_TX_VAL}}', '90일 후')
html = html.replace('{{COV_ONSET_CANCER_TX_SUB}}', '암 진단 확정 후 10년간 연간 1회 지급. 하이클래스 특정치료비·항암약물치료비 동일.')
html = html.replace('{{COV_ONSET_BRAIN_HEART_VAL}}', '즉시보장')
html = html.replace('{{COV_ONSET_BRAIN_HEART_SUB}}', '뇌혈관질환·허혈성심장질환 진단비는 계약일 즉시 보장됩니다.')
html = html.replace('{{COV_ONSET_CIRC_VAL}}', '1년 감액')
html = html.replace('{{COV_ONSET_CIRC_SUB}}', '180일 미만 10% 지급, 1년 미만(180일 제외) 50% 지급. 1년 이후 100% 보장.')
html = html.replace('{{COV_ONSET_SURG_VAL}}', '즉시보장')
html = html.replace('{{COV_ONSET_SURG_SUB}}', '질병 수술비는 계약 즉시 보장. 단, 양성신생물 수술비는 1년 미만 50% 감액 지급.')
html = html.replace('{{COV_ONSET_INJ_VAL}}', '즉시보장')
html = html.replace('{{COV_ONSET_INJ_SUB}}', '상해 수술비·골절·화상·중환자실 입원일당은 계약 즉시 보장됩니다.')

# ─────────────────────────────────────────────────────────────
# 납입면제 항목
# ─────────────────────────────────────────────────────────────
waiver_items = """<div class="waiver-item"><div class="w-dot"></div>[납입면제_본문]</div>
<div class="waiver-item"><div class="w-dot"></div>[납입면제_본문]</div>
<div class="waiver-item"><div class="w-dot"></div>[납입면제_본문]</div>
<div class="waiver-item"><div class="w-dot"></div>[납입면제_본문]</div>
<div class="waiver-item"><div class="w-dot"></div>[납입면제_본문]</div>"""
html = html.replace('{{WAIVER_ITEMS}}', waiver_items)

# ─────────────────────────────────────────────────────────────
# 꼭 확인하세요 섹션
# ─────────────────────────────────────────────────────────────
html = html.replace('{{NOTICE_HEALTH_DISCOUNT}}', '10년 건강고지형 적용으로 일반고지형 대비 보험료가 할인됩니다. 건강고지 6년고지형에서 10년고지형 순으로 저렴하며, 최저 수준의 보험료로 동일한 보장을 받을 수 있습니다.')
html = html.replace('{{NOTICE_EXTRA_DISCOUNT}}', '별도 추가할인 없음 (10년고지형이 적용 가능한 최대 할인 수준입니다).')
html = html.replace('{{NOTICE_EXTRA}}', '갱신형 담보(표적항암약물허가 치료비 등)는 10년 단위로 갱신되며 갱신 시 보험료가 변동될 수 있습니다. 납입기간(20년) 중 중도해지 시 비갱신담보 해약환급금은 지급되지 않습니다(해약환급금 미지급형).')

# ─────────────────────────────────────────────────────────────
# Footer 변수
# ─────────────────────────────────────────────────────────────
html = html.replace('{{COMPANY_CS_NUMBER}}', '1588-5114')
html = html.replace('{{DISPUTE_ORG}}', '손해보험협회')
html = html.replace('{{DISPUTE_NUMBER}}', '02-3702-8500')
html = html.replace('{{ISSUE_DATE}}', '[발행일]')

# ─────────────────────────────────────────────────────────────
# TAB1 COVERAGE JSON
# ─────────────────────────────────────────────────────────────
tab1_json = """{
  cancer: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  brain: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  heart: [
    ['[보장명]', '[보장기간]', true, '[가입금액]']
  ],
  surgery: [
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  injury: [
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ]
}"""
html = html.replace('{{TAB1_COVERAGE_JSON}}', tab1_json)

# ─────────────────────────────────────────────────────────────
# TAB2 COVERAGE JSON
# ─────────────────────────────────────────────────────────────
tab2_json = """{
  cancer: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  brain: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]']
  ],
  heart: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  surgery: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  injury: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ]
}"""
html = html.replace('{{TAB2_COVERAGE_JSON}}', tab2_json)

# ─────────────────────────────────────────────────────────────
# TAB3 COVERAGE JSON (탭2와 유사, 일부 금액 차이)
# ─────────────────────────────────────────────────────────────
tab3_json = """{
  cancer: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  brain: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]']
  ],
  heart: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  surgery: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ],
  injury: [
    ['[보장명]', '[보장기간]', true, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]'],
    ['[보장명]', '[보장기간]', false, '[가입금액]']
  ]
}"""
html = html.replace('{{TAB3_COVERAGE_JSON}}', tab3_json)


# ─────────────────────────────────────────────────────────────
# v14 신규: [기존보험현황] 섹션 (트리거 1 워크플로우 신규 영역)
# ─────────────────────────────────────────────────────────────
# 본 영역은 트리거 3 양식 고객정보(상품별 보장 목록)를 LLM이 자체 분석하여
# build_existing_insurance_section() 빌더 함수로 HTML 생성하는 영역이다.
#
# 빌더 함수 본질 (LLM 자체 판단 — references/ 5종 + insurance_order.md 정합):
#   1. 파싱: 트리거 3 양식의 "상품 별 보장 목록" 영역만 활용 (매트릭스 영역 ❌)
#   2. 본인/가족 분류: 피보험자 필드 "/본인" vs "/가족명" 기준
#   3. 정렬: insurance_order.md 8단계 + 같은 분류 내 최근 가입일순
#   4. 펼침 영역 분류: 7 sub-title (실손의료비보장 + 암 + 뇌혈관 + 심장 + 수술 + 상해/기타 + 보험료 효율 낮음)
#   5. 형광펜 매칭: references/ 5종(cancer·brain·heart·surgery·silson) 정합
#
# 참조 양식 본문 — placeholder 영역은 고객정보 양식의 [상품 별 보장 목록] 기반 작성 의무:
# 본 본문 그대로 다음 케이스 작성 시 양식 참조. 데이터·구조 변경 ❌, 양식만 정합.
EXISTING_INSURANCE_SECTION_HTML = """<section id="existing-insurance-section">
  <div class="exi-title-row">
    <div class="exi-title">[기존보험현황]</div>
    <button class="collapse-all-btn" type="button" data-collapse-target="#existing-insurance-section">펼친내용모두접기</button>
  </div>
<div class="grp-block">
  <div class="grp-title">[그룹타이틀 — 본인/가족 [고객명]님 보험 : 총 [건수]건 ([월납건수]월납 [월납보험료_합계]원)]</div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-silson">
      <div class="cat-title">실손의료비보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-cancer">
      <div class="cat-title">암관련보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-brain">
      <div class="cat-title">뇌혈관관련</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-heart">
      <div class="cat-title">심장관련</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-surgery">
      <div class="cat-title">수술관련</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-injury">
      <div class="cat-title">상해/기타보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-nonefficient">
      <div class="cat-title">보험료 효율이 높지 않은 보장</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-cancer">
      <div class="cat-title">암관련보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-brain">
      <div class="cat-title">뇌혈관관련</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-heart">
      <div class="cat-title">심장관련</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-surgery">
      <div class="cat-title">수술관련</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-injury">
      <div class="cat-title">상해/기타보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-nonefficient">
      <div class="cat-title">보험료 효율이 높지 않은 보장</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-injury">
      <div class="cat-title">상해/기타보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    <div class="cat-block cat-nonefficient">
      <div class="cat-title">보험료 효율이 높지 않은 보장</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-nonefficient">
      <div class="cat-title">보험료 효율이 높지 않은 보장</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-nonefficient">
      <div class="cat-title">보험료 효율이 높지 않은 보장</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-nonefficient">
      <div class="cat-title">보험료 효율이 높지 않은 보장</div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
</div>
<div class="grp-block">
  <div class="grp-title">[그룹타이틀 — 본인/가족 [고객명]님 보험 : 총 [건수]건 ([월납건수]월납 [월납보험료_합계]원)]</div>
  <div class="ins-row" data-ins-row>
    <div class="ins-head" data-ins-toggle>
      <div class="ins-label">[[보험사]] [상품명]</div>
      <div class="ins-price-wrap"><span class="ins-price">[보험료]원 ([납입양식])</span><span class="ins-caret">▼</span></div>
    </div>
    <div class="ins-body">
    <div class="cat-block cat-silson">
      <div class="cat-title">실손의료비보장</div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row "><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
      <div class="cov-row cov-hl"><span class="cov-name">[보장명]</span><span class="cov-amt">[가입금액]</span></div>
    </div>
    </div>
  </div>
</div>
</section>"""

html = html.replace('{{INSURANCE_SECTION_HTML}}', EXISTING_INSURANCE_SECTION_HTML)

# ─────────────────────────────────────────────────────────────
# 보험료 비교 섹션 (신규 — 첨부 보험료비교표 이미지 기반 동적 생성)
# ─────────────────────────────────────────────────────────────
# ⚠️ LLM 의무 (추측 ❌ — 첨부 이미지·문구 본문 분석 기반으로만 작성):
#
# [입력 경로] 상담자료교체 트리거 시 요청 4종:
#   ① 설명문구  ② 고객정보 붙여넣기  ③ 보험료비교표 이미지 1장  ④ PDF 3개
#   → ②③④는 함께 첨부됨. 본 섹션 데이터는 ③ 이미지 + ① 문구의 탭1·2·3 에서 추출.
#
# [1] 카테고리 블록 N개 (보통 2~3, 가변). .pcmp-block 을 실제 블록 수만큼
#     반복/삭제. <tr> 은 그 블록 보험사 수만큼 반복/삭제.
#
# [2] 블록 제목 변환 — 1순위(최상단) 블록 전용, 딱 2케이스 (결정론적):
#       · 원문 "손보 청소년5.10.10(무해지)"  -> "손해보험 청소년 5.10.10보험 (보험료 할인)"
#       · 원문 "손보 5.10.10(무해지)"        -> "손해보험 일반 5.10.10보험 (보험료 할인)"
#     규칙: 손보->손해보험(생보->생명보험) / "청소년" 있으면 "청소년 5.10.10보험",
#           없으면 "일반 5.10.10보험" / "(무해지)"등 괄호 제거 / 끝 " (보험료 할인)"
#     "5.10.10" 포함 상품의 비교표가 항상 1순위(최상단). 띄어쓰기 위 형식 그대로.
#     2순위 이하 블록: 손보->손해보험·(무해지)제거·끝"보험", "(보험료 할인)" 미부가
#
# [3] 블록 제목 앞 "N순위 " 접두: 1순위/2순위/3순위... 블록 순서대로 자동.
#
# [4] 표 = 보험사 | 보험상품명 | 보험료. 보험료 = 각 표 "합계" 행 금액만
#     (담보별 미포함), 전 셀 "원" 부가 (예: 114,542원).
#
# [5] 최상단 블록에서 mr.와이가 이미지에 박스(강조)친 보험사 행에만
#     class="pcmp-row-hl". 추천 판단 로직 ❌ — 박스 위치를 그대로 데이터로
#     사용 (최저보험료가 아닐 수도 있음).
#
# [6] 각 표 아래 형광펜 위치 설명글을 .pcmp-note 에 항목 단위로 분해:
#     "1."/"2."/"-"/"※" 등 라벨 + 본문을 .pcmp-note-item 으로 한 줄씩.
#     형광펜/글자 색 무관 — 해당 위치 텍스트 그대로. (CSS가 hanging indent 처리)
#
# [7] 판독 불가 셀(주석 가림 등)은 임의 추측·계산 ❌ ->
#     "[판독불가 — mr.와이 확인 요청]" 그대로 표기 후 산출 보고 시 명시.
#
# 아래는 reference (심재윤 = 2블록 예시). 실제 블록·행·항목 수는 가변.
PREMIUM_COMPARE_HTML = """<div class="pcmp-block">
  <div class="pcmp-block-title">1순위 손해보험 청소년 5.10.10보험 (보험료 할인)</div>
  <table class="pcmp-table">
    <thead><tr><th>보험사</th><th>보험상품명</th><th class="pcmp-col-price">보험료</th></tr></thead>
    <tbody>
      <tr class="pcmp-row-hl"><td>[박스친 보험사]</td><td>[보험상품명]</td><td class="pcmp-col-price">[합계]원</td></tr>
      <tr><td>[보험사]</td><td>[보험상품명]</td><td class="pcmp-col-price">[합계]원</td></tr>
    </tbody>
  </table>
  <div class="pcmp-note">
    <div class="pcmp-note-item"><span class="pcmp-note-label">1.</span>[1.문장 — 형광펜 위치 그대로]</div>
    <div class="pcmp-note-item"><span class="pcmp-note-label">-</span>[하이픈 문장]</div>
    <div class="pcmp-note-item"><span class="pcmp-note-label">※</span>[※ 문장]</div>
  </div>
</div>
<div class="pcmp-block">
  <div class="pcmp-block-title">2순위 손해보험 청소년보험</div>
  <table class="pcmp-table">
    <thead><tr><th>보험사</th><th>보험상품명</th><th class="pcmp-col-price">보험료</th></tr></thead>
    <tbody>
      <tr><td>[보험사]</td><td>[보험상품명]</td><td class="pcmp-col-price">[합계]원</td></tr>
    </tbody>
  </table>
  <div class="pcmp-note">
    <div class="pcmp-note-item"><span class="pcmp-note-label">2.</span>[2.문장]</div>
    <div class="pcmp-note-item"><span class="pcmp-note-label">-</span>[하이픈 문장]</div>
  </div>
</div>"""

html = html.replace('{{PREMIUM_COMPARE_HTML}}', PREMIUM_COMPARE_HTML)

# ─────────────────────────────────────────────────────────────
# 적용 보험상품 — 보험명 3줄(이동) + 플랜 4줄
# ─────────────────────────────────────────────────────────────
# [C] {{COMPANY_NAME}}·{{PRODUCT_NAME}} = 기존 변수 그대로 (위치만 이동, 별도 처리 ❌)
#
# {{TAB_COUNT}} = 탭 수 (현재 템플릿 탭1·2·3 고정 -> 3). 탭 가변 시 그 수.
TAB_COUNT = 3  # 현재 템플릿 탭 3개 고정. 탭 수 가변화 시 실제 탭 수로.
html = html.replace('{{TAB_COUNT}}', str(TAB_COUNT))

# [B] 플랜 4줄 — ① PDF 3개(탭1·2·3)의 파일명·내부에서 플랜명·월보험료 추출.
#     기존 [탭1/2/3_보험료] 추출값과 동일 소스 연결 (정합). 설명문구 ❌.
#     총보험료 = 월보험료 × 12 × 20 = 월 × 240 (결정론적 자동 계산).
#     마지막 괄호줄은 불릿·들여쓰기 표시 없음 (3번째 줄 첫 글자와 좌측 정렬).
# [예시값 — 실제 작업 시 ① PDF 탭1·2·3 의 플랜명·보험료로 교체 필수]
PLAN_ITEMS = [
    # (플랜명, 월보험료_정수)  ← 탭1·2·3 순서. 탭 수 가변 시 항목 수 연동.
    # 월보험료는 [탭1/2/3_보험료] 추출값과 동일 소스(PDF) 사용.
    ('기존보험비교', 80144),
    ('안심보장플랜', 128459),
    ('프리미엄플랜', 150240),
]
PLAN_PAREN = '(20년납 90세만기 / 비갱신형 구성)'  # 예시 — 실제 PDF 기준


def _won(n):
    """정수 -> 천단위 콤마 + '원'."""
    return format(n, ',') + '원'


def build_plan_list(items, paren):
    """플랜 N줄(hanging indent 불릿) + 괄호줄. 총보험료=월×240 자동 계산."""
    rows = []
    for name, monthly in items:
        total = monthly * 240  # 12개월 × 20년
        rows.append(
            '      <div class="pcmp-plan-item">'
            '<span class="pcmp-plan-bul">\u00b7</span>'
            '%s - 월 %s / 총 %s</div>' % (name, _won(monthly), _won(total)))
    rows.append('      <div class="pcmp-plan-paren">%s</div>' % paren)
    return '\n'.join(rows)


html = html.replace('{{PLAN_LIST_HTML}}', build_plan_list(PLAN_ITEMS, PLAN_PAREN))

# ─────────────────────────────────────────────────────────────
# 혹시 남은 플레이스홀더 확인
# ─────────────────────────────────────────────────────────────
remaining = re.findall(r'\{\{[^}]+\}\}', html)
if remaining:
    print("남은 플레이스홀더:", set(remaining))
else:
    print("모든 플레이스홀더 치환 완료!")

# ⚠️ LLM 의무: 출력 파일명 양식 → toss_insureport_{고객명}님_{생년월일}.html (SKILL.md 정합)
with open('/home/claude/toss_insureport_[고객명]님_[생년월일].html', 'w', encoding='utf-8') as f:
    f.write(html)

print("파일 저장 완료:", len(html), "자")
