# -*- coding: utf-8 -*-
"""
replace_jeonansu_reference.py — 보장요약리포트 빌더 함수 참조 스크립트
====================================================================

[용도]
    "상담자료 교체" 트리거 구동 시, Claude가 새 고객용 replace.py를 작성할 때
    참조하는 빌더 함수 모음 (A작업·D작업의 함수 시그니처·구현 예시).

[주의 — 다른 클로드가 이 파일을 수정·실행할 때 반드시 확인]
    1. 이것은 "참조용" 스크립트다. 그대로 실행하지 말 것.
    2. 본 파일은 전안수 케이스(2026-04 작성)의 실제 데이터가 그대로 들어 있어
       빌더 함수 사용 예시 + 변수 치환 예시 역할을 한다.
    3. 새 고객 작업 시 새 replace.py를 별도로 작성한다.
       (이 파일의 빌더 함수 시그니처·구현 패턴만 참조)
    4. 경로·고객 데이터·상품 데이터는 모두 예시값 — 새 케이스에서 교체 필수.
    5. 빌더 함수 시그니처·구현 패턴·자료구조는 임의로 변경 금지.
       변경 시 SKILL.md의 D작업 시그니처와 충돌 발생.

[수정 규칙]
    - 빌더 함수 추가·수정 → SKILL.md "[내장] D작업" 섹션 동시 동기화 필수
    - 새 보험사·상품 추가 → mappings/insurers/{보험사}.json 갱신
    - 본 파일의 예시 데이터(전안수 케이스) 자체는 변경하지 않는 것 권장
      (변경 필요 시 새 reference 파일을 만들고 SKILL.md 갱신)
"""
import re

# 다른 클로드 사용 시: 실제 베이스템플릿 경로로 교체할 것
# 기본 경로: /mnt/skills/user/report-skill/base_template.html
# 작업 임시 경로: /home/claude/base_template.html (작업 폴더 복사 후 사용)
with open('/home/claude/base_template.html', 'r', encoding='utf-8') as f:
    html = f.read()

# ─────────────────────────────────────────────────────────────
# 추천 탭 설정 (TAB_REC: 'min' / 'mid' / 'max')
# ─────────────────────────────────────────────────────────────
TAB_REC = 'mid'  # 예시값 — 실제 작업 시 PDF 분석·고객 상담 결과로 결정

# ─────────────────────────────────────────────────────────────
# 고객/상품 기본 정보
# ─────────────────────────────────────────────────────────────
html = html.replace('{{CUSTOMER_NAME}}', '전안수')
html = html.replace('{{CUSTOMER_BIRTH}}', '1993')
html = html.replace('{{CUSTOMER_GENDER}}', '남성')
html = html.replace('{{CUSTOMER_AGE}}', '33')
html = html.replace('{{CUSTOMER_JOB}}', '웹/멀티미디어디자이너 · 1급')
html = html.replace('{{COVERAGE_END_DATE}}', '2083.04.30')
html = html.replace('{{COMPANY_NAME}}', '삼성화재')
html = html.replace('{{PRODUCT_NAME}}', '건강보험 New내돈내삼1640 (10년고지형)')

# ─────────────────────────────────────────────────────────────
# 탭 기본 정보
# ─────────────────────────────────────────────────────────────
html = html.replace('{{TAB1_PLAN_NAME}}', '기존보험비교')
html = html.replace('{{TAB2_PLAN_NAME}}', '안심보장플랜')
html = html.replace('{{TAB3_PLAN_NAME}}', '프리미엄플랜')
html = html.replace('{{TAB1_PRICE}}', '27,347')
html = html.replace('{{TAB2_PRICE}}', '117,644')
html = html.replace('{{TAB3_PRICE}}', '145,476')
html = html.replace('{{TAB1_COMPLETE}}', '암진단비 2천만원 외 보장 전무')
html = html.replace('{{TAB2_COMPLETE}}', '필요보장 80% 구성')
html = html.replace('{{TAB3_COMPLETE}}', '필요한 보장 완성 (100%)')
html = html.replace('{{TAB1_DESC}}', '기존보험과 동일한 보장으로 구성 / 보험료 50% 이상 절감')
html = html.replace('{{TAB2_DESC}}', '핵심보장 완성 / 균형잡힌 보장 구성')
html = html.replace('{{TAB3_DESC}}', '완벽한 보장 완성 / 동일보장 보험료 최소 지출')
html = html.replace('{{TAB1_OPINION}}', '기존보험과 동일 / 필요보장이 사실상 전무하여 보험효율 매우 낮음')
html = html.replace('{{TAB2_OPINION}}', '대부분의 치료상황에서 충분한 보장을 받을 수 있는 기본 플랜')
html = html.replace('{{TAB3_OPINION}}', '필요한 보장이 100% 완성될 수 있는 플랜 / 향후 보험의 추가가입 불필요')
html = html.replace("'{{TAB_REC}}'", f"'{TAB_REC}'")
html = html.replace('{{TAB_REC}}', TAB_REC)

# 추천 탭 패널 active 클래스 동적 적용
_panel_map = {'min': ('active', '', ''), 'mid': ('', 'active', ''), 'max': ('', '', 'active')}
_p = _panel_map.get(TAB_REC, ('', 'active', ''))
html = html.replace('{{REC_PANEL_MIN}}', _p[0])
html = html.replace('{{REC_PANEL_MID}}', _p[1])
html = html.replace('{{REC_PANEL_MAX}}', _p[2])
html = html.replace('{{REC_PLAN_NAME}}', '안심보장플랜')

# ─────────────────────────────────────────────────────────────
# DIFF 제목
# ─────────────────────────────────────────────────────────────
html = html.replace('{{NON_REC_TITLE_MIN}}', '기존보험비교 대비 줄어든 항목')
html = html.replace('{{NON_REC_TITLE_MAX}}', '프리미엄플랜 대비 강화된 항목')

# ─────────────────────────────────────────────────────────────
# REC_CHIPS (탭2 추천 플랜 핵심보장)
# ─────────────────────────────────────────────────────────────
rec_chips = """<span class="chip chip-g">✓ 통합암진단비 2,000만원 (충분)</span>
<span class="chip chip-g">✓ 하이클래스 암특정치료비 2,000만원 (충분)</span>
<span class="chip chip-g">✓ 표적항암약물허가 치료비 1억원 (충분)</span>
<span class="chip chip-g">✓ 뇌혈관질환 진단비 1,000만원 (충분)</span>
<span class="chip chip-g">✓ 허혈성심장질환 진단비 2,000만원 (충분)</span>"""
html = html.replace('{{REC_CHIPS}}', rec_chips)

# ─────────────────────────────────────────────────────────────
# NON_REC_CHIPS_MIN (탭1 - 추천보다 저렴, 빨간칩)
# ─────────────────────────────────────────────────────────────
non_rec_chips_min = """<span class="chip chip-r">▼ 통합암진단비 (보장제외)</span>
<span class="chip chip-r">▼ 하이클래스 암특정치료비 (보장제외)</span>
<span class="chip chip-r">▼ 허혈성심장질환 진단비 (보장제외)</span>
<span class="chip chip-r">▼ 표적항암약물허가 치료비 (보장제외)</span>
<span class="chip chip-r">▼ 질병 1~5종 수술비 (보장제외)</span>
<span class="chip chip-r">▼ 상해 중환자실 입원일당 (보장제외)</span>"""
html = html.replace('{{NON_REC_CHIPS_MIN}}', non_rec_chips_min)

# ─────────────────────────────────────────────────────────────
# NON_REC_CHIPS_MAX (탭3 - 추천보다 비쌈, 초록칩)
# ─────────────────────────────────────────────────────────────
non_rec_chips_max = """<span class="chip chip-g">▲ 통합암진단비 3,000만원 (50% 보강)</span>
<span class="chip chip-g">▲ 유사암 진단비 600만원 (50% 보강)</span>
<span class="chip chip-g">▲ 하이클래스 암특정치료비 3,000만원 (50% 보강)</span>
<span class="chip chip-g">▲ 하이클래스 항암약물치료비 3,000만원 (50% 보강)</span>
<span class="chip chip-g">▲ 뇌혈관질환 진단비 2,000만원 (100% 보강)</span>"""
html = html.replace('{{NON_REC_CHIPS_MAX}}', non_rec_chips_max)

# ═════════════════════════════════════════════════════════════
# SC-WRAP 빌더 함수들 (PDF 데이터 → sc-wrap HTML 동적 생성)
# 모든 함수는 인자로 받은 담보 데이터만 사용 (하드코딩 없음)
# ═════════════════════════════════════════════════════════════

def fmt_amt(man_won):
    """만원 단위 숫자를 억원/만원 단위 문자열로 변환"""
    if man_won >= 10000:
        uk = man_won // 10000
        rem = man_won % 10000
        return f'{uk}억원' if rem == 0 else f'{uk}억 {rem:,}만원'
    return f'{man_won:,}만원'

def build_cancer_sc(
    tongham_unit=0, tongham_cnt=0,
    ilban_diag=0,
    yusa_diag=0,
    hiclass_tx=0,
    hiclass_chemo=0,
    jungipja=0,
    pyokjeok=0,
    rec_tab='',
    this_tab='',
    sep='·',
    tongham_note='',                 # 통합암 sc-detail 앞에 추가할 메모 (예: '추천플랜 대비 1,000만원 추가. ')
):
    """암 관련 sc-wrap HTML 생성"""
    cards = ''

    # ── sc-card 1: 진단비
    if tongham_unit > 0 and tongham_cnt > 0:
        total = tongham_unit * tongham_cnt
        amt = f'최대 {fmt_amt(tongham_unit)}'
        detail = f'부위별 통합암진단비. 전이 포함 보장. {tongham_note}· {tongham_cnt}개 부위 합산 최대 {fmt_amt(total)}'
        # 추천탭 대비 비교 메모 (최대탭인 경우)
        if rec_tab and this_tab and rec_tab != this_tab:
            rec_unit = tongham_unit  # 기본값
            # 추천보다 높으면 추가 표시
        cards += f'      <div class="sc-card"><div class="sc-title">일반암 진단 시</div><div class="sc-amt">{amt}</div><div class="sc-detail">{detail}</div></div>\n'
    elif ilban_diag > 0:
        detail = f'유사암(갑상선암·기타피부암 등)은 {fmt_amt(yusa_diag)} 지급' if yusa_diag > 0 else ''
        cards += f'      <div class="sc-card"><div class="sc-title">일반암 진단 시</div><div class="sc-amt">{fmt_amt(ilban_diag)}</div><div class="sc-detail">{detail}</div></div>\n'

    # ── sc-card 2: 치료비 (하이클래스)
    tx_total = hiclass_tx + hiclass_chemo
    if tx_total > 0:
        detail = f'하이클래스 암특정치료비 {fmt_amt(hiclass_tx)} + 하이클래스 항암약물치료비 {fmt_amt(hiclass_chemo)} (각 연 1회)'
        cards += f'      <div class="sc-card"><div class="sc-title">암 치료 중 (진단 후 10년간)</div><div class="sc-amt">최대 {fmt_amt(tx_total)}/년</div><div class="sc-detail">{detail}</div></div>\n'

    # ── sc-card 3: 중입자/표적 (하나라도 있으면)
    if jungipja > 0 or pyokjeok > 0:
        j_part = f'항암 중입자방사선 치료비 {fmt_amt(jungipja)} (최초 1회)' if jungipja > 0 else ''
        p_part = f'표적항암약물허가 치료비 {fmt_amt(pyokjeok)} {sep} 전액본인부담 표적항암약물허가 치료비 {fmt_amt(pyokjeok)} (각 최초 1회, 갱신형)' if pyokjeok > 0 else ''
        parts = [x for x in [j_part, p_part] if x]
        detail = f' {sep} '.join(parts)
        j_str = f'중입자 {fmt_amt(jungipja)}' if jungipja > 0 else ''
        p_str = f'표적 {fmt_amt(pyokjeok)}' if pyokjeok > 0 else ''
        amt_parts = [x for x in [j_str, p_str] if x]
        cards += f'      <div class="sc-card"><div class="sc-title">항암 중입자방사선 {sep} 표적항암약물 치료</div><div class="sc-amt">{f" {sep} ".join(amt_parts)}</div><div class="sc-detail">{detail}</div></div>\n'

    if not cards:
        return ''

    # ── 치료방식 notice (항상 노출)
    notice = '      <div class="sc-card" style="background:rgba(49,130,246,0.05);"><div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 상이</div><div class="sc-detail">항암방사선·항암약물·표적항암·CAR-T 등 치료방식에 따라 추가 보장금액이 달라질 수 있습니다.</div></div>\n'

    # ── guarantee-info
    has_tx = tx_total > 0 or tongham_cnt > 0
    if has_tx:
        gi = (
            '      <div class="guarantee-info cancer-guarantee">\n'
            '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
            '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">암보장을 받은 후에도, 2번째·3번째 암도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
            '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">암 보장을 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
            '      </div>'
        )
    else:
        gi = (
            '      <div class="guarantee-info cancer-guarantee">\n'
            '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">암 보장을 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
            '      </div>'
        )

    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'


def build_brain_sc(diag=0, surg=0, icu=0, gwanhyeol=0, bigwanhyeol=0,
                   neuro_surg=0, hyeoljeon=0, note=''):
    """뇌혈관질환 sc-wrap HTML 생성"""
    cards = ''
    if diag > 0:
        cards += (f'      <div class="sc-card"><div class="sc-title">뇌혈관질환 진단 시</div>'
                  f'<div class="sc-amt">{fmt_amt(diag)}</div>'
                  f'<div class="sc-detail">뇌졸중 포함 모든 뇌혈관질환 진단 확정 시 지급 (최초 1회){note}</div></div>\n')
    tx_total = surg + icu + gwanhyeol + bigwanhyeol + neuro_surg
    if tx_total > 0:
        parts = []
        if surg > 0:         parts.append(f'상급종합병원 순환계질환 특정치료비(수술) {fmt_amt(surg)}')
        if icu > 0:          parts.append(f'중환자실 {fmt_amt(icu)}')
        if gwanhyeol > 0:    parts.append(f'2대주요기관 관혈수술비 {fmt_amt(gwanhyeol)}')
        if bigwanhyeol > 0:  parts.append(f'2대주요기관 비관혈수술비 {fmt_amt(bigwanhyeol)}')
        if neuro_surg > 0:   parts.append(f'뇌혈관질환수술비 {fmt_amt(neuro_surg)}')
        tx_detail = ' + '.join(parts)
        if hyeoljeon > 0:    tx_detail += f' / 혈전용해치료비(뇌경색증) {fmt_amt(hyeoljeon)} 별도'
        cards += (f'      <div class="sc-card"><div class="sc-title">뇌혈관질환 치료 중 (진단 후)</div>'
                  f'<div class="sc-amt">최대 {fmt_amt(tx_total)}</div>'
                  f'<div class="sc-detail">{tx_detail}</div></div>\n')
    notice = ('      <div class="sc-card" style="background:rgba(49,130,246,0.05);">'
              '<div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 보장금액 상이</div>'
              '<div class="sc-detail">수술 여부, 혈전용해치료 적용 여부 등 치료 방식에 따라 실제 수령 금액이 달라질 수 있습니다.</div></div>\n') if tx_total > 0 else ''
    if tx_total > 0:
        gi = ('      <div class="guarantee-info brain-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">뇌혈관 치료에 대한 보장을 받은 후에도, 2번째 3번째 질환으로도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">뇌혈관 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    else:
        gi = ('      <div class="guarantee-info brain-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">뇌혈관 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'


def build_heart_sc(diag=0, bujeongmaek=0, surg=0, icu=0, gwanhyeol=0,
                   bigwanhyeol=0, heart_surg=0, hyeoljeon=0, note=''):
    """심장질환 sc-wrap HTML 생성"""
    cards = ''
    if diag > 0:
        bj = f' / 심장부정맥 진단비 {fmt_amt(bujeongmaek)} 포함' if bujeongmaek > 0 else ''
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 진단 시</div>'
                  f'<div class="sc-amt">{fmt_amt(diag)}</div>'
                  f'<div class="sc-detail">허혈성심장질환 진단 확정 시 지급 (최초 1회){bj}{note}</div></div>\n')
    tx_total = surg + icu + gwanhyeol + bigwanhyeol + heart_surg
    if tx_total > 0:
        parts = []
        if surg > 0:         parts.append(f'상급종합병원 순환계질환 특정치료비(수술) {fmt_amt(surg)}')
        if icu > 0:          parts.append(f'중환자실 {fmt_amt(icu)}')
        if gwanhyeol > 0:    parts.append(f'2대주요기관 관혈수술비 {fmt_amt(gwanhyeol)}')
        if bigwanhyeol > 0:  parts.append(f'2대주요기관 비관혈수술비 {fmt_amt(bigwanhyeol)}')
        if heart_surg > 0:   parts.append(f'허혈성심장질환수술비 {fmt_amt(heart_surg)}')
        tx_detail = ' + '.join(parts)
        if hyeoljeon > 0:    tx_detail += f' / 혈전용해치료비(급성심근경색증) {fmt_amt(hyeoljeon)} 별도'
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 치료 중 (진단 후)</div>'
                  f'<div class="sc-amt">최대 {fmt_amt(tx_total)}</div>'
                  f'<div class="sc-detail">{tx_detail}</div></div>\n')
    notice = ('      <div class="sc-card" style="background:rgba(49,130,246,0.05);">'
              '<div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 보장금액 상이</div>'
              '<div class="sc-detail">수술 여부, 혈전용해치료 적용 여부 등 치료 방식에 따라 실제 수령 금액이 달라질 수 있습니다.</div></div>\n') if tx_total > 0 else ''
    if tx_total > 0:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">심장질환 치료에 대한 보장을 받은 후에도, 2번째 3번째 질환으로도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    else:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'
    if diag > 0:
        bj = f' / 심장부정맥 진단비 {fmt_amt(bujeongmaek)} 포함' if bujeongmaek > 0 else ''
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 진단 시</div>'
                  f'<div class="sc-amt">{fmt_amt(diag)}</div>'
                  f'<div class="sc-detail">허혈성심장질환 진단 확정 시 지급 (최초 1회){bj}{note}</div></div>\n')
    tx_total = surg + icu + gwanhyeol + bigwanhyeol + heart_surg
    if tx_total > 0:
        parts = []
        if surg > 0:         parts.append(f'상급종합병원 순환계질환 특정치료비(수술) {fmt_amt(surg)}')
        if icu > 0:          parts.append(f'중환자실 {fmt_amt(icu)}')
        if gwanhyeol > 0:    parts.append(f'2대주요기관 관혈수술비 {fmt_amt(gwanhyeol)}')
        if bigwanhyeol > 0:  parts.append(f'2대주요기관 비관혈수술비 {fmt_amt(bigwanhyeol)}')
        if heart_surg > 0:   parts.append(f'허혈성심장질환수술비 {fmt_amt(heart_surg)}')
        tx_detail = ' + '.join(parts)
        if hyeoljeon > 0:    tx_detail += f' / 혈전용해치료비(급성심근경색증) {fmt_amt(hyeoljeon)} 별도'
        cards += (f'      <div class="sc-card"><div class="sc-title">심장질환 치료 중 (진단 후)</div>'
                  f'<div class="sc-amt">최대 {fmt_amt(tx_total)}</div>'
                  f'<div class="sc-detail">{tx_detail}</div></div>\n')
    notice = ('      <div class="sc-card" style="background:rgba(49,130,246,0.05);">'
              '<div class="sc-title" style="color:var(--gray-500);">치료방식에 따라 보장금액 상이</div>'
              '<div class="sc-detail">수술 여부, 혈전용해치료 적용 여부 등 치료 방식에 따라 실제 수령 금액이 달라질 수 있습니다.</div></div>\n') if tx_total > 0 else ''
    has_tx = tx_total > 0
    if has_tx:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">📅</span><span class="gi-text">위에 기재된 보장금액은 <strong>1회(1년) 기준금액</strong>입니다. 치료기간이 길어지면, 보장금액은 해마다 추가됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#10145;&#65039;</span><span class="gi-text">심장질환 치료에 대한 보장을 받은 후에도, 2번째 3번째 질환으로도 <strong>반복보장</strong>되도록 보장이 계속 유지됩니다.</span></div>\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    else:
        gi = ('      <div class="guarantee-info heart-guarantee">\n'
              '        <div class="gi-row"><span class="gi-icon">&#9989;</span><span class="gi-text">심장질환 치료를 받은 후에는 <strong>보험료 납입이 면제</strong>되며, 이후에도 보장은 정상적으로 유지됩니다.</span></div>\n'
              '      </div>')
    return f'    <div class="sc-wrap">\n{cards}{notice}{gi}\n    </div>\n'


def build_surgery_sc(disease_min=0, disease_max=0, injury_min=0, injury_max=0,
                     disease_detail='', injury_detail=''):
    """수술 sc-wrap HTML 생성"""
    cards = ''
    if disease_max > 0:
        amt = f'{fmt_amt(disease_min)} ~ 최대 {fmt_amt(disease_max)}' if disease_min < disease_max else f'최대 {fmt_amt(disease_max)}'
        cards += (f'      <div class="sc-card"><div class="sc-title">질병으로 수술을 받는 경우</div>'
                  f'<div class="sc-amt">{amt}</div>'
                  f'<div class="sc-detail">{disease_detail}</div></div>\n')
    if injury_max > 0:
        amt = f'{fmt_amt(injury_min)} ~ 최대 {fmt_amt(injury_max)}' if injury_min < injury_max else f'최대 {fmt_amt(injury_max)}'
        cards += (f'      <div class="sc-card"><div class="sc-title">사고(상해)로 수술을 받는 경우</div>'
                  f'<div class="sc-amt">{amt}</div>'
                  f'<div class="sc-detail">{injury_detail}</div></div>\n')
    if not cards:
        return ''
    return f'    <div class="sc-wrap">\n{cards}    </div>\n'


def build_injury_sc(goljeol_diag=0, daegoljeol_diag=0, goljeol_surg=0, daegoljeol_surg=0,
                    gips=0, hwasang_diag=0, hwasang_surg=0, icu_amt=0):
    """상해·기타 sc-wrap HTML 생성"""
    items = []
    if goljeol_diag > 0:    items.append(('골절 진단비', goljeol_diag))
    if daegoljeol_diag > 0: items.append(('5대골절 진단비', daegoljeol_diag))
    if goljeol_surg > 0:    items.append(('골절 수술비', goljeol_surg))
    if daegoljeol_surg > 0: items.append(('5대골절 수술비', daegoljeol_surg))
    if gips > 0:            items.append(('깁스치료비', gips))
    if hwasang_diag > 0:    items.append(('화상 진단비', hwasang_diag))
    if hwasang_surg > 0:    items.append(('화상 수술비', hwasang_surg))
    if not items:
        return ''
    amts = [a for _, a in items]
    mn, mx = min(amts), max(amts)
    amt_str = f'{fmt_amt(mn)} ~ 최대 {fmt_amt(mx)}' if mn < mx else f'최대 {fmt_amt(mx)}'
    detail = ' / '.join([f'{n} {fmt_amt(a)}' for n, a in items])
    if icu_amt > 0:
        detail += f' (상해 중환자실 입원일당 {fmt_amt(icu_amt)}/일 별도)'
    card = (f'      <div class="sc-card"><div class="sc-title">골절 · 화상 보장</div>'
            f'<div class="sc-amt">{amt_str}</div>'
            f'<div class="sc-detail">{detail}</div></div>\n')
    return f'    <div class="sc-wrap">\n{card}    </div>\n'


# ═════════════════════════════════════════════════════════════
# D작업 - cov-card·row 빌더 함수 (replace.py HTML 직접 작성 대체)
# ═════════════════════════════════════════════════════════════

# 1-5종 분류표 (하드코딩 고정, surgery cov-card에서만 사용)
_SURGERY_TABLE_HTML = '''    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>'''


def build_row(name, amount, pill=None, sub_detail=None):
    """단일 담보 row HTML 생성

    Args:
        name: 담보명 (PDF 원형 유지 권장)
        amount: 가입금액 문자열 (예: '3,000만원', '미가입', '10만원/일')
        pill: None / 'rec' (★추천) / 'r' (▼빈약) / 'blue' (▲강화) / 'add' (✚보장추가)
        sub_detail: row 아래 추가 설명 문자열 (선택)

    Returns:
        <div class="row">...</div> HTML 문자열
    """
    # pill별 스타일 결정
    pill_html = ''
    name_color = ''
    val_color = ''

    if pill == 'rec':
        pill_html = '<span class="pill pill-rec">★추천</span>'
    elif pill == 'r':
        pill_html = '<span class="pill pill-r">▼빈약</span>'
        name_color = ' style="color:var(--toss-red);"'
        val_color = ' style="color:var(--toss-red);"'
    elif pill == 'blue':
        pill_html = '<span class="pill pill-blue">▲강화</span>'
        name_color = ' style="color:var(--toss-blue);"'
        val_color = ' style="color:var(--toss-blue);"'
    elif pill == 'add':
        pill_html = '<span class="pill pill-blue" style="background:var(--toss-blue);color:white;font-weight:800;">✚보장추가</span>'
        name_color = ' style="color:var(--toss-blue);"'
        val_color = ' style="color:var(--toss-blue);"'

    html = (f'    <div class="row">'
            f'<span class="row-name"{name_color}>{name}</span>'
            f'<div class="row-right">'
            f'<span class="row-val"{val_color}>{amount}</span>'
            f'{pill_html}'
            f'</div></div>')

    if sub_detail:
        html += f'\n    <div class="row-sub" style="font-size:11px;color:var(--gray-500);margin-top:-8px;margin-bottom:8px;padding-left:12px;">※ {sub_detail}</div>'

    return html + '\n'


def build_cov_card(icon, category, sub, max_v, max_l, sc_html='', rows=None,
                   repeat_notice=False, surgery_table=False):
    """카테고리별 cov-card 전체 HTML 생성

    Args:
        icon: ('ico-c','🎗️') 등 튜플 — 5종: ico-c/ico-b/ico-h/ico-s/ico-i
        category: "암 관련 보장" 등 카테고리명
        sub: cov-sub 서브타이틀
        max_v: cov-max-v (우측 상단 대표 금액, 예: '3,000만원')
        max_l: cov-max-l (라벨, 예: '일반암 진단' / '보장제외')
        sc_html: sc-wrap 빌더(build_cancer_sc 등)의 반환값
        rows: build_row() 결과 리스트
        repeat_notice: "매회 지급" 문구 포함 여부 (주로 surgery cov-card)
        surgery_table: 1-5종 분류표 포함 여부 (surgery cov-card만 True)

    Returns:
        <div class="cov-card reveal">...</div> HTML 문자열
    """
    if rows is None:
        rows = []
    icon_class, icon_emoji = icon

    rows_html = ''.join(rows)
    repeat_html = ''
    if repeat_notice:
        repeat_html = '    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>\n'
    table_html = ''
    if surgery_table:
        table_html = _SURGERY_TABLE_HTML + '\n'

    return (f'<div class="cov-card reveal">\n'
            f'  <div class="cov-hd ripple-host" onclick="tog(this)">\n'
            f'    <div class="cov-ico {icon_class}">{icon_emoji}</div>\n'
            f'    <div class="cov-hd-info"><div class="cov-cat">{category}</div><div class="cov-sub">{sub}</div></div>\n'
            f'    <div class="cov-max"><div class="cov-max-v">{max_v}</div><span class="cov-max-l">{max_l}</span></div>\n'
            f'    <div class="tog">▼</div>\n'
            f'  </div>\n'
            f'  <div class="cov-detail">\n'
            f'{sc_html}'
            f'    <div class="items-title">담보 상세 내역</div>\n'
            f'{rows_html}'
            f'{repeat_html}'
            f'{table_html}'
            f'  </div>\n'
            f'</div>\n')


def build_tab_cov_list(cards):
    """5개 또는 6개 cov-card를 받아 탭 COV_LIST 변수값 생성 (순서 검증 포함)

    Args:
        cards: build_cov_card() 결과 리스트
               - 5개: cancer → brain → heart → surgery → injury (간병 담보 없을 때)
               - 6개: cancer → brain → heart → surgery → injury → care (간병 담보 있을 때)

    Returns:
        cov-card들을 연결한 HTML 문자열

    Raises:
        ValueError: cov-card 순서가 잘못됐거나 개수가 5/6이 아닐 때
    """
    if len(cards) not in (5, 6):
        raise ValueError(f'cov-card는 반드시 5개(기본) 또는 6개(간병 포함)여야 합니다 (현재 {len(cards)}개). '
                         f'순서: cancer → brain → heart → surgery → injury [→ care]')

    expected_icons_base = ['ico-c', 'ico-b', 'ico-h', 'ico-s', 'ico-i']
    expected_icons = expected_icons_base + (['ico-care'] if len(cards) == 6 else [])
    icon_names = ['cancer', 'brain', 'heart', 'surgery', 'injury', 'care']

    for i, (card, expected) in enumerate(zip(cards, expected_icons)):
        if f'class="cov-ico {expected}"' not in card:
            raise ValueError(f'cov-card #{i+1}에 {expected} 아이콘이 없습니다. '
                             f'순서: ' + ' → '.join(
                                 f'{icon_names[j]}({expected_icons[j]})'
                                 for j in range(len(expected_icons))
                             ))

    return ''.join(cards)


# 아이콘 상수 (빈번히 사용)
ICON_CANCER  = ('ico-c', '🎗️')
ICON_BRAIN   = ('ico-b', '🧠')
ICON_HEART   = ('ico-h', '❤️')
ICON_SURGERY = ('ico-s', '🔬')
ICON_INJURY  = ('ico-i', '🛡️')
ICON_CARE    = ('ico-care', '🏥')


# ═════════════════════════════════════════════════════════════
# 간병 카드 전용 빌더 (신규)
# ═════════════════════════════════════════════════════════════

def classify_care_group(name, amount_man):
    """간병 담보의 그룹 분류 (1/2/3)

    Args:
        name: 담보명 문자열
        amount_man: 가입금액 (만원 단위 정수, 예: 15만원이면 15)

    Returns:
        1, 2, 3 중 하나

    분류 규칙 (우선순위 순):
        - 그룹 3 예외: 5만원 + 담보명에 "간호" 또는 "통합" 포함 → 그룹 3
        - 그룹 1: 15만원 OR 담보명에 "상급종합병원" 또는 "종합병원" 포함
        - 그룹 2: 5만원 / 3만원 / 6만원
        - 그룹 3: 7만원 / 10만원
    """
    has_care_keyword = ('간호' in name) or ('통합' in name)

    # 그룹 3 예외 규칙 먼저 체크 (5만원 + 간호/통합)
    if amount_man == 5 and has_care_keyword:
        return 3

    # 그룹 1: 15만원 OR 상급종합병원/종합병원 포함
    if amount_man == 15 or '상급종합병원' in name or '종합병원' in name:
        return 1

    # 그룹 2: 5만원 / 3만원 / 6만원
    if amount_man in (3, 5, 6):
        return 2

    # 그룹 3: 7만원 / 10만원
    if amount_man in (7, 10):
        return 3

    # 정의되지 않은 금액 — 사용자 확인 필요
    return None


def is_care_181plus(name):
    """담보명이 181일이상(연간 181일 이상) 담보인지 판별

    Returns: True이면 181일이상 (합산 제외, 나열만),
             False이면 180일한도 (중요보장 합산 포함)
    """
    return '181일이상' in name or '181일 이상' in name


def build_care_card(care_rows_180, care_rows_181=None, tab_type='rec'):
    """간병 cov-card 전체 HTML 생성

    Args:
        care_rows_180: 180일한도 담보 리스트, 각 원소는 dict:
                       {'name': str, 'amount': str (예: '15만원'), 'amount_man': int,
                        'pill': str or None, 'sub_detail': str or None}
        care_rows_181: 181일이상 담보 리스트 (동일 형식). None이면 빈 리스트.
        tab_type: 'rec' / 'low' / 'high' (탭 성격에 따른 pill 배치 참고용)

    Returns:
        간병 cov-card HTML 문자열

    동작:
        1. 180일한도 담보를 그룹1/2/3으로 분류
        2. 그룹1 → 그룹2 → 그룹3 순으로 row 생성 (중요보장 합산 포함)
        3. 181일이상 담보는 동일한 그룹 순서로 나열만 (합산 제외)
        4. 대표 금액(max_v) = 그룹1 최대 담보금액
    """
    if care_rows_181 is None:
        care_rows_181 = []

    # 1. 180일한도 담보 그룹 분류
    groups_180 = {1: [], 2: [], 3: []}
    for r in care_rows_180:
        g = classify_care_group(r['name'], r['amount_man'])
        if g is None:
            raise ValueError(f"간병 담보 '{r['name']}' (금액 {r['amount_man']}만원)의 "
                             f"그룹을 결정할 수 없습니다. 사용자 확인 필요.")
        groups_180[g].append(r)

    # 2. 그룹 1 내부 정렬: 15만원 먼저 → 상급종합병원/종합병원 담보
    def sort_group1(rows):
        g1_15 = [r for r in rows if r['amount_man'] == 15]
        g1_rest = [r for r in rows if r['amount_man'] != 15]
        return g1_15 + g1_rest

    groups_180[1] = sort_group1(groups_180[1])

    # 3. 181일이상도 동일 그룹 분류 (합산은 제외, 나열 순서만)
    groups_181 = {1: [], 2: [], 3: []}
    for r in care_rows_181:
        g = classify_care_group(r['name'], r['amount_man'])
        if g is None:
            raise ValueError(f"간병 담보(181일이상) '{r['name']}' (금액 {r['amount_man']}만원)의 "
                             f"그룹을 결정할 수 없습니다. 사용자 확인 필요.")
        groups_181[g].append(r)
    groups_181[1] = sort_group1(groups_181[1])

    # 4. row HTML 생성 (180일한도 먼저, 그룹 1 → 2 → 3 순)
    rows_html = []
    for g in (1, 2, 3):
        for r in groups_180[g]:
            rows_html.append(build_row(
                name=r['name'],
                amount=r['amount'],
                pill=r.get('pill'),
                sub_detail=r.get('sub_detail')
            ))

    # 5. 181일이상 담보 나열 (합산 제외 — row에 '나열만' 표시 권장)
    for g in (1, 2, 3):
        for r in groups_181[g]:
            sub = r.get('sub_detail') or ''
            sub_with_flag = (sub + ' · ' if sub else '') + '※ 연간 181일이상 담보 (합산 제외)'
            rows_html.append(build_row(
                name=r['name'],
                amount=r['amount'],
                pill=r.get('pill'),
                sub_detail=sub_with_flag
            ))

    # 6. 대표 금액 = 그룹1 최대 담보금액 (180일한도 기준)
    if groups_180[1]:
        max_r = max(groups_180[1], key=lambda x: x['amount_man'])
        max_v = max_r['amount']
        max_l = '간병 대표'
    else:
        # 그룹1이 없으면 그룹2에서 최대
        all_180 = groups_180[2] + groups_180[3]
        if all_180:
            max_r = max(all_180, key=lambda x: x['amount_man'])
            max_v = max_r['amount']
            max_l = '간병 대표'
        else:
            max_v = '-'
            max_l = '간병 없음'

    return build_cov_card(
        icon=ICON_CARE,
        category='간병 보장',
        sub='간병인 사용 + 간호간병통합서비스',
        max_v=max_v,
        max_l=max_l,
        sc_html='',  # 간병은 sc-wrap 별도 없음
        rows=rows_html,
        repeat_notice=False,
        surgery_table=False,
    )


# ═════════════════════════════════════════════════════════════
# D작업 함수 사용 예시 (주석, 실행되지 않음)
# ═════════════════════════════════════════════════════════════
"""
사용 예시 — 탭3(추천) 암 cov-card:

tab3_cancer_card = build_cov_card(
    icon=ICON_CANCER,
    category='암 관련 보장',
    sub='진단비 + 전이암 + 치료비 완성',
    max_v='3,000만원',
    max_l='일반암 진단',
    sc_html=sc_cancer_tab3,
    rows=[
        build_row('일반암 진단비', '3,000만원', pill='rec'),
        build_row('유사암 진단비(갑상선암·기타피부암 등)', '600만원'),
        build_row('표적항암약물허가 치료비 4종', '각 3,000만원', pill='rec'),
        # ... 이하 row 반복
    ]
)

# surgery cov-card는 repeat_notice=True, surgery_table=True 옵션 필수:
tab3_surgery_card = build_cov_card(
    icon=ICON_SURGERY,
    category='수술 관련',
    sub='1~5종 수술비 + 입원·통원',
    max_v='500만원',
    max_l='5종 수술',
    sc_html=sc_surgery_tab3,
    rows=[
        build_row('질병수술비Ⅱ(5종)', '500만원', pill='rec'),
        # ...
    ],
    repeat_notice=True,
    surgery_table=True
)

# 최종 탭 COV_LIST:
tab3_cov_list = build_tab_cov_list([
    tab3_cancer_card,  # ico-c
    tab3_brain_card,   # ico-b
    tab3_heart_card,   # ico-h
    tab3_surgery_card, # ico-s
    tab3_injury_card,  # ico-i
])
html = html.replace('{{TAB3_COV_LIST}}', tab3_cov_list)
"""


# ─────────────────────────────────────────────────────────────
# PDF 데이터 기반 sc-wrap 생성 (전안수님 / 삼성화재 New내돈내삼1640)
# ─────────────────────────────────────────────────────────────
TAB_REC = 'mid'  # ← 스킬 구동 시 추천 탭에 맞게 변경

# ── 암
sc_cancer_tab1 = build_cancer_sc(ilban_diag=2000, yusa_diag=1000)
sc_cancer_tab2 = build_cancer_sc(tongham_unit=2000, tongham_cnt=10, hiclass_tx=2000, hiclass_chemo=2000, jungipja=100, pyokjeok=10000)
sc_cancer_tab3 = build_cancer_sc(tongham_unit=3000, tongham_cnt=10, hiclass_tx=3000, hiclass_chemo=3000, jungipja=100, pyokjeok=10000, sep='/', tongham_note='추천플랜 대비 1,000만원 추가. ')

# ── 뇌혈관
sc_brain_tab1 = build_brain_sc()  # 뇌졸중만 있으므로 없음
sc_brain_tab2 = build_brain_sc(diag=1000, surg=2000, icu=500, gwanhyeol=1000, bigwanhyeol=500, hyeoljeon=3000)
sc_brain_tab3 = build_brain_sc(diag=2000, surg=2000, icu=500, gwanhyeol=1000, bigwanhyeol=500, hyeoljeon=3000, note=' (추천플랜 대비 1,000만원 추가 보강)')

# ── 심장
sc_heart_tab1 = build_heart_sc()  # 급성심근경색만 있으므로 없음
sc_heart_tab2 = build_heart_sc(diag=2000, bujeongmaek=500, surg=2000, icu=500, gwanhyeol=1000, bigwanhyeol=500, hyeoljeon=3000)
sc_heart_tab3 = build_heart_sc(diag=2000, bujeongmaek=500, surg=2000, icu=500, gwanhyeol=1000, bigwanhyeol=500, hyeoljeon=3000)

# ── 수술
sc_surgery_tab1 = build_surgery_sc(
    disease_min=20, disease_max=20, injury_min=100, injury_max=100,
    disease_detail='질병 입원/통원 수술비 각 20만원 (경증질병 제외, 매회 지급)',
    injury_detail='상해 입원/통원 수술비 각 100만원 (경증상해 제외, 매회 지급)'
)
sc_surgery_tab2 = build_surgery_sc(
    disease_min=30, disease_max=1000, injury_min=100, injury_max=100,
    disease_detail='질병 1~5종 수술비 30만~1,000만원 (수술 난이도별) + 질병 입원/통원 수술비 각 30만원 (매회 지급)',
    injury_detail='상해 입원/통원 수술비 각 100만원 (매회 지급)'
)
sc_surgery_tab3 = build_surgery_sc(
    disease_min=30, disease_max=1000, injury_min=100, injury_max=100,
    disease_detail='질병 1~5종 수술비 30만~1,000만원 (수술 난이도별) + 질병 입원/통원 수술비 각 30만원 (매회 지급)',
    injury_detail='상해 입원/통원 수술비 각 100만원 (매회 지급)'
)

# ── 상해·기타
sc_injury_tab1 = build_injury_sc()  # 골절/화상 없음
sc_injury_tab2 = build_injury_sc(goljeol_diag=30, daegoljeol_diag=30, goljeol_surg=20, daegoljeol_surg=50, gips=20, hwasang_diag=20, hwasang_surg=30, icu_amt=18)
sc_injury_tab3 = build_injury_sc(goljeol_diag=30, daegoljeol_diag=30, goljeol_surg=20, daegoljeol_surg=50, gips=20, hwasang_diag=20, hwasang_surg=30, icu_amt=18)

# ─────────────────────────────────────────────────────────────
# TAB1 COV LIST (기존보험비교 - 매우 제한적 보장)
# ─────────────────────────────────────────────────────────────
tab1_cov_list = """<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-c">🎗️</div>
    <div class="cov-hd-info"><div class="cov-cat">암 관련 보장</div><div class="cov-sub">암진단비 단일 구성</div></div>
    <div class="cov-max"><div class="cov-max-v">2,000만원</div><span class="cov-max-l">최대</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_cancer_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">암 진단비(유사암 제외)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">통합암진단비(부위별)</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">하이클래스 암 특정치료비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">표적항암약물허가 치료비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">유사암 진단비(갑상선암 등 5종)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-b">🧠</div>
    <div class="cov-hd-info"><div class="cov-cat">뇌혈관 질환</div><div class="cov-sub">뇌졸중 한정 보장</div></div>
    <div class="cov-max"><div class="cov-max-v">2,000만원</div><span class="cov-max-l">최대</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_brain_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">뇌혈관질환 진단비(전체)</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">뇌졸중 진단비</span><div class="row-right"><span class="row-val">2,000만원</span></div></div>
    <div class="row"><span class="row-name">보험료 납입면제대상(3대질병진단)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">순환계질환 특정치료비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">혈전용해치료비(뇌경색증)</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-h">❤️</div>
    <div class="cov-hd-info"><div class="cov-cat">심장 질환</div><div class="cov-sub">급성심근경색증 한정</div></div>
    <div class="cov-max"><div class="cov-max-v">2,000만원</div><span class="cov-max-l">최대</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_heart_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">허혈성심장질환 진단비(전체)</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">급성심근경색증 진단비</span><div class="row-right"><span class="row-val">2,000만원</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">심장부정맥 진단비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-s">🔬</div>
    <div class="cov-hd-info"><div class="cov-cat">수술 관련</div><div class="cov-sub">최소한의 수술비만 구성</div></div>
    <div class="cov-max"><div class="cov-max-v">100만원</div><span class="cov-max-l">최대</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_surgery_tab1 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">질병 1~5종 수술비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">상해 입원 수술비(경증상해 제외)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">상해 통원 수술비(경증상해 제외)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">질병 입원 수술비Ⅱ(경증질병 제외)</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">질병 통원 수술비Ⅱ(경증질병 제외)</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>
    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-i">🛡️</div>
    <div class="cov-hd-info"><div class="cov-cat">상해·기타</div><div class="cov-sub">골절·화상·중환자실 전무</div></div>
    <div class="cov-max"><div class="cov-max-v">미가입</div><span class="cov-max-l">보장제외</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">상해 중환자실 입원일당</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">골절 진단비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">깁스치료비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-red);">화상 진단비</span><div class="row-right"><span class="row-val" style="color:var(--toss-red);">미가입</span><span class="pill pill-r">▼빈약</span></div></div>
    <div class="row"><span class="row-name">상해 사망</span><div class="row-right"><span class="row-val">100만원</span></div></div>
  </div>
</div>"""
html = html.replace('{{TAB1_COV_LIST}}', tab1_cov_list)

# ─────────────────────────────────────────────────────────────
# TAB2 COV LIST (안심보장플랜 - 추천)
# ─────────────────────────────────────────────────────────────
tab2_cov_list = """<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-c">🎗️</div>
    <div class="cov-hd-info"><div class="cov-cat">암 관련 보장</div><div class="cov-sub">부위별 통합암 + 치료비</div></div>
    <div class="cov-max"><div class="cov-max-v">2,000만원</div><span class="cov-max-l">부위별 각</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_cancer_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">통합암진단비(두경부암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(위암 및 식도암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(소장·대장·항문암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(간·담낭·담도·췌장암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(흉곽내기관·중피성암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(골·피부 등 전신부위)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(유방·비뇨기관·부신암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(남성생식기암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(뇌암·중추신경계통암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">통합암진단비(혈액암)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">유사암 진단비(갑상선암 등 5종)</span><div class="row-right"><span class="row-val">400만원</span></div></div>
    <div class="row"><span class="row-name">하이클래스 암 특정치료비(진단후 10년, 연1회)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">하이클래스 항암약물치료비(진단후 10년, 연1회)</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">표적항암약물허가 치료비(갱신형)</span><div class="row-right"><span class="row-val">1억원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">전액본인부담 표적항암약물허가 치료비</span><div class="row-right"><span class="row-val">1억원</span></div></div>
    <div class="row"><span class="row-name">항암방사선·약물치료비Ⅲ(일반암)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">항암방사선·약물치료비Ⅲ(유사암)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">항암 중입자방사선 치료비</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">암(일반) 특정치료비(진단후 10년, 연1회)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">유사암진단 납입지원</span><div class="row-right"><span class="row-val">5만3천원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-b">🧠</div>
    <div class="cov-hd-info"><div class="cov-cat">뇌혈관 질환</div><div class="cov-sub">뇌혈관질환 전체 + 치료비</div></div>
    <div class="cov-max"><div class="cov-max-v">3,000만원</div><span class="cov-max-l">혈전용해 포함</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_brain_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">뇌혈관질환 진단비(뇌졸중포함)</span><div class="row-right"><span class="row-val">1,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">상급종합병원 순환계질환 특정치료비(수술·혈전)(1년감액)</span><div class="row-right"><span class="row-val">2,000만원</span></div></div>
    <div class="row"><span class="row-name">상급종합병원 순환계질환 특정치료비(중환자실)(1년감액)</span><div class="row-right"><span class="row-val">500만원</span></div></div>
    <div class="row"><span class="row-name">혈전용해치료비(뇌경색증)</span><div class="row-right"><span class="row-val">3,000만원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-h">❤️</div>
    <div class="cov-hd-info"><div class="cov-cat">심장 질환</div><div class="cov-sub">허혈성심장질환 전체 + 부정맥</div></div>
    <div class="cov-max"><div class="cov-max-v">3,000만원</div><span class="cov-max-l">혈전용해 포함</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_heart_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">허혈성심장질환 진단비</span><div class="row-right"><span class="row-val">2,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">기타 심장부정맥 진단비</span><div class="row-right"><span class="row-val">500만원</span></div></div>
    <div class="row"><span class="row-name">혈전용해치료비(급성심근경색증)</span><div class="row-right"><span class="row-val">3,000만원</span></div></div>
    <div class="row"><span class="row-name">2대주요기관질병 관혈수술비Ⅱ(1년감액)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">2대주요기관질병 비관혈수술비Ⅱ(1년감액)</span><div class="row-right"><span class="row-val">500만원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-s">🔬</div>
    <div class="cov-hd-info"><div class="cov-cat">수술 관련</div><div class="cov-sub">1~5종 수술비 + 양성신생물</div></div>
    <div class="cov-max"><div class="cov-max-v">1,000만원</div><span class="cov-max-l">5종 수술</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_surgery_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(5종)</span><div class="row-right"><span class="row-val">1,000만원</span><span class="pill pill-rec">★추천</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(4종)</span><div class="row-right"><span class="row-val">500만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(3종)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(2종)</span><div class="row-right"><span class="row-val">50만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(1종)</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">질병 입원 수술비Ⅱ(당일입원 제외)</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">질병 통원 수술비Ⅱ</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">상해 입원 수술비(당일입원 제외)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">상해 통원 수술비</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(대장양성신생물)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(식도·결장·항문)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(위·십이지장)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(갑상선·두경부)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(간·폐)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(뇌·심장)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(특정기타부위)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(남녀특정)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>
    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-i">🛡️</div>
    <div class="cov-hd-info"><div class="cov-cat">상해·기타</div><div class="cov-sub">골절·화상·중환자실 보장</div></div>
    <div class="cov-max"><div class="cov-max-v">18만원/일</div><span class="cov-max-l">중환자실</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_injury_tab2 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">골절 진단비(치아파절 제외)</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">5대골절 진단비</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">깁스치료비(부목치료 제외)</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">화상 진단비(심재성 2도 이상)</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">상해 골절 수술비</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">5대골절 수술비</span><div class="row-right"><span class="row-val">50만원</span></div></div>
    <div class="row"><span class="row-name">화상 수술비</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">상해 사망</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">보험료 납입면제대상(3대질병진단)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">상해 중환자실 입원일당(1일이상)</span><div class="row-right"><span class="row-val">18만원/일</span><span class="pill pill-rec">★추천</span></div></div>
  </div>
</div>"""
html = html.replace('{{TAB2_COV_LIST}}', tab2_cov_list)

# ─────────────────────────────────────────────────────────────
# TAB3 COV LIST (프리미엄플랜 - 탭2 대비 강화 항목 표시)
# ─────────────────────────────────────────────────────────────
tab3_cov_list = """<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-c">🎗️</div>
    <div class="cov-hd-info"><div class="cov-cat">암 관련 보장</div><div class="cov-sub">통합암 3,000만원 + 치료비 최대</div></div>
    <div class="cov-max"><div class="cov-max-v">3,000만원</div><span class="cov-max-l">부위별 각</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_cancer_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">통합암진단비(위암·폐암 등 10개 부위별)</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">3,000만원</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">유사암 진단비(갑상선암 등 5종)</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">600만원</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">하이클래스 암 특정치료비(진단후 10년, 연1회)</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">3,000만원</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">하이클래스 항암약물치료비(진단후 10년, 연1회)</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">3,000만원</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name">표적항암약물허가 치료비(갱신형)</span><div class="row-right"><span class="row-val">1억원</span></div></div>
    <div class="row"><span class="row-name">전액본인부담 표적항암약물허가 치료비</span><div class="row-right"><span class="row-val">1억원</span></div></div>
    <div class="row"><span class="row-name">항암방사선·약물치료비Ⅲ(일반암)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">항암방사선·약물치료비Ⅲ(기타피부암·갑상선암)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">암 특정치료비(진단후10년,연1회)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">기타피부암·갑상선암 암특정치료비(진단후10년)</span><div class="row-right"><span class="row-val">50만원</span></div></div>
    <div class="row"><span class="row-name">암(일반) 치료비 지원</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">기타피부암·갑상선암 치료비 지원</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">항암 중입자방사선 치료비</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">유사암진단 납입지원</span><div class="row-right"><span class="row-val">6만5천원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-b">🧠</div>
    <div class="cov-hd-info"><div class="cov-cat">뇌혈관 질환</div><div class="cov-sub">뇌혈관질환 2,000만원으로 보강</div></div>
    <div class="cov-max"><div class="cov-max-v">3,000만원</div><span class="cov-max-l">혈전용해 포함</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_brain_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name" style="color:var(--toss-blue);">뇌혈관질환 진단비(뇌졸중포함)</span><div class="row-right"><span class="row-val" style="color:var(--toss-blue);">2,000만원</span><span class="pill pill-blue">▲강화</span></div></div>
    <div class="row"><span class="row-name">상급종합병원 순환계질환 특정치료비(수술·혈전)(1년감액)</span><div class="row-right"><span class="row-val">2,000만원</span></div></div>
    <div class="row"><span class="row-name">상급종합병원 순환계질환 특정치료비(중환자실)(1년감액)</span><div class="row-right"><span class="row-val">500만원</span></div></div>
    <div class="row"><span class="row-name">혈전용해치료비(뇌경색증)</span><div class="row-right"><span class="row-val">3,000만원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-h">❤️</div>
    <div class="cov-hd-info"><div class="cov-cat">심장 질환</div><div class="cov-sub">허혈성심장질환 + 부정맥</div></div>
    <div class="cov-max"><div class="cov-max-v">3,000만원</div><span class="cov-max-l">혈전용해 포함</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_heart_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">허혈성심장질환 진단비</span><div class="row-right"><span class="row-val">2,000만원</span></div></div>
    <div class="row"><span class="row-name">기타 심장부정맥 진단비</span><div class="row-right"><span class="row-val">500만원</span></div></div>
    <div class="row"><span class="row-name">혈전용해치료비(급성심근경색증)</span><div class="row-right"><span class="row-val">3,000만원</span></div></div>
    <div class="row"><span class="row-name">2대주요기관질병 관혈수술비Ⅱ(1년감액)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">2대주요기관질병 비관혈수술비Ⅱ(1년감액)</span><div class="row-right"><span class="row-val">500만원</span></div></div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-s">🔬</div>
    <div class="cov-hd-info"><div class="cov-cat">수술 관련</div><div class="cov-sub">1~5종 수술비 + 양성신생물</div></div>
    <div class="cov-max"><div class="cov-max-v">1,000만원</div><span class="cov-max-l">5종 수술</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_surgery_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(5종)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(4종)</span><div class="row-right"><span class="row-val">500만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(3종)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(2종)</span><div class="row-right"><span class="row-val">50만원</span></div></div>
    <div class="row"><span class="row-name">질병 1~5종 수술비(1종)</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">질병 입원 수술비Ⅱ / 통원 수술비Ⅱ</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">상해 입원/통원 수술비</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(대장)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(갑상선·두경부)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(간·폐)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(뇌·심장)</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(특정기타부위)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="row"><span class="row-name">양성신생물 수술비(남녀특정)</span><div class="row-right"><span class="row-val">100만원</span></div></div>
    <div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div>
    <div class="surg-table-wrap" style="margin-top:18px;">
      <div class="surg-table-title">📋 질병수술비 1–5종 분류 기준</div>
      <table class="surg-table">
        <thead>
          <tr><th>종류</th><th>주요 수술 예시</th><th>특징</th></tr>
        </thead>
        <tbody>
          <tr class="surg-row-1">
            <td class="surg-type"><span class="surg-badge s1">1종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">백내장, 치질수술</span>, 탈장, 제왕절개, 하지정맥류, 비중격만곡증, 피부이식, 편도·아데노이드 절제, 누관삽입술, 수정체 관련 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">비교적 간단한 수술, 회복기간이 짧은 소수술 중심</td>
          </tr>
          <tr class="surg-row-2">
            <td class="surg-type"><span class="surg-badge s2">2종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">대장용종 제거, 충수염(맹장), 체외충격파쇄석술</span>, 망막박리, 자궁·난소·난관 관련 수술, 상악·하악·악관절 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">중등도 난이도의 일반 수술</td>
          </tr>
          <tr class="surg-row-3">
            <td class="surg-type"><span class="surg-badge s3">3종</span></td>
            <td class="surg-ex" style="line-height:2.0;">녹내장, <span class="surg-hl">추간판(디스크) 수술</span>, 갑상선 절제, 유방절제, 폐·신경계 수술 일부, 담낭·담도 수술, 두개내 감마나이프, 상피종양 절제 등</td>
            <td class="surg-feat" style="line-height:2.0;">입원 및 전신마취가 필요한 중증 수술</td>
          </tr>
          <tr class="surg-row-4">
            <td class="surg-type"><span class="surg-badge s4">4종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">척추수술(고난도)</span>, 갑상선·유방 고난도 수술, 폐·신경계 고난도 수술, 담도 재건, 두개내 수술 등</td>
            <td class="surg-feat" style="line-height:2.0;">고난도 수술, 회복기간이 길고 합병증 위험 존재</td>
          </tr>
          <tr class="surg-row-5">
            <td class="surg-type"><span class="surg-badge s5">5종</span></td>
            <td class="surg-ex" style="line-height:2.0;"><span class="surg-hl">암 관련 주요 수술, 뇌종양 제거</span>, 대동맥·심장·폐혈관 수술, 심장내 수술, 장기이식(신장·간·심장 등)</td>
            <td class="surg-feat" style="line-height:2.0;">생명과 직결되는 최고난도 대수술</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="cov-card reveal">
  <div class="cov-hd ripple-host" onclick="tog(this)">
    <div class="cov-ico ico-i">🛡️</div>
    <div class="cov-hd-info"><div class="cov-cat">상해·기타</div><div class="cov-sub">골절·화상·중환자실 보장</div></div>
    <div class="cov-max"><div class="cov-max-v">18만원/일</div><span class="cov-max-l">중환자실</span></div>
    <div class="tog">▼</div>
  </div>
  <div class="cov-detail">
""" + sc_injury_tab3 + """
    <div class="items-title">담보 상세 내역</div>
    <div class="row"><span class="row-name">골절 진단비(치아파절 제외)</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">5대골절 진단비</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">깁스치료비(부목치료 제외)</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">화상 진단비(심재성 2도 이상)</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">상해 골절 수술비</span><div class="row-right"><span class="row-val">20만원</span></div></div>
    <div class="row"><span class="row-name">5대골절 수술비</span><div class="row-right"><span class="row-val">50만원</span></div></div>
    <div class="row"><span class="row-name">화상 수술비</span><div class="row-right"><span class="row-val">30만원</span></div></div>
    <div class="row"><span class="row-name">상해 사망</span><div class="row-right"><span class="row-val">1,000만원</span></div></div>
    <div class="row"><span class="row-name">보험료 납입면제대상(3대질병진단)</span><div class="row-right"><span class="row-val">10만원</span></div></div>
    <div class="row"><span class="row-name">상해 중환자실 입원일당(1일이상)</span><div class="row-right"><span class="row-val">18만원/일</span></div></div>
  </div>
</div>"""
html = html.replace('{{TAB3_COV_LIST}}', tab3_cov_list)

# ─────────────────────────────────────────────────────────────
# 보장개시일 변수
# ─────────────────────────────────────────────────────────────
html = html.replace('{{COV_ONSET_CANCER_VAL}}', '90일 후')
html = html.replace('{{COV_ONSET_CANCER_SUB}}', '계약일로부터 90일 경과 후 보장개시. 90일 이내 진단 시 보험금 미지급.')
html = html.replace('{{COV_ONSET_CANCER_TX_VAL}}', '90일 후')
html = html.replace('{{COV_ONSET_CANCER_TX_SUB}}', '암 진단 확정 후 10년간 연간 1회 지급. 하이클래스 특정치료비·항암약물치료비 동일.')
html = html.replace('{{COV_ONSET_BRAIN_HEART_VAL}}', '즉시보장')
html = html.replace('{{COV_ONSET_BRAIN_HEART_SUB}}', '뇌혈관질환·허혈성심장질환 진단비는 계약일 즉시 보장됩니다.')
html = html.replace('{{COV_ONSET_CIRC_VAL}}', '1년 감액')
html = html.replace('{{COV_ONSET_CIRC_SUB}}', '180일 미만 10% 지급, 1년 미만(180일 제외) 50% 지급. 1년 이후 100% 보장.')
html = html.replace('{{COV_ONSET_SURG_VAL}}', '즉시보장')
html = html.replace('{{COV_ONSET_SURG_SUB}}', '질병 수술비는 계약 즉시 보장. 단, 양성신생물 수술비는 1년 미만 50% 감액 지급.')
html = html.replace('{{COV_ONSET_INJ_VAL}}', '즉시보장')
html = html.replace('{{COV_ONSET_INJ_SUB}}', '상해 수술비·골절·화상·중환자실 입원일당은 계약 즉시 보장됩니다.')

# ─────────────────────────────────────────────────────────────
# 납입면제 항목
# ─────────────────────────────────────────────────────────────
waiver_items = """<div class="waiver-item"><div class="w-dot"></div>암(유사암 제외) 진단 확정 시 (계약일로부터 90일 후 보장개시)</div>
<div class="waiver-item"><div class="w-dot"></div>뇌혈관질환 진단 확정 시</div>
<div class="waiver-item"><div class="w-dot"></div>허혈성심장질환 진단 확정 시</div>
<div class="waiver-item"><div class="w-dot"></div>중대 화상·부식 진단 확정 시</div>
<div class="waiver-item"><div class="w-dot"></div>뇌·내장손상으로 수술 시</div>"""
html = html.replace('{{WAIVER_ITEMS}}', waiver_items)

# ─────────────────────────────────────────────────────────────
# 꼭 확인하세요 섹션
# ─────────────────────────────────────────────────────────────
html = html.replace('{{NOTICE_HEALTH_DISCOUNT}}', '10년 건강고지형 적용으로 일반고지형 대비 보험료가 할인됩니다. 건강고지 6년고지형에서 10년고지형 순으로 저렴하며, 최저 수준의 보험료로 동일한 보장을 받을 수 있습니다.')
html = html.replace('{{NOTICE_EXTRA_DISCOUNT}}', '별도 추가할인 없음 (10년고지형이 적용 가능한 최대 할인 수준입니다).')
html = html.replace('{{NOTICE_EXTRA}}', '갱신형 담보(표적항암약물허가 치료비 등)는 10년 단위로 갱신되며 갱신 시 보험료가 변동될 수 있습니다. 납입기간(20년) 중 중도해지 시 비갱신담보 해약환급금은 지급되지 않습니다(해약환급금 미지급형).')

# ─────────────────────────────────────────────────────────────
# Footer 변수
# ─────────────────────────────────────────────────────────────
html = html.replace('{{COMPANY_CS_NUMBER}}', '1588-5114')
html = html.replace('{{DISPUTE_ORG}}', '손해보험협회')
html = html.replace('{{DISPUTE_NUMBER}}', '02-3702-8500')
html = html.replace('{{ISSUE_DATE}}', '2026.04.23')

# ─────────────────────────────────────────────────────────────
# TAB1 COVERAGE JSON
# ─────────────────────────────────────────────────────────────
tab1_json = """{
  cancer: [
    ['암 진단비(유사암 제외)', '20년납/90세만기', true, '2,000만원'],
    ['유사암 진단비(기타피부암)', '20년납/90세만기', false, '1,000만원'],
    ['유사암 진단비(갑상선암)', '20년납/90세만기', false, '1,000만원'],
    ['유사암 진단비(대장점막내암)', '20년납/90세만기', false, '1,000만원'],
    ['유사암 진단비(제자리암)', '20년납/90세만기', false, '1,000만원'],
    ['유사암 진단비(경계성종양)', '20년납/90세만기', false, '1,000만원']
  ],
  brain: [
    ['뇌졸중 진단비', '20년납/90세만기', true, '2,000만원'],
    ['보험료 납입면제대상(3대질병진단)', '20년납/90세만기', false, '10만원']
  ],
  heart: [
    ['급성심근경색증 진단비', '20년납/90세만기', true, '2,000만원']
  ],
  surgery: [
    ['상해 입원 수술비(당일입원·경증상해 제외)', '20년납/90세만기', false, '100만원'],
    ['상해 통원 수술비(경증상해 제외)', '20년납/90세만기', false, '100만원'],
    ['질병 입원 수술비Ⅱ(당일입원·경증질병 제외)', '20년납/90세만기', false, '20만원'],
    ['질병 통원 수술비Ⅱ(경증질병 제외)', '20년납/90세만기', false, '20만원']
  ],
  injury: [
    ['상해 사망', '20년납/90세만기', false, '100만원']
  ]
}"""
html = html.replace('{{TAB1_COVERAGE_JSON}}', tab1_json)

# ─────────────────────────────────────────────────────────────
# TAB2 COVERAGE JSON
# ─────────────────────────────────────────────────────────────
tab2_json = """{
  cancer: [
    ['통합암진단비(두경부암)', '20년납/90세만기', true, '2,000만원'],
    ['통합암진단비(위암 및 식도암)', '20년납/90세만기', true, '2,000만원'],
    ['통합암진단비(소장·대장·항문암 및 기타암)', '20년납/90세만기', true, '2,000만원'],
    ['통합암진단비(간·담낭·담도암 및 췌장암)', '20년납/90세만기', true, '2,000만원'],
    ['통합암진단비(흉곽내기관·중피성암 및 연조직암)', '20년납/90세만기', true, '2,000만원'],
    ['통합암진단비(골·피부 등 전신부위암)', '20년납/90세만기', false, '2,000만원'],
    ['통합암진단비(유방·비뇨기관·부신암 및 내분비선암)', '20년납/90세만기', false, '2,000만원'],
    ['통합암진단비(남성생식기암)', '20년납/90세만기', true, '2,000만원'],
    ['통합암진단비(뇌암 및 중추신경계통암)', '20년납/90세만기', false, '2,000만원'],
    ['통합암진단비(혈액암)', '20년납/90세만기', false, '2,000만원'],
    ['유사암 진단비(기타피부암 등 5종)', '20년납/90세만기', false, '400만원(각)'],
    ['하이클래스 암 특정치료비(진단후10년,연1회)', '20년납/90세만기', true, '2,000만원'],
    ['하이클래스 항암약물치료비(진단후10년,연1회)', '20년납/90세만기', true, '2,000만원'],
    ['표적항암약물허가 치료비(갱신형)', '10년갱신/90세만기', true, '1억원'],
    ['전액본인부담 표적항암약물허가 치료비(갱신형)', '10년갱신/90세만기', false, '1억원'],
    ['암 특정치료비(진단후10년,연1회)', '20년납/90세만기', false, '100만원'],
    ['기타피부암·갑상선암 암특정치료비(진단후10년)', '20년납/90세만기', false, '50만원'],
    ['암(일반) 치료비 지원', '20년납/90세만기', false, '10만원'],
    ['기타피부암·갑상선암 치료비 지원', '20년납/90세만기', false, '10만원'],
    ['항암방사선·약물치료비Ⅲ(일반암)', '20년납/90세만기', false, '100만원'],
    ['항암방사선·약물치료비Ⅲ(기타피부암·갑상선암)', '20년납/90세만기', false, '100만원'],
    ['항암 중입자방사선 치료비', '20년납/90세만기', false, '100만원'],
    ['유사암진단 납입지원', '20년납/20년만기', false, '5만3천원']
  ],
  brain: [
    ['뇌혈관질환 진단비(뇌졸중포함)', '20년납/90세만기', true, '1,000만원'],
    ['상급종합병원 순환계질환 특정치료비(수술·혈전,1년감액)', '20년납/90세만기', true, '2,000만원'],
    ['상급종합병원 순환계질환 특정치료비(중환자실,1년감액)', '20년납/90세만기', false, '500만원'],
    ['혈전용해치료비(뇌경색증)', '20년납/90세만기', true, '3,000만원']
  ],
  heart: [
    ['허혈성심장질환 진단비', '20년납/90세만기', true, '2,000만원'],
    ['기타 심장부정맥 진단비', '20년납/90세만기', false, '500만원'],
    ['혈전용해치료비(급성심근경색증)', '20년납/90세만기', true, '3,000만원'],
    ['2대주요기관질병 관혈수술비Ⅱ(1년감액)', '20년납/90세만기', false, '1,000만원'],
    ['2대주요기관질병 비관혈수술비Ⅱ(1년감액)', '20년납/90세만기', false, '500만원']
  ],
  surgery: [
    ['질병 1~5종 수술비(5종)', '20년납/90세만기', true, '1,000만원'],
    ['질병 1~5종 수술비(4종)', '20년납/90세만기', false, '500만원'],
    ['질병 1~5종 수술비(3종)', '20년납/90세만기', false, '100만원'],
    ['질병 1~5종 수술비(2종)', '20년납/90세만기', false, '50만원'],
    ['질병 1~5종 수술비(1종)', '20년납/90세만기', false, '30만원'],
    ['질병 입원 수술비Ⅱ(당일입원 제외)', '20년납/90세만기', false, '30만원'],
    ['질병 통원 수술비Ⅱ', '20년납/90세만기', false, '30만원'],
    ['상해 입원 수술비(당일입원 제외)', '20년납/90세만기', false, '100만원'],
    ['상해 통원 수술비', '20년납/90세만기', false, '100만원'],
    ['양성신생물 수술비(대장양성신생물)', '20년납/90세만기', false, '10만원'],
    ['양성신생물 수술비(식도·결장·항문)', '20년납/90세만기', false, '10만원'],
    ['양성신생물 수술비(위·십이지장)', '20년납/90세만기', false, '10만원'],
    ['양성신생물 수술비(갑상선·두경부)', '20년납/90세만기', false, '100만원'],
    ['양성신생물 수술비(간·폐)', '20년납/90세만기', false, '1,000만원'],
    ['양성신생물 수술비(뇌·심장)', '20년납/90세만기', false, '1,000만원'],
    ['양성신생물 수술비(특정기타부위)', '20년납/90세만기', false, '100만원'],
    ['양성신생물 수술비(남녀특정)', '20년납/90세만기', false, '100만원']
  ],
  injury: [
    ['상해 중환자실 입원일당(1일이상)', '20년납/90세만기', true, '18만원/일'],
    ['골절 진단비(치아파절 제외)', '20년납/90세만기', false, '30만원'],
    ['5대골절 진단비', '20년납/90세만기', false, '30만원'],
    ['깁스치료비(부목치료 제외)', '20년납/90세만기', false, '20만원'],
    ['화상 진단비(심재성 2도 이상)', '20년납/90세만기', false, '20만원'],
    ['상해 골절 수술비', '20년납/90세만기', false, '20만원'],
    ['5대골절 수술비', '20년납/90세만기', false, '50만원'],
    ['화상 수술비', '20년납/90세만기', false, '30만원'],
    ['상해 사망', '20년납/90세만기', false, '1,000만원'],
    ['보험료 납입면제대상(3대질병진단)', '20년납/90세만기', false, '10만원']
  ]
}"""
html = html.replace('{{TAB2_COVERAGE_JSON}}', tab2_json)

# ─────────────────────────────────────────────────────────────
# TAB3 COVERAGE JSON (탭2와 유사, 일부 금액 차이)
# ─────────────────────────────────────────────────────────────
tab3_json = """{
  cancer: [
    ['통합암진단비(두경부암)', '20년납/90세만기', true, '3,000만원'],
    ['통합암진단비(위암 및 식도암)', '20년납/90세만기', true, '3,000만원'],
    ['통합암진단비(소장·대장·항문암 및 기타암)', '20년납/90세만기', true, '3,000만원'],
    ['통합암진단비(간·담낭·담도암 및 췌장암)', '20년납/90세만기', true, '3,000만원'],
    ['통합암진단비(흉곽내기관·중피성암 및 연조직암)', '20년납/90세만기', true, '3,000만원'],
    ['통합암진단비(골·피부 등 전신부위암)', '20년납/90세만기', false, '3,000만원'],
    ['통합암진단비(유방·비뇨기관·부신암 및 내분비선암)', '20년납/90세만기', false, '3,000만원'],
    ['통합암진단비(남성생식기암)', '20년납/90세만기', true, '3,000만원'],
    ['통합암진단비(뇌암 및 중추신경계통암)', '20년납/90세만기', false, '3,000만원'],
    ['통합암진단비(혈액암)', '20년납/90세만기', false, '3,000만원'],
    ['유사암 진단비(기타피부암 등 5종)', '20년납/90세만기', false, '600만원(각)'],
    ['하이클래스 암 특정치료비(진단후10년,연1회)', '20년납/90세만기', true, '3,000만원'],
    ['하이클래스 항암약물치료비(진단후10년,연1회)', '20년납/90세만기', true, '3,000만원'],
    ['표적항암약물허가 치료비(갱신형)', '10년갱신/90세만기', true, '1억원'],
    ['전액본인부담 표적항암약물허가 치료비(갱신형)', '10년갱신/90세만기', false, '1억원'],
    ['암 특정치료비(진단후10년,연1회)', '20년납/90세만기', false, '100만원'],
    ['기타피부암·갑상선암 암특정치료비(진단후10년)', '20년납/90세만기', false, '50만원'],
    ['암(일반) 치료비 지원', '20년납/90세만기', false, '10만원'],
    ['기타피부암·갑상선암 치료비 지원', '20년납/90세만기', false, '10만원'],
    ['항암방사선·약물치료비Ⅲ(일반암)', '20년납/90세만기', false, '100만원'],
    ['항암방사선·약물치료비Ⅲ(기타피부암·갑상선암)', '20년납/90세만기', false, '100만원'],
    ['항암 중입자방사선 치료비', '20년납/90세만기', false, '100만원'],
    ['유사암진단 납입지원', '20년납/20년만기', false, '6만5천원']
  ],
  brain: [
    ['뇌혈관질환 진단비(뇌졸중포함)', '20년납/90세만기', true, '2,000만원'],
    ['상급종합병원 순환계질환 특정치료비(수술·혈전,1년감액)', '20년납/90세만기', true, '2,000만원'],
    ['상급종합병원 순환계질환 특정치료비(중환자실,1년감액)', '20년납/90세만기', false, '500만원'],
    ['혈전용해치료비(뇌경색증)', '20년납/90세만기', true, '3,000만원']
  ],
  heart: [
    ['허혈성심장질환 진단비', '20년납/90세만기', true, '2,000만원'],
    ['기타 심장부정맥 진단비', '20년납/90세만기', false, '500만원'],
    ['혈전용해치료비(급성심근경색증)', '20년납/90세만기', true, '3,000만원'],
    ['2대주요기관질병 관혈수술비Ⅱ(1년감액)', '20년납/90세만기', false, '1,000만원'],
    ['2대주요기관질병 비관혈수술비Ⅱ(1년감액)', '20년납/90세만기', false, '500만원']
  ],
  surgery: [
    ['질병 1~5종 수술비(5종)', '20년납/90세만기', true, '1,000만원'],
    ['질병 1~5종 수술비(4종)', '20년납/90세만기', false, '500만원'],
    ['질병 1~5종 수술비(3종)', '20년납/90세만기', false, '100만원'],
    ['질병 1~5종 수술비(2종)', '20년납/90세만기', false, '50만원'],
    ['질병 1~5종 수술비(1종)', '20년납/90세만기', false, '30만원'],
    ['질병 입원 수술비Ⅱ(당일입원 제외)', '20년납/90세만기', false, '30만원'],
    ['질병 통원 수술비Ⅱ', '20년납/90세만기', false, '30만원'],
    ['상해 입원 수술비(당일입원 제외)', '20년납/90세만기', false, '100만원'],
    ['상해 통원 수술비', '20년납/90세만기', false, '100만원'],
    ['양성신생물 수술비(대장)', '20년납/90세만기', false, '10만원'],
    ['양성신생물 수술비(간·폐)', '20년납/90세만기', false, '1,000만원'],
    ['양성신생물 수술비(뇌·심장)', '20년납/90세만기', false, '1,000만원'],
    ['양성신생물 수술비(갑상선·두경부)', '20년납/90세만기', false, '100만원'],
    ['양성신생물 수술비(특정기타부위)', '20년납/90세만기', false, '100만원'],
    ['양성신생물 수술비(남녀특정)', '20년납/90세만기', false, '100만원']
  ],
  injury: [
    ['상해 중환자실 입원일당(1일이상)', '20년납/90세만기', true, '18만원/일'],
    ['골절 진단비(치아파절 제외)', '20년납/90세만기', false, '30만원'],
    ['5대골절 진단비', '20년납/90세만기', false, '30만원'],
    ['깁스치료비(부목치료 제외)', '20년납/90세만기', false, '20만원'],
    ['화상 진단비(심재성 2도 이상)', '20년납/90세만기', false, '20만원'],
    ['상해 골절 수술비', '20년납/90세만기', false, '20만원'],
    ['5대골절 수술비', '20년납/90세만기', false, '50만원'],
    ['화상 수술비', '20년납/90세만기', false, '30만원'],
    ['상해 사망', '20년납/90세만기', false, '1,000만원'],
    ['보험료 납입면제대상(3대질병진단)', '20년납/90세만기', false, '10만원']
  ]
}"""
html = html.replace('{{TAB3_COVERAGE_JSON}}', tab3_json)

# ─────────────────────────────────────────────────────────────
# 혹시 남은 플레이스홀더 확인
# ─────────────────────────────────────────────────────────────
remaining = re.findall(r'\{\{[^}]+\}\}', html)
if remaining:
    print("남은 플레이스홀더:", set(remaining))
else:
    print("모든 플레이스홀더 치환 완료!")

with open('/home/claude/insu-report_전안수님_v1.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("파일 저장 완료:", len(html), "자")
