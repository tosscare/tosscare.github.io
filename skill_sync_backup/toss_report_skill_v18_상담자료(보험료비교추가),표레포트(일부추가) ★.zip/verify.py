# -*- coding: utf-8 -*-
"""
B작업 - 보장요약리포트 HTML 구조 정합성 자동 검증 스크립트
=========================================================

용도:
    상담자료 교체 스킬로 생성된 HTML의 구조 오류를 11개 카테고리로 자동 체크.
    수동 grep 검증을 대체하며, 탭 active 불일치 · 플레이스홀더 잔존 등 오류를
    명확한 메시지로 지적한다.

사용법:
    python3 verify.py <HTML파일경로>
    python3 verify.py <HTML파일경로> --json  (JSON 리포트도 저장)

리턴:
    0: 모든 검증 통과
    1: 하나 이상 실패

출력:
    각 체크 항목의 ✅/❌ 및 실패 시 수정 가이드
    JSON 옵션 시 verify_report_{파일명}.json 생성
"""
import re
import sys
import json
import os
from collections import Counter


# ═══════════════════════════════════════════════════════════════
# 검증 체크 클래스
# ═══════════════════════════════════════════════════════════════

class VerifyResult:
    def __init__(self):
        self.results = []  # [(카테고리, 통과여부, 메시지)]

    def add(self, category, passed, expected='', actual='', guide=''):
        self.results.append({
            'category': category,
            'passed': passed,
            'expected': expected,
            'actual': actual,
            'guide': guide,
        })

    def passed_count(self):
        return sum(1 for r in self.results if r['passed'])

    def total_count(self):
        return len(self.results)

    def all_passed(self):
        return all(r['passed'] for r in self.results)


# ═══════════════════════════════════════════════════════════════
# 검증 함수들 (11개 카테고리)
# ═══════════════════════════════════════════════════════════════

def check_1_placeholders(html, vr):
    """#1 플레이스홀더 정합성 - {{...}} 잔존 0개"""
    remaining = re.findall(r'\{\{[^}]+\}\}', html)
    unique = sorted(set(remaining))
    if not remaining:
        vr.add('#1 플레이스홀더 정합성', True,
               expected='{{...}} 잔존 0개',
               actual='0개')
    else:
        vr.add('#1 플레이스홀더 정합성', False,
               expected='{{...}} 잔존 0개',
               actual=f'{len(remaining)}개 ({len(unique)}종): {unique[:10]}',
               guide='replace.py에서 해당 변수 치환 확인')


def check_2_count_integrity(html, vr):
    """#2 개수 정합성 - cov-card 15~18개 (간병 카드 유무), panel 3개, tab-btn 3개, ico 각 3개 (간병 0 또는 3)"""
    cov_card = len(re.findall(r'<div class="cov-card', html))
    panel_ids = re.findall(r'id="panel-(min|mid|max)"', html)
    tab_btn = len(re.findall(r'<button class="tab-btn', html))
    ico_c = len(re.findall(r'class="cov-ico ico-c"', html))
    ico_b = len(re.findall(r'class="cov-ico ico-b"', html))
    ico_h = len(re.findall(r'class="cov-ico ico-h"', html))
    ico_s = len(re.findall(r'class="cov-ico ico-s"', html))
    ico_i = len(re.findall(r'class="cov-ico ico-i"', html))
    ico_care = len(re.findall(r'class="cov-ico ico-care"', html))

    errors = []
    # 간병 카드는 선택적 (0개 또는 3개 — 탭별 1개씩)
    has_care = ico_care > 0
    expected_cov_card = 18 if has_care else 15
    if cov_card != expected_cov_card:
        errors.append(f'cov-card {cov_card}개 (기대 {expected_cov_card}, 간병 {"포함" if has_care else "미포함"})')
    if len(panel_ids) != 3:
        errors.append(f'panel id {len(panel_ids)}개 (기대 3)')
    if tab_btn != 3:
        errors.append(f'tab-btn {tab_btn}개 (기대 3)')
    if ico_c != 3:
        errors.append(f'ico-c(암) {ico_c}개 (기대 3)')
    if ico_b != 3:
        errors.append(f'ico-b(뇌) {ico_b}개 (기대 3)')
    if ico_h != 3:
        errors.append(f'ico-h(심) {ico_h}개 (기대 3)')
    if ico_s != 3:
        errors.append(f'ico-s(수) {ico_s}개 (기대 3)')
    if ico_i != 3:
        errors.append(f'ico-i(상) {ico_i}개 (기대 3)')
    # 간병: 0 또는 3만 허용
    if ico_care not in (0, 3):
        errors.append(f'ico-care(간병) {ico_care}개 (기대 0 또는 3 - 탭별 1개씩)')

    # sc-wrap은 유동 (탭별 담보 유무에 따라)
    sc_wrap = len(re.findall(r'<div class="sc-wrap">', html))
    if sc_wrap < 3 or sc_wrap > 15:
        errors.append(f'sc-wrap {sc_wrap}개 (기대 3~15)')

    if not errors:
        care_msg = ' / care 3' if has_care else ' / care 0'
        vr.add('#2 개수 정합성', True,
               expected=f'cov-card {expected_cov_card} / panel 3 / tab-btn 3 / ico 각 3{care_msg} / sc-wrap 3~15',
               actual=f'cov-card {cov_card} / panel {len(panel_ids)} / tab-btn {tab_btn} / sc-wrap {sc_wrap}{care_msg}')
    else:
        vr.add('#2 개수 정합성', False,
               expected=f'cov-card {expected_cov_card} / panel 3 / tab-btn 3 / ico 각 3 / 간병(care) 0 또는 3',
               actual=', '.join(errors),
               guide='replace.py의 cov-card 생성 로직 또는 base_template 변수 치환 확인')


def check_3_tab_active_consistency(html, vr):
    """#3 탭 active 정합성 ⭐ - panel.active와 tab-btn.active가 같은 탭"""
    # panel.active 추출
    panel_active = re.findall(r'<div class="panel active"\s+id="panel-(min|mid|max)"', html)
    # tab-btn.active 추출
    tab_active = re.findall(r'<button class="tab-btn ripple-host active"\s+id="tab-(min|mid|max)"', html)
    # JS recTab 변수 추출
    rec_tab_matches = re.findall(r"var\s+recTab\s*=\s*['\"](min|mid|max)['\"]", html)
    rec_tab_js = rec_tab_matches[0] if rec_tab_matches else None

    errors = []
    if len(panel_active) != 1:
        errors.append(f'panel.active {len(panel_active)}개 (기대 1)')
    if len(tab_active) != 1:
        errors.append(f'tab-btn.active {len(tab_active)}개 (기대 1)')

    if panel_active and tab_active:
        if panel_active[0] != tab_active[0]:
            errors.append(f'panel.active=panel-{panel_active[0]} vs tab-btn.active=tab-{tab_active[0]} (불일치)')
    if rec_tab_js and panel_active:
        if rec_tab_js != panel_active[0]:
            errors.append(f'JS recTab={rec_tab_js} vs panel.active=panel-{panel_active[0]} (불일치)')

    if not errors:
        vr.add('#3 탭 active 정합성', True,
               expected='panel.active 1개 = tab-btn.active 1개 = JS recTab',
               actual=f'panel-{panel_active[0] if panel_active else "?"} = tab-{tab_active[0] if tab_active else "?"} = recTab \'{rec_tab_js}\'')
    else:
        vr.add('#3 탭 active 정합성', False,
               expected='panel.active 1개 = tab-btn.active 1개 = JS recTab (모두 동일 탭)',
               actual=', '.join(errors),
               guide="replace.py에서 TAB_REC 기반 active 동기화 로직 확인. tab-mid 하드코딩 active 제거 필요.")


def check_4_rec_tab_mapping(html, vr):
    """#4 추천탭 매핑 - diff-title, prog-pct 색상, chips 종류"""
    rec_tab_matches = re.findall(r"var\s+recTab\s*=\s*['\"](min|mid|max)['\"]", html)
    rec_tab = rec_tab_matches[0] if rec_tab_matches else None

    if not rec_tab:
        vr.add('#4 추천탭 매핑', False,
               expected='recTab 변수 확인 가능',
               actual='recTab 추출 실패',
               guide='JS 영역의 recTab 변수 확인')
        return

    errors = []
    # 추천탭 diff-title: "추천하는 이유" 포함
    diff_title_rec = re.search(rf'id="diff-title-{rec_tab}">([^<]+)</div>', html)
    if diff_title_rec:
        if '추천하는 이유' not in diff_title_rec.group(1):
            errors.append(f'추천탭({rec_tab}) diff-title에 "추천하는 이유" 없음: "{diff_title_rec.group(1)}"')

    # 비추천탭 diff-title: "대비" 포함 (대비 빈약/줄어든/강화된 등)
    for t in ['min', 'mid', 'max']:
        if t == rec_tab:
            continue
        diff_title_other = re.search(rf'id="diff-title-{t}">([^<]+)</div>', html)
        if diff_title_other:
            if '대비' not in diff_title_other.group(1):
                errors.append(f'비추천탭({t}) diff-title에 "대비" 없음: "{diff_title_other.group(1)}"')

    if not errors:
        vr.add('#4 추천탭 매핑', True,
               expected=f'추천탭({rec_tab}) "추천하는 이유", 비추천 "대비 ..."',
               actual='매핑 일치')
    else:
        vr.add('#4 추천탭 매핑', False,
               expected='추천탭 "추천하는 이유", 비추천탭 "대비 ..."',
               actual='; '.join(errors),
               guide='replace.py의 NON_REC_TITLE_*, REC_PLAN_NAME 치환 로직 확인')


def check_5_cov_card_order(html, vr):
    """#5 cov-card 순서 - 각 탭에서 cancer→brain→heart→surgery→injury [→ care] 순"""
    expected_base = ['ico-c', 'ico-b', 'ico-h', 'ico-s', 'ico-i']
    expected_with_care = expected_base + ['ico-care']
    errors = []

    for panel_id in ['panel-min', 'panel-mid', 'panel-max']:
        # 각 panel 블록 추출 (panel 시작 ~ 다음 panel 시작 또는 문서 끝)
        m = re.search(rf'<div class="panel[^"]*"\s+id="{panel_id}">(.*?)(?=<div class="panel[^"]*"\s+id="panel-|<!-- ════|$)', html, re.DOTALL)
        if not m:
            errors.append(f'{panel_id} 블록 추출 실패')
            continue
        panel_html = m.group(1)
        # ico-care 포함 regex
        ico_sequence = re.findall(r'class="cov-ico (ico-[cbhsi]|ico-care)"', panel_html)
        if ico_sequence != expected_base and ico_sequence != expected_with_care:
            errors.append(f'{panel_id}: {ico_sequence} (기대 {expected_base} 또는 {expected_with_care})')

    if not errors:
        vr.add('#5 cov-card 순서', True,
               expected='암→뇌→심→수→상 [→ 간병] (ico-c,b,h,s,i[,care])',
               actual='3탭 모두 정렬 일치')
    else:
        vr.add('#5 cov-card 순서', False,
               expected='cancer→brain→heart→surgery→injury [→ care]',
               actual='; '.join(errors),
               guide='replace.py의 tab_cov_list 내 cov-card 배치 순서 확인')


def check_6_data_appearance(html, vr):
    """#6 데이터 등장 - 고객명, 가격, 회사명, 생년월일 등장 횟수"""
    # title 태그에서 고객명 후보 추출
    # 실제 템플릿 형식: <title>보험 안내 레포트 - {고객명}님</title>
    title_match = re.search(r'<title>보험\s*안내\s*레포트\s*-\s*([^<\s]+)님</title>', html)
    customer_name = title_match.group(1) if title_match else None

    # 보험명 3줄이 보험료비교 섹션 아래(.pcmp-product-name)로 이동됨 — 회사명 추출 위치 정합
    # v5: pcmp-product-name 내부가 <span class="pcmp-hl">로 래핑됨 → span 유무 모두 대응
    company_match = re.search(
        r'<div class="pcmp-product-name">(?:<span[^>]*>)?([^<]+)<', html)
    company_candidate = company_match.group(1).strip() if company_match else None

    # 생년월일: 다운로드 파일명에서 추출
    birth_match = re.search(r"toss_insureport_[^_]+_(\d{8})\.html", html)
    birth = birth_match.group(1) if birth_match else None

    # 가격 후보: tab-btn의 t-price
    tab_prices = re.findall(r'id="t-price-(?:min|mid|max)"[^>]*>([^<]+)원</span>', html)

    errors = []
    if customer_name:
        cnt = len(re.findall(re.escape(customer_name), html))
        if cnt < 3:
            errors.append(f'고객명 "{customer_name}" {cnt}회 등장 (기대 3회+)')
    else:
        errors.append('title에서 고객명 추출 실패')

    if company_candidate:
        cnt = len(re.findall(re.escape(company_candidate), html))
        if cnt < 1:
            errors.append(f'회사명 "{company_candidate}" {cnt}회 등장 (기대 1회+)')
    else:
        errors.append('pcmp-product-name에서 회사명 추출 실패')

    if birth:
        if len(re.findall(birth, html)) < 1:
            errors.append(f'생년월일 {birth} 등장 없음')

    for price in tab_prices:
        cnt = len(re.findall(re.escape(price), html))
        if cnt < 2:
            errors.append(f'가격 "{price}" {cnt}회 (기대 2회+)')

    if not errors:
        vr.add('#6 데이터 등장', True,
               expected='고객명 3+ / 회사명 1+ / 각 가격 2+',
               actual=f'고객명 "{customer_name}" / 회사명 "{company_candidate}" / 가격 {tab_prices}')
    else:
        vr.add('#6 데이터 등장', False,
               expected='주요 데이터 충분히 등장',
               actual='; '.join(errors),
               guide='replace.py의 고객/상품/가격 변수 치환 확인')


def check_7_hardcoded_items(html, vr):
    """#7 하드코딩 유지 항목 - guarantee-info 3종, 안내카드, 매회지급 문구, 1-5종 분류표"""
    errors = []

    # guarantee-info 3종 (각 3개 탭에 있거나, 치료비 무소시 개수 유동)
    cancer_gi = len(re.findall(r'class="guarantee-info cancer-guarantee"', html))
    brain_gi = len(re.findall(r'class="guarantee-info brain-guarantee"', html))
    heart_gi = len(re.findall(r'class="guarantee-info heart-guarantee"', html))

    if cancer_gi < 3:
        errors.append(f'cancer-guarantee {cancer_gi}개 (기대 3)')
    if brain_gi < 3:
        errors.append(f'brain-guarantee {brain_gi}개 (기대 3)')
    if heart_gi < 3:
        errors.append(f'heart-guarantee {heart_gi}개 (기대 3)')

    # 치료방식 안내카드 (암/뇌/심 각 탭에 있어야 함, 단 치료비 없으면 없을 수도)
    treatment_cancer = len(re.findall(r'치료방식에 따라 상이', html))
    treatment_bh = len(re.findall(r'치료방식에 따라 보장금액 상이', html))
    if treatment_cancer + treatment_bh < 3:
        errors.append(f'치료방식 안내카드 {treatment_cancer + treatment_bh}개 (기대 3+)')

    # 매회 지급 문구 (surgery cov-card에 있어야 하므로 최소 2~3개)
    repeat = len(re.findall(r'질병·상해 수술 발생 시마다 매회 지급', html))
    if repeat < 2:
        errors.append(f'매회 지급 문구 {repeat}개 (기대 2+)')

    # 1-5종 분류표 (surgery cov-card가 있는 탭에 있어야 함)
    surg_badge = len(re.findall(r'class="surg-badge s1"', html))
    if surg_badge < 2:
        errors.append(f'1-5종 분류표 1종 배지 {surg_badge}개 (기대 2+)')

    if not errors:
        vr.add('#7 하드코딩 유지 항목', True,
               expected='guarantee-info 3종×3 / 안내카드 / 매회지급 / 1-5종분류표',
               actual=f'cancer-gi {cancer_gi} / brain-gi {brain_gi} / heart-gi {heart_gi} / 안내카드 {treatment_cancer + treatment_bh} / 매회지급 {repeat} / 분류표 {surg_badge}')
    else:
        vr.add('#7 하드코딩 유지 항목', False,
               expected='빌더 함수 내장 하드코딩 유지',
               actual='; '.join(errors),
               guide='replace_jeonansu_reference.py의 빌더 함수를 그대로 복사했는지 확인')


def check_8_footer_and_onset(html, vr):
    """#8 footer·보장개시일 치환 확인"""
    errors = []

    onset_vars = ['COV_ONSET_CANCER_VAL', 'COV_ONSET_CANCER_TX_VAL',
                  'COV_ONSET_BRAIN_HEART_VAL', 'COV_ONSET_CIRC_VAL',
                  'COV_ONSET_SURG_VAL', 'COV_ONSET_INJ_VAL']
    for v in onset_vars:
        if '{{' + v + '}}' in html:
            errors.append(f'{v} 미치환')

    footer_vars = ['COMPANY_CS_NUMBER', 'DISPUTE_ORG', 'DISPUTE_NUMBER', 'ISSUE_DATE']
    for v in footer_vars:
        if '{{' + v + '}}' in html:
            errors.append(f'{v} 미치환')

    if '{{WAIVER_ITEMS}}' in html:
        errors.append('WAIVER_ITEMS 미치환')

    if not errors:
        vr.add('#8 footer·보장개시일', True,
               expected='COV_ONSET_*, Footer 변수, WAIVER_ITEMS 모두 치환',
               actual='모두 치환됨')
    else:
        vr.add('#8 footer·보장개시일', False,
               expected='하단 안내 변수 전체 치환',
               actual='; '.join(errors),
               guide='replace.py의 하단 섹션 변수 치환 로직 확인')


def check_9_json_integrity(html, vr):
    """#9 JSON 무결성 - cancer/brain/heart/surgery/injury 키 각 3회, care는 선택적 (0 또는 3회)"""
    keys_required = ['cancer', 'brain', 'heart', 'surgery', 'injury']
    errors = []
    for k in keys_required:
        # "  cancer: [" 또는 "cancer: [" 패턴
        cnt = len(re.findall(rf'\b{k}:\s*\[', html))
        if cnt != 3:
            errors.append(f'{k}: 키 {cnt}회 (기대 3)')

    # care 키는 선택적 (간병 담보 있으면 3회, 없으면 0회)
    care_cnt = len(re.findall(r'\bcare:\s*\[', html))
    has_care = care_cnt > 0
    if care_cnt not in (0, 3):
        errors.append(f'care: 키 {care_cnt}회 (기대 0 또는 3)')

    if not errors:
        total = 15 + (3 if has_care else 0)
        vr.add('#9 JSON 무결성', True,
               expected=f'{5 + (1 if has_care else 0)}종 × 3탭 = {total}회 키 등장',
               actual=f'{"6종 (간병 포함)" if has_care else "5종 (간병 미포함)"} 각 3회 정확')
    else:
        vr.add('#9 JSON 무결성', False,
               expected='cancer/brain/heart/surgery/injury 각 3회, care 0 또는 3',
               actual='; '.join(errors),
               guide='replace.py의 TABx_COVERAGE_JSON 치환 확인')


def check_10_builder_trace(html, vr):
    """#10 빌더 함수 사용 흔적 - sc-wrap 내부 구조가 빌더 결과물 형태인지"""
    errors = []

    # sc-wrap 내부에 sc-card 구조 확인
    sc_wraps = re.findall(r'<div class="sc-wrap">.*?</div>\s*</div>', html, re.DOTALL)
    if not sc_wraps:
        errors.append('sc-wrap 구조 추출 실패')
    else:
        # 최소 하나의 sc-wrap에 sc-card 포함되어 있어야 함
        has_sc_card = any('<div class="sc-card">' in s for s in sc_wraps)
        if not has_sc_card:
            errors.append('sc-wrap에 sc-card 구조 없음 - 빌더 미사용 추정')

    # 빌더 결과물 시그니처: sc-title, sc-amt, sc-detail이 세트로 존재해야 함
    sc_title_cnt = len(re.findall(r'<div class="sc-title">', html))
    sc_amt_cnt = len(re.findall(r'<div class="sc-amt">', html))
    if abs(sc_title_cnt - sc_amt_cnt) > 3:  # 3개 정도의 오차 허용 (안내카드)
        errors.append(f'sc-title {sc_title_cnt} vs sc-amt {sc_amt_cnt} 구조 불일치')

    if not errors:
        vr.add('#10 빌더 함수 사용 흔적', True,
               expected='sc-wrap 내부 sc-card/sc-title/sc-amt 구조 일관',
               actual=f'sc-title {sc_title_cnt}, sc-amt {sc_amt_cnt}')
    else:
        vr.add('#10 빌더 함수 사용 흔적', False,
               expected='빌더 함수로 생성된 구조',
               actual='; '.join(errors),
               guide='sc-wrap을 문자열 하드코딩하지 말고 빌더 함수 호출로 생성')


def check_11_edge_cases(html, vr):
    """#11 특이 구조 재발 방지 - tab-btn/panel active 중복 없음, 불일치 없음"""
    errors = []

    # tab-btn active 중복 체크
    tab_active_all = re.findall(r'<button class="tab-btn[^"]*\bactive\b', html)
    if len(tab_active_all) > 1:
        errors.append(f'tab-btn active 중복: {len(tab_active_all)}개')

    # panel active 중복 체크
    panel_active_all = re.findall(r'<div class="panel[^"]*\bactive\b', html)
    if len(panel_active_all) > 1:
        errors.append(f'panel active 중복: {len(panel_active_all)}개')

    # 빈 패널 없음 (panel id는 있는데 내용 누락)
    for panel_id in ['min', 'mid', 'max']:
        m = re.search(rf'id="panel-{panel_id}"[^>]*>(.*?)<!-- ════|id="panel-{panel_id}"[^>]*>(.*?)$',
                      html, re.DOTALL)
        content = (m.group(1) if m and m.group(1) else (m.group(2) if m else '')).strip() if m else ''
        if not content or len(content) < 500:
            errors.append(f'panel-{panel_id} 내용 비어있거나 비정상적으로 짧음')

    if not errors:
        vr.add('#11 특이 구조 재발 방지', True,
               expected='tab-btn/panel active 중복 없음, 모든 panel 내용 존재',
               actual='정상')
    else:
        vr.add('#11 특이 구조 재발 방지', False,
               expected='active 클래스 중복 없음',
               actual='; '.join(errors),
               guide='base_template의 tab-mid 하드코딩 active 처리 확인. replace.py에서 TAB_REC별 이동 필요.')


# ═══════════════════════════════════════════════════════════════
# 메인 검증 실행
# ═══════════════════════════════════════════════════════════════

def verify_html(filepath):
    """HTML 파일 검증 - VerifyResult 객체 반환"""
    if not os.path.exists(filepath):
        print(f"❌ 파일 없음: {filepath}")
        sys.exit(2)

    with open(filepath, 'r', encoding='utf-8') as f:
        html = f.read()

    vr = VerifyResult()

    # 11개 카테고리 순차 검증
    check_1_placeholders(html, vr)
    check_2_count_integrity(html, vr)
    check_3_tab_active_consistency(html, vr)
    check_4_rec_tab_mapping(html, vr)
    check_5_cov_card_order(html, vr)
    check_6_data_appearance(html, vr)
    check_7_hardcoded_items(html, vr)
    check_8_footer_and_onset(html, vr)
    check_9_json_integrity(html, vr)
    check_10_builder_trace(html, vr)
    check_11_edge_cases(html, vr)
    check_12_existing_insurance_section(html, vr)

    return vr


def check_12_existing_insurance_section(html, vr):
    """v14 신설 verify_existing_insurance_section(dict 반환)을 vr에 연결.
    기존 함수 본문은 변경하지 않고 어댑터로만 통합 (12-1~12-11)."""
    try:
        res = verify_existing_insurance_section(html)
    except Exception as e:  # noqa: BLE001 — 검증 자체 실패도 결함으로 보고
        vr.add('#12 신규/기존보험 섹션', False, '검증 함수 예외: %s' % e)
        return
    for key, ok in res.items():
        vr.add('#12 신규/기존보험 섹션', bool(ok),
                expected='%s 정합' % key,
                actual='OK' if ok else 'FAIL')


def print_report(vr, filepath):
    """검증 결과를 사람이 읽기 쉽게 출력"""
    print('=' * 70)
    print(f' 보장요약리포트 구조 정합성 검증 — {os.path.basename(filepath)}')
    print('=' * 70)

    for r in vr.results:
        icon = '✅' if r['passed'] else '❌'
        print(f"\n{icon} [{r['category']}]")
        if r['passed']:
            print(f"   기대값: {r['expected']}")
            print(f"   실제값: {r['actual']}")
        else:
            print(f"   기대값: {r['expected']}")
            print(f"   실제값: {r['actual']}")
            if r['guide']:
                print(f"   💡 수정가이드: {r['guide']}")

    print('\n' + '=' * 70)
    passed = vr.passed_count()
    total = vr.total_count()
    if vr.all_passed():
        print(f' 🎉 검증 결과: {passed}/{total} 통과 — 모든 항목 정상')
    else:
        print(f' ⚠️  검증 결과: {passed}/{total} 통과, {total - passed}개 실패')
    print('=' * 70)


def save_json_report(vr, filepath):
    """JSON 리포트 저장"""
    customer = os.path.basename(filepath).replace('toss_insureport_', '').split('_')[0]
    report_path = f'verify_report_{customer}.json'
    data = {
        'file': filepath,
        'passed_count': vr.passed_count(),
        'total_count': vr.total_count(),
        'all_passed': vr.all_passed(),
        'results': vr.results,
    }
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"\n📝 JSON 리포트 저장: {report_path}")


# v14 신규 검증 룰 (트리거 1 — [기존보험현황] 섹션)
# ─────────────────────────────────────────────────────────────
def verify_existing_insurance_section(html):
    """#12: [기존보험현황] 섹션 존재 + 본인/가족 분류 + 형광펜 적용 검증."""
    results = {}

    # #12-1: 섹션 존재
    results['12-1_section_exists'] = '<section id="existing-insurance-section">' in html

    # #12-2: 큰 타이틀 ([기존보험현황] + [보험 효율 개선을 위한 신규 보험 안내])
    results['12-2_title_exists'] = (
        '[기존보험현황]' in html and
        '[보험 효율 개선을 위한 신규 보험 안내]' in html
    )

    # #12-3: 펼친내용모두접기 버튼 (기존보험현황 1 + 보장항목별 상세 3 탭)
    # collapse-all-btn 은 단독/다중클래스(class="collapse-all-btn collapse-cov-cards")
    # 모두 존재 → 부분일치(class 속성 내 단어 단위)로 정확히 카운트
    btn_count = len(re.findall(r'class="[^"]*\bcollapse-all-btn\b[^"]*"', html))
    results['12-3_collapse_btn_count_ge_4'] = btn_count >= 4  # 기존보험현황 1 + 보장항목별 3

    # #12-4: cov-title-row 영역 (보장항목별 상세 sticky)
    cov_title_row_count = html.count('<div class="cov-title-row">')
    results['12-4_cov_title_row_count_eq_3'] = cov_title_row_count == 3

    # #12-5: 형광펜 (cov-row.cov-hl) — references/ 5종 정합 매칭
    highlight_count = html.count('cov-row cov-hl')
    results['12-5_highlight_applied'] = highlight_count > 0  # 기존보험 ❌ 케이스는 0 정합

    # #12-6: 7 sub-title 분류 (실손의료비보장·암관련·뇌혈관·심장·수술·상해/기타·보험료 효율 낮음)
    sub_titles = [
        '실손의료비보장',
        '암관련보장',
        '뇌혈관관련',
        '심장관련',
        '수술관련',
        '상해/기타보장',
        '보험료 효율이 높지 않은 보장',
    ]
    # 본 영역은 케이스별 분류 결과에 따라 일부만 등장 정합 — 1개 이상 등장 시 ✅
    sub_count = sum(1 for t in sub_titles if t in html)
    results['12-6_sub_title_ge_1'] = sub_count >= 1

    # #12-7: CSS 변수 동적 본문 (--sticky-top-exi, --sticky-top-cov)
    results['12-7_css_var_dynamic'] = (
        '--sticky-top-exi' in html and
        '--sticky-top-cov' in html
    )

    # #12-8: 보험료비교 섹션 골격 (sub타이틀 2종 + wrap)
    results['12-8_pcmp_section'] = (
        'class="pcmp-wrap"' in html and
        '기준 적용보험 보험료 비교 (최저보험료 확인)]' in html and
        '보험료 비교를 통해 적용된 보험상품' in html
    )

    # #12-9: 보험료비교 표 + 강조행 + 순위접두 + 구조화 note
    results['12-9_pcmp_table'] = (
        html.count('class="pcmp-block"') >= 1 and
        html.count('class="pcmp-table"') >= 1 and
        html.count('pcmp-row-hl') >= 1 and
        '1순위' in html and
        html.count('class="pcmp-note-item"') >= 1
    )

    # #12-10: 보험명 3줄 이동 + 형광펜(span.pcmp-hl) + 신규문구
    results['12-10_product_moved'] = (
        'class="hero-intro"' in html and
        'class="pcmp-product-name"' in html and
        'class="pcmp-hl"' in html and
        '<div class="hero-title">' not in html
    )

    # #12-11: 플랜 4줄 (item N개 + 괄호줄 1개) + 미치환 placeholder 부재
    plan_items = html.count('class="pcmp-plan-item"')
    results['12-11_plan_list'] = (
        plan_items >= 1 and
        html.count('class="pcmp-plan-paren"') == 1 and
        '{{PLAN_LIST_HTML}}' not in html and
        '{{TAB_COUNT}}' not in html and
        '보장플랜별 보장항목,보험료 비교를 위한' in html
    )

    return results


def main():
    if len(sys.argv) < 2:
        print("사용법: python3 verify.py <HTML파일경로> [--json]")
        sys.exit(2)

    filepath = sys.argv[1]
    save_json = '--json' in sys.argv

    vr = verify_html(filepath)
    print_report(vr, filepath)

    if save_json:
        save_json_report(vr, filepath)

    sys.exit(0 if vr.all_passed() else 1)


if __name__ == '__main__':
    main()

# ─────────────────────────────────────────────────────────────


