"""parse.py v2 — raw 자료 파서 + 본인/가족 분리"""
import re
from pathlib import Path

# 본 데이터 38 소분류 → builder 28 키 매핑
SUBCAT_TO_BUILDER = {
    "질병입원의료비": "silson_disease_hosp",
    "질병외래의료비": "silson_disease_out",
    "질병처방조제료": "silson_disease_pres",
    "상해입원의료비": "silson_injury_hosp",
    "상해외래의료비": "silson_injury_out",
    "상해처방조제료": "silson_injury_pres",
    "일반암진단": "cancer_general_diag",
    "소액암(유사암)진단": "cancer_small_diag",
    "고액암진단": "cancer_high_treat",
    "뇌혈관질환진단": "brain_diag",
    "허혈성심장질환진단": "heart_diag",
    "질병수술": "surgery_disease",
    "상해수술": "surgery_injury",
    "암수술": "surgery_cancer",
    "뇌혈관질환수술": "surgery_brain",
    "허혈성심장질환수술": "surgery_heart",
    "질병입원": "hosp_daily_disease",
    "상해입원": "hosp_daily_injury",
    "질병사망": "death_disease",
    "상해사망": "death_injury",
    "질병80%이상후유장해": "disability_disease_50",
    "질병80%미만후유장해": "disability_disease_3",
    "상해80%이상후유장해": "disability_injury_50",
    "상해80%미만후유장해": "disability_injury_3",
    "골절진단": "fracture_diag",
    "화상진단": "burn_diag",
    "가족생활배상책임담보": "liability_family",
    "일상생활배상책임담보": "liability_daily",
    "교통사고처리지원금": "driver_traffic",
    "벌금(대물)": "driver_fine_prop",
    "벌금(대인)": "driver_fine_person",
    "변호사선임비용": "driver_lawyer",
    "자동차부상치료비": "driver_injury",
    "화재벌금": "fire_fine",
    "보존치료": "dental_cavity",
    "보철치료": "dental_crown",
}


def normalize(txt):
    return [l.strip() for l in txt.replace("\r\n", "\n").split("\n")]


def parse_amount(s):
    if not s or s == "-":
        return 0
    s = s.replace(",", "").replace("만원", "").strip()
    try:
        return int(s)
    except ValueError:
        return 0


def parse_won(s):
    if not s:
        return 0
    s = s.replace(",", "").replace("원", "").strip().lstrip("*").strip()
    try:
        return int(s)
    except ValueError:
        return 0


def classify(contractor, insured, owner):
    """피보험자 영역 기준 분류 (self/common/auto/family)"""
    if insured == "본인":
        return "self"
    if insured.startswith("본인,") or insured.startswith("본인 "):
        return "common"
    if "기명피보험자" in insured or "한정운전" in insured or re.search(r"^\S*\d", insured):
        return "auto"
    if insured == owner:
        return "self"
    if "*" in insured:
        return "family"
    return "self"


def find_idx(lines, label):
    for i, l in enumerate(lines):
        if l == label:
            return i
    return -1


def parse_customer(txt_path):
    txt = Path(txt_path).read_text(encoding="utf-8")
    lines = [l for l in normalize(txt) if l != ""]
    name = lines[0]

    gender = "—"
    i = find_idx(lines, "성별")
    if i >= 0 and i + 1 < len(lines):
        v = lines[i + 1]
        gender = "여성" if v == "여자" else ("남성" if v == "남자" else "—")

    insurance_age = 0
    i = find_idx(lines, "생년월일")
    if i >= 0 and i + 1 < len(lines):
        m = re.search(r"보험나이\s*(\d+)\s*세", lines[i + 1])
        if m: insurance_age = int(m.group(1))

    n_cols = 0
    for l in lines:
        m = re.search(r"페이지 노출 보험\s*(\d+)\s*개", l)
        if m: n_cols = int(m.group(1)); break

    insurance_count = 0
    i = find_idx(lines, "보험 개수")
    if i >= 0 and i + 1 < len(lines):
        m = re.search(r"(\d+)\s*개", lines[i + 1])
        if m: insurance_count = int(m.group(1))

    totals = {"monthly": 0, "paid": 0, "remaining": 0, "grand": 0}
    label_map = {"월납 보험료 합계": "monthly", "기납 보험료 합계": "paid",
                 "잔여 보험료 합계": "remaining", "총 보험료 합계": "grand"}
    for i, l in enumerate(lines):
        if l in label_map and i + 1 < len(lines):
            totals[label_map[l]] = parse_won(lines[i + 1])

    def slice_label(label, n):
        i = find_idx(lines, label)
        if i < 0: return [""] * n
        result = lines[i + 1: i + 1 + n]
        return result + [""] * max(0, n - len(result))

    # 첫 "보험명" 라벨
    first_name_idx = find_idx(lines, "보험명")
    ins_names = lines[first_name_idx + 1: first_name_idx + 1 + n_cols] if first_name_idx >= 0 else [""] * n_cols
    while len(ins_names) < n_cols:
        ins_names.append("")

    ins = {
        "names": ins_names,
        "companies": slice_label("보험사명", n_cols),
        "contract_dates": slice_label("계약일", n_cols),
        "status": slice_label("계약상태", n_cols),
        "renewal": slice_label("갱신 유무", n_cols),
        "contractor": slice_label("계약자/피보험자", n_cols),
        "payment_status": slice_label("납입 여부", n_cols),
        "payment_period": slice_label("납입주기/납입기간", n_cols),
        "coverage_end": slice_label("보장만기/만기연령", n_cols),
        "pay_end": slice_label("납입종료일/종료연령", n_cols),
        "monthly_won": [parse_won(s) for s in slice_label("월납보험료", n_cols)],
        "paid_won": [parse_won(s) for s in slice_label("기납보험료", n_cols)],
        "remaining_won": [parse_won(s) for s in slice_label("잔여보험료", n_cols)],
        "total_won": [parse_won(s) for s in slice_label("총보험료", n_cols)],
    }

    # 매트릭스 추출 — 두 번째 "보험명" 라인 다음부터
    matrix_start = -1
    cnt = 0
    for i, l in enumerate(lines):
        if l == "보험명":
            cnt += 1
            if cnt == 2:
                matrix_start = i
                break
    matrix_end = find_idx(lines, "상품 별 보장 목록")

    ins_matrix = [dict() for _ in range(n_cols)]
    cat_totals = {}
    if matrix_start >= 0 and matrix_end >= 0 and n_cols > 0:
        body = lines[matrix_start + 1 + n_cols: matrix_end]
        i = 0
        while i < len(body):
            sub = body[i]
            if sub in SUBCAT_TO_BUILDER:
                bkey = SUBCAT_TO_BUILDER[sub]
                if i + 1 < len(body):
                    cat_totals[bkey] = parse_amount(body[i + 1])
                    for col in range(n_cols):
                        if i + 2 + col < len(body):
                            ins_matrix[col][bkey] = parse_amount(body[i + 2 + col])
                        else:
                            ins_matrix[col][bkey] = 0
                i += 1 + 1 + n_cols
                continue
            i += 1

    # 분류
    ins_class = []
    ins_family_name = []
    for j in range(n_cols):
        ct = ins["contractor"][j] if j < len(ins["contractor"]) else ""
        if "/" in ct:
            c, ins_per = ct.split("/", 1)
        else:
            c, ins_per = ct, ""
        cls = classify(c, ins_per, name)
        ins_class.append(cls)
        ins_family_name.append(ins_per if cls == "family" else "")

    # 갱신형 (실손/실비 단일 제외, exact match)
    has_renewal = False
    for j, ren in enumerate(ins["renewal"]):
        if ren not in ("갱신형 특약", "갱신형 보험"): continue
        bn = ins_names[j] if j < len(ins_names) else ""
        if "실손" in bn or "실비" in bn: continue
        has_renewal = True
        break

    return {
        "name": name, "gender": gender, "insurance_age": insurance_age,
        "n_cols": n_cols, "insurance_count": insurance_count,
        "monthly_total_won": totals["monthly"], "paid_total_won": totals["paid"],
        "remaining_total_won": totals["remaining"], "grand_total_won": totals["grand"],
        "ins": ins, "ins_matrix": ins_matrix, "ins_class": ins_class,
        "ins_family_name": ins_family_name, "cat_totals": cat_totals,
        "has_renewal": has_renewal,
    }


def build_entries(parsed, indices):
    """주어진 인덱스 영역만 builder insurances entry 리스트로 변환"""
    entries = []
    ins = parsed["ins"]
    for j in indices:
        entries.append({
            "name": ins["names"][j], "company": ins["companies"][j],
            "contract_date": ins["contract_dates"][j],
            "is_renewal": ins["renewal"][j] in ("갱신형 특약", "갱신형 보험"),
            "contractor_insured": ins["contractor"][j],
            "payment_status": ins["payment_status"][j],
            "payment_period": ins["payment_period"][j],
            "coverage_end": ins["coverage_end"][j],
            "monthly_premium": f"{ins['monthly_won'][j]:,}",
            "paid_premium": f"{ins['paid_won'][j]:,}",
            "remaining_premium": f"{ins['remaining_won'][j]:,}",
            "total_premium": f"{ins['total_won'][j]:,}",
            "matrix": parsed["ins_matrix"][j],
        })
    return entries


def has_5jong_coverage(matrix):
    """5종 보장 (실손·암·뇌·심·수술) 中 1건 이상 ✅ 검증"""
    if matrix.get("silson_disease_hosp", 0) >= 1 or matrix.get("silson_injury_hosp", 0) >= 1:
        return True
    if matrix.get("cancer_general_diag", 0) >= 1:  # 일반암 진단비 적용
        return True
    if matrix.get("brain_diag", 0) >= 1:  # 뇌혈관 진단비
        return True
    if matrix.get("heart_diag", 0) >= 1:  # 허혈성심장 진단비
        return True
    if matrix.get("surgery_disease", 0) >= 1 or matrix.get("surgery_injury", 0) >= 1:
        return True
    return False


def has_death_only(name, matrix):
    """사망단독 (종신·정기·생명 + 사망 ✅ + 그 외 보장 ❌) 검증"""
    is_life = any(k in name for k in ["종신", "정기", "생명", "라이프"])
    if not is_life:
        return False
    has_death = matrix.get("death_disease", 0) >= 1 or matrix.get("death_injury", 0) >= 1
    if not has_death:
        return False
    # 그 외 모든 보장 ❌
    other_keys = [k for k in matrix if k not in ("death_disease", "death_injury") and matrix[k] >= 1]
    return len(other_keys) == 0


def classify_8step(parsed, j):
    """8단계 분류 (insurance_order.md 정합) — 우선순위 적용

    1. 실손 → 1
    2. 자동차/이륜차 → 8
    3. 저축/연금 → 7
    4. 주택화재 → 6
    5. 운전자 → 5
    6. 5종 보장 ≥1 + 사망단독 ❌ → 2 (보장성)
    7. 사망단독 ✅ → 3
    8. 그 외 → 4
    """
    name = parsed["ins"]["names"][j]
    matrix = parsed["ins_matrix"][j]
    cls = parsed["ins_class"][j]

    # 1. 실손
    if "실손" in name or matrix.get("silson_disease_hosp", 0) >= 1 or matrix.get("silson_injury_hosp", 0) >= 1:
        return 1
    # 8. 자동차/이륜차
    if cls == "auto" or "자동차" in name or "이륜차" in name:
        return 8
    # 7. 저축/연금
    if any(k in name for k in ["저축", "연금", "유니버셜", "Standby", "스탠바이"]):
        return 7
    # 6. 주택화재
    if "화재" in name and ("주택" in name or "화재보험" in name):
        return 6
    # 5. 운전자
    if "운전자" in name:
        return 5
    # 6 vs 2 분기: 5종 보장 ✅
    if has_5jong_coverage(matrix):
        if has_death_only(name, matrix):
            return 3
        return 2
    # 7. 사망단독
    if has_death_only(name, matrix):
        return 3
    # 8. 그 외 → 4 (1·2·3 외)
    return 4


def sort_by_insurance_order(parsed, indices):
    """주어진 indices를 8단계 분류 + 같은 분류 내 최근 가입일 정렬 (왼쪽=최근)"""
    def sort_key(j):
        step = classify_8step(parsed, j)
        date_str = parsed["ins"]["contract_dates"][j] or "0000-00-00"
        # 최근 날짜가 앞 (왼쪽) → 날짜 내림차순 → 음수 변환
        return (step, -int(date_str.replace("-", "") or 0))
    return sorted(indices, key=sort_key)


def stats_box_4classify(parsed, indices):
    """stats-box 4분류 매핑 (보장성·기타·저축·미확인)
    - 보장성 = 분류 1+2 (실손 + 5종 보장 ≥1)
    - 기타 = 분류 3+4+5+6+8 (사망단독 + 1·2·3외 + 운전자 + 주택화재 + 자동차)
    - 저축 = 분류 7
    - 미확인 = 월보험료 0 또는 일시납·납입중 ❌

    납입중 + 월보험료 ≥1만 합산 (납입종료·일시납 ❌)
    """
    protection_c = protection_p = 0
    other_c = other_p = 0
    saving_c = saving_p = 0
    unconfirmed_c = 0
    for j in indices:
        step = classify_8step(parsed, j)
        prem = parsed["ins"]["monthly_won"][j]
        pay_status = parsed["ins"]["payment_status"][j]
        period = parsed["ins"]["payment_period"][j]
        status = parsed["ins"]["status"][j]
        # 미확인 = 정상 ❌ 또는 월보험료 0 또는 일시납·납입종료
        is_active = (status == "정상" and pay_status == "납입중" and prem > 0 and "일시납" not in period)
        if not is_active:
            unconfirmed_c += 1
            continue
        if step in (1, 2):
            protection_c += 1
            protection_p += prem
        elif step == 7:
            saving_c += 1
            saving_p += prem
        else:  # 3, 4, 5, 6, 8
            other_c += 1
            other_p += prem
    return {
        "protection_count": protection_c, "protection_premium": protection_p,
        "other_count": other_c, "other_premium": other_p,
        "saving_count": saving_c, "saving_premium": saving_p,
        "unconfirmed_count": unconfirmed_c,
    }


def split_self_family(parsed):
    """본인(self+common) / 자동차(auto) / 가족(family 그룹별) 분리"""
    self_idx = [j for j, c in enumerate(parsed["ins_class"]) if c in ("self", "common")]
    auto_idx = [j for j, c in enumerate(parsed["ins_class"]) if c == "auto"]
    family_idx = [j for j, c in enumerate(parsed["ins_class"]) if c == "family"]

    groups = {}
    for j in family_idx:
        fname = parsed["ins_family_name"][j]
        groups.setdefault(fname, []).append(j)

    # 정렬: 보험료 많은 순 → 건수 많은 순
    sort_key = [(fname, idxs,
                 sum(parsed["ins"]["monthly_won"][j] for j in idxs),
                 len(idxs)) for fname, idxs in groups.items()]
    sort_key.sort(key=lambda x: (-x[2], -x[3]))

    # 본인 매트릭스 재계산 (self+common만)
    self_matrix = {}
    for j in self_idx:
        for k, v in parsed["ins_matrix"][j].items():
            self_matrix[k] = self_matrix.get(k, 0) + v

    return {
        "self_indices": self_idx, "auto_indices": auto_idx,
        "family_groups": [(fname, idxs) for fname, idxs, _, _ in sort_key],
        "self_matrix": self_matrix,
    }
