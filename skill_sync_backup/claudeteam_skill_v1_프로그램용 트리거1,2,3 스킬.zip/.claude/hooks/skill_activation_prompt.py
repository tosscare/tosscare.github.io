#!/usr/bin/env python3
"""
UserPromptSubmit Hook — 트리거 명령어 감지 시 SKILL.md 영역 강제 주입
본 Hook은 본 클로드가 SKILL.md 본문 무시 영역 차단 본질 (advisory → deterministic).
"""
import json
import sys
import re


# 트리거 명령어 영역 (SKILL.md §83~97 박제 본문)
TRIGGER_PATTERNS = {
    "트리거1": re.compile(r"(상담자료\s*교체|/트리거1)", re.IGNORECASE),
    "트리거2": re.compile(
        r"(새보험분석|새로운\s*보험\s*분석|다른\s*보험\s*분석|이\s*보험\s*분석|보험상품\s*분석|/트리거2)",
        re.IGNORECASE,
    ),
    "트리거3": re.compile(r"(레포트작성|^\s*레포트\s*$|/트리거3)", re.IGNORECASE),
    "용어": re.compile(r"용어를?\s*보여줘|용어보여줘", re.IGNORECASE),
}


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    prompt = data.get("prompt", "") or data.get("user_prompt", "")
    if not prompt:
        sys.exit(0)

    matched = None
    for name, pattern in TRIGGER_PATTERNS.items():
        if pattern.search(prompt):
            matched = name
            break

    if not matched:
        sys.exit(0)

    # SKILL.md 영역 강제 주입 영역 본문
    additional_context = f"""

[Skill Activation — 강제 주입]
트리거 감지: {matched}

CRITICAL — 본 트리거 진행 시 절대 룰:
1. .claude/skills/report-skill/SKILL.md 본문 view 의무 (본 영역 ❌ 시 자격 박탈)
2. 8 확정 원본 한 글자 변경 ❌ — exec·import·python3 직접 호출만
3. references/ + mappings/ 영역 view 의무 (트리거 본문에 따라)
4. 변명·핑계 ❌ — "오버엔지니어링·간소화·외부 의존성·안전 처리·회피" 발화 시 자격 박탈
5. 산출 후 사용자 시점 검증 의무 — 합의 양식·디자인·색깔·변수 영역 100% 정합

본 영역 위반 시 자격 박탈 + 즉시 정정 의무.
"""
    print(additional_context)
    sys.exit(0)


if __name__ == "__main__":
    main()
