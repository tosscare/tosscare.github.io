# claudeteam — 토스 레포트 스킬 통합 영역 (Claude Code + Hooks + Sub-agents)

## 본 영역 본질

- **트리거 1·2·3** Slash command 영역 본문
- **8 확정 원본 + SKILL.md + references/ + mappings/** 영구 박제 (한 글자 변경 ❌)
- **Hooks 4종** 영역 — 본 클로드 본능 100% 차단 본질 (deterministic)
- **Sub-agents** 영역 — 트리거 3 N명 병렬 본질
- **Skill Activation** 영역 — 트리거 명령어 시 SKILL.md 강제 주입

## 적용 영역 (mr.와이 — Windows)

### 1. 압축 해제 영역

본 zip 영역을 `C:\dev\projects\claudeteam\` 영역에 압축 해제.

```
C:\dev\projects\claudeteam\
├── .claude\               ← 본 zip 영역
│   ├── settings.json
│   ├── skills\
│   │   └── report-skill\  ← 박제 본문 (SKILL.md + 8 확정 원본 + references + mappings)
│   ├── commands\          ← /트리거1, /트리거2, /트리거3
│   ├── agents\            ← toss-report-agent (Sub-agent 병렬 본질)
│   └── hooks\             ← Python Hook 4종 (PreToolUse·PostToolUse·Stop·UserPromptSubmit)
├── input\                 ← 고객정보 영역 (data1.txt·data2.txt...)
├── output\                ← 산출물 영역
└── work\                  ← 기존 카톡 자동화 영역 (claudeteam ⑳)
```

### 2. Claude Code 적용 영역

```powershell
cd C:\dev\projects\claudeteam
claude
```

본 영역 진입 시 자동:
- `.claude/skills/report-skill/SKILL.md` 영역 자동 로드
- `.claude/settings.json` Hooks 4종 자동 발동
- `.claude/commands/*.md` Slash command 등록

### 3. 1명 검증 영역 (전병철님)

#### 3-1. 입력 영역 본문

```
C:\dev\projects\claudeteam\input\전병철\
├── data.txt           ← 고객정보 (1명 1파일 표준)
└── jeonansu_reference.html  ← (트리거 1 영역 — 기존 상담자료)
```

#### 3-2. 트리거 3 영역 본문

```
/트리거3
```

본 영역 발동 시:
1. `input/` 영역 1명 자동 감지 (전병철)
2. SKILL.md 본문 + 8 확정 원본 영역 자동 로드
3. `output/전병철/` 영역 산출:
   - `report.png` (본인 보장요약)
   - `report_01.png`·`report_02.png`... (가족 — 본문 영역에 따라)
   - `message.txt` (txt 메시지)
4. Stop Hook 영역 사용자 시점 검증 자동 발동

#### 3-3. 정합 검증

mr.와이 영역에서 산출물 검증:
- 합의 양식 정합 (Nanum Gothic 폰트·data-skin·외부 스크립트·CSS 영역)
- 합의 색상·디자인·구조 영역 100% 정합
- 양주미님 합의 양식 영역 정합

### 4. 정합 통과 → 정식 운용 영역

#### 트리거 1 (상담자료 교체)
```
/트리거1
```
입력: 기존 상담자료 + 고객정보 → 신규 상담자료 HTML 산출 (스킨 선택 영역)

#### 트리거 2 (새보험분석)
```
/트리거2
```
입력: 새 보험상품 자료 → SKILL.md·terms·mappings 갱신만 (HTML 산출 ❌)

#### 트리거 3 (레포트작성 — N명 병렬)
```
/트리거3
```
입력: `input/data1.txt`·`data2.txt`...`dataN.txt` → N개 Sub-agent 병렬 → 본인+가족 PNG + txt + zip 산출

## 본 영역의 본질

| 영역 | 본문 |
|---|---|
| **정확성** | Hooks deterministic 100% — 본 클로드 본능 직접 차단 |
| **속도** | Sub-agents 병렬 — N명 동시 처리 (직렬 N배 → 병렬 N배 빠름) |
| **간소화** | 명령 1줄 (`/트리거3`) — N명 자동 분기·취합 |
| **누락·변경·왜곡·훼손 ❌** | PreToolUse(차단) + PostToolUse(검증) + Stop(사용자 시점) + Skill Activation(강제 주입) 4중 영역 |

## Hook 영역 본질

| Hook | 영역 | 본문 |
|---|---|---|
| **PreToolUse** | Edit·Write·MultiEdit | 8 확정 원본·SKILL.md·references·mappings 변경 시도 즉시 차단 (exit 2) |
| **PostToolUse** | Bash | exec·import·python3 호출 후 산출물 정합 검증 |
| **Stop** | 본 클로드 "완료" 시 | 사용자 시점 검증 (Nanum Gothic·data-skin·합의 양식) — 결함 시 재진행 강제 |
| **UserPromptSubmit** | mr.와이 명령어 입력 시 | 트리거 명령어 감지 → SKILL.md + 8 확정 원본 영역 강제 주입 |

## 본 영역 검증 의무

### 본 클로드 자체 한계

본 영역은 **본 클로드 환경 (Linux + Claude.ai 웹)** 영역에서 작성. mr.와이 환경 (**Windows + Claude Code**) 작동 검증 의무.

### 검증 절차

1. mr.와이 압축 해제 → Claude Code 진입
2. `/트리거3` 1명 검증 (전병철님)
3. 산출물 영역 정합 검증
4. 결함 시 본 클로드 정정 영역 진행
5. 정합 통과 시 정식 운용 영역 진입

## 박제 본문 영역 정합

본 영역 진행 시 worklog·02_summary·instruction 영역 갱신 의무 (㉤ 룰).
