#!/usr/bin/env python3
"""
skin_preview_gen.py — 스킨 선택 Artifact 생성기 (6단계 사용)

사용법:
    python3 skin_preview_gen.py \
      --customer "김리아" \
      --cust-info "여성 · 만 39세 · 1987년생" \
      --rec-plan "보장완성플랜" \
      --rec-price "156,012" \
      --rec-complete "필요한 보장 완성 (100%)" \
      --tab1-name "기존보장비교" --tab1-price "99,072" \
      --tab2-name "부족보장추가플랜" --tab2-price "62,459" \
      --tab3-name "보장완성플랜" --tab3-price "156,012" \
      --tab-rec 3 \
      --output /mnt/user-data/outputs/skin_preview_김리아님.html

추천 탭 번호(--tab-rec)에 따라 해당 탭만 rec 클래스 적용.
템플릿 파일: skin_preview_template.html (같은 폴더)
"""
import argparse
import os
import sys

SKIN_INFO = [
    ("1", "토스블루", "기본 · 신뢰·정통"),
    ("2", "베이지", "따뜻·차분"),
    ("3", "스카이블루", "청량·시원"),
    ("4", "핑크", "부드러움·친근"),
    ("5", "다크", "프리미엄·모던"),
]

SLIDE_TPL = """<div class="slide" data-skin="{num}">
  <div class="skin-head"><div style="display:flex;align-items:center;gap:8px;"><span class="num">{num}</span><div><div class="name">{name}</div><div class="tag">{tag}</div></div></div></div>
  <div class="mini-nav"><span class="logo">🔷 insurance</span><span class="label">보장요약</span></div>
  <div class="cust-card"><div class="cname">{customer}님</div><div class="cinfo">{cust_info}</div></div>
  <div class="tabs">{tabs}</div>
  <div class="plan-card"><div class="badge">★ 추천 플랜</div><div class="pname">{rec_plan}</div><div class="pprice">{rec_price}<span class="unit">원/월</span></div><div class="prog"><div class="prog-row"><span class="pl">필요보장 완성도</span><span class="pv">{rec_complete}</span></div><div class="prog-track"><div class="prog-fill"></div></div></div></div>
  <div class="cov-list"><div class="cov"><div class="cov-ico ico-c">🎗️</div><div class="cov-txt"><div class="ct">암 진단</div><div class="ca">일반암·유사암·전이암</div></div></div><div class="cov"><div class="cov-ico ico-b">🧠</div><div class="cov-txt"><div class="ct">뇌혈관</div><div class="ca">진단·혈전용해·수술</div></div></div><div class="cov"><div class="cov-ico ico-h">❤️</div><div class="cov-txt"><div class="ct">심장질환</div><div class="ca">허혈·부정맥·수술</div></div></div></div>
</div>"""


def build_tabs(tabs_data, rec_idx):
    """tabs_data = [(name, price), (name, price), (name, price)]. rec_idx: 1|2|3"""
    out = []
    for i, (name, price) in enumerate(tabs_data, 1):
        rec_cls = " rec" if i == rec_idx else ""
        out.append(f'<div class="tab{rec_cls}"><div class="tn">{name}</div><div class="tp">{price}</div></div>')
    return "".join(out)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--customer", required=True)
    p.add_argument("--cust-info", required=True)
    p.add_argument("--rec-plan", required=True)
    p.add_argument("--rec-price", required=True)
    p.add_argument("--rec-complete", required=True)
    p.add_argument("--tab1-name", required=True)
    p.add_argument("--tab1-price", required=True)
    p.add_argument("--tab2-name", required=True)
    p.add_argument("--tab2-price", required=True)
    p.add_argument("--tab3-name", required=True)
    p.add_argument("--tab3-price", required=True)
    p.add_argument("--tab-rec", required=True, type=int, choices=[1, 2, 3])
    p.add_argument("--output", required=True)
    p.add_argument("--template", default=None)
    args = p.parse_args()

    tpl_path = args.template or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "skin_preview_template.html"
    )
    with open(tpl_path, "r", encoding="utf-8") as f:
        template = f.read()

    tabs_html = build_tabs(
        [
            (args.tab1_name, args.tab1_price),
            (args.tab2_name, args.tab2_price),
            (args.tab3_name, args.tab3_price),
        ],
        args.tab_rec,
    )

    slides = []
    for num, name, tag in SKIN_INFO:
        slides.append(
            SLIDE_TPL.format(
                num=num,
                name=name,
                tag=tag,
                customer=args.customer,
                cust_info=args.cust_info,
                tabs=tabs_html,
                rec_plan=args.rec_plan,
                rec_price=args.rec_price,
                rec_complete=args.rec_complete,
            )
        )

    slides_html = "\n      ".join(slides)
    out = template.replace("<!-- SLIDE_PLACEHOLDER -->", slides_html)

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(out)

    print(f"✅ 스킨 선택 Artifact 생성: {args.output}")
    print(f"   크기: {os.path.getsize(args.output):,} bytes")


if __name__ == "__main__":
    main()
