"""
report_builder.py — 트리거 3 (레포트작성) 통합 빌더 v10

본질:
- 트리거 3 호출 시 3종 산출물 통합 생성 (png레포트 + png표레포트 + txt문구)
- 베이스 템플릿 3종 활용 + 변수 치환 (단일 source 본문)
- 모든 dict 키·변수 영문 통일
- 가변 보험 개수 N 지원 (body width = 422 + 120*N)
- N개 보험 동적 ins-table·matrix HTML 생성

활용 양식:
    from report_builder import generate_trigger3_reports
    generate_trigger3_reports(customers, output_zip_path)

customer dict 본문 (영문 통일):
    {
        "name": "강선영",
        "gender": "여성",
        "insurance_age": 53,
        "location": "—",
        "is_family": False,
        # 5종 라벨 (실손/암/뇌/심장/수술)
        "labels": {"silson": "적정", "cancer": "과잉", "brain": "빈약", "heart": "빈약", "surgery": "과잉"},
        # 5종 카드 detail (트리거 1·2 공용)
        "details": {
            "silson_out": "30만", "silson_hosp": "5,000만",
            "cancer_diag": "15,000만원", "cancer_treat": "0만원",
            "brain_diag": "1,000만원", "brain_treat": "0만원",
            "heart_diag": "1,000만원", "heart_treat": "0만원",
            "surgery_disease": "520만원", "surgery_injury": "2,170만원",
        },
        # 보험료 영역
        "monthly_premium_total": "469,826",
        "insurance_count": 10,
        "protection_count": 10, "protection_premium": "469,826",
        "saving_count": 0, "saving_premium": "0",
        "other_count": 0, "other_premium": "0",
        "unconfirmed_count": 0,
        "self_premium": "469,826", "family_premium": "0",
        "total_paid_premium": "23,140,388",
        "total_remaining_premium": "84,104,692",
        "total_all_premium": "107,245,080",
        # 카드 ③ 5단계 라벨
        "level_label": "매우과잉",     # 매우과잉/높은편/보통/낮음/미확인
        "completion_pct": 60,           # 0/20/40/60/80/100
        # 갱신형
        "has_renewal": True,
        # 5종 평균 라벨 (헤드라인·결론 본문 매핑)
        "avg_label": "보통",           # 과잉/적정/보통/빈약/부재
        # 5종 카드 메시지 (트리거 2 한정)
        "mssgs": {
            "silson": "권장 수준에 부합하는 적정 보장",
            "cancer": "필요이상과다가입 - 보험료낭비위험",
            "brain": "기본 보장 미달 - 보강 필요",
            "heart": "기본 보장 미달 - 보강 필요",
            "surgery": "필요이상과다가입 - 보험료낭비위험",
        },
        # 5종 보장금액 (트리거 2 cov-card amt)
        "amounts": {
            "silson": "월 19,000원", "cancer": "1억 5,500만원",
            "brain": "1,000만원", "heart": "1,000만원", "surgery": "2,690만원",
        },
        # 보험 목록 (트리거 2 한정 — N개 보험, 정렬 후 본문)
        "insurances": [
            {
                "name": "실손의료비1.0_기본[질병입원,선택Ⅱ]",
                "company": "삼성생명보험",
                "contract_date": "2018-12-03",
                "is_renewal": True,
                "contractor_insured": "강선영/본인",
                "payment_status": "납입중",  # 납입중/납입종료
                "payment_period": "월납 / 8년",
                "coverage_end": "2026-12-03<br/>/ 54 세",
                "monthly_premium": "47,590",
                "paid_premium": "4,283,100",
                "remaining_premium": "285,540",
                "total_premium": "4,568,640",
                # 매트릭스 보장 금액 (만원 단위) — 영문 키
                "matrix": {
                    "silson_disease_hosp": 5000, "silson_disease_out": 30,
                    "silson_injury_hosp": 5000, "silson_injury_out": 30,
                    # ... 11 카테고리 28종
                },
            },
            # ...
        ],
        # 가족 본문 (트리거 1 가족 표 한정)
        "family_summaries": [
            {
                "name": "이*호", "premium": "180,809원", "count": 3,
                "labels": {"silson": "부재", ...},
                "has_renewal": False,
            },
        ],
    }
"""

import re
import shutil
import zipfile
from pathlib import Path
from playwright.sync_api import sync_playwright


# ═══════════════════════════════════════════════════════════════════════════════
# 본 영역 — 매핑 본문 (단일 출처)
# ═══════════════════════════════════════════════════════════════════════════════

# 헤드라인 본문 매핑 (5종 평균 라벨 기준 — png검정박스 + png노란박스 + txt 결론 통일)
HEADLINE_BY_LEVEL = {
    "과잉": "핵심 의료보장이 지나치게 과잉상태입니다",
    "적정": "핵심 의료보장이 완성된 상태입니다",
    "보통": "핵심 의료보장이 완성되지 않았습니다",
    "빈약": "핵심 의료보장이 빈약한 상태입니다",
    "부재": "핵심 의료보장이 전무한 상태입니다",
}

# txt 결론 본문 (메시지 "으로" 시작)
CONCLUSION_TEXT_BY_LEVEL = {
    "과잉": "으로 핵심 의료보장이 지나치게 과잉상태입니다.",
    "적정": "으로 핵심 의료보장이 완성된 상태입니다.",
    "보통": "으로 핵심 의료보장이 완성되지 않았습니다.",
    "빈약": "으로 핵심 의료보장이 빈약한 상태입니다.",
    "부재": "으로 핵심 의료보장이 전무한 상태입니다.",
}

# 카드 ③ 5단계 라벨 → CSS class·색상 매핑
LEVEL_CLASS_MAP = {
    "매우과잉": "과잉",
    "높은편": "적정",
    "보통": "보통",
    "낮음": "빈약",
    "미확인": "부재",
    "미확인 (또는 0원)": "부재",
}

# 카드 ③ level-bar active 단수 (4단)
LEVEL_BAR_ACTIVE_MAP = {
    "매우과잉": ["active-rich"] * 4,
    "높은편": ["active-good"] * 3 + [""],
    "보통": ["active-neutral"] * 2 + [""] * 2,
    "낮음": ["active-warning"] + [""] * 3,
    "미확인": ["active-danger"] + [""] * 3,
    "미확인 (또는 0원)": ["active-danger"] + [""] * 3,
}

# 5종 라벨 → 트리거 2 cov-card class (lbl-*)
LABEL_TO_LBL_CLASS = {
    "과잉": "rich",
    "적정": "good",
    "보통": "good",   # 보통은 적정과 동일 처리 (양주미 본문 기준)
    "빈약": "warning",
    "부재": "danger",
}

# 메시지 ①②③④ 본문
RENEWAL_LINE_1 = "❌ 보험료가 계속 인상되는 갱신형보험이 구성되어 보험료가 낭비를 넘어 크게 새고 있습니다."
RENEWAL_LINE_4 = "❌ 이후 납입할 {amount:,}원에 더해 갱신형보험 인상분으로 보험료가 크게 낭비되게 됩니다."
PREMIUM_OVERAGE_LINE = "❌ 기납입보험료 외에도 {amount:,}원이나 되는 보험료를 낭비하게 됩니다."
PREMIUM_NORMAL_LINE = "⭕ 잔여보험료가 {amount:,}원으로 일반적인 수준입니다."


# ═══════════════════════════════════════════════════════════════════════════════
# 본 영역 — 베이스 템플릿 load
# ═══════════════════════════════════════════════════════════════════════════════

TEMPLATES_DIR = Path(__file__).parent / "templates"
BASE_PNG_REPORT = TEMPLATES_DIR / "base_png_report.html"
BASE_PNG_TABLE = TEMPLATES_DIR / "base_png_table_report.html"
BASE_TXT_MESSAGE = TEMPLATES_DIR / "base_txt_message.txt"


def _load(path):
    return path.read_text(encoding="utf-8")


def _replace(content, mapping):
    """단순 변수 치환 (str.replace 반복)"""
    for key, val in mapping.items():
        content = content.replace(key, str(val))
    return content


# ═══════════════════════════════════════════════════════════════════════════════
# 트리거 1 산출 (png레포트)
# ═══════════════════════════════════════════════════════════════════════════════

def _build_level_bar_html(level_label):
    """카드 ③ level-bar HTML 본문 산출"""
    active = LEVEL_BAR_ACTIVE_MAP.get(level_label, [""] * 4)
    return "".join(f'<div class="level-seg {a}"></div>' for a in active)


def _build_renewal_warning_block(has_renewal):
    """갱신형 ✅ 시 빨간 박스, ❌ 시 빈 본문"""
    if not has_renewal:
        return ""
    return '<div class="renewal-warning">진단결과와 별개로 갱신형보험 구성으로, 보험료 낭비 과다상태입니다!</div>'


def _build_family_summary_block(family_summaries):
    """가족 ✅ 시 가족 표 HTML, ❌ 시 빈 본문"""
    if not family_summaries:
        return ""
    blocks = []
    for idx, fs in enumerate(family_summaries, start=1):
        name = fs.get("name", "—")
        premium = fs.get("premium", "0원")
        count = fs.get("count", 0)
        labels = fs.get("labels", {})
        completion_map = {"부재": 0, "빈약": 30, "보통": 50, "적정": 100, "과잉": 100}
        items = [
            ("실손의료비", labels.get("silson", "부재")),
            ("암(진단,치료)", labels.get("cancer", "부재")),
            ("뇌(진단,치료)", labels.get("brain", "부재")),
            ("심장(진단,치료)", labels.get("heart", "부재")),
            ("질병수술비", labels.get("surgery", "부재")),
        ]
        labels_html = ""
        for k, v in items:
            pct = completion_map.get(v, 0)
            labels_html += f'<div class="fam-line"><span class="fam-key">{k}</span><span class="fam-val val-{v}">{v}({pct}%)</span></div>'
        # 가족 자체 결론
        cancer = labels.get("cancer", "부재")
        brain = labels.get("brain", "부재")
        heart = labels.get("heart", "부재")
        sufficient = sum(1 for l in [cancer, brain, heart] if l in {"과잉", "적정"})
        if all(l == "부재" for l in [labels.get("cancer", "부재"), labels.get("brain", "부재"),
                                        labels.get("heart", "부재"), labels.get("surgery", "부재")]):
            fam_label = "부재"
        elif sufficient == 3:
            fam_label = "과잉"
        elif sufficient == 2:
            fam_label = "보통"
        elif sufficient == 1:
            fam_label = "빈약"
        else:
            fam_label = "부재"
        fam_headline = HEADLINE_BY_LEVEL.get(fam_label, HEADLINE_BY_LEVEL["부재"]) + "."
        block = f'''
<div class="family-block">
  <div class="family-block-title">가족분 보험도 보유하고 계시며, 가족{idx}({name})님 보험 현황입니다.</div>
  <div class="family-block-row">
    <div class="family-block-head">가입현황</div>
    <div class="family-block-count">
      <div class="family-block-count-num">{count}건</div>
      <div class="family-block-premium">{premium}</div>
    </div>
    <div class="family-block-labels">{labels_html}</div>
  </div>
  <div class="family-block-row family-block-row-review">
    <div class="family-block-head">검토의견</div>
    <div class="family-block-review">가족{idx}({name})님의 보험은<br>{fam_headline}</div>
  </div>
</div>
'''
        blocks.append(block)
    return "\n".join(blocks)


def build_png_report_html(customer):
    """트리거 1 — png레포트 HTML 산출 (변수 치환)"""
    html = _load(BASE_PNG_REPORT)

    name = customer["name"]
    gender = customer.get("gender", "—")
    age = customer.get("insurance_age", "—")
    location = customer.get("location", "—")
    is_family = customer.get("is_family", False)
    labels = customer.get("labels", {})
    details = customer.get("details", {})
    avg_label = customer.get("avg_label", "부재")
    level_label = customer.get("level_label", "미확인")
    completion_pct = customer.get("completion_pct", 0)
    has_renewal = customer.get("has_renewal", False)

    # 헤더 부제
    if is_family:
        header_subtitle = f"{gender} · {location}"
    else:
        header_subtitle = f"{gender} · 보험나이 {age}세 · {location}"

    # 헤드라인 본문 (avg_label 기준)
    headline_text = HEADLINE_BY_LEVEL.get(avg_label, HEADLINE_BY_LEVEL["부재"])
    headline_sub_html = customer.get("headline_sub_html", "")

    # 카드 ③ class·완성도
    level_class = LEVEL_CLASS_MAP.get(level_label, "부재")
    completion_class = avg_label

    mapping = {
        "{{CUSTOMER_NAME}}": name,
        "{{HEADER_SUBTITLE}}": header_subtitle,
        "{{HEADLINE_TEXT}}": headline_text,
        "{{HEADLINE_SUB_HTML}}": headline_sub_html,
        "{{MONTHLY_PREMIUM_TOTAL}}": customer.get("monthly_premium_total", "0"),
        "{{INSURANCE_COUNT}}": str(customer.get("insurance_count", 0)),
        "{{PROTECTION_COUNT}}": str(customer.get("protection_count", 0)),
        "{{PROTECTION_PREMIUM}}": customer.get("protection_premium", "0"),
        "{{SAVING_COUNT}}": str(customer.get("saving_count", 0)),
        "{{SAVING_PREMIUM}}": customer.get("saving_premium", "0"),
        "{{SELF_PREMIUM}}": customer.get("self_premium", "0"),
        "{{FAMILY_PREMIUM}}": customer.get("family_premium", "0"),
        "{{LABEL_SILSON}}": labels.get("silson", "부재"),
        "{{LABEL_CANCER}}": labels.get("cancer", "부재"),
        "{{LABEL_BRAIN}}": labels.get("brain", "부재"),
        "{{LABEL_HEART}}": labels.get("heart", "부재"),
        "{{LABEL_SURGERY}}": labels.get("surgery", "부재"),
        "{{LEVEL_CLASS}}": level_class,
        "{{LEVEL_LABEL}}": level_label,
        "{{LEVEL_BAR_HTML}}": _build_level_bar_html(level_label),
        "{{COMPLETION_PCT}}": str(completion_pct),
        "{{COMPLETION_CLASS}}": completion_class,
        "{{RENEWAL_WARNING_BLOCK}}": _build_renewal_warning_block(has_renewal),
        "{{SILSON_OUT}}": details.get("silson_out", "—"),
        "{{SILSON_HOSP}}": details.get("silson_hosp", "—"),
        "{{CANCER_DIAG}}": details.get("cancer_diag", "—"),
        "{{CANCER_TREAT}}": details.get("cancer_treat", "—"),
        "{{BRAIN_DIAG}}": details.get("brain_diag", "—"),
        "{{BRAIN_TREAT}}": details.get("brain_treat", "—"),
        "{{HEART_DIAG}}": details.get("heart_diag", "—"),
        "{{HEART_TREAT}}": details.get("heart_treat", "—"),
        "{{SURGERY_DISEASE}}": details.get("surgery_disease", "—"),
        "{{SURGERY_INJURY}}": details.get("surgery_injury", "—"),
        "{{FAMILY_SUMMARY_BLOCK}}": _build_family_summary_block(customer.get("family_summaries", [])),
    }
    return _replace(html, mapping)


# ═══════════════════════════════════════════════════════════════════════════════
# 트리거 2 산출 (png표레포트)
# ═══════════════════════════════════════════════════════════════════════════════

# 매트릭스 11 카테고리 — (cat_label, rowspan, [(sub_label, key, css_class, total_bold), ...])
MATRIX_CATEGORIES = [
    ("실비", 6, "", [
        ("질병입원의료비", "silson_disease_hosp", "", True),
        ("질병외래의료비", "silson_disease_out", "", True),
        ("질병처방조제료", "silson_disease_pres", "", True),
        ("상해입원의료비", "silson_injury_hosp", "", True),
        ("상해외래의료비", "silson_injury_out", "", True),
        ("상해처방조제료", "silson_injury_pres", "", True),
    ]),
    ("3대진단", 8, "bg-amni-cat", [
        ("일반암진단", "cancer_general_diag", "bg-amni", True),
        ("소액암(유사암)진단", "cancer_small_diag", "bg-amni", True),
        ("암 치료비", "cancer_treat", "bg-amni", False),
        ("고액항암치료비", "cancer_high_treat", "bg-amni", False),
        ("뇌혈관질환진단", "brain_diag", "bg-brain", True),
        ("뇌혈관질환치료비", "brain_treat", "bg-brain", False),
        ("허혈성심장진단", "heart_diag", "bg-heart", False),
        ("심장질환치료비", "heart_treat", "bg-heart", False),
    ]),
    ("수술비", 5, "bg-surg-cat", [
        ("질병수술", "surgery_disease", "bg-surg", True),
        ("상해수술", "surgery_injury", "bg-surg", True),
        ("암수술", "surgery_cancer", "bg-surg", True),
        ("뇌혈관질환수술", "surgery_brain", "bg-surg", True),
        ("허혈성심장질환수술", "surgery_heart", "bg-surg", True),
    ]),
    ("입원일당", 2, "bg-grey-cat", [
        ("질병입원", "hosp_daily_disease", "bg-grey", False),
        ("상해입원", "hosp_daily_injury", "bg-grey", True),
    ]),
    ("사망보장", 3, "bg-grey-cat", [
        ("일반사망", "death_general", "bg-grey", False),
        ("질병사망", "death_disease", "bg-grey", False),
        ("상해사망", "death_injury", "bg-grey", True),
    ]),
    ("후유장해", 4, "bg-grey-cat", [
        ("질병 50%이상 후유장해", "disability_disease_50", "bg-grey", False),
        ("상해 50%이상 후유장해", "disability_injury_50", "bg-grey", False),
        ("질병 3%이상 후유장해", "disability_disease_3", "bg-grey", False),
        ("상해 3%이상 후유장해", "disability_injury_3", "bg-grey", False),
    ]),
    ("골절화상", 2, "", [
        ("골절진단", "fracture_diag", "", True),
        ("화상진단", "burn_diag", "", True),
    ]),
    ("배상책임", 2, "", [
        ("가족생활배상책임담보", "liability_family", "", True),
        ("일상생활배상책임담보", "liability_daily", "", False),
    ]),
    ("운전자", 5, "bg-driver-cat", [
        ("교통사고처리지원금", "driver_traffic", "bg-driver", False),
        ("벌금(대물)", "driver_fine_prop", "bg-driver", False),
        ("벌금(대인)", "driver_fine_person", "bg-driver", False),
        ("변호사선임비용", "driver_lawyer", "bg-driver", False),
        ("자동차부상치료비", "driver_injury", "bg-driver", True),
    ]),
    ("주택화재보험", 4, "bg-fire-cat", [
        ("화재벌금", "fire_fine", "bg-fire", False),
        ("화재폭발배상책임", "fire_liability", "bg-fire", False),
        ("붕괴·침강", "fire_collapse", "bg-fire", False),
        ("누수(급배수)", "fire_leak", "bg-fire", False),
    ]),
    ("치아보장", 3, "bg-tooth-cat", [
        ("충치치료", "dental_cavity", "bg-tooth", False),
        ("크라운치료", "dental_crown", "bg-tooth", False),
        ("임플란트", "dental_implant", "bg-tooth", False),
    ]),
]


def _truncate(text, max_len):
    """매트릭스 헤더 보험명 — max_len 자르고 말줄임표 추가"""
    if len(text) <= max_len:
        return text
    return text[:max_len] + "..."


def _truncate_company(text, max_len=7):
    """보험사명 7자 자르기 (말줄임표 ❌)"""
    return text[:max_len]


def _build_ins_table_html(insurances, max_cols=10):
    """가입보험 표 HTML 산출 (N개 보험 동적)
    - 13행 (보험명·보험사명·계약일·갱신유무·계약자/피보험자·납입여부·납입주기·보장만기·월납·기납·잔여·총)
    - 5개열 강제 — 보험 ≤5 시 빈칸으로 채움, 최대 10칸까지 동적
    - cols = max(5, len(insurances))
    """
    n = len(insurances)
    cols = max(5, n) if n <= max_cols else n  # ≥5 강제, ≥6은 그대로
    # colgroup
    colgroup = '<colgroup><col class="col-label" style="width:90px"/>'
    colgroup += ''.join(f'<col class="col-data" style="width:120px"/>' for _ in range(cols))
    colgroup += '</colgroup>'

    # row 13개 본문
    def _cells(get_val, td_class="ins-cell", inner_clamp=False):
        cells = ""
        for i in range(cols):
            if i < n:
                val = get_val(insurances[i])
            else:
                val = ""  # 빈칸
            if inner_clamp:
                cells += f'<td class="{td_class}" style="width:120px"><span class="cell-clamp">{val}</span></td>'
            else:
                cells += f'<td class="{td_class}" style="width:120px">{val}</td>'
        return cells

    def _row(label, cells):
        return f'<tr><th class="ins-row-label" style="width:90px">{label}</th>{cells}</tr>'

    rows = []
    rows.append(_row("보험명", _cells(lambda ins: ins.get("name", ""), "ins-cell ins-name", inner_clamp=True)))
    rows.append(_row("보험사명", _cells(lambda ins: _truncate_company(ins.get("company", "")), "ins-cell ins-insurer")))
    rows.append(_row("계약일", _cells(lambda ins: ins.get("contract_date", ""), "ins-cell")))

    # 갱신유무 — 갱신 ✅ 시 빨간 라벨, ❌ 시 "비갱신형"
    def _renewal_html(ins):
        return '<span class="renewal-tag">갱신형보험</span>' if ins.get("is_renewal") else '비갱신형'
    rows.append(_row("갱신 유무", _cells(_renewal_html, "ins-cell")))

    rows.append(_row("계약자<br/>/피보험자",
                     _cells(lambda ins: ins.get("contractor_insured", ""), "ins-cell ins-contractor", inner_clamp=True)))

    # 납입여부 — 납입중/납입종료
    def _payment_html(ins):
        status = ins.get("payment_status", "납입중")
        cls = "pay-tag pay-active" if status == "납입중" else "pay-tag pay-end"
        return f'<span class="{cls}">{status}</span>'
    rows.append(_row("납입 여부", _cells(_payment_html, "ins-cell")))

    rows.append(_row("납입주기<br/>/납입기간", _cells(lambda ins: ins.get("payment_period", ""), "ins-cell")))
    rows.append(_row("보장만기<br/>/만기연령", _cells(lambda ins: ins.get("coverage_end", ""), "ins-cell")))

    # 월납보험료 — 납입중 파란, 납입종료 검정
    def _monthly_premium_cells():
        cells = ""
        for i in range(cols):
            if i < n:
                ins = insurances[i]
                val = f'{ins.get("monthly_premium", "0")} 원'
                cls = "ins-cell amt-blue-text amt-right" if ins.get("payment_status") == "납입중" else "ins-cell amt-black-text amt-right"
                cells += f'<td class="{cls}" style="width:120px">{val}</td>'
            else:
                cells += '<td class="ins-cell amt-right" style="width:120px"></td>'
        return cells
    rows.append(_row("월납보험료", _monthly_premium_cells()))

    rows.append(_row("기납보험료", _cells(lambda ins: f'{ins.get("paid_premium", "0")} 원', "ins-cell amt-right")))
    rows.append(_row("잔여보험료", _cells(lambda ins: f'{ins.get("remaining_premium", "0")} 원', "ins-cell amt-right")))
    rows.append(_row("총보험료", _cells(lambda ins: f'{ins.get("total_premium", "0")} 원', "ins-cell amt-right")))

    table = f'<table class="ins-table">{colgroup}<tbody>{"".join(rows)}</tbody></table>'
    return table


def _build_matrix_html(insurances, max_cols=10):
    """매트릭스 HTML 산출 (N개 보험 × 11 카테고리 동적)"""
    n = len(insurances)
    cols = max(5, n) if n <= max_cols else n

    # 헤더 row — 보험명 (8자 자름 + 말줄임표)
    head_cells = '<th class="cat-cell">대분류</th><th class="sub-cell">소분류</th><th class="total-cell">보장총액</th>'
    for i in range(cols):
        if i < n:
            head_cells += f'<th class="ins-col matrix-col-head">{_truncate(insurances[i].get("name", ""), 8)}</th>'
        else:
            head_cells += '<th class="ins-col matrix-col-head"></th>'
    head_row = f'<tr class="matrix-head">{head_cells}</tr>'

    # 11 카테고리 row
    body_rows = []
    for cat_idx, (cat_label, rowspan, cat_extra_cls, sub_list) in enumerate(MATRIX_CATEGORIES):
        # 3대진단·수술비·입원일당 앞 spacer·warning 영역 본문 처리
        if cat_label == "수술비":
            # 입원일당·warning-row 가 수술비 직전이 아니라 직후 (강선영 본문 정합)
            pass

        for sub_idx, (sub_label, key, sub_bg_cls, total_bold) in enumerate(sub_list):
            # row 클래스 산출 (3대진단·수술비 외곽선)
            row_cls = ""
            if cat_label == "3대진단":
                row_cls = "row-3jin"
                if sub_idx == 0:
                    row_cls += " row-3jin-top"
                if sub_idx == len(sub_list) - 1:
                    row_cls += " row-3jin-bot"
            elif cat_label == "수술비":
                row_cls = "row-surg-box"
                if sub_idx == 0:
                    row_cls += " row-surg-top"
                if sub_idx == len(sub_list) - 1:
                    row_cls += " row-surg-bot"

            # 보장총액 산출
            total = sum(ins.get("matrix", {}).get(key, 0) for ins in insurances)
            if total > 0:
                total_cls = f"total-cell {sub_bg_cls} amt-blue total-bold" if total_bold else f"total-cell {sub_bg_cls} amt-blue"
                total_html = f'{total:,}'
            else:
                total_cls = f"total-cell {sub_bg_cls} empty"
                total_html = ""

            # row 본문
            row_html = f'<tr class="{row_cls}">'
            if sub_idx == 0:
                # cat-cell rowspan 영역
                cat_bg = ""
                if cat_label in ("3대진단",):
                    cat_bg = "bg-amni"
                elif cat_label == "수술비":
                    cat_bg = "bg-surg"
                elif cat_label in ("입원일당", "사망보장", "후유장해"):
                    cat_bg = "bg-grey"
                elif cat_label == "운전자":
                    cat_bg = "bg-driver"
                elif cat_label == "주택화재보험":
                    cat_bg = "bg-fire"
                elif cat_label == "치아보장":
                    cat_bg = "bg-tooth"
                row_html += f'<th class="cat-cell {cat_bg}" rowspan="{rowspan}">{cat_label}</th>'
            row_html += f'<td class="sub-cell {sub_bg_cls}">{sub_label}</td>'
            row_html += f'<td class="{total_cls}">{total_html}</td>'

            for i in range(cols):
                if i < n:
                    val = insurances[i].get("matrix", {}).get(key, 0)
                    val_html = f'{val:,}' if val > 0 else ''
                else:
                    val_html = ''
                row_html += f'<td class="ins-col {sub_bg_cls}">{val_html}</td>'
            row_html += '</tr>'
            body_rows.append(row_html)

            # spacer·warning-row 본문 (수술비 끝 직후)
            if cat_label == "수술비" and sub_idx == len(sub_list) - 1:
                colspan = 3 + cols
                body_rows.append(f'<tr class="spacer-row"><td colspan="{colspan}" style="height:6px;border:0;background:transparent;padding:0;"></td></tr>')
                body_rows.append(f'<tr class="warning-spacer"><td colspan="{colspan}"></td></tr>')
                body_rows.append(f'<tr class="warning-row"><td colspan="{colspan}">매우 비효율적인 보장항목 = 받는 보험금보다 내는 보험료가 몇 배 많은 비효율 보장</td></tr>')

        # 카테고리 사이 안내 row (운전자·주택화재·치아보장 앞)
        if cat_label == "후유장해":
            colspan = 3 + cols
            # 후유장해 끝 → 골절화상 시작 직전 (안내 row ❌, spacer만)
            pass
        elif cat_label == "배상책임":
            colspan = 3 + cols
            body_rows.append(f'<tr class="cat-info-row"><td colspan="{colspan}" style="background:#4F46E5;color:#fff;text-align:center;padding:6px 8px;font-weight:700;font-size:11px;border:0;">운전을 할 경우, 운전자보험 준비 필요 (최신기준 운전자보험 필수)</td></tr>')
        elif cat_label == "운전자":
            colspan = 3 + cols
            body_rows.append(f'<tr class="cat-info-row"><td colspan="{colspan}" style="background:#EA580C;color:#fff;text-align:center;padding:6px 8px;font-weight:700;font-size:11px;border:0;">주택화재에 대한 위험 대비 검토 필요</td></tr>')
        elif cat_label == "주택화재보험":
            colspan = 3 + cols
            body_rows.append(f'<tr class="cat-info-row"><td colspan="{colspan}" style="background:#0D9488;color:#fff;text-align:center;padding:6px 8px;font-weight:700;font-size:11px;border:0;">치아 치료계획이 있을 경우 치아보험 준비 필요</td></tr>')

    matrix_html = f'<table class="cov-matrix"><tbody>{head_row}{"".join(body_rows)}</tbody></table>'
    return matrix_html


def _build_renewal_block_html(insurances):
    """갱신형 박스 HTML (갱신형 보험 1건 이상 시 노출)"""
    renewal_insurances = [ins for ins in insurances if ins.get("is_renewal")]
    if not renewal_insurances:
        return ""
    list_text = ", ".join(f'{ins.get("company", "")} {ins.get("name", "")}' for ins in renewal_insurances)
    list_text += "이 갱신형으로 구성 또는 보장항목(특약) 중 갱신형으로 구성된 항목이 있습니다."
    return f'''<div class="renewal-box"><div class="renewal-title">갱신형 보험 안내</div></div>
<div class="renewal-list">{list_text}</div>
<div class="renewal-conclusion">→ 보험료 인상 위험 — 추가적 점검 필요</div>'''


def _build_conclusion_text(label):
    """5종 카드 결론 본문 (cov-card-mssg 본문)"""
    mapping = {
        "과잉": "필요이상과다가입 - 보험료낭비위험",
        "적정": "권장 수준에 부합하는 적정 보장",
        "보통": "권장 수준에 부합하는 적정 보장",
        "빈약": "기본 보장 미달 - 보강 필요",
        "부재": "보장 ❌ - 보강 필요",
    }
    return mapping.get(label, "")


def build_png_table_html(customer):
    """트리거 2 — png표레포트 HTML 산출 (변수 치환 + 동적 width·HTML)"""
    html = _load(BASE_PNG_TABLE)

    insurances = customer.get("insurances", [])
    n = len(insurances)
    cols = max(5, n) if n <= 10 else n

    # body width = 422 + 120 × N (강선영 N=10 → 1622px)
    body_width = 422 + 120 * cols
    # ins-table-wrap width = 90 + 120 × N
    ins_table_width = 90 + 120 * cols

    labels = customer.get("labels", {})
    amounts = customer.get("amounts", {})
    mssgs = customer.get("mssgs", {})

    mapping = {
        "{{CUSTOMER_NAME}}": customer["name"],
        "{{PERSON_TYPE}}": "가족" if customer.get("is_family") else "본인",
        "{{GENDER}}": customer.get("gender", "—"),
        "{{INSURANCE_AGE}}": str(customer.get("insurance_age", "—")),
        "{{BODY_WIDTH}}": str(body_width),
        "{{INS_TABLE_WIDTH}}": str(ins_table_width),
        "{{TOTAL_INSURANCE_COUNT}}": str(customer.get("insurance_count", 0)),
        "{{MONTHLY_PREMIUM_TOTAL}}": customer.get("monthly_premium_total", "0"),
        "{{PROTECTION_COUNT}}": str(customer.get("protection_count", 0)),
        "{{PROTECTION_PREMIUM}}": customer.get("protection_premium", "0"),
        "{{OTHER_COUNT}}": str(customer.get("other_count", 0)),
        "{{OTHER_PREMIUM}}": customer.get("other_premium", "0"),
        "{{SAVING_COUNT}}": str(customer.get("saving_count", 0)),
        "{{SAVING_PREMIUM}}": customer.get("saving_premium", "0"),
        "{{UNCONFIRMED_COUNT}}": str(customer.get("unconfirmed_count", 0)),
        "{{TOTAL_PAID_PREMIUM}}": customer.get("total_paid_premium", "0"),
        "{{TOTAL_REMAINING_PREMIUM}}": customer.get("total_remaining_premium", "0"),
        "{{TOTAL_ALL_PREMIUM}}": customer.get("total_all_premium", "0"),
        "{{INS_TABLE_HTML}}": _build_ins_table_html(insurances),
        "{{MATRIX_HTML}}": _build_matrix_html(insurances),
        "{{RENEWAL_BLOCK_HTML}}": _build_renewal_block_html(insurances),
        # 5종 카드
        "{{AMOUNT_SILSON}}": amounts.get("silson", "—"),
        "{{AMOUNT_CANCER}}": amounts.get("cancer", "—"),
        "{{AMOUNT_BRAIN}}": amounts.get("brain", "—"),
        "{{AMOUNT_HEART}}": amounts.get("heart", "—"),
        "{{AMOUNT_SURGERY}}": amounts.get("surgery", "—"),
        "{{LABEL_SILSON}}": labels.get("silson", "부재"),
        "{{LABEL_CANCER}}": labels.get("cancer", "부재"),
        "{{LABEL_BRAIN}}": labels.get("brain", "부재"),
        "{{LABEL_HEART}}": labels.get("heart", "부재"),
        "{{LABEL_SURGERY}}": labels.get("surgery", "부재"),
        "{{LABEL_CLASS_SILSON}}": LABEL_TO_LBL_CLASS.get(labels.get("silson", "부재"), "danger"),
        "{{LABEL_CLASS_CANCER}}": LABEL_TO_LBL_CLASS.get(labels.get("cancer", "부재"), "danger"),
        "{{LABEL_CLASS_BRAIN}}": LABEL_TO_LBL_CLASS.get(labels.get("brain", "부재"), "danger"),
        "{{LABEL_CLASS_HEART}}": LABEL_TO_LBL_CLASS.get(labels.get("heart", "부재"), "danger"),
        "{{LABEL_CLASS_SURGERY}}": LABEL_TO_LBL_CLASS.get(labels.get("surgery", "부재"), "danger"),
        "{{MSSG_SILSON}}": mssgs.get("silson", _build_conclusion_text(labels.get("silson", "부재"))),
        "{{MSSG_CANCER}}": mssgs.get("cancer", _build_conclusion_text(labels.get("cancer", "부재"))),
        "{{MSSG_BRAIN}}": mssgs.get("brain", _build_conclusion_text(labels.get("brain", "부재"))),
        "{{MSSG_HEART}}": mssgs.get("heart", _build_conclusion_text(labels.get("heart", "부재"))),
        "{{MSSG_SURGERY}}": mssgs.get("surgery", _build_conclusion_text(labels.get("surgery", "부재"))),
        # 결론 영역
        "{{CONCLUSION_SILSON}}": _build_conclusion_text(labels.get("silson", "부재")),
        "{{CONCLUSION_3JIN}}": (
            f"암(진단,치료) {_build_conclusion_text(labels.get('cancer', '부재'))} / "
            f"뇌혈관(진단,치료) {_build_conclusion_text(labels.get('brain', '부재'))} / "
            f"심장(진단,치료) {_build_conclusion_text(labels.get('heart', '부재'))}"
        ),
        "{{CONCLUSION_SURGERY}}": _build_conclusion_text(labels.get("surgery", "부재")),
        # 어드바이저 자동산출 박스 3줄
        "{{ADVISOR_BULLET_1}}": customer.get("advisor_bullets", ["", "", ""])[0],
        "{{ADVISOR_BULLET_2}}": customer.get("advisor_bullets", ["", "", ""])[1],
        "{{ADVISOR_BULLET_3}}": customer.get("advisor_bullets", ["", "", ""])[2],
    }
    return _replace(html, mapping)


# ═══════════════════════════════════════════════════════════════════════════════
# 트리거 3 산출 (txt문구)
# ═══════════════════════════════════════════════════════════════════════════════

def build_txt_message(customer):
    """트리거 3 — txt문구 산출 (베이스 템플릿 변수 치환)"""
    txt = _load(BASE_TXT_MESSAGE)

    name = customer["name"]
    labels = customer.get("labels", {})
    has_renewal = customer.get("has_renewal", False)
    level_label = customer.get("level_label", "미확인")
    avg_label = customer.get("avg_label", "부재")
    # total_remaining_premium은 원 단위 숫자
    total_remaining_raw = customer.get("total_remaining_premium", "0")
    if isinstance(total_remaining_raw, str):
        total_remaining = int(total_remaining_raw.replace(",", "").replace("원", "").strip() or 0)
    else:
        total_remaining = int(total_remaining_raw)

    # 1번 항목 분기 본문 산출
    sub_lines = []
    if has_renewal:
        sub_lines.append(RENEWAL_LINE_1)
        sub_lines.append(RENEWAL_LINE_4.format(amount=total_remaining))
    else:
        if level_label in ("매우과잉", "높은편"):
            sub_lines.append(PREMIUM_OVERAGE_LINE.format(amount=total_remaining))
        elif level_label in ("보통", "낮음"):
            sub_lines.append(PREMIUM_NORMAL_LINE.format(amount=total_remaining))
        # 미확인: ②/③ 둘 다 미노출

    line_1_block = ""
    for sl in sub_lines:
        line_1_block += "\n\n" + sl

    # 결론 본문
    headline_close = CONCLUSION_TEXT_BY_LEVEL.get(avg_label, CONCLUSION_TEXT_BY_LEVEL["부재"])

    mapping = {
        "{{CUSTOMER_NAME}}": name,
        "{{LINE_1_BLOCK}}": line_1_block,
        "{{LABEL_SILSON}}": labels.get("silson", "부재"),
        "{{LABEL_CANCER}}": labels.get("cancer", "부재"),
        "{{LABEL_BRAIN}}": labels.get("brain", "부재"),
        "{{LABEL_HEART}}": labels.get("heart", "부재"),
        "{{LABEL_SURGERY}}": labels.get("surgery", "부재"),
        "{{HEADLINE_CLOSE}}": headline_close,
    }
    return _replace(txt, mapping)


# ═══════════════════════════════════════════════════════════════════════════════
# 본 영역 — HTML → PNG 변환
# ═══════════════════════════════════════════════════════════════════════════════

def html_to_png(html_content, png_path, work_dir, viewport_width=720, device_scale_factor=3):
    """HTML → PNG 변환 (Playwright Chromium)"""
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)

    # 로고 복사
    logo_src = Path(__file__).parent / "toss_logo.png"
    logo_dst = work_path / "toss_logo.png"
    if not logo_dst.exists() and logo_src.exists():
        shutil.copy(logo_src, logo_dst)

    html_path = work_path / "temp_report.html"
    html_path.write_text(html_content, encoding="utf-8")

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(
            viewport={"width": viewport_width, "height": 1280},
            device_scale_factor=device_scale_factor,
        )
        page.goto(f"file://{html_path.absolute()}")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(png_path), full_page=True, type="png")
        browser.close()


# ═══════════════════════════════════════════════════════════════════════════════
# 메인 — 트리거 3 통합 산출
# ═══════════════════════════════════════════════════════════════════════════════

def generate_trigger3_reports(customers, output_zip, work_root="/tmp/trigger3_work"):
    """
    트리거 3 (레포트작성) 통합 산출 — N명 고객 처리.

    각 고객별 산출물:
    - {NN}.{name}.png       (트리거 1 png레포트 — 본인)
    - {NN}.{name}.txt       (트리거 3 txt문구 — 본인)
    - {NN}.{name}_table.png (트리거 2 png표레포트 — 본인)
    - {NN}.{name}{FF}_table.png (트리거 2 png표레포트 — 가족 FF=01·02·...)

    zip 안 모든 파일 평탄 저장 (고객 폴더 ❌).
    """
    work_path = Path(work_root)
    if work_path.exists():
        shutil.rmtree(work_path)
    work_path.mkdir(parents=True, exist_ok=True)

    for nn, customer in enumerate(customers, start=1):
        nn_str = f"{nn:02d}"
        name = customer["name"]

        # 1) 트리거 1 — png레포트 (본인 + 가족 표 통합)
        report_html = build_png_report_html(customer)
        report_png = work_path / f"{nn_str}.{name}.png"
        html_to_png(report_html, report_png, work_path, viewport_width=720, device_scale_factor=3)

        # 2) 트리거 3 — txt문구 (본인)
        msg = build_txt_message(customer)
        msg_path = work_path / f"{nn_str}.{name}.txt"
        msg_path.write_text(msg, encoding="utf-8")

        # 3) 트리거 2 — png표레포트 (본인)
        table_html = build_png_table_html(customer)
        # body width 산출
        n = len(customer.get("insurances", []))
        cols = max(5, n) if n <= 10 else n
        body_width = 422 + 120 * cols
        table_png = work_path / f"{nn_str}.{name}_table.png"
        html_to_png(table_html, table_png, work_path, viewport_width=body_width, device_scale_factor=2)

        # 4) 트리거 2 — 가족별 png표레포트
        for f_idx, fs in enumerate(customer.get("family_summaries", []), start=1):
            fam_customer = {
                "name": fs.get("name", "—"),
                "gender": fs.get("gender", "—"),
                "insurance_age": fs.get("insurance_age", "—"),
                "is_family": True,
                "labels": fs.get("labels", {"silson": "부재", "cancer": "부재", "brain": "부재", "heart": "부재", "surgery": "부재"}),
                "amounts": fs.get("amounts", {}),
                "mssgs": fs.get("mssgs", {}),
                "insurance_count": fs.get("count", 0),
                "monthly_premium_total": fs.get("premium", "0원").replace("원", ""),
                "protection_count": fs.get("count", 0),
                "protection_premium": fs.get("premium", "0").replace("원", ""),
                "insurances": fs.get("insurances", []),
            }
            fam_html = build_png_table_html(fam_customer)
            fam_n = len(fam_customer.get("insurances", []))
            fam_cols = max(5, fam_n) if fam_n <= 10 else fam_n
            fam_body_width = 422 + 120 * fam_cols
            ff_str = f"{f_idx:02d}"
            fam_png = work_path / f"{nn_str}.{name}{ff_str}_table.png"
            html_to_png(fam_html, fam_png, work_path, viewport_width=fam_body_width, device_scale_factor=2)

    # 임시 파일 정리
    for f in ["temp_report.html", "toss_logo.png"]:
        fp = work_path / f
        if fp.exists():
            fp.unlink()

    # zip 패키징 (UTF-8 한글 호환, 디렉토리 엔트리 ❌, 평탄 저장)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work_path.iterdir()):
            if f.is_file():
                zf.write(f, f.name)

    return output_zip


if __name__ == "__main__":
    # 강선영 단순 테스트
    customer_kang = {
        "name": "강선영",
        "gender": "여성",
        "insurance_age": 53,
        "location": "—",
        "labels": {"silson": "적정", "cancer": "과잉", "brain": "빈약", "heart": "빈약", "surgery": "과잉"},
        "details": {
            "silson_out": "30만", "silson_hosp": "5,000만",
            "cancer_diag": "15,000만원", "cancer_treat": "0만원",
            "brain_diag": "1,000만원", "brain_treat": "0만원",
            "heart_diag": "1,000만원", "heart_treat": "0만원",
            "surgery_disease": "520만원", "surgery_injury": "2,170만원",
        },
        "monthly_premium_total": "469,826",
        "insurance_count": 10,
        "protection_count": 10, "protection_premium": "469,826",
        "saving_count": 0, "saving_premium": "0",
        "self_premium": "469,826", "family_premium": "0",
        "total_paid_premium": "23,140,388",
        "total_remaining_premium": "84,104,692",
        "total_all_premium": "107,245,080",
        "level_label": "매우과잉",
        "completion_pct": 60,
        "has_renewal": True,
        "avg_label": "보통",
        "headline_sub_html": '강선영님의 기존보험에 갱신형보험이 다수 포함되어 보험료 누수가 발생되고 있습니다.<br>강선영님 보험의 보장은 <strong>적정</strong>이나 <span class="accent">뇌·심장 보장이 부족</span>하여 보강이 필요합니다.',
        "insurances": [],  # 표레포트용 (강선영 본 영역은 별도)
    }
    msg = build_txt_message(customer_kang)
    print(msg)
    print("---")
    print(f"트리거 1 HTML 길이: {len(build_png_report_html(customer_kang))} bytes")
