# report_conditions.md — 상담자료·CRM레포트 v23 조건 판정표 + spec 키 명세 (2026-10-28 · 2026-11-01 보완)

> 단일 출처: 첨부 자료(조건값) → 적용 모듈. 고객명은 등장하지 않는다 — 모든 분기는 첨부 유무·수치·지시값으로 결정.
> 구현 = `lib/report_lib.py`(상담자료) · `lib/crm_lib.py`(CRM) · `lib/pdf_tools.py`(PDF). 예시 spec = `examples/`.
> 작업 순서: CRM 레포트 먼저(PAGES 산출) → 상담자료(PAGES 재사용). 자료 접수는 확인만, "작업 시작/go"에 일괄.

## 1. 상담자료 판정표

| 조건(첨부/지시) | 판정 | 적용 모듈 (spec 키) |
|---|---|---|
| 설계안 PDF 개수 | 2개 → 2탭(안심/full, min 제거·2등분) / 3개 → 3탭(기존동일/안심/full) | `tabs.count` · `apply_tabs` |
| 추천 플랜 지시 | 지시된 탭에만 ★추천 뱃지(탭 기본 활성 = 탭1 고정) · 미지시 → 뱃지 없음(`rec=None`) | `tabs.rec` |
| 보장완성도 지시값 | 탭 문구·게이지(`fill`)·시나리오·현황표 헤더·확대보기 이미지 4곳 동일 | `tabs.cover/fill` · `hwang.need_row` · 확대보기 이미지는 첨부 원본 |
| 기존보험 총액 대비 차액 지시(3탭) | 탭1 t-diff "기존대비 −N원 (실손포함)" 빨강 | `tabs.min_diff` |
| **보험료 추가할인 표 첨부** | ③ 적용상품 하단 추가할인 표(모바일 가로스크롤) + 각 탭 버튼 "○○○원으로 추가할인"(표의 **마지막 해** 보험료, 빨강) · 평균보험료 병기 ❌ | `sec3.discount` · `tabs.discount_last` |
| PDF 상품 = 메리츠 5.10.5 계열 | `parse_meritz` → `to_coverage`(담보명 키워드 분류) / 패널 = `patch_meritz_cov(source='mid'|'max')` 수치 패치 | `coverage` · `panels` |
| PDF 상품 = KB라이프 딱좋은0540 (10년고지·최대할인형) | `parse_kb` → `kb_norm` → `kb_coverage`(KB 담보명 분류: 뇌/심 수술은 수술 카드 병기) / 패널 3개 모두 `card()/sc()/gi()/tongap_table(note=)` 빌더 · 탭1 = 가입내용 요약표 기준(주계약·남녀특정암 제외는 mr.와이 확인값) · 납입면제 사유 `waiver` · 핵심확인 5번 `hl5` · 현황요약표 6열(기존 1 + 플랜 3, `sect_head` 사용) · 예시 = `spec_report_hong.py` | `panels` (callable) · `waiver` · `hl5` |
| **PDF 상품 = 간편보험** (상품명에 간편/간편고지/3N5 등) | 일반보험과 동일 구성 + **간편보험 유형 비교표**(이영욱님 원형) = 비교표 2개 아래·③ 적용상품 직전에 자동 생성 · 적용 유형(3610/355/345/335/325 — 설계안 상품명·지시값) 행 #FFF9C4 강조 + 파란 "적용" 뱃지 · 무스크롤(모바일 확인됨) · 추가할인 표 ❌ | `ganpyeon={'applied':'355'}` → `ganpyeon_type_block` |
| **설계안 PDF 보험사 = 메리츠·KB라이프 외** (현대해상·롯데 등 — 간편 고객에서 발생 가능) | 파서 미지원 → **작업 전 확인**(해당 PDF 레이아웃으로 `pdf_tools`에 파서 추가 후 진행, 또는 담보 값을 spec에 직접 기재) · 추측 파싱 ❌ | — |
| **기존보험 없음 (유효 계약 0건 · 전부 실효/해지)** | 기존보험현황 = 실효/해지 리스트(`cancel_block`)만 · 적정성 전 항목 미가입(`'none'`, 가입 `'0'`) · 실손 = **신규가입 블록**(`sil_block(mode='new')` — "| 실손보험 신규가입 안내" + "[○○ 실손보험_신규]" 월보험료 (5세대 / 1년 갱신 / 5년 후 재가입)) 위치 = ③ 제목과 상품 요약 사이(`sec3.before_product_html`) · 운전자 = **신규 가입 문안**(`driver=dict(mode='new')` — 4번 신규 보험료만, 1:1 교체 표기 ❌, 뱃지 "신규 가입") · 탭1 기존대비 차액 없음(`min_diff=None`) · CRM레포트는 산출 없음 · 예시 = `spec_report_jwc.py` | `existing.pages=[]`, `tail=cancel_block`, `sec3.before_product_html`, `driver.mode='new'` |
| 탭1(3탭) 담보가 베이스와 상이 | 탭1 카드 = PDF1 기준 `card()` 빌더로 직접 구성 후 `replace_cards(s,'min',...)` | `panels['min']` |
| 암 통합치료비Ⅱ 담보 **없음** | 암 카드 ct2 표 제거 + 헤더 "통합암진단비 5분류 + 표적·면역항암 각 1억" | `P['ct2']=False` |
| plus 수술비 담보 없음 | 수술 카드 문구 plus 제외 | `P['plus_surgery']=False` |
| 161 순환계(1억) vs 151(5,000만) | source='max'(1억 표 내장) / source='mid'(5,000만 표 내장) 선택 — 베이스 표 수치가 약관 수치와 같으면 약관 이미지 임베드 ❌ | `patch_meritz_cov(source=)` |
| PDF 공란 행 지시 | `remove_blank_rows` → 모달 페이지 이미지는 fixed본, **담보 파싱은 원본** | `pdf_pages` |
| 요약표/세부표 수치 불일치 | 작업 전 확인 → 지시 시 `redact_text`로 세부표 수치 통일 | — |
| CRM PAGES 재사용 | 기존보험현황 = PAGES 그대로(카테고리·음영·의견) · 그룹 제목 "총 N건 (월 합계 · 납입중 n건 기준 / 납입종료 m건 포함)" · 자동차·휴대폰 = "+ 2건 (보장분석 제외)" | `existing.pages/grp_title` |
| 실손 포함 보험 + 전환 설계 첨부 | 해당 보험 ins-body 하단 `sil_block(S)` (안내 블록 + HTML 표 · 출생전/후 열 ❌ · 특별약관 colspan) + CRM 의견 전환 문장 끝에 "(기존 월 X → Y, 월 D · 절약)" 병기 · 세대 = 가입일 판정 | `existing.blocks['N번.']` |
| 갱신형 보험 + 갱신 예시 수치 첨부 | `renew_block` **전치형**(기간 가로) — 해당 보험 ins-body 하단(의견 아래) · 하단 "유효보장 : …" / "내는돈 > 받는돈" | `existing.blocks` |
| 보험조회 PDF 실효/해지 페이지 | `cancel_block` 리스트형(보험사→상품명→계약일→납입기간→만기→보험료→상태) 기존보험현황 맨 하단 | `existing.tail` |
| 약관 이미지 첨부 | 텍스트 내용 적용(카드 표 수치 반영) · 베이스 표가 이미 동일 수치면 생략 · 이미지 임베드 ❌ | 패널 패치 |
| 운전자 설계 첨부 | `driver_replace(D)` (①~⑤ 안내 문안·보험료·상품명·개정월·담보표 수정·`grade_table` 급수별 표) · 최근 가입이면 "조정(1:1 교체)" 문안 | `driver=dict(...)` |
| 운전자 삭제 지시 / 회사단체보험 | `delete_driver` (섹션 전체 삭제) | `driver='delete'` |
| 운전자 자료 없음 | 베이스 내용 그대로 노출 ❌ → 삭제 지시 여부 확인 | — |
| 비교표 이미지 + 비율 지시 | 1순위: 지정값 + 나머지 ×(1+N%) / 2순위: ×(1+M%) / "특정 n사만" 부분 적용 · 반올림 half-up · 안내문 이미지 그대로 | `pcmp_rows` |
| 플랜비교 이미지 | 확대보기 모달 원본 임베드 + `apply_hwang` HTML 표 셀 단위 재현(열 수 가변, 실손전환 열 헤더 "자기부담금 증가/납입보험료 절약") · 셀 스타일 `bl`(파랑)/`rd`(빨강)/`ru`(빨강+밑줄)/`yl`(노랑 빈 셀) · 열 폭 규격 = 6·8열 베이스 CSS / 그 외 `min-width = 400+100×N`px(11열 1500 · 12열 1600 확정) | `hwang` · `modal_img` |
| 플랜비교 이미지 수치가 계산값과 다름 | 작업 전 확인 → 지시 시 이미지 셀을 PIL로 재작성(동일 폰트·크기)해 표·이미지 모두 계산값 (정우찬 안심대비) | `modal_img` |
| 비교표 강조 행 | 적용 보험사(`pcmp.chosen`)와 보험사명이 같은 행만 `pcmp-row-hl` (2순위 표에 적용사가 없으면 강조 없음 — KB라이프 적용 시) | `apply_pcmp` |
| 고객 지시 강조(형광펜·박스 등 단건) | `extra_zr=[(old,new,n)]` 또는 `post=[f]`(전체 문서 후처리, 내부 zr count 검증) — lib 수정 ❌ | `extra_zr` · `post` |
| 베이스 고유값과 고객값 우연 일치(예: 만 38세) | `residual_allow=[...]`로 해당 키만 잔존 검사 제외 | `residual_allow` |
| 핵심 확인사항 | full 플랜 기준 4카드 수치 | `hl` |
| 이미지·PDF 수치 불일치 | 룰: 표·현황표 = 이미지 / 카드·모달 = PDF — ㉧ 보고에 명시 | — |

## 2. 상담자료 spec 키 (build_report)

```
spec = dict(
  name, birth8, hero,                       # 식별 (hero = '남성 · 만 N세 (YYYY.MM.DD년생 · 보험나이 N세)<br>보험기간 ~YYYY-MM-DD (90세 만기 · 20년납)')
  product_name_old, product_name,           # 베이스 상품명 → 실제 (예: '보장보험2607(3.0)' → '보장보험2607(4.0)')
  tabs=dict(count, rec, price{min,mid,max}, total{...}, cover{mid}, fill{min,mid,max}, min_name, min_desc, min_cover, min_note, min_diff, discount_last{tab:금액}),
  chips={'mid':[...], 'max':[...]},         # 플랜 라벨 칩 (mid=+추가 / max=★강화)
  coverage={'min':C|None, 'mid':C, 'max':C},# getCoverageData 단일 소스 (to_coverage 결과)
  panels={'mid': f, 'max': f, 'min': f},    # f(s)→cov-wrap HTML 또는 전체 문서 — 순서 mid → max → min
  existing=dict(pages=PAGES, grp_title, blocks={'N번.':[html,...]}, tail=html),
  adequacy=dict(rows=[(대분류, span, [(담보, imp, 'ok|lack|none', 권장, 가입)...])...], note='※ ...'),
  pcmp=dict(t1, t2, t1_title, t2_title, order_text, chosen, note1),
  sec3=dict(product_hl, product_sub, plans=[(명, 월, 평균|None, 총)], paren, discount|None, min_note|None, after_paren|None, before_product_html|'', after_html|''),
  ganpyeon={'applied':'3610'|'355'|'345'|'335'|'325'}|None,   # 간편보험 → 유형 비교표 자동
  waiver=[문장...]|None, hl5=str|None,          # 납입면제 사유 그리드 / 핵심확인 5번 문구 (KB라이프 등)
  extra_zr=[(old,new,n)...], post=[f(s)->s...], residual_allow=[...],
  hwang=dict(name, n_exi, n_plan, n_rows, title, prod_html, sect_head, exi_head, plan_head, need_row, price_row, price2_row, groups),
  modal_img, hl=[(val, sub)x4], driver='delete'|dict(mode='new'|None, ...)|callable|None, pdf_pages={'min':(pdf,n)|None,'mid':..,'max':..}, residual=[...], out)
```

예시 spec 대응표: `spec_report_khj.py`(2탭·메리츠·추가할인·실손전환·갱신표·실효해지·운전자 삭제) / `spec_report_pjm.py`(3탭·메리츠·탭1 커스텀·운전자 조정·급수표) / `spec_report_hong.py`(3탭·KB라이프 10년고지·6열 현황표·운전자 삭제) / `spec_report_jwc.py`(3탭·메리츠·기존보험 없음·실손 신규·운전자 신규) / 간편보험 = 위 메리츠·KB 예시에 `ganpyeon` 1줄 추가
```
```

## 3. CRM레포트 판정표

| 조건 | 판정 | 적용 |
|---|---|---|
| 보험 건수 N | 전체레포트 상품 N열 — **열 폭 152.5px·앞 영역 390px·여백 12px·폰트 원형 고정(김재욱 확정본)**, N>4 → body 폭 1080+(N−4)×152.5 (세로 분할·폭 축소·폰트 축소 ❌) · shot 폭 = body 폭 | `build_full(n)` · `shot(width)` |
| 기납/잔여/총 입력 없음 | `premium_calc`(월납×납입기간, 경과월 = 계약일~기준일, 납입완료 = 총액, 일시납 = 보험료) · 좌측 합계 = 납입중 건 기준 | `full.paid/remain/total` |
| 지출정도 | `spend_level(월합계, 연령대 적정)` → 낮음/보통/높은편/매우과잉 (게이지 1~4단) | `full.level` |
| 보장완성도 | mr.와이 지정값(없으면 적정성 표 (적정+과잉)×20%) | `full.completion` |
| 자동차·휴대폰보험 | 건수·보험료 합계 제외 · 보험별 레포트는 마지막 배치 | spec 작성 시 제외 |
| 갱신형 보험 + 갱신 예시 수치 | PAGES[i]['renew'] = [title, rows, avg] → 전문가의견 아래 **전치형** 표 | `build_detail` |
| 갱신형 보험(상품 단위) | `renewProduct: True` → 보험명 빨강 "(갱신형)" / 특약 단위 → 담보명 자동 빨강 / `noRenew: True` → 억제 | PAGES |
| 담보 많은 보험 | `tall: True` → 페이지 높이 자동(9:16 초과 허용 — 분할 넘버링 대신 사용된 확정 방식) | PAGES |
| 파란 강조 행 | row[5]=True → 담보명 파랑(통합암 5분류 등) | PAGES |
| 실효/해지 페이지 | 레포트 제외 · `cancel_keep.json`으로 보관 → 상담자료 `cancel_block` | — |
| 입력 = 보험가입 상세 PDF | 페이지 범위 지시(예: 5~15p 기존보험) 대로 텍스트 추출 → PAGES | pymupdf |

## 4. 공통 검증 (산출 전 필수)
1. 모든 앵커 교체 count 검증(zr) — 실패 시 중단, 추측 ❌
2. 이전 고객 잔존 0 (`RESIDUAL` + spec.residual)
3. `node lib/render_check.js <html> <outdir>` — PC 1080 + 모바일 420, JS 오류 0, 탭/패널/zoom-area 수 일치
4. 단건 수정 시 이전 산출본 diff(base64 제외)로 변경 지점만 확인 후 보고
5. (v22 `verify.py` 12카테고리 검사는 v23 패키지에서 제외 — 1~3이 동일 역할. 2026-11-01 mr.와이 확정)
