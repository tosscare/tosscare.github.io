"""
insurance_classifier.py — 보험 분류·정렬·stats-box 4분류 매핑 (v11 신설)

본 모듈의 본질:
- references/insurance_order.md 8단계 분류 룰 코드 구현
- 같은 분류 내 최근 가입일 우선 정렬
- stats-box 4분류 매핑 (보장성·기타·저축·미확인)

활용 양식:
    from insurance_classifier import (classify_8step, sort_by_insurance_order,
                                       stats_box_4classify)

본 모듈 본문 적용 영역:
- 트리거 1·2·3 공통 (insurance_order.md 정합)
- 본인·가족 페이지 각각 별도 정렬 (페이지별 별도 호출)
"""


def has_5jong_coverage(matrix):
    """5종 보장 (실손·암·뇌·심·수술) 中 1건 이상 ✅ 검증

    references 정합 적용:
    - silson.md: 질병/상해입원의료비 ≥1
    - cancer.md: 일반암 진단비 ≥1 (소액암·고액암·통합전이암·남녀특정암 ❌)
    - brain.md: 뇌혈관진단비 ≥1 (뇌출혈·뇌졸중·뇌경색·특정양성뇌종양 ❌)
    - heart.md: 허혈성심장진단비·부정맥진단비 ≥1 (급성심근경색·심혈관특정·심장판막·심근병증 ❌)
    - surgery.md: 질병수술비 + 상해수술비 ≥1 (일반 + 5종 수술비. 1·2·3·4종 ❌, 암수술 별도)

    매트릭스 합계 본문은 raw 자료 정합 — 본 카테고리별 합계가 references 적용 ✅ 담보 합산.
    """
    if matrix.get("silson_disease_hosp", 0) >= 1 or matrix.get("silson_injury_hosp", 0) >= 1:
        return True
    if matrix.get("cancer_general_diag", 0) >= 1:
        return True
    if matrix.get("brain_diag", 0) >= 1:
        return True
    if matrix.get("heart_diag", 0) >= 1:
        return True
    if matrix.get("surgery_disease", 0) >= 1 or matrix.get("surgery_injury", 0) >= 1:
        return True
    return False


def has_death_only(name, matrix):
    """사망단독 (종신·정기·생명 + 사망 ✅ + 그 외 모든 보장 ❌) 검증

    references/insurance_order.md 분류 3 본문 정합.
    """
    is_life = any(k in name for k in ["종신", "정기", "생명", "라이프"])
    if not is_life:
        return False
    has_death = matrix.get("death_disease", 0) >= 1 or matrix.get("death_injury", 0) >= 1
    if not has_death:
        return False
    # 그 외 모든 보장 ❌
    other_keys = [k for k in matrix if k not in ("death_disease", "death_injury") and matrix[k] >= 1]
    return len(other_keys) == 0


def classify_8step(parsed, j):
    """8단계 분류 (references/insurance_order.md 정합) — 우선순위 적용

    | # | 분류 | 식별 본문 |
    |---|---|---|
    | 1 | 실손보험 | 상품명 "실손" ✅ 또는 매트릭스 실손 보장 ✅ |
    | 2 | 보장성 보험 | 5종 보장 ≥1 ✅ — 사망단독 ❌ |
    | 3 | 사망보험금만 (사망단독) | 종신·정기·생명 + 사망 ✅ + 그 외 ❌ |
    | 4 | 1·2·3 외 | 5종 ❌ + 사망 외 보장 ✅ (치아·재가·간병·상해·교통재해·후유장해·골절·배상·사망+후유 등) |
    | 5 | 운전자 | 상품명 "운전자" |
    | 6 | 주택화재 | 상품명 "화재"+"주택" 또는 "화재" |
    | 7 | 저축/연금 | 상품명 "저축"·"연금"·"유니버셜"·"Standby"·"스탠바이" |
    | 8 | 자동차/이륜차 | 상품명 "자동차"·"이륜차" |

    분류 우선순위 (위에서 아래 — insurance_order.md 정합):
    1. 실손 검증 → ✅ 시 1
    2. 자동차/이륜차 검증 → ✅ 시 8 (가장 마지막)
    3. 저축/연금 → ✅ 시 7
    4. 주택화재 → ✅ 시 6
    5. 운전자 → ✅ 시 5
    6. 5종 ✅ + 사망단독 ❌ → 2
    7. 사망단독 → ✅ 시 3
    8. 그 외 → 4

    Parameters:
    - parsed: parse_customer() 결과 dict
    - j: 보험 인덱스 (0-base)

    Returns: 1~8 (int)
    """
    name = parsed["ins"]["names"][j]
    matrix = parsed["ins_matrix"][j]
    cls = parsed["ins_class"][j]  # parse 영역의 self/common/auto/family

    # 1. 실손 (상품명 또는 매트릭스 본문)
    if "실손" in name or matrix.get("silson_disease_hosp", 0) >= 1 or matrix.get("silson_injury_hosp", 0) >= 1:
        return 1
    # 8. 자동차/이륜차
    if cls == "auto" or "자동차" in name or "이륜차" in name:
        return 8
    # 7. 저축/연금
    if any(k in name for k in ["저축", "연금", "유니버셜", "Standby", "스탠바이"]):
        return 7
    # 6. 주택화재
    if "화재" in name and ("주택" in name or "화재보험" in name):
        return 6
    # 5. 운전자
    if "운전자" in name:
        return 5
    # 2·3 분기: 5종 보장 ✅
    if has_5jong_coverage(matrix):
        if has_death_only(name, matrix):
            return 3
        return 2
    # 3. 사망단독
    if has_death_only(name, matrix):
        return 3
    # 4. 그 외 (1·2·3 외)
    return 4


def sort_by_insurance_order(parsed, indices):
    """주어진 indices를 8단계 분류 + 같은 분류 내 최근 가입일 정렬

    references/insurance_order.md 정합:
    - 8단계 분류 본문 (실손→...→자동차)
    - 같은 분류 내 — 최근 가입일이 첫 위치 (왼쪽=최근)
    - 본인·가족 페이지 각각 별도 정렬 (페이지별 별도 호출)
    - 위·아래 표 단일 source — 정렬 변경 시 동시 동일 적용
    """
    def sort_key(j):
        step = classify_8step(parsed, j)
        date_str = parsed["ins"]["contract_dates"][j] or "0000-00-00"
        # 최근 날짜 앞 (왼쪽) → 날짜 내림차순 → 음수 변환
        return (step, -int(date_str.replace("-", "") or 0))
    return sorted(indices, key=sort_key)


def stats_box_4classify(parsed, indices):
    """stats-box 4분류 매핑 (보장성·기타·저축·미확인)

    매핑 본문 (insurance_order.md 8단계 분류 정합):
    - 보장성 = 분류 1+2 (실손 + 5종 보장 ≥1)
    - 기타 = 분류 3+4+5+6+8 (사망단독 + 1·2·3외 + 운전자 + 주택화재 + 자동차)
    - 저축 = 분류 7 (저축/연금)
    - 미확인 = 납입종료·일시납·월보험료 0원·계약상태 정상 ❌

    합산 본문:
    - 납입중 + 정상 + 월보험료 ≥1 + 일시납 ❌ 만 합산
    - 그 외 모두 미확인으로 분류

    ⚠️ 본 매핑 룰은 본 클로드 자체 매핑 본문 — references 직접 명시 ❌.
    mr.와이 도메인 본문 확정 시 정정 필요 영역 (강선영 케이스 #3·#10 분류 모순 ✅).

    Returns:
        dict {protection_count·premium, other_count·premium, saving_count·premium, unconfirmed_count}
    """
    p_c = p_p = o_c = o_p = s_c = s_p = u_c = 0
    for j in indices:
        step = classify_8step(parsed, j)
        prem = parsed["ins"]["monthly_won"][j]
        pay_status = parsed["ins"]["payment_status"][j]
        period = parsed["ins"]["payment_period"][j]
        status = parsed["ins"]["status"][j]
        # 미확인 = 정상 ❌ or 납입중 ❌ or 월보험료 0 or 일시납
        is_active = (status == "정상" and pay_status == "납입중"
                     and prem > 0 and "일시납" not in period)
        if not is_active:
            u_c += 1
            continue
        if step in (1, 2, 3, 4):  # 보장성: 실손 + 5종 보장 + 사망단독 + 1·2·3외 (치아 포함)
            p_c += 1
            p_p += prem
        elif step == 7:  # 저축/연금
            s_c += 1
            s_p += prem
        else:  # 기타: 5·6·8 (운전자·주택화재·자동차/이륜차)
            o_c += 1
            o_p += prem
    return {
        "protection_count": p_c, "protection_premium": p_p,
        "other_count": o_c, "other_premium": o_p,
        "saving_count": s_c, "saving_premium": s_p,
        "unconfirmed_count": u_c,
    }
