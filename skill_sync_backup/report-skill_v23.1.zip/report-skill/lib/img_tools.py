# -*- coding: utf-8 -*-
"""img_tools.py — 첨부 이미지(플랜비교·비교표) 셀 단위 수정 도구 (mr.와이 지시 시에만 · 임의 수정 ❌)
    fix_cell(src, dst, box, text, size=27, weight='Medium', color=(0,0,0), align='center')
      box = (x0, y0, x1, y1) 픽셀 — 셀 내부 영역. 배경색은 셀 좌상단 픽셀에서 샘플링(음영 유지), 텍스트 = Pretendard 동일 굵기.
    실례: 정우찬 플랜비교 이미지 안심대비 셀 139,520 → 39,610(계산값) · Pretendard-Medium 27px
"""
import os
from PIL import Image, ImageDraw, ImageFont
FONT_DIRS = [os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'fonts'), '/usr/local/share/fonts/pretendard']
def font(weight='Medium', size=27):
    for d in FONT_DIRS:
        p = os.path.join(d, f'Pretendard-{weight}.otf')
        if os.path.exists(p): return ImageFont.truetype(p, size)
    raise FileNotFoundError('Pretendard 폰트 없음 — lib/setup_fonts.sh 실행')
def fix_cell(src, dst, box, text, size=27, weight='Medium', color=(0, 0, 0), align='center', pad=2):
    im = Image.open(src).convert('RGB'); d = ImageDraw.Draw(im); x0, y0, x1, y1 = box
    bg = im.getpixel((x0 + pad, y0 + pad)); d.rectangle([x0, y0, x1, y1], fill=bg)
    f = font(weight, size); bb = d.textbbox((0, 0), text, font=f); tw, th = bb[2] - bb[0], bb[3] - bb[1]
    tx = {'center': (x0 + x1 - tw) // 2, 'right': x1 - pad - tw, 'left': x0 + pad}[align] - bb[0]; ty = (y0 + y1 - th) // 2 - bb[1]
    d.text((tx, ty), text, font=f, fill=color); im.save(dst, 'PNG', optimize=True); return dst
