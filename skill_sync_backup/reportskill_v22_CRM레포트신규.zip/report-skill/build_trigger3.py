#!/usr/bin/env python3
"""build_trigger3.py — 단일 고객 트리거 3 산출 wrapper (v19)

[목적]
    토스 페르소나가 트리거 3(TXT 메시지) 구동 시,
    LLM 자체 커맨드 생성 ❌ → 본 wrapper만 호출 → 결정론적 산출.

[입력]
    --raw <고객명.txt 파일>  : parse_customer가 소비할 원시 텍스트
    --output-dir <폴더>      : 산출 TXT 저장 위치 (기본: /mnt/user-data/outputs)
    --nn <번호>              : 파일명 prefix (예: '01', '02'; 기본: '01')

[출력]
    {output-dir}/{nn}.{고객명}.txt — TXT 메시지 1종

[박제 룰 (v19)]
    - LLM 책임: PDF → 고객명.txt 산출까지 (parse 단계)
    - Python 책임: parse_customer → build_customer → build_txt_message → TXT
    - 트리거 3은 TXT 메시지 1종만 (PNG 산출 ❌)
    - 진행조건 1 정합: 기존 pre_report 시스템 그대로 호출 → 기능 영향 ❌
"""
import sys
import argparse
from pathlib import Path

_SKILL_DIR = Path(__file__).parent.resolve()
_PRE_REPORT_DIR = _SKILL_DIR / "pre_report"
sys.path.insert(0, str(_PRE_REPORT_DIR))
sys.path.insert(0, str(_SKILL_DIR))

from parse import parse_customer, split_self_family  # noqa: E402
from report_builder import build_txt_message  # noqa: E402
from insurance_classifier import sort_by_insurance_order  # noqa: E402
from pre_report_gen import build_customer, build_entry  # noqa: E402


def run_trigger3(raw_path: Path, output_dir: Path, nn: str = "01") -> Path:
    """단일 고객 트리거 3 산출 — TXT 메시지 1종.

    Args:
        raw_path: 고객명.txt 파일 경로 (parse_customer 입력)
        output_dir: TXT 산출 폴더
        nn: 파일명 prefix (예: '01')

    Returns:
        산출된 TXT 파일 경로
    """
    if not raw_path.exists():
        raise FileNotFoundError(f"원시 파일 없음: {raw_path}")

    name = raw_path.stem
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1) PDF·txt 데이터 → 구조화 dict
    p = parse_customer(raw_path)
    s = split_self_family(p)
    table_indices = s["self_indices"] + s["auto_indices"]

    # 2) 본인 customer dict 빌드 (트리거 1과 동일 데이터 구조)
    c = build_customer(p, s, table_indices, is_family_pg=False)
    png_indices = sort_by_insurance_order(p, s["self_indices"])
    c_png = dict(c)
    c_png["insurances"] = [build_entry(p, j) for j in png_indices]

    # 3) TXT 메시지 빌드 (결정론적 — references/*.md 정합)
    txt_content = build_txt_message(c_png)

    # 4) TXT 저장
    txt_path = output_dir / f"{nn}.{name}.txt"
    txt_path.write_text(txt_content, encoding="utf-8")

    return txt_path


def main():
    parser = argparse.ArgumentParser(description="트리거 3 단일 고객 TXT 메시지 산출 (v19)")
    parser.add_argument("--raw", required=True, help="고객명.txt 파일 경로")
    parser.add_argument("--output-dir", default="/mnt/user-data/outputs",
                        help="TXT 산출 폴더 (기본: /mnt/user-data/outputs)")
    parser.add_argument("--nn", default="01", help="파일명 prefix (기본: '01')")
    args = parser.parse_args()

    raw_path = Path(args.raw)
    output_dir = Path(args.output_dir)
    txt_path = run_trigger3(raw_path, output_dir, args.nn)
    print(f"✅ 트리거 3 산출 완료: {txt_path}")


if __name__ == "__main__":
    main()
