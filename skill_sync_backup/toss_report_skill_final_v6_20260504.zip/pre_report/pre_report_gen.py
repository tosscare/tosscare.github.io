"""
pre_report_gen.py — 사전상담 자료 생성 스크립트

역할:
1. 고객 데이터 입력받아 → 변수 치환된 HTML 생성
2. HTML → PNG 변환 (Playwright)
3. message.txt 생성
4. 다수 고객 → zip 패키징 (고객별 폴더)

사용법:
  from pre_report_gen import generate_reports
  
  customers = [
      {
          "이름": "유태수",
          "성별": "남",
          "보험나이": 45,
          "거주": "경기도 고양시",
          "labels": {
              "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
          },
          "current_values": {
              "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
              "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
          },
          "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
          "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
          "헤드라인_main": "핵심 의료보장이 <span class=\"accent\">전부 부재한 상태</span>입니다.",
          "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
      }
  ]
  generate_reports(customers, output_zip="report_20260427.zip")
"""

import os
import re
import zipfile
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright


# ===== 라벨 매핑 =====

# v6 — 7가지 케이스 결론 본문 (4개 보장 라벨로 자체 산출 — determine_conclusion_case)
# 본 매핑은 PNG 검정박스 + 메시지 결론 본문 동시 사용 (통일)
# 박제 B-1: 케이스 1·2 (과잉) 만 accent 빨간색 / 그 외 흰색 (accent ❌)
HEADLINE_BY_LEVEL = {
    "보장 전무":   "핵심 의료보장이 보장이 전무한 상태입니다.",
    "사실상 부재": "핵심 의료보장이 사실상 부재한 상태입니다.",
    "매우 취약":   "핵심 의료보장이 매우 취약한 상태입니다.",
    "빈약":       "핵심 의료보장이 빈약한 상태입니다.",
    "미완성":     "핵심 의료보장의 완성이 되지 않은 상태입니다.",
    "과잉":       "<span class=\"accent\">핵심 의료보장이 과잉 수준</span>입니다.",  # 케이스 1·2 — 빨간색
    # 가족 PNG fallback (식별정보 ❌ — 부재 본문, 흰색)
    "부재":       "핵심 의료보장이 전부 부재한 상태입니다.",
    "—":         "핵심 의료보장이 전부 부재한 상태입니다.",
}

# v6 — 메시지 결론 본문 (txt — accent 태그 ❌)
CONCLUSION_TEXT_BY_LEVEL = {
    "보장 전무":   "핵심 의료보장이 보장이 전무한 수준입니다.",
    "사실상 부재": "핵심 의료보장이 사실상 부재한 수준입니다.",
    "매우 취약":   "핵심 의료보장이 매우 취약한 수준입니다.",
    "빈약":       "핵심 의료보장이 빈약한 수준입니다.",
    "미완성":     "핵심 의료보장의 완성이 되지 않았습니다.",
    "과잉":       "핵심 의료보장이 과잉 수준입니다.",
    # fallback
    "부재":       "핵심 의료보장이 전부 부재한 상태입니다.",
}

# 갱신형 감지 룰 (rules.json renewal_handling 박제)
RENEWAL_KEYWORD = "갱신"
# 메시지 ① 변수 본문 (트리거 3 룰 변경 — 2026-05-01 / v6 유지)
RENEWAL_MESSAGE_LINE_1 = "❌ 보험료가 계속 인상되는 갱신형보험이 구성되어 보험료가 낭비를 넘어 크게 새고 있습니다."
# 메시지 ② 변수 본문 (갱신 ❌ + 라벨 ∈ {과잉, 적정})
PREMIUM_OVERAGE_LINE = "❌ 기납입보험료 외에도 {amount:,}원이나 되는 보험료를 낭비하게 됩니다."
# 메시지 ③ 변수 본문 (갱신 ❌ + 라벨 ∈ {보통, 빈약, 부재})
PREMIUM_NORMAL_LINE = "⭕ 잔여보험료가 {amount:,}원으로 일반적인 수준입니다."
# 메시지 ④ 변수 본문 — v6 신설 (갱신 ✅ 시 라벨 무관 ① + ④ 무조건 노출)
RENEWAL_REMAINING_LINE = "❌ 이후 납입할 {amount:,}원에 더해 갱신형보험 인상분으로 보험료가 크게 낭비되게 됩니다."
# PNG 갱신형 버튼 본문 (빨간 배경 + 노란 굵은 글씨 — 2026-05-01 / v6 폰트 22px 갱신)
RENEWAL_REPORT_HTML = (
    '<div class="renewal-warning">'
    '갱신형보험이 구성되어 보험료 누수가 발생한 상태입니다!'
    '</div>'
)


def determine_conclusion_case(labels):
    """v6 — 4개 보장(암·뇌·심장·수술) 라벨로 7가지 결론 케이스 결정.

    충분 = {과잉, 적정} / 부족 = {보통, 빈약, 부재}

    매칭 우선순위:
        7 (보장 전무) > 6 (사실상 부재) > 1·2·3·4·5 상호 배타

    Args:
        labels: dict — {"실손": ..., "암": ..., "뇌": ..., "심장": ..., "수술": ...}

    Returns:
        결론 케이스 라벨 (str): "과잉" / "미완성" / "빈약" / "매우 취약" / "사실상 부재" / "보장 전무"
    """
    SUFFICIENT = {"과잉", "적정"}

    cancer = labels.get("암", "부재")
    brain = labels.get("뇌", "부재")
    heart = labels.get("심장", "부재")
    surgery = labels.get("수술", "부재")

    # 케이스 7 — 4개 모두 부재(0) 우선 매칭
    if all(l == "부재" for l in [cancer, brain, heart, surgery]):
        return "보장 전무"

    # 암·뇌·심장 충분 개수 (수술 무관)
    main3 = [cancer, brain, heart]
    sufficient_count = sum(1 for l in main3 if l in SUFFICIENT)
    surgery_sufficient = surgery in SUFFICIENT

    if sufficient_count == 3:
        # 케이스 1·2 — 3개 충분 (수술 무관) → "과잉"
        return "과잉"
    elif sufficient_count == 2:
        # 케이스 3 — 2충분+1부족 (수술 무관) → "미완성"
        return "미완성"
    elif sufficient_count == 1:
        # 케이스 4 — 1충분+2부족 (수술 무관) → "빈약"
        return "빈약"
    else:
        # 0충분 (3개 모두 부족) — 수술 분기
        if surgery_sufficient:
            return "매우 취약"  # 케이스 5
        else:
            return "사실상 부재"  # 케이스 6


def detect_renewal(raw_customer_text):
    """고객정보 원문 텍스트에 '실손이 아닌' 갱신형 보험·특약이 있는지 정확 검증.

    v5 룰 (2026-05-01) — 순수 실손보험 제외:
    - 모든 실손의료비보험은 본질적으로 갱신형 구조 (도메인 표준)
    - 메시지 ①·PNG 박스의 "갱신형보험" 경고는 '실손 외 보장성 갱신형'을 가리키는 영역
    - 따라서 갱신형 보험 중 보장 카테고리가 '실비' 단일이면 트리거에서 제외
    - 실비 + 다른 카테고리(3대진단·수술비·사망 등) 혼합 시 → 일반 갱신형보험으로 ✅
    - 갱신형 보험·특약이 1건이라도 실손 외 카테고리 보장 시 → 트리거 ✅

    알고리즘:
    1. "상품 별 보장 목록" 섹션에서 각 보험명 ↔ 갱신유무·보장카테고리 매핑
    2. 갱신형 보험·특약 중 — 실비 단일 보장이 아닌 보험이 1건 이상이면 ✅
    """
    if not raw_customer_text:
        return False

    # 1차 빠른 검증 — 텍스트에 갱신형 키워드 자체 ❌이면 즉시 ❌
    if not (("갱신형 특약" in raw_customer_text) or ("갱신형 보험" in raw_customer_text)):
        return False

    # 2차 정밀 검증 — 보험별 갱신유무·카테고리 매핑
    insurances = parse_insurances(raw_customer_text)

    for ins in insurances:
        if not ins["is_renewal"]:
            continue
        # 갱신형 보험·특약 — 보장 카테고리 검사
        cats = ins["categories"]
        # 실비 단일이면 순수 실손보험 → 트리거 제외
        if cats == {"실비"}:
            continue
        # 실비 외 카테고리 1개라도 있으면 → 일반 갱신형보험으로 ✅
        if cats - {"실비"}:
            return True
        # cats == set() (보장 카테고리 ❌, 빈 영역) → 보수적으로 ❌ 처리
        # (단체보험·반려동물 등 카테고리 매핑 ❌ 케이스. 펫퍼민트 등은 "기타"로 분류되어 cats에 포함됨)

    return False


def parse_insurances(raw_customer_text):
    """텍스트에서 보험별 (이름·갱신유무·보장카테고리) 추출.

    "가입보험 상세정보" 표 구조:
    - "보험명" 행 — 다음 N줄에 보험 N개의 이름
    - "갱신 유무" 행 — 다음 N줄에 갱신유무 (갱신형 특약 / 갱신형 보험 / 비갱신형)
    - "상품 별 보장 목록" 섹션 — 보험별 카테고리 표

    Returns:
        list of dict: [{"name": str, "is_renewal": bool, "categories": set}]
    """
    lines = raw_customer_text.split("\n")
    lines = [ln.rstrip() for ln in lines]  # 우측 공백만 제거 (좌측 indent 보존)

    # 1. "보험명" 행과 "갱신 유무" 행 영역 추출 (헤더 영역 — N개의 보험 이름·갱신유무 1:1 대응)
    name_idx = -1
    renewal_idx = -1
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s == "보험명" and name_idx == -1:
            name_idx = i
        elif s == "갱신 유무":
            renewal_idx = i
            break

    if name_idx == -1 or renewal_idx == -1:
        return []

    # "보험명" 다음 → "보험사명" 직전까지 = 보험 이름 N개
    insurance_names = []
    for i in range(name_idx + 1, len(lines)):
        s = lines[i].strip()
        if s == "보험사명":
            break
        if s:
            insurance_names.append(s)

    # "갱신 유무" 다음 → N개 = 각 보험의 갱신유무
    renewal_states = []
    count = 0
    for i in range(renewal_idx + 1, len(lines)):
        s = lines[i].strip()
        if not s:
            continue
        if s in ("갱신형 특약", "갱신형 보험", "비갱신형", "—", "-"):
            renewal_states.append(s)
            count += 1
            if count >= len(insurance_names):
                break
        else:
            # 다음 헤더 라벨 도달 (예: "계약자/피보험자")
            break

    if len(renewal_states) != len(insurance_names):
        # 영역 매핑 실패 — 보수적으로 빈 결과 반환
        return []

    # 2. "상품 별 보장 목록" 섹션에서 보험별 카테고리 매핑
    # 카테고리 매핑 룰: 표 구조 "대분류 / 소분류" 기반
    CATEGORIES = {
        "실비": {"질병입원의료비", "질병외래의료비", "질병처방조제료",
                "상해입원의료비", "상해외래의료비", "상해처방조제료"},
        "3대진단": {"일반암진단", "소액암(유사암)진단", "고액암진단",
                  "뇌혈관질환진단", "뇌졸중질환진단", "뇌출혈질환진단",
                  "허혈성심장질환진단", "급성심근경색진단"},
        "수술비": {"질병수술", "상해수술", "암수술", "뇌혈관질환수술", "허혈성심장질환수술"},
        "입원일당": {"질병입원", "상해입원"},
        "사망": {"질병사망", "상해사망"},
        "후유장해": {"질병80%이상후유장해", "질병80%미만후유장해",
                  "상해80%이상후유장해", "상해80%미만후유장해"},
        "골절화상": {"골절진단", "화상진단"},
        "생활배상책임": {"가족생활배상책임담보", "일상생활배상책임담보"},
        "운전자": {"교통사고처리지원금", "벌금(대물)", "벌금(대인)",
                "변호사선임비용", "자동차부상치료비"},
        "화재": {"화재벌금"},
        "치아": {"보존치료", "보철치료"},
    }
    # 소분류 → 대분류 역매핑
    SUB_TO_MAIN = {sub: main for main, subs in CATEGORIES.items() for sub in subs}

    # 보험별 카테고리 추출 — 표 데이터 영역 ("상품 별 보장 목록" 직전까지)
    # 카테고리별 상세정보 표는 [소분류] 다음 행에 [보험1값, 보험2값, ...] 순서로 N+1줄 (합계 + 보험별)
    section_end = -1
    for i, ln in enumerate(lines):
        if ln.strip() == "상품 별 보장 목록":
            section_end = i
            break

    if section_end == -1:
        section_end = len(lines)

    insurance_categories = [set() for _ in insurance_names]

    i = 0
    while i < section_end:
        s = lines[i].strip()
        if s in SUB_TO_MAIN:
            # 다음 줄부터 합계 + N개 보험값
            # 형식: [합계] [보험1] [보험2] ... [보험N] (총 N+1줄)
            values = []
            j = i + 1
            while j < section_end and len(values) < len(insurance_names) + 1:
                v = lines[j].strip()
                if not v:
                    j += 1
                    continue
                # 다음 소분류 라벨이면 break
                if v in SUB_TO_MAIN or v in ("실비", "3대진단", "수술비", "입원일당",
                                              "사망", "후유장해", "골절화상", "생활배상책임",
                                              "운전자", "화재", "치아"):
                    break
                values.append(v)
                j += 1

            # 첫 값 = 합계, 나머지 N개 = 보험별
            if len(values) >= len(insurance_names) + 1:
                main_cat = SUB_TO_MAIN[s]
                for ins_idx, val in enumerate(values[1:1 + len(insurance_names)]):
                    if val and val not in ("-", "—"):
                        insurance_categories[ins_idx].add(main_cat)
            i = j
        else:
            i += 1

    result = []
    for nm, st, cats in zip(insurance_names, renewal_states, insurance_categories):
        result.append({
            "name": nm,
            "is_renewal": st in ("갱신형 특약", "갱신형 보험"),
            "categories": cats,
        })
    return result

LEVEL_BAR_HTML = {
    "부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "사실상 부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "매우 취약": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "빈약": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "보통": '<div class="level-seg active-warning"></div><div class="level-seg active-warning"></div><div class="level-seg"></div>',
    "적정": '<div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg active-good"></div>',
    "과잉": '<div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div>',
}

# 라벨 → CSS class용 (공백·특수문자 제거)
def label_to_class(label):
    return label.replace(" ", "").replace("·", "")


# ===== HTML 변수 치환 =====

def render_html(template_path, customer):
    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    labels = customer["labels"]
    current = customer["current_values"]
    premium = customer["월보험료"]
    level = customer["연령대비"]
    is_family = customer.get("is_family", False)

    # v6 — 헤더 부제목 자체 분기
    # 일반 customer: "{성별} · 보험나이 {보험나이}세 · {거주}"
    # 가족 customer: "성별/나이 추가확인필요 · {거주}"  (보험나이 ❌, 한 줄 통합)
    if is_family:
        header_subtitle = f"{customer['성별']} · {customer['거주']}"
    else:
        header_subtitle = f"{customer['성별']} · 보험나이 {customer['보험나이']}세 · {customer['거주']}"

    # v6 — 헤드라인 본문 자체 산출 (4개 보장 라벨로 7가지 케이스 결정)
    # 외부 입력 우선, fallback 시 자체 산출
    if customer.get("헤드라인_main"):
        headline_main = customer["헤드라인_main"]
    elif is_family:
        headline_main = HEADLINE_BY_LEVEL["부재"]
    else:
        case_label = determine_conclusion_case(labels)
        headline_main = HEADLINE_BY_LEVEL.get(case_label, HEADLINE_BY_LEVEL["부재"])

    replacements = {
        "{{CUSTOMER_NAME}}": customer["이름"],
        "{{HEADER_SUBTITLE}}": header_subtitle,

        "{{HEADLINE_MAIN}}": headline_main,
        "{{HEADLINE_SUB}}": customer.get("헤드라인_sub", ""),

        "{{LABEL_실손}}": labels["실손"],
        "{{LABEL_실손_CLASS}}": label_to_class(labels["실손"]),
        "{{LABEL_암}}": labels["암"],
        "{{LABEL_암_CLASS}}": label_to_class(labels["암"]),
        "{{LABEL_뇌}}": labels["뇌"],
        "{{LABEL_뇌_CLASS}}": label_to_class(labels["뇌"]),
        "{{LABEL_심장}}": labels["심장"],
        "{{LABEL_심장_CLASS}}": label_to_class(labels["심장"]),
        "{{LABEL_수술}}": labels["수술"],
        "{{LABEL_수술_CLASS}}": label_to_class(labels["수술"]),

        "{{CURRENT_실손}}": current["실손"],
        "{{CURRENT_암}}": current["암"],
        "{{CURRENT_뇌}}": current["뇌"],
        "{{CURRENT_심장}}": current["심장"],
        "{{CURRENT_수술}}": current["수술"],
        "{{CURRENT_상해수술}}": current["상해수술"],

        "{{TOTAL_PREMIUM}}": premium["합계"],
        "{{PREMIUM_PROTECTION}}": premium["보장"],
        "{{PREMIUM_SAVINGS}}": premium["저축"],

        "{{LABEL_LEVEL}}": level["label"],
        "{{LABEL_LEVEL_CLASS}}": label_to_class(level["label"]),
        "{{LEVEL_BAR_HTML}}": LEVEL_BAR_HTML.get(level["label"], LEVEL_BAR_HTML["부재"]),
        "{{LEVEL_PERCENT}}": str(level["percent"]),
        "{{AGE_GROUP}}": level["age_group"],
        "{{RENEWAL_WARNING_BLOCK}}": RENEWAL_REPORT_HTML if customer.get("has_renewal") else "",
    }

    for key, val in replacements.items():
        html = html.replace(key, val)

    return html


# ===== 메시지 생성 =====

def render_message(customer):
    """메시지 본문 생성 — v6 (2026-05-04 박제).

    1번 항목 분기 (3가지 조합):
    - 갱신형 ✅ + 라벨 무관   → ① + ④ (라벨 분기 ❌, 무조건 ① + ④)
    - 갱신형 ❌ + 과잉·적정  → ② 만
    - 갱신형 ❌ + 보통·빈약·부재 → ③ 만

    2번 항목 결론 본문 — 4개 보장 라벨로 7가지 케이스 자체 산출
    (determine_conclusion_case + CONCLUSION_TEXT_BY_LEVEL).

    ① 노출 시 ① 직전·④ 또는 ② 또는 ③ 직전에 빈 줄 1행 추가.
    """
    name = customer["이름"]
    labels = customer["labels"]
    has_renewal = customer.get("has_renewal", False)
    # 잔여보험료합계액 (정수 — 원 단위, 갱신형 포함/제외 영역 ❌ 단순 전체 합계)
    total_remaining = customer.get("total_remaining_premium", 0)

    # v6 — 4개 보장 라벨로 결론 케이스 자체 산출
    case_label = determine_conclusion_case(labels)
    headline_close = CONCLUSION_TEXT_BY_LEVEL.get(case_label, CONCLUSION_TEXT_BY_LEVEL["부재"])

    # 1번 항목 분기 변수 조립 (v6 — 갱신 우선 분기)
    sub_lines = []
    if has_renewal:
        # 갱신형 ✅ 시 라벨 무관 ① + ④ 무조건
        sub_lines.append(RENEWAL_MESSAGE_LINE_1)  # ①
        sub_lines.append(RENEWAL_REMAINING_LINE.format(amount=total_remaining))  # ④
    else:
        # 갱신형 ❌ 시 라벨 분기 (② or ③)
        # 본 분기는 case_label(7가지)과 별개 — 잔여보험료 분기는 5종 라벨 기준 유지
        # 본 영역 결정: 4개 보장 자체 산출 case_label로 ② vs ③ 분기 (도메인 일관)
        if case_label == "과잉":  # 케이스 1·2 → 보장 충분 → ② "낭비"
            sub_lines.append(PREMIUM_OVERAGE_LINE.format(amount=total_remaining))
        elif case_label in ("미완성", "빈약", "매우 취약", "사실상 부재"):
            # 케이스 3·4·5·6 → 일반 ~ 부족 → ③ "일반적 수준"
            sub_lines.append(PREMIUM_NORMAL_LINE.format(amount=total_remaining))
        # case_label == "보장 전무" (케이스 7): ②/③ 둘 다 미노출 (잔여보험료 0원 추정)

    # 빈 줄 1행 추가 룰 — 각 sub_line 위에 빈 줄 삽입
    line_1_parts = [f"1. {name}님의 보험은,"]
    for sl in sub_lines:
        line_1_parts.append("")  # 빈 줄 1행
        line_1_parts.append(sl)
    line_1 = "\n".join(line_1_parts)

    msg = f"""{name}님 안녕하세요.
토스 보험분석 어드바이저입니다.

토스앱으로 보험 점검 신청을 주셔서 토스 본사 소속 상담사가 연락드렸습니다.

{line_1}

2. 필수보장을 기준으로,
- 실손의료비 : {labels["실손"]}
- 암보장 : {labels["암"]}
- 뇌혈관보장 : {labels["뇌"]}
- 심장보장 : {labels["심장"]}
- 수술보장 : {labels["수술"]}
으로 {headline_close}

3. 보험은 치료/사고 후에는 효율적으로 가입하기 어렵습니다.
올바르게 준비되어 있는지 꼭 점검해 보시기를 바랍니다.

❗궁금하신점은 [보험검토요청] 등으로 남겨주세요.
❗본사 상담사가 순차적으로 안내드릴 예정입니다.

✅ 본사 상담사 재직정보 확인 > https://service.tossinsu.com/insulink/vO03jJGuLG
"""
    return msg


# ===== HTML → PNG 변환 =====

def html_to_png(html_content, png_path, work_dir):
    """work_dir에 임시 HTML + 로고 복사 → PNG 변환"""
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)

    # 로고 복사
    logo_src = Path(__file__).parent / "toss_logo.png"
    logo_dst = work_path / "toss_logo.png"
    if not logo_dst.exists():
        shutil.copy(logo_src, logo_dst)

    # HTML 임시 저장
    html_path = work_path / "temp_report.html"
    html_path.write_text(html_content, encoding="utf-8")

    # PNG 변환
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 720, "height": 1280}, device_scale_factor=2)
        page.goto(f"file://{html_path.absolute()}")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(png_path), full_page=True, type="png")
        browser.close()


# ===== 가족 피보험자 헬퍼 =====

def build_family_member(premium_str, has_renewal=False, family_index=1):
    """가족 피보험자 PNG 데이터 생성 — v6 (2026-05-04 박제 B-3).

    피보험자가 본인이 아닌 가족인 경우 그 가족 기준 PNG를 생성하기 위한 데이터.
    CRM 데이터에는 가족 피보험자의 생년월일·성별 정보 없음.

    v6 갱신:
    - 이름: "—" → "가족{family_index}님" (NN_가족 순서: 01→가족1, 02→가족2)
    - 성별·보험나이: "—"·"—" 분리 → "성별/나이 추가확인필요" 한 줄 통합
    - 거주: "—" 유지

    Args:
        premium_str: 가족 피보험자 보험의 월보험료 합계 표시 문자열 (예: '513,314원')
        has_renewal: 가족 피보험자 보험 중 갱신형 포함 여부
        family_index: 가족 순번 (1·2·3·... — 본인 그룹 내 NN_가족과 동일)

    Returns:
        family_member dict — customer dict와 동일 구조 + is_family 플래그
    """
    return {
        "이름": f"가족{family_index}",  # 템플릿 "{{CUSTOMER_NAME}}님의 보장분석" 자동 처리
        "성별": "성별/나이 추가확인필요",  # render_html에서 헤더 한 줄 통합 처리 (보험나이 ❌)
        "보험나이": "",  # render_html에서 is_family=True 분기로 미사용
        "거주": "—",
        "is_family": True,  # render_html 헤더 분기 플래그
        "labels": {"실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"},
        "current_values": {
            "실손": "없음 (0원)",
            "암": "없음 (0원)",
            "뇌": "없음 (0원)",
            "심장": "없음 (0원)",
            "수술": "없음 (0원)",
            "상해수술": "0원"
        },
        "월보험료": {"보장": premium_str, "저축": "0원", "합계": premium_str},
        "연령대비": {"label": "—", "percent": "—", "age_group": "—"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": (
            "<span class=\"yellow\">세부정보 확인필요</span> — 가족 피보험자별 "
            "<span class=\"yellow\">생년월일·성별·보장 상세 데이터</span>는<br>"
            "<span class=\"red\">별도 조회가 필요</span>합니다."
        ),
        "has_renewal": has_renewal,
    }


# ===== 메인 함수 =====

def generate_reports(customers, output_zip, template_path=None, work_root="/tmp/pre_report_work"):
    """
    v2 폴더 평탄화 + NN.고객명 파일명 (2026-05-01 박제 ㉑ 정합).

    customers: list of customer dicts.
        각 customer dict는 옵셔널 키 'family_members' (list of dict) 가질 수 있음.
        family_members 정렬은 호출자가 보험료 많은 순 → 건수 많은 순 → 랜덤 순으로 미리 정렬.
    output_zip: 결과 zip 파일 경로
    template_path: HTML 템플릿 경로 (기본: 같은 폴더의 pre_report_template.html)

    산출물 구조 (v2 — 폴더 평탄화):
        zip 안 모든 파일 평탄 저장 (고객별 폴더 ❌)
        본인 PNG : {NN}.{고객명}.png (NN = 입력 순서, zfill 2자리)
        본인 메시지 : {NN}.{고객명}.txt
        가족 PNG : {NN}.{고객명}{NN_가족}.png (본인과 동일 NN)
    """
    if template_path is None:
        template_path = Path(__file__).parent / "pre_report_template.html"

    work_root = Path(work_root)
    if work_root.exists():
        shutil.rmtree(work_root)
    work_root.mkdir(parents=True, exist_ok=True)

    # 각 고객별 처리 — 단일 폴더에 평탄 저장 (NN.고객명 파일명)
    for nn, customer in enumerate(customers, start=1):
        name = customer["이름"]
        nn_str = f"{nn:02d}"  # zfill 2자리

        # 본인 PNG : {NN}.{고객명}.png
        html_content = render_html(template_path, customer)
        png_path = work_root / f"{nn_str}.{name}.png"
        html_to_png(html_content, png_path, work_root)

        # 가족 피보험자 PNG : {NN}.{고객명}{NN_가족}.png (본인과 동일 NN)
        # v6 — 호출자 무관 family_index 자체 보완 (박제 B-3)
        for fam_idx, family in enumerate(customer.get("family_members", []), start=1):
            family["이름"] = f"가족{fam_idx}"  # 템플릿이 "님의 보장분석" 자동 추가
            family["is_family"] = True
            if "성별" not in family or family.get("성별") in (None, "", "—"):
                family["성별"] = "성별/나이 추가확인필요"
            if "거주" not in family or family.get("거주") in (None, ""):
                family["거주"] = "—"
            family_html = render_html(template_path, family)
            family_png_path = work_root / f"{nn_str}.{name}{fam_idx:02d}.png"
            html_to_png(family_html, family_png_path, work_root)

        # 메시지 (본인 1개만 — 가족 메시지 ❌) : {NN}.{고객명}.txt
        msg = render_message(customer)
        msg_path = work_root / f"{nn_str}.{name}.txt"
        msg_path.write_text(msg, encoding="utf-8")

    # 임시 HTML·로고 정리
    for f in ["temp_report.html", "toss_logo.png"]:
        fp = work_root / f
        if fp.exists():
            fp.unlink()

    # zip 패키징 (Python zipfile — UTF-8 한글 호환, 디렉토리 엔트리 ❌, 평탄 저장)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work_root.iterdir()):
            if f.is_file():
                zf.write(f, f.name)  # arcname = 파일명만 (폴더 ❌)

    return output_zip



if __name__ == "__main__":
    # 테스트: 유태수 케이스
    test_customer = {
        "이름": "유태수",
        "성별": "남",
        "보험나이": 45,
        "거주": "경기도 고양시",
        "labels": {
            "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
        },
        "current_values": {
            "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
            "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
        },
        "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
        "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
    }

    out = generate_reports([test_customer], "/tmp/test_report.zip")
    print(f"Generated: {out}")
