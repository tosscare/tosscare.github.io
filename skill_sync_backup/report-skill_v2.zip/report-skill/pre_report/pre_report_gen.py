"""
pre_report_gen.py — 사전상담 자료 생성 스크립트

역할:
1. 고객 데이터 입력받아 → 변수 치환된 HTML 생성
2. HTML → PNG 변환 (Playwright)
3. message.txt 생성
4. 다수 고객 → zip 패키징 (고객별 폴더)

사용법:
  from pre_report_gen import generate_reports
  
  customers = [
      {
          "이름": "유태수",
          "성별": "남",
          "보험나이": 45,
          "거주": "경기도 고양시",
          "labels": {
              "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
          },
          "current_values": {
              "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
              "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
          },
          "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
          "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
          "헤드라인_main": "핵심 의료보장이 <span class=\"accent\">전부 부재한 상태</span>입니다.",
          "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
      }
  ]
  generate_reports(customers, output_zip="report_20260427.zip")
"""

import os
import re
import zipfile
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright


# ===== 라벨 매핑 =====

HEADLINE_BY_LEVEL = {
    "부재": "핵심 의료보장이 <span class=\"accent\">전부 부재한 상태</span>입니다.",
    "사실상 부재": "핵심 의료보장이 <span class=\"accent\">사실상 부재한 상태</span>입니다.",
    "매우 취약": "핵심 의료보장이 <span class=\"accent\">매우 취약한 상태</span>입니다.",
    "빈약": "핵심 의료보장이 <span class=\"accent\">빈약한 상태</span>입니다.",
    "보통": "핵심 의료보장이 보통 수준입니다.",
    "적정": "핵심 의료보장이 적정 수준입니다.",
    "과잉": "핵심 의료보장이 과잉 수준입니다.",
}

# 갱신형 감지 룰 (rules.json renewal_handling 박제)
RENEWAL_KEYWORD = "갱신"
RENEWAL_MESSAGE_LINE = "보험의 일부(또는 전부)가 갱신형으로 구성되어 보험료가 크게 높아질 수 있습니다."
RENEWAL_REPORT_HTML = (
    '<div class="renewal-warning">'
    '※ 보험의 일부(또는 전부)가 갱신형으로 구성되어 보험료가 크게 높아질 수 있습니다.'
    '</div>'
)


def detect_renewal(raw_customer_text):
    """고객정보 원문 텍스트에 '갱신' 단어 포함 여부 (어디든 — 갱신 유무 행·담보명 모두)."""
    if not raw_customer_text:
        return False
    return RENEWAL_KEYWORD in raw_customer_text

LEVEL_BAR_HTML = {
    "부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "사실상 부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "매우 취약": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "빈약": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "보통": '<div class="level-seg active-warning"></div><div class="level-seg active-warning"></div><div class="level-seg"></div>',
    "적정": '<div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg active-good"></div>',
    "과잉": '<div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div>',
}

# 라벨 → CSS class용 (공백·특수문자 제거)
def label_to_class(label):
    return label.replace(" ", "").replace("·", "")


# ===== HTML 변수 치환 =====

def render_html(template_path, customer):
    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    labels = customer["labels"]
    current = customer["current_values"]
    premium = customer["월보험료"]
    level = customer["연령대비"]

    replacements = {
        "{{CUSTOMER_NAME}}": customer["이름"],
        "{{GENDER}}": customer["성별"],
        "{{AGE}}": str(customer["보험나이"]),
        "{{REGION}}": customer["거주"],

        "{{HEADLINE_MAIN}}": customer.get("헤드라인_main", HEADLINE_BY_LEVEL.get(level["label"], HEADLINE_BY_LEVEL["부재"])),
        "{{HEADLINE_SUB}}": customer.get("헤드라인_sub", ""),

        "{{LABEL_실손}}": labels["실손"],
        "{{LABEL_실손_CLASS}}": label_to_class(labels["실손"]),
        "{{LABEL_암}}": labels["암"],
        "{{LABEL_암_CLASS}}": label_to_class(labels["암"]),
        "{{LABEL_뇌}}": labels["뇌"],
        "{{LABEL_뇌_CLASS}}": label_to_class(labels["뇌"]),
        "{{LABEL_심장}}": labels["심장"],
        "{{LABEL_심장_CLASS}}": label_to_class(labels["심장"]),
        "{{LABEL_수술}}": labels["수술"],
        "{{LABEL_수술_CLASS}}": label_to_class(labels["수술"]),

        "{{CURRENT_실손}}": current["실손"],
        "{{CURRENT_암}}": current["암"],
        "{{CURRENT_뇌}}": current["뇌"],
        "{{CURRENT_심장}}": current["심장"],
        "{{CURRENT_수술}}": current["수술"],
        "{{CURRENT_상해수술}}": current["상해수술"],

        "{{TOTAL_PREMIUM}}": premium["합계"],
        "{{PREMIUM_PROTECTION}}": premium["보장"],
        "{{PREMIUM_SAVINGS}}": premium["저축"],

        "{{LABEL_LEVEL}}": level["label"],
        "{{LABEL_LEVEL_CLASS}}": label_to_class(level["label"]),
        "{{LEVEL_BAR_HTML}}": LEVEL_BAR_HTML.get(level["label"], LEVEL_BAR_HTML["부재"]),
        "{{LEVEL_PERCENT}}": str(level["percent"]),
        "{{AGE_GROUP}}": level["age_group"],
        "{{RENEWAL_WARNING_BLOCK}}": RENEWAL_REPORT_HTML if customer.get("has_renewal") else "",
    }

    for key, val in replacements.items():
        html = html.replace(key, val)

    return html


# ===== 메시지 생성 =====

def render_message(customer):
    name = customer["이름"]
    labels = customer["labels"]
    level_label = customer["연령대비"]["label"]
    has_renewal = customer.get("has_renewal", False)

    # 헤드라인 텍스트 (마침표 포함) - 메시지 2번 마무리에 사용 (갱신형 영향 ❌)
    headline_text_map = {
        "부재": "핵심 의료보장이 전부 부재한 상태입니다.",
        "사실상 부재": "핵심 의료보장이 사실상 부재한 상태입니다.",
        "매우 취약": "핵심 의료보장이 매우 취약한 상태입니다.",
        "빈약": "핵심 의료보장이 빈약한 상태입니다.",
        "보통": "핵심 의료보장이 보통 수준입니다.",
        "적정": "핵심 의료보장이 적정 수준입니다.",
        "과잉": "핵심 의료보장이 과잉 수준입니다.",
    }
    headline_close = headline_text_map.get(level_label, headline_text_map["부재"])

    # 메시지 1번 - 갱신형 감지 시 우선 적용 (라벨 무관)
    if has_renewal:
        line_1 = f"1. {name}님의 보험은, {RENEWAL_MESSAGE_LINE}"
    else:
        line_1 = f"1. {name}님의 보험은, {headline_close}"

    msg = f"""{name}님 안녕하세요.
토스 보험분석 어드바이저입니다.

토스앱으로 보험 점검 신청을 주셔서 토스 본사 소속 상담사가 연락드렸습니다.

{line_1}

2. 필수보장을 기준으로,
- 실손의료비 : {labels["실손"]}
- 암보장 : {labels["암"]}
- 뇌혈관보장 : {labels["뇌"]}
- 심장보장 : {labels["심장"]}
- 수술보장 : {labels["수술"]}
으로 {headline_close}

3. 보험은 올바르게 가입하지 않으면 질병 발병, 사고 후에는 가입이 어렵습니다.
올바르게 준비되어 있는지 꼭 점검해 보시기를 바랍니다.

❗궁금하신 점은 메시지 남겨주세요.
❗본사  상담사가 순차적으로 안내드릴 예정입니다.

✅ 본사 상담사 재직정보 확인 > https://service.tossinsu.com/insulink/vO03jJGuLG
"""
    return msg


# ===== HTML → PNG 변환 =====

def html_to_png(html_content, png_path, work_dir):
    """work_dir에 임시 HTML + 로고 복사 → PNG 변환"""
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)

    # 로고 복사
    logo_src = Path(__file__).parent / "toss_logo.png"
    logo_dst = work_path / "toss_logo.png"
    if not logo_dst.exists():
        shutil.copy(logo_src, logo_dst)

    # HTML 임시 저장
    html_path = work_path / "temp_report.html"
    html_path.write_text(html_content, encoding="utf-8")

    # PNG 변환
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 720, "height": 1280}, device_scale_factor=2)
        page.goto(f"file://{html_path.absolute()}")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(png_path), full_page=True, type="png")
        browser.close()


# ===== 가족 피보험자 헬퍼 =====

def build_family_member(premium_str, has_renewal=False):
    """가족 피보험자 PNG 데이터 생성 — 모든 식별정보 '—' 표기, 5종 모두 부재.

    피보험자가 본인이 아닌 가족인 경우 그 가족 기준 PNG를 생성하기 위한 데이터.
    CRM 데이터에는 가족 피보험자의 생년월일·성별 정보 없음 → 모두 '—'로 처리.
    헤드라인 sub에 '세부정보 확인필요' 명시.

    Args:
        premium_str: 가족 피보험자 보험의 월보험료 합계 표시 문자열 (예: '513,314원')
        has_renewal: 가족 피보험자 보험 중 갱신형 포함 여부

    Returns:
        family_member dict — customer dict와 동일 구조
    """
    return {
        "이름": "—",
        "성별": "—",
        "보험나이": "—",
        "거주": "—",
        "labels": {"실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"},
        "current_values": {
            "실손": "없음 (0원)",
            "암": "없음 (0원)",
            "뇌": "없음 (0원)",
            "심장": "없음 (0원)",
            "수술": "없음 (0원)",
            "상해수술": "0원"
        },
        "월보험료": {"보장": premium_str, "저축": "0원", "합계": premium_str},
        "연령대비": {"label": "—", "percent": "—", "age_group": "—"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": (
            "<span class=\"yellow\">세부정보 확인필요</span> — 가족 피보험자별 "
            "<span class=\"yellow\">생년월일·성별·보장 상세 데이터</span>는<br>"
            "<span class=\"red\">별도 조회가 필요</span>합니다."
        ),
        "has_renewal": has_renewal,
    }


# ===== 메인 함수 =====

def generate_reports(customers, output_zip, template_path=None, work_root="/tmp/pre_report_work"):
    """
    customers: list of customer dicts.
        각 customer dict는 옵셔널 키 'family_members' (list of dict) 가질 수 있음.
        family_members 정렬은 호출자가 보험료 많은 순 → 건수 많은 순 → 랜덤 순으로 미리 정렬.
    output_zip: 결과 zip 파일 경로
    template_path: HTML 템플릿 경로 (기본: 같은 폴더의 pre_report_template.html)

    파일명 룰 (v2 — 폴더 평탄화):
    - 본인: {NN}.{고객명}.png + {NN}.{고객명}.txt
    - 가족: {NN}.{고객명}{NN_가족}.png (NN_가족 = 01·02·...)
    - NN = 입력 순서대로 01·02·... (zfill 2자리)
    - zip 안에 모든 파일이 같은 위치에 평탄 저장 (고객별 폴더 ❌)
    """
    if template_path is None:
        template_path = Path(__file__).parent / "pre_report_template.html"

    work_root = Path(work_root)
    if work_root.exists():
        shutil.rmtree(work_root)
    work_root.mkdir(parents=True, exist_ok=True)

    # 각 고객별 처리 — 입력 순서대로 NN 부여
    for cust_idx, customer in enumerate(customers, start=1):
        name = customer["이름"]
        nn = f"{cust_idx:02d}"

        # 본인 PNG
        html_content = render_html(template_path, customer)
        html_to_png(html_content, work_root / f"{nn}.{name}.png", work_root)

        # 가족 피보험자 PNG (옵션) — 정렬된 순서대로 {NN}.{고객명}01.png, {NN}.{고객명}02.png ...
        for family_idx, family in enumerate(customer.get("family_members", []), start=1):
            family_html = render_html(template_path, family)
            family_png_path = work_root / f"{nn}.{name}{family_idx:02d}.png"
            html_to_png(family_html, family_png_path, work_root)

        # 메시지 (본인 기준 1개만 — 가족 메시지 ❌)
        msg = render_message(customer)
        (work_root / f"{nn}.{name}.txt").write_text(msg, encoding="utf-8")

    # 임시 HTML·로고 정리
    for f in ["temp_report.html", "toss_logo.png"]:
        fp = work_root / f
        if fp.exists():
            fp.unlink()

    # zip 패키징 (Python zipfile — UTF-8 한글 호환, 폴더 평탄화)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work_root.iterdir()):
            if f.is_file():
                zf.write(f, f.name)

    return output_zip



if __name__ == "__main__":
    # 테스트: 유태수 케이스
    test_customer = {
        "이름": "유태수",
        "성별": "남",
        "보험나이": 45,
        "거주": "경기도 고양시",
        "labels": {
            "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
        },
        "current_values": {
            "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
            "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
        },
        "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
        "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
    }

    out = generate_reports([test_customer], "/tmp/test_report.zip")
    print(f"Generated: {out}")
