---
name: "ta-call-brief"
description: "토스 CRM 고객리스트 → 1차 TA(전화) 킬포인트 보드 자동 생성. 트리거 \"TA자료\" / \"TA자료분석\" / \"전화자료\" / \"전화자료분석\". 고객별 상담가능성 점수·유형·킬포인트·보유보험 진단태그 + CRM 전체레포트(report-skill crm_lib 기준) + 체결보험·상담이력 팝업을 카드형 아티팩트로 산출. 미터치 고객은 상담내용 자동 등록 후 작성. 카드별 상담내용입력(상태 토글+메모, 아티팩트 DB 저장) 포함."
---

# TA자료 (1차 전화 킬포인트 보드) v1.0 — 2026-11-08 확립

> 목적: 상담확률 높은 고객을 골라, mr.와이가 **1차 콜에서 한마디로 본상담 전환**할 수 있는 킬포인트를 쥐어주는 것.
> 원칙: **정확한 규칙 · 최소 토큰 · 최소 시간**. 룰을 바꾸지 말고 아래 코드를 그대로 실행한다. 룰 변경은 mr.와이 지시로만, 변경 시 §9 프로토콜.

## §0. 트리거 · 대화 규칙
| 발화 | 동작 |
|---|---|
| `TA자료` `TA자료분석` `전화자료` `전화자료분석` | §3 파이프라인 전체 실행 → 새 아티팩트 링크 (제목 `TA_YYMMDD`, 작업일) |
| 선별 조건 동반 (예: "상담내용 261105 TA 예정만", "미터치 고객", "배정일 11/1~11/5") | 조건은 **선별(필터)에만** 사용. 점수·킬포인트에는 절대 반영 ❌ |
| 같은 작업의 수정 요청 | 같은 아티팩트 URL에 재발행 (`url` 지정) · **제목 변경 ❌** (`TA_YYMMDD` 유지) |
| 새 선별 조건 | **새 아티팩트** (부제에 조건·날짜) |
| 질문만 할 때 | 답변만. 작업 착수 ❌. "답변부터"/"yes·no만"이면 그대로 |

**절대 룰**
1. 점수·킬포인트 입력 = `기본정보(생년·성별·전화) + 가입보험(마이데이터) + 보장분석 매트릭스`만. **상담내용·칸반상태·상담상태·신청이력은 점수/킬포인트에 0% 반영**. 단, 카드 **표시용**으로는 사용: 최근 신청(일시·지역·카테고리)·배정일, 상담이력 특이사항 요약, 상담이력 팝업(원문), 체결보험 팝업.
2. 설계안·상담자료 spec·report-skill의 고객별 파일 참조 ❌. 상품명·설계보험료·절약액 ❌ (CRM 단계는 진단+방향까지). 단, **report-skill의 `lib/crm_lib.py`(CRM 전체레포트 빌더)·`crm_report/` 템플릿은 레포트보기 생성에 그대로 사용**(코드 수정 ❌).
3. 고객 식별 = **고객명 + 휴대폰 전체번호** (No. 사용 ❌, 번호 바뀜).
4. 보험료 = 원 단위 정확히, 가입일 = YYYY-MM-DD.
5. **미터치(untouched) 고객 자동 등록**: 선별된 고객 중 리스트 API `untouched===true`인 고객은 보드 작성 **전에** `POST /api/v3/counsel-note/{id}` (payload `{content:'YYMMDD TA 예정', sendCounselLog:true, …}` — 실행 당일, 예 `261106 TA 예정`)로 **일괄 등록**(상담노트 + 상담이력 동시 반영 = 미터치 해제) → 그 고객까지 포함해 작성. 고객 수와 무관하게 수 초. 이미 TA 예정이 있는 고객은 작성만. 등록한 명단은 보고에 기재. fetch 실패 시 폴백은 §4-A2.
6. CRM 전체레포트(레포트보기)의 담보 집계 = **CRM 보장분석 탭 분류 그대로**: `insuranceCovers[].subCategories`(NONE 제외) 기준, **상품 내 같은 소분류는 합산이 아니라 최댓값**, **만원 미만 절사**, 피보험자 구분 없이 전체 담보. 특약명 키워드 재매핑 ❌(오분류 확인됨). 검증: 장다혜·김미영·서현옥 CRM 화면 셀 단위 대조 일치(서현옥 뉴사랑나무 사망 2셀만 API 담보 공백 예외).

## §1. 점수 룰 v3 (2트랙, 100 상한)
적정보험료: 20대 10만 / 30대 15만 / 40대 18만 / 50대 25만 / 60대+ 40만 (보장성 월납 합계 ÷ 적정 = 지출정도)
보장성 합계 제외: 자동차·여행·휴대폰·펫·보증·화재/재물·주택, 연금·저축, 납입완료, 피보험자≠본인(자녀보험)

**A 조정형** (과잉·갱신 → "완벽 보강해도 절약")
| 축 | 배점 |
|---|---|
| 보험료 낭비 | ≥170% 30 / 130~169% 25 / 90~129% 15 / <90% 5 **+ 갱신 가산(지출 ≥90%일 때만)**: 갱신 비중 ≥50% +15 / 20~49% 또는 1·2세대 실손 +10 / >0 +5 |
| 보장 공백 | 항목당 6 (최대 30): 암(합계<5,000만 or 단일상품 최대<5,000만) · 뇌혈관 or 허혈성 <3,000만 · 1~5종 수술비 없음 · 표적항암 없음 · 간병 없음(40대↑만) |
| 완벽보강해도절약 | 낭비≥25 and 공백≥18 → 15 |
| 종신저축오인 | 1건 20 / 2건↑ 30 |

**B 보강형** (저보험료 + 공백 → "큰 병 대비 0 / 지금이 가장 쌀 때"): 지출 <90% **and** 핵심공백(간병 제외) 2개↑ → 공백 항목당 12 + 보장성無(실손·운전자만) 15 / 구형(1·2세대 실손 or 2011년 이전 가입) 10 + 종신오인
**잔여비율 가산** (보장성 납입중 계약의 잔여보험료 ÷ 총보험료): ≥90% +10 / 70~89% +7 / 50~69% +4 / 30~49% +2 / <30% 0 — 최근 가입일수록 조정 허들이 낮다
**채택** = max(A,B) + 잔여비율 가산 → 유형 = B>A 보강형 / A≥35 조정형 / 그 외 양호 → **× 연령** 30~40대 1.0 / 20대 0.85 / 50대 0.7 / 60대+ 0.5 → **100 상한**
**등급** 🔥 65+ (적극 거절 전까지 2~3회 컨택) / 🟢 50~64 (정상 TA) / 🟡 35~49 (바쁘면 뒤로) / ⚪ <35 (스킵 가능)
**갱신 비중** = (전체갱신형 보험료 + 특약갱신 보험료×0.5) ÷ 보장성 합계. 실손 세대: ~2009.09 1 / ~2017.03 2 / ~2021.06 3 / ~2026.05.05 4 / 이후 5.

## §2. 종신 · 상품 진단태그 · 조정방향
**종신·CI·유니버설 (납입중만)**: 납입 3·5·7년 → `저축으로 오인 가입` · 10년↑ → `사망보장·상속세 재원`, 단 보험료가 10만 단위로 딱 떨어지거나 100만↑ → `저축으로 오인 가입`
**상품 태그 → 조정방향** (빨강 = 상담 대상)
| 태그 | 방향 |
|---|---|
| 저축으로 오인 가입 | 🔴 리모델링 고려 (저축 목적 재확인) |
| 보험료 과다 + 보장 빈약 (단일상품 ≥ 적정 50% & 암<3천/뇌심<2천/1~5종 無) | 🔴 리모델링 고려 |
| 보험료 과다 + 보장은 충분 | 유지 · 보험료만 점검 |
| 갱신형 구성(·보장 빈약) | 🔴 비갱신 전환 고려 |
| (구형·)보장 빈약 | 🔴 보강 또는 통합 리모델링 |
| 보장 충분·유지 | 유지 |
| 실손 1·2세대·갱신 인상 / 3세대·전환 검토 / 4·5세대·유지 | 🔴 5세대 전환 / 🔴 전환 검토 / 유지 |
| 운전자 최신·유지(2024↑) / 운전자 구형·교체 | 유지 / 🔴 최신 상품으로 교체 |
| 치아·갱신형 / 치아 | 필요성 확인 후 유지·해지 / 유지 |
| 납입완료·유지 / 저축·연금 / 자녀보험·분석제외 / 사망보장·상속세 재원 | 유지 / 유지(분석 제외) / 별도 점검 / 유지·상속세 재원 필요성 확인 |

**킬포인트 (최대 3, 카드엔 2줄, 우선순위순)**: 💰종신오인 → 📉과잉(공백 3개↑면 "보장 100%로 올려도 보험료 줄어듦" / 아니면 "최대 보험료 1건 지목") or 🕳보강형("보장성 사실상 없음" / "월 N만 내는데 ○○ 대비 없음·구형") → 🔁갱신 ≥30% → 🏥실손 1·2세대 → 👨‍👩‍👧자녀보험 별도

## §3. 파이프라인 (토큰 최소화 — 이 순서 고정)
0. **세션 확인 (필수 첫 단계)**: 고객리스트 탭에서 javascript_tool로 `(await fetch('/api/customer/v2/list?size=1',{credentials:'include'})).status` 실행. 200이 아니거나 탭 URL이 `erp.tossinsu.com/login.go`면 작업 중단하고 채팅에 **"CRM 로그인 후 알려주세요"** 한 줄만 보내고 대기. 로그인·OTP 입력은 mr.와이가 직접 한다(Claude는 비밀번호·OTP 입력 불가). "됐어/로그인했어" 응답 후 0번부터 재확인하고 진행. 작업 중 브라우저 호출 공백이 25분을 넘기면(긴 빌드·발행 뒤) 다음 브라우저 단계 전에 0번을 다시 실행한다.
1. **선별**: 고객리스트 탭에서 §4-A 실행 (list API `size=2000` → 조건으로 id·name·배정일·untouched 선별 → `localStorage.__ta_sel`). 리스트 페이지 `get_page_text` ❌.
2. **미터치 등록** (해당자 있을 때만): 같은 탭에서 §4-A2 fetch 일괄 실행 → 결과의 `fail`이 비어 있으면 진행. 실패 고객만 §4-A2 폴백.
3. **추출·채점**: 같은 탭에서 §4-B 실행 (customer/v2 + contracts + counselor API 순회 → 채점·태그·킬포인트·생년월일코드·최근신청·상담이력·체결보험·보험별 계약자/피보험자·만기·증권번호·소분류 최댓값 담보 → `localStorage.__ta_out2`).
4. **반출**: 새 탭 `https://crm.tossinsu.com/robots.txt` → `document.body.innerHTML='<pre>'+localStorage.__ta_out2.replace(/</g,'&lt;')+'</pre>'` → `get_page_text` 1회 (30k 초과 시 `slice`로 2~3분할). 탭 닫기. (javascript_tool 직접 출력은 1.5k 절단·`[BLOCKED]` 발생 → 반드시 pre 덤프)
5. **저장**: 결과 JSON을 `Write`로 `/home/claude/ta/data.json` (분할 가능, 요약·생략 ❌).
6. **빌드**: `/home/claude/ta`에서 §4-C `python3 build.py "선별 조건 문구" "마이데이터 기준일" "TA_YYMMDD"` → `ta_board.html`(상담내용입력 모듈 내장) + `crm/{고객id}_{그룹}.html`(본인보험=0, 가족 피보험자별 1..) + `crm/toss_logo.png` + `files.json`. `node --check`로 script 구문 체크 1회.
7. **발행**: `Artifact` publish — `file_path=ta_board.html`, `root=/home/claude/ta`, `files=files.json의 목록`(crm/*.html + crm/toss_logo.png 전부, 레포트보기 iframe 소스, **상대경로**), 새 작업 = 새 URL(icon `phone`), 수정 = `url` 지정, **`capabilities={"db":{}}` 필수**(상담내용입력 저장소 · 누락 시 기록이 브라우저에만 남음). 제목 = **`TA_YYMMDD`**(작업일, build.py 3번째 인자와 동일) — 수정 재발행 시에도 제목 유지. 발행 후 `ArtifactData list notes`로 DB 연결 1회 확인.
8. **보고** (채팅): **이슈만** — 미터치 등록 명단(실패자 포함) + 이번 회차 룰·데이터 이슈 1~3줄. 등급 분포·🔥 명단·작성 기준 서머리 ❌ (보드에 다 있음). 이슈 없으면 "이슈 없음" 한 줄.

## §4. 코드 (그대로 실행)
### 4-A 선별 (list 탭, javascript_tool)
```js
const e=performance.getEntriesByType('resource').map(e=>e.name).find(n=>n.includes('/api/customer/v2/list'));
const u=new URL(e); u.searchParams.set('size','2000');
const j=await (await fetch(u.pathname+u.search,{credentials:'include'})).json();
// ▼ 선별 조건만 교체 (기본: 최근 상담내용 정규식). 미터치 고객 선별이면 RE 대신 x.untouched===true 사용
const RE=/26110[2-5]\s*TA\s*예정/;
const sel=j.results.filter(x=>RE.test(JSON.stringify((x.counselLogsSimpleModel||[]).slice(0,1)))).map(x=>({id:x.id,name:x.name,asg:(x.counselorAssignedAt||'').slice(0,16),un:!!x.untouched}));
localStorage.setItem('__ta_sel',JSON.stringify(sel)); ({n:sel.length,untouched:sel.filter(s=>s.un).map(s=>s.name),names:sel.map(s=>s.name).join(' ')})
```
### 4-A2 미터치 상담노트 일괄 등록 (list 탭, javascript_tool) — 2026-11-06 payload 검증 완료
```js
const S=JSON.parse(localStorage.__ta_sel); const d=new Date(), TXT=String(d.getFullYear()).slice(2)+('0'+(d.getMonth()+1)).slice(-2)+('0'+d.getDate()).slice(-2)+' TA 예정';
const tg=S.filter(s=>s.un); const ok=[],fail=[];
for(let i=0;i<tg.length;i+=6){ await Promise.all(tg.slice(i,i+6).map(async s=>{ try{ const r=await fetch('/api/v3/counsel-note/'+s.id,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({content:TXT,counselNoteFileRequests:[],counselNoteType:null,sendCounselLog:true})}); const t=await r.text(); if(r.status===200&&t.includes('SUCCESS')){ok.push(s.name);s.un=false;} else fail.push(s.name+':'+r.status);}catch(e){fail.push(s.name+':'+e.message)} })); }
localStorage.setItem('__ta_sel',JSON.stringify(S)); ({txt:TXT,ok,fail})
```
- `sendCounselLog:true` = "상담이력에도 추가하기" 체크와 동일 → 상담노트 + 상담이력 동시 등록, 리스트 `untouched` 즉시 false.
- 검증(선택): 임의 1명 `/api/customer/v2/{id}`의 `counselLogs`에 `상담노트입력 YYMMDD TA 예정` 행 확인.
- **폴백** (`fail`에 남은 고객만): `navigate /crm-v2/customers/{id}` → `find` 입력칸·체크박스·남기기 → 입력칸 `left_click`+`type` → 체크박스는 **반드시 `left_click`** (`form_input`은 화면만 바뀌고 React 상태 미반영 → `sendCounselLog:false`로 전송됨) → 남기기 `left_click` → `counselLogs`로 확인. 그래도 이력 미반영이면 노트만 남긴 상태로 두고 **보고에 이슈로 기재**(추측 재시도 ❌). 처리 후 4-B 진행.

### 4-B 추출·채점 (list 탭, javascript_tool) — 결과 `__ta_out2`
```js
const SEL=JSON.parse(localStorage.getItem('__ta_sel')); const kw=(s,re)=>re.test(s||'');
async function fetchC(c){ const j=await (await fetch(`/api/customer/v2/${c.id}`,{credentials:'include'})).json(); const b0=(j.birthDate&&j.birthDate.value)||j.birthDate||'', g0=(j.gender&&j.gender.value)||j.gender||'';
 const Lq=(j.counselRequestLogs||[]).slice().sort((x,y)=>(y.counselRequestedAt||'')<(x.counselRequestedAt||'')?-1:1)[0]||{}; const req=[Lq.counselRequestedAt||'',(Lq.userLocation||'').trim(),Lq.counselPurpose||''];
 const raw=(j.counselLogs||[]).map(l=>[l.counselAt||'',l.status||'',l.counselorName||'',l.content||'']);
 const ct=((await (await fetch(`/api/customer/v2/${c.id}/contracts`,{credentials:'include'})).json()).contracts||[]).map(x=>[x.receiveAt||'',x.contractStatus||'',x.insuranceCompanyName||'',x.insuranceProductName||'',x.policyNo||'',x.afterQcStatus||'',x.autographDone==null?'':(x.autographDone?'완료':'미완'),x.amount||0,x.paymentCycle||'',x.paymentPeriod||'',x.contractorName||'',(x.insuredNames||[]).join(','),x.counselorName||'',x.depositorName||'']);
 const p=(await (await fetch(`/api/customer/v2/${c.id}/insurance-analysis/counselor`,{credentials:'include'})).json()).payload; if(!p) return {...c,phone:(j.phoneNumber&&j.phoneNumber.value)||'',b:b0,g:g0,req,raw,ct,ins:[]};
 const n=c.name, mask=n.length>=2?new RegExp('^'+n[0]+'\\*+'+n[n.length-1]+'$'):null;
 return {...c,phone:p.phoneNumber,g:p.gender||g0,b:p.birthDate||b0,req,raw,ct,ins:(p.insurances||[]).map(i=>{const cv=i.insuranceCovers||[]; const live=i.status==='정상'; const agg={},fl=new Set(); if(live) for(const x of cv){ if(x.category!=='NONE'){const k=x.subCategories[0]; agg[k]=(agg[k]||0)+Math.round(x.coverAmount/10000);} }
  const names=cv.map(x=>x.coverName).join('|'); if(kw(names,/표적|면역항암|카티/))fl.add('T'); if(kw(names,/1[~\-]5종|5종수술|종수술/))fl.add('S'); if(kw(names,/간병|치매|요양/))fl.add('C');
  const w=((i.insuredNames||[]).join(',')).trim(); const self=!w||/본인/.test(w)||w===n||(mask&&mask.test(w))||/[0-9]|운전|한정|누구나|특별시|광역시|공제|회사|조합|법인|단체|학교|\(주\)/.test(w);
  return {co:i.companyName,nm:i.insuranceName,st:i.status,ps:i.paymentStatus,cyc:i.paymentCycle,per:i.paymentPeriod,s:i.coverStartDate,e:i.coverEndDate||'',ea:i.coverEndAge,fee:i.insuranceAmount,paid:i.paidInsuranceAmount||0,rem:i.remainingInsuranceAmount||0,ren:i.renewalContract,fl:[...fl].join(''),self,who:w||'본인',ctr:i.contractorName||'',cv:agg,pn:i.policyNo||'',pe:(i.paymentEndDate||'').slice(0,7),pa:i.paymentEndAge||'',mc:(i.maskedContractorName||i.contractorName||'')+'/'+((i.maskedInsuredNames||i.insuredNames||[]).join(',')||'본인'),cm:(()=>{const m={};for(const x of cv){for(const s of (x.subCategories||[])){if(s==='NONE')continue;m[s]=Math.max(m[s]||0,Math.floor((x.coverAmount||0)/10000));}}return Object.entries(m).filter(e=>e[1]>0).map(e=>e[0]+'='+e[1]).join(';');})()};})};}
const TODAY=new Date(); const age=b=>{const d=new Date(b);let a=TODAY.getFullYear()-d.getFullYear();if(TODAY<new Date(TODAY.getFullYear(),d.getMonth(),d.getDate()))a--;return a};
const proper=a=>a<30?100000:a<40?150000:a<50?180000:a<60?250000:400000; const mult=a=>a<30?0.85:a<50?1.0:a<60?0.7:0.5;
const isCar=n=>/자동차|개인용|이륜차|퍼마일|업무용|Hicar|애니카|Readycar|다이렉트\(|CM\)|라이더/.test(n);
const isEtc=n=>/휴대폰|여행|펫보험|보증보험|화재보험|재물|재산종합|가정종합|홈앤|우리집|M-House|주택/.test(n);
const isSave=n=>/연금|저축|변액연금/.test(n)&&!/종신/.test(n); const isWhole=n=>/종신|CI|유니버설/.test(n);
const isDrv=n=>/운전자/.test(n); const isDent=n=>/치아|덴탈/.test(n);
const isSil=i=>/실손|실비|의료비보험|의료비보장/.test(i.nm)||Object.keys(i.cv).some(k=>/입원의료비/.test(k));
const silGen=s=>s<='2009-09-30'?1:s<='2017-03-31'?2:s<='2021-06-30'?3:s<='2026-05-05'?4:5;
const man=v=>Math.round(v/10000); const co=s=>s.replace(/보험|해상|화재|생명/g,''); const nm=s=>s.replace(/^\(무\)\s*|무배당\s*|無/g,'');
const wholeMis=i=>{ if(!isWhole(i.nm)||i.ps!=='정상-납입중'||!(i.fee>0)) return false; const p=parseInt(i.per); if(!isNaN(p)&&p<=7) return true; return i.fee%100000===0||i.fee>=1000000; };
const rrn=(b,g)=>{ if(!b) return ''; const y=+b.slice(0,4); const c=y<2000?(g==='MALE'?'1':'2'):(g==='MALE'?'3':'4'); return b.slice(2,4)+b.slice(5,7)+b.slice(8,10)+'-'+c; };
const SYS=/TA\s*예정|첫인사를 보냈|보험 연결을 요청|^\s*$/; const NEG=/전화연결\s*X|부재|수신거부|전원off|차단|거부|잘못|캔슬|관심없|상담미희망|상담종료|pass/i; const CUST=/계약고객|기존고객|가입완료|계약완료/; const POS=/설계안|레포트|통화성공|호의|안내|이해도|다시 연락|재연락/;
function hist(raw){ const m=raw.filter(x=>!SYS.test(x[3])); if(!m.length) return {has:false,notes:[]}; const notes=[]; const d=s=>s.slice(2,10);
 const neg=m.filter(x=>NEG.test(x[3])||NEG.test(x[1])); if(neg.length) notes.push(`⛔ 거절·연락불가 ${neg.length}회 (최근 ${d(neg[0][0])}: ${neg[0][3].replace(/\s+/g,' ').slice(0,40)})`);
 const cu=m.find(x=>CUST.test(x[3])); if(cu) notes.push(`⚠️ 기존·계약고객 (${d(cu[0])}: ${cu[3].replace(/\s+/g,' ').slice(0,30)})`);
 const po=m.filter(x=>POS.test(x[3])&&!NEG.test(x[3])).slice(0,2); for(const x of po) notes.push(`📋 ${d(x[0])} ${x[3].replace(/\s+/g,' ').slice(0,70)}`);
 return {has:true,notes:notes.slice(0,3)}; }
function run(o){
 const a=age(o.b), P=proper(a); const live=o.ins.filter(i=>i.st==='정상'); const base=live.filter(i=>i.self);
 const fam=live.filter(i=>!i.self&&!isCar(i.nm)&&!isEtc(i.nm)&&i.fee>0&&i.ps==='정상-납입중');
 const guar=base.filter(i=>i.ps==='정상-납입중'&&i.cyc==='02'&&i.fee>0&&!isCar(i.nm)&&!isEtc(i.nm)&&!isSave(i.nm));
 const total=guar.reduce((s,i)=>s+i.fee,0), ratio=total/P; const mis=guar.filter(wholeMis);
 const renFull=guar.filter(i=>i.ren==='RENEWAL_INSURANCE'); const renFee=guar.reduce((s,i)=>s+(i.ren==='RENEWAL_INSURANCE'?i.fee:i.ren==='RENEWAL_INSURANCE_COVER'?i.fee*0.5:0),0), renShare=total?renFee/total:0;
 const sils=base.filter(isSil).filter(i=>i.s), silG=sils.map(i=>silGen(i.s)), oldSil=silG.some(g=>g<=2);
 let waste=ratio>=1.7?30:ratio>=1.3?25:ratio>=0.9?15:5; if(ratio>=0.9) waste+=renShare>=0.5?15:(renShare>=0.2||oldSil)?10:renShare>0?5:0;
 const cov={},mx={},fl=new Set(); let oldest=null;
 for(const i of base){ if(isCar(i.nm)||isEtc(i.nm)||isSave(i.nm)) continue; for(const [k,v] of Object.entries(i.cv)){cov[k]=(cov[k]||0)+v;mx[k]=Math.max(mx[k]||0,v);} for(const c of i.fl) fl.add(c); if(!isDrv(i.nm)&&!isSil(i)&&i.s&&i.fee>0&&(!oldest||i.s<oldest.s)) oldest=i; }
 const g=k=>cov[k]||0; const gaps=[];
 if(g('일반암진단')<5000||(mx['일반암진단']||0)<5000) gaps.push('암'); if(g('뇌혈관질환진단')<3000||g('허혈성심장질환진단')<3000) gaps.push('뇌·심장'); if(!fl.has('S')) gaps.push('수술비'); if(!fl.has('T')) gaps.push('고액치료비'); if(a>=40&&!fl.has('C')) gaps.push('간병');
 const core=gaps.filter(x=>x!=='간병').length; const wm=mis.length?(20+(mis.length>=2?10:0)):0; const gapA=gaps.length*6, bonus=(waste>=25&&gapA>=18)?15:0; const A=waste+gapA+bonus+wm;
 const nonSil=base.filter(i=>!isCar(i.nm)&&!isEtc(i.nm)&&!isSave(i.nm)&&!isSil(i)&&!isDrv(i.nm)); let B=0;
 if(ratio<0.9&&core>=2){B=gaps.length*12; if(nonSil.length===0)B+=15; else if(oldSil||(oldest&&oldest.s<'2011-01-01'))B+=10; B+=wm;}
 const gp=guar.reduce((s,i)=>s+i.paid,0), gr=guar.reduce((s,i)=>s+i.rem,0), remq=(gp+gr)?Math.round(gr/(gp+gr)*100):null; const rembo=remq===null?0:remq>=90?10:remq>=70?7:remq>=50?4:remq>=30?2:0;
 const rawS=Math.max(A,B), track=B>A?'보강형':(A>=35?'조정형':'양호'), fin=Math.min(100,Math.round((rawS+rembo)*mult(a)));
 const tags=[]; if(core>=2)tags.push('보장강화필요'); if(mis.length)tags.push('종신저축오인'); if(oldSil)tags.push('실손'+Math.min(...silG)+'세대'); if(renShare>=0.5&&ratio>=0.9)tags.push('갱신과다'); if(fam.length)tags.push('자녀보험'+fam.length+'건');
 const T=man(total),pct=Math.round(ratio*100),Pm=P/10000; const top=[...guar].sort((x,y)=>y.fee-x.fee)[0]; const oS=sils.filter(i=>silGen(i.s)<=2).sort((x,y)=>x.s<y.s?-1:1)[0]; const K=[];
 if(mis.length){const w=[...mis].sort((x,y)=>y.fee-x.fee)[0]; K.push(`💰 ${co(w.co)} ${nm(w.nm).slice(0,16)} 월 ${w.fee.toLocaleString()}원·${w.per}년납${mis.length>1?' 외 '+(mis.length-1)+'건':''} — 저축으로 알고 계시면 꼭 확인 (종신, 만기환급 ✕)`);}
 if(track==='조정형'){ if(pct>=130&&gaps.length>=3) K.push(`📉 또래 적정 ${Pm}만 vs 월 ${T}만 (${pct}%) — 그런데 ${gaps.slice(0,3).join('·')} 대비는 비어 있음 → 보장 100%로 올려도 지금보다 보험료 줄어듦`); else if(pct>=130) K.push(`📉 또래 적정 ${Pm}만 vs 월 ${T}만 (${pct}%)${top?` — ${co(top.co)} ${nm(top.nm).slice(0,14)} 하나가 ${man(top.fee)}만`:''}. 어디서 새는지 10분이면 보임`); else if(gaps.length>=2) K.push(`📉 월 ${T}만 내는데 ${gaps.slice(0,3).join('·')} 대비 없음 — 같은 돈으로 보장 2배 가능`); const rf=renFull.reduce((s,i)=>s+i.fee,0); if(rf>0&&total&&rf/total>=0.3) K.push(`🔁 보장성의 ${Math.round(rf/total*100)}%(월 ${man(rf)}만)가 갱신형 — 60대엔 지금의 2배↑. 비갱신 전환 시점 확인`);}
 else if(track==='보강형'){ const hasSil=sils.some(i=>i.fee>0),hasDrv=guar.some(i=>isDrv(i.nm)); if(nonSil.filter(i=>i.fee>0&&i.ps==='정상-납입중').length===0) K.push(`🕳 보장성 보험 사실상 없음 (${[hasSil?'실손':'',hasDrv?'운전자':''].filter(Boolean).join('·')||'0건'}${hasSil||hasDrv?'만':''}) — 암·뇌·심장·수술 대비 0. ${a<40?'지금이 가장 싸게 완성하는 시기':'더 늦으면 가입 자체가 어려워지는 구간'}`); else K.push(`🕳 월 ${T}만 내는데 ${gaps.join('·')} 대비 없음${oldest?` — ${oldest.s.slice(0,4)}년 ${co(oldest.co)} 기준이라 지금 기준 보장의 1/5 수준`:''}`);}
 else K.push('✅ 구성 양호 — 운전자 최신 여부·실손 세대만 확인');
 if(oS) K.push(`🏥 실손 ${oS.s.slice(0,4)}년 ${silGen(oS.s)}세대${oS.fee?` 월 ${oS.fee.toLocaleString()}원`:''} — 매년 인상 구조. 5세대 전환 시 절반 이하`);
 if(fam.length) K.push(`👨‍👩‍👧 자녀보험 ${fam.length}건 월 ${man(fam.reduce((s,i)=>s+i.fee,0))}만 별도 (본인 보장 분석 제외)`);
 const dtag=i=>{ if(!i.self) return '자녀보험·분석제외'; if(isCar(i.nm)||isEtc(i.nm)) return '분석제외'; if(isSave(i.nm)) return '저축·연금'; if(i.ps==='정상-납입종료'||(i.fee===0)) return '납입완료·유지';
  if(isWhole(i.nm)) return wholeMis(i)?'저축으로 오인 가입':'사망보장·상속세 재원'; if(isSil(i)){const gn=silGen(i.s||'2000'); return '실손 '+gn+'세대'+(gn<=2?'·갱신 인상':gn<=3?'·전환 검토':'·유지');}
  if(isDrv(i.nm)) return (i.s||'')>='2024'?'운전자 최신·유지':'운전자 구형·교체'; if(isDent(i.nm)) return i.ren==='RENEWAL_INSURANCE'?'치아·갱신형':'치아';
  const c=i.cv, strong=(c['일반암진단']||0)>=3000&&(c['뇌혈관질환진단']||0)>=2000&&(c['허혈성심장질환진단']||0)>=2000&&i.fl.includes('S'); const big=i.fee>=P*0.5; const old=(i.s||'')<'2016';
  if(i.ren==='RENEWAL_INSURANCE') return '갱신형 구성'+(strong?'':'·보장 빈약'); if(big&&!strong) return '보험료 과다 + 보장 빈약'; if(big&&strong) return '보험료 과다 + 보장은 충분'; if(strong) return '보장 충분·유지'; return (old?'구형·':'')+'보장 빈약'; };
 const rank=i=>isSave(i.nm)?3:isWhole(i.nm)?2:(isCar(i.nm)||isEtc(i.nm)||isDrv(i.nm)||isDent(i.nm))?4:isSil(i)?0:1;
 const ins=live.map(i=>[co(i.co).slice(0,5),nm(i.nm).slice(0,26),i.fee,i.s||'',i.per||'',i.ren==='RENEWAL_INSURANCE'?'갱신':i.ren==='RENEWAL_INSURANCE_COVER'?'특약갱신':'',dtag(i),i.paid||0,i.rem||0,i.ctr,i.who,rank(i),i.e,i.ea,i.cyc==='02'?'월납':i.cyc==='01'?'일시납':i.cyc==='03'?'연납':(i.cyc||''),i.pn,i.pe+'/'+i.pa,i.mc,i.cm,i.ren||'',i.ps||'']).sort((x,y)=>x[11]-y[11]||(x[3]<y[3]?-1:x[3]>y[3]?1:0)||y[2]-x[2]);
 const own=ins.filter(x=>!x[6].startsWith('자녀')&&x[6]!=='분석제외'); const paid=own.reduce((s,x)=>s+x[7],0), tot=own.reduce((s,x)=>s+x[7]+x[8],0);
 const keep=[...new Set(guar.filter(i=>isDrv(i.nm)&&i.s>='2024').map(i=>co(i.co)+' 운전자'))], conv=[...new Set(sils.filter(i=>silGen(i.s)<=3&&i.fee>0).map(i=>co(i.co)+' 실손'+silGen(i.s)+'세대'))], rebuild=guar.filter(i=>!isSil(i)&&!(isDrv(i.nm)&&i.s>='2024')&&(i.ren==='RENEWAL_INSURANCE'||isWhole(i.nm)||(i.s&&i.s<'2016'))).map(i=>co(i.co)+' '+nm(i.nm).slice(0,12)+'('+man(i.fee)+'만)').slice(0,5);
 const H=hist(o.raw||[]);
 return {name:o.name,id:o.id,asg:o.asg||'',phone:o.phone,rrn:rrn(o.b,o.g),req:o.req,hist:H.notes,hasLog:H.has,raw:o.raw||[],ct:o.ct||[],age:a,g:o.g==='MALE'?'M':'F',track,fin,remq,rembo,total,ratio:+ratio.toFixed(2),paid,tot,tags,kp:K.slice(0,3),keep,conv,rebuild,ins}; }
const out=[]; for(let i=0;i<SEL.length;i+=6){ const b=await Promise.all(SEL.slice(i,i+6).map(fetchC)); for(const o of b){ out.push(o.ins.length?run(o):{name:o.name,id:o.id,asg:o.asg||'',phone:o.phone,rrn:rrn(o.b,o.g),req:o.req,hist:hist(o.raw||[]).notes,hasLog:hist(o.raw||[]).has,raw:o.raw||[],ct:o.ct||[],age:age(o.b||'2000-01-01'),na:1}); } }
const s=JSON.stringify(out); localStorage.setItem('__ta_out2',s); ({n:out.length,len:s.length,dist:out.reduce((d,r)=>{const k=r.na?'NA':r.fin>=65?'🔥':r.fin>=50?'🟢':r.fin>=35?'🟡':'⚪';d[k]=(d[k]||0)+1;return d},{})})
```
**4-B 출력 ins 행 인덱스**: 0 보험사 · 1 상품 · 2 월보험료 · 3 가입일 · 4 납입년 · 5 갱신표기 · 6 진단태그 · 7 기납입 · 8 잔여 · 9 계약자 · 10 피보험자 · 11 정렬rank(실손0·보장성1·종신2·연금저축3·기타4) · 12 보장만기일 · 13 만기연령 · 14 납입주기 · 15 증권번호 · 16 납입종료 `YYYY-MM/연령` · 17 마스킹 `계약자/피보험자` · 18 담보 `소분류=만원;…`(최댓값·절사) · 19 renewalContract 원값 · 20 paymentStatus. 행은 rank → 가입일↑ → 보험료↓ 정렬 완료 상태.

### 4-C 빌드 `build.py` (입력 `data.json`, 출력 `ta_board.html` + `crm/`)
```python
# build.py v1.0(확립) — 입력 data.json(4-B 출력) → ta_board.html + crm/*.html (CRM 전체레포트) + 상담내용입력 모듈
# 사용: python3 build.py "선별 조건 문구" "마이데이터 기준일" "TA_YYMMDD"
import json, html, re, sys, os, glob
e=html.escape
SUB=sys.argv[1] if len(sys.argv)>1 else '선별 조건 미기재'; MD=sys.argv[2] if len(sys.argv)>2 else ''; TITLE=sys.argv[3] if len(sys.argv)>3 else '1차 TA 킬포인트 보드'
D=json.load(open('data.json'))
SK=(glob.glob('/root/.claude/skills/**/report-skill',recursive=True)+glob.glob(os.path.expanduser('~/.claude/skills/**/report-skill'),recursive=True))[0]
sys.path.insert(0,SK+'/lib'); import crm_lib; crm_lib.RESIDUAL=[]
os.makedirs('crm',exist_ok=True)
import shutil; shutil.copy(SK+'/crm_report/toss_logo.png','crm/toss_logo.png')
def grade(f): return '🔥' if f >= 65 else '🟢' if f >= 50 else '🟡' if f >= 35 else '⚪'
def gcls(f): return 'g4' if f >= 65 else 'g3' if f >= 50 else 'g2' if f >= 35 else 'g1'
TRK = {'조정형': ('🔧', 'trk-a'), '보강형': ('➕', 'trk-b'), '양호': ('✅', 'trk-c')}
def ddir(t):
    if '저축으로 오인' in t: return '리모델링 고려 (저축 목적 재확인)'
    if '과다' in t and '빈약' in t: return '리모델링 고려'
    if '과다' in t and '충분' in t: return '유지 · 보험료만 점검'
    if t.startswith('갱신형'): return '비갱신 전환 고려'
    if '보장 빈약' in t: return '보강 또는 통합 리모델링'
    if '보장 충분' in t: return '유지'
    if t.startswith('실손'):
        return '5세대 전환' if '갱신 인상' in t else '전환 검토' if '전환 검토' in t else '유지'
    if t.startswith('운전자'): return '유지' if '유지' in t else '최신 상품으로 교체'
    if t.startswith('치아'): return '필요성 확인 후 유지/해지' if '갱신' in t else '유지'
    if t.startswith('납입완료'): return '유지'
    if t.startswith('저축'): return '유지 (분석 제외)'
    if t.startswith('자녀'): return '별도 점검'
    if t.startswith('사망보장'): return '유지 · 상속세 재원 필요성 확인'
    return '확인'
def dcls(t):
    if '저축으로 오인' in t: return 'dt-w'
    if '과다' in t and '빈약' in t: return 'dt-r'
    if '갱신' in t and '유지' not in t: return 'dt-o'
    if '빈약' in t: return 'dt-o'
    if '유지' in t or '충분' in t: return 'dt-g'
    return 'dt-m'
def mult(a): return 0.85 if a<30 else 1.0 if a<50 else 0.7 if a<60 else 0.5
def whole_tag(fee, per):
    try: p=int(per)
    except: p=None
    if p is not None and p<=7: return '저축으로 오인 가입'
    if fee>0 and (fee%100000==0 or fee>=1000000): return '저축으로 오인 가입'
    return '사망보장·상속세 재원'

KEYS=['질병입원의료비','질병외래의료비','질병처방조제료','상해입원의료비','상해외래의료비','상해처방조제료','일반암진단','소액암(유사암)진단','고액암진단','뇌혈관질환진단','뇌졸중질환진단','뇌출혈질환진단','허혈성심장질환진단','급성심근경색진단','질병수술','상해수술','암수술','뇌혈관질환수술','허혈성심장질환수술','질병입원','상해입원','질병사망','상해사망','질병80%이상후유장해','질병80%미만후유장해','상해80%이상후유장해','상해80%미만후유장해','골절진단','화상진단','가족생활배상책임담보','일상생활배상책임담보','교통사고처리지원금','벌금(대물)','벌금(대인)','변호사선임비용','자동차부상치료비','화재벌금','보존치료','보철치료','(가족)일상생활배상책임','상해1-5종수술','질병1-5종수술']
ALIAS={'(가족)일상생활배상책임':'가족생활배상책임담보','상해1-5종수술':'상해수술','질병1-5종수술':'질병수술'}
def parse_cov(s):
    d={}
    for t in (s.split(';') if s else []):
        k,v=t.split('='); k=ALIAS.get(k,k); d[k]=max(d.get(k,0),int(v))
    return d
def manwon(v): return f'{int(v):,} 만원' if v else ''
LIMIT=lambda age:100000 if age<30 else 150000 if age<40 else 180000 if age<50 else 250000 if age<60 else 400000
def crm_full(name,cid,gi,L,age):
    N=len(L); P={'NAMES':[],'보험사명':[],'계약일':[],'갱신':[],'계약자':[],'증권번호':[],'납입':[],'납입기간':[],'만기':[],'종료':[],'월납':[],'기납':[],'잔여':[],'총':[]}
    rows={k:[0]*(N+1) for k in KEYS if k not in ALIAS}
    pol=[];monthly=0;sub={'보장성':[0,0],'기타':[0,0],'저축':[0,0]}
    for i,x in enumerate(L):
        c=x['cov']; P['NAMES'].append(e(x['nm'])); P['보험사명'].append(e(x['co'])); P['계약일'].append(x['dt'] or '-')
        P['갱신'].append({'RENEWAL_INSURANCE':'<span class="b-orange">갱신형 보험</span>','RENEWAL_INSURANCE_COVER':'<span class="b-orange">갱신형 특약</span>'}.get(x['rc'],'비갱신형'))
        P['계약자'].append(e((c[4] or '-')+'/'+(c[5] or '-').replace('본*','본인'))); P['증권번호'].append(e(c[0] or '-'))
        act=x['ps']=='정상-납입중' and x['cyc']=='월납' and x['fee']>0
        P['납입'].append('<span class="b-blue">납입중</span>' if x['ps']=='정상-납입중' else '<span class="b-gray">납입종료</span>')
        P['납입기간'].append(f"{x['cyc'] or '-'} / {x['per'] or '0'}년"); P['만기'].append(('종신' if x['ce']=='9999-12-31' else (x['ce'] or '-'))+f" / {x['ea'] if x['ea'] is not None else '-'} 세")
        P['종료'].append(f"{c[1] or '-'} / {c[2] or '-'}"); P['월납'].append(f"{x['fee']:,}")
        tot=x['paid']+x['rem']; P['기납'].append(f"{x['paid']:,} 원"); P['잔여'].append(f"{x['rem']:,} 원"); P['총'].append(f"{tot:,} 원")
        car=any(k in x['nm'] for k in ('자동차','이륜','휴대폰'))
        if act and not car: monthly+=x['fee']; pol.append((x['paid'],x['rem'],tot))
        kind='저축' if x['rk']==3 else '기타' if (x['rk']==4 and any(k in x['nm'] for k in ('자동차','이륜','화재','휴대폰','펫','보증','주택','재물','여행'))) else '보장성'
        if not car: sub[kind][0]+=1; sub[kind][1]+=x['fee'] if act else 0
        for k,v in parse_cov(c[7]).items():
            if k in rows: rows[k][i+1]+=v; rows[k][0]+=v
    R={k:[manwon(v) for v in vs] for k,vs in rows.items()}
    g=lambda *ks:sum(rows[k][0] for k in ks)
    comp=20*sum([g('일반암진단','고액암진단')>=3000, max(rows['뇌혈관질환진단'][0],rows['뇌졸중질환진단'][0],rows['뇌출혈질환진단'][0])>=2000, max(rows['허혈성심장질환진단'][0],rows['급성심근경색진단'][0])>=2000, g('질병수술','상해수술')>0, rows['질병입원의료비'][0]>0])
    out=f'/home/claude/ta/crm/{cid}_{gi}.html'
    crm_lib.build_full(dict(name=name,n=N,monthly=monthly,sub={k:tuple(v) for k,v in sub.items()},paid=sum(a for a,b,c in pol),remain=sum(b for a,b,c in pol),total=sum(c for a,b,c in pol),level=crm_lib.spend_level(monthly,LIMIT(age)),completion=comp,products=P,rows=R,out=out,comment=f'// {N}열 — TA 보드 자동생성'))
    return out

ETC=('치아','운전자','화재','자동차','이륜','여행','휴대폰','펫','주택','재물','보증','골프')
def is_self(who,name):
    if not who or re.search(r'[0-9]|운전|한정|누구나|특별시|광역시|[가-힣]+도 |[가-힣]+시 |공제|회사|조합|법인|단체|학교|\(주\)',who): return True
    for w in who.split(','):
        w=w.strip()
        if w=='본인' or w==name: return True
        if len(w)>=2 and name and re.fullmatch(re.escape(w[0])+r'\*+'+re.escape(w[-1]),w) and name[0]==w[0] and name[-1]==w[-1]: return True
    return False
def red(t): return any(k in ddir(t) for k in ('리모델링','전환','교체','보강'))
def row_html(co,nm,fee,dt,per,ren,dtag,paid,rem,ctr,who,ea):
    feet=f'{fee:,}원' if fee else '-'
    if '일시납' in nm or (per=='0' and fee>1000000): feet+=' (일시납)'
    tag=f'<br><span class="dt {dcls(dtag)}">{e(dtag)}</span> <span class="dd {"dd-r" if red(dtag) else ""}">→ {e(ddir(dtag))}</span>' if dtag else ''
    return f'<tr><td>{e(co)}</td><td class="cw">{e(ctr)}<br><span class="mut">{e(who)}</span></td><td class="nm">{e(nm)}{tag}</td><td class="n">{feet}</td><td class="n">{e(dt) or "-"}</td><td class="n">{e(per)+"년" if per and per!="0" else "-"}</td><td>{e(ren)}</td><td class="n">{paid:,}</td><td class="n">{rem:,}</td></tr>'
TH='<thead><tr><th>보험사</th><th>계약자<br>피보험자</th><th>상품 · 진단</th><th class="n">월 보험료</th><th class="n">가입일</th><th class="n">납입</th><th>갱신</th><th class="n">기납입</th><th class="n">잔여</th></tr></thead>'
def build_ins(r):
    name=r['name']; rows=[]
    for x in r['ins']:
        co,nm,fee,st,per,ren,dtag,paid,rem,ctr,who,rk,ce,ea,cyc,pn,pepa,mc,cm,rc,ps=x[:21]
        if dtag.startswith('자녀') and is_self(who,name): dtag='분석제외'
        pe,pa=(pepa.split('/')+[''])[:2]; m1,m2=(mc.split('/')+[''])[:2]
        rows.append(dict(co=co,nm=nm.strip(),fee=fee,dt=st,per=per,ren=ren,dtag=dtag,paid=paid,rem=rem,ctr=ctr,who=who,ce=ce,ea=ea,cyc=cyc,ps=ps,self=is_self(who,name),rk=rk,rc=rc,cov=[pn,pe,pa,0,m1,m2,st,cm]))
    mine=[x for x in rows if x['self']]; fam=[x for x in rows if not x['self']]
    def tbl(title,L): return f'<div class="tt">{title} <span class="mut">{len(L)}건</span></div><div class="tw"><table>{TH}<tbody>{"".join(row_html(x["co"],x["nm"],x["fee"],x["dt"],x["per"],x["ren"],x["dtag"],x["paid"],x["rem"],x["ctr"],x["who"],x["ea"]) for x in L)}</tbody></table></div>'
    groups={}
    for x in fam: groups.setdefault(x['who'],[]).append(x)
    split=bool(mine and groups)
    def tbl2(cls,title,L): return f'<div class="tt {cls}"><mark class="{cls}">{title}</mark> <span class="mut">{len(L)}건</span></div>'+tbl('',L).split('</div>',1)[1] if split else tbl(title,L)
    h=tbl2('hl-me','본인보험',mine) if mine else ''
    for who,L in groups.items(): h+=tbl2('hl-fam',f'가족보험 · 피보험자 {e(who)}',L)
    G=([('본인보험',mine)] if mine else [])+[(f'가족보험 · 피보험자 {who}',L) for who,L in groups.items()]
    files=[(t,crm_full(name,r['id'],gi,L,r['age'])) for gi,(t,L) in enumerate(G)]
    return rows,h,files
def ct_html(r):
    ct=r.get('ct',[])
    if not ct: return '<b class="ctx">체결보험 X</b>'
    return f'<button type="button" class="lgbtn ctbtn" data-n="{e(r["name"])}">체결보험 O ({len(ct)}건) ▸</button>'
rows=sorted([r for r in D if not r.get('na')],key=lambda x:((x.get('req') or [''])[0],x.get('asg','')))+[r for r in D if r.get('na')]
cards=[];RPT={};CT={};RAW={};FILES={'crm/toss_logo.png':'crm/toss_logo.png'}
for r in rows:
    phone=r.get('phone',''); rq=r.get('req') or ['','','']; RAW[r['name']]=r.get('raw',[]); CT[r['name']]=r.get('ct',[])
    lg=f'<button type="button" class="lgbtn" data-n="{e(r["name"])}">상담이력 O ({len(r.get("raw",[]))}건) ▸</button>' if r.get('hasLog') else '<b>상담이력 X</b>'
    hist=''.join(f'<div class="hist {"hist-r" if h[:1] in "⛔⚠" else ""}">{e(h)}</div>' for h in r.get('hist',[]))
    if r.get('na'):
        cards.append(f'<article class="card g1" data-g="NA" data-t="NA" data-tags="" data-q="{e(r["name"])} {phone}"><div class="stripe"></div><div class="body"><div class="head"><div><div class="who"><span class="cpn" data-n="{e(r["name"])}" data-r="{e(r.get("rrn",""))}">{e(r["name"])}</span> <span class="ph">{phone}</span> <span class="rrn">{e(r.get("rrn",""))}</span></div><div class="meta">{r.get("age","")}세 · 신청 {e(rq[0])} · 배정 {e(r.get("asg",""))} · {e(rq[1])} · <b>{e(rq[2])}</b></div>{hist}<div class="logs">{lg}</div><div class="logs nt"><button type="button" class="nbtn">상담내용입력</button> <span class="ntb"></span></div></div><div class="score"><span class="pill trk-c">❓ 데이터없음</span></div></div><ul class="kps"><li>마이데이터 미연동(수기 고객) — 보험 현황 직접 확인 필요</li></ul><div class="logs ctl">{ct_html(r)}</div></div></article>'); continue
    ico,tc=TRK[r['track']]; sex='남' if r['g']=='M' else '여'
    kps2=''.join(f'<li>{e(k)}</li>' for k in r['kp'][:2])
    dirs=[]
    if r['keep']: dirs.append(f'<span class="d d-k">유지</span>{e(" · ".join(r["keep"]))}')
    if r['conv']: dirs.append(f'<span class="d d-c">전환</span>{e(" · ".join(r["conv"]))}')
    if r['rebuild']: dirs.append(f'<span class="d d-r">재구성</span>{e(" · ".join(r["rebuild"]))}')
    if r['track']=='보강형' and not r['rebuild']: dirs.append('<span class="d d-r">신규</span>비갱신 보장성 1건 구성')
    dirh=''.join(f'<div class="dir">{d}</div>' for d in dirs) or '<div class="dir"><span class="d d-k">유지</span>현 구성 유지</div>'
    irows,ih,files=build_ins(r)
    RPT[r['name']]={'id':r['id'],'g':[[t,os.path.relpath(f)] for t,f in files]}  # 상대경로 필수 (절대경로면 iframe 빈 화면)
    FILES.update({os.path.relpath(f):os.path.relpath(f) for t,f in files})
    lv=f'<details><summary>보유 보험 {len(irows)}건 (정상 계약 전체) <button type="button" class="rbtn" data-n="{e(r["name"])}">레포트보기</button></summary>{ih}</details>' if irows else '<div class="mut" style="margin-top:8px;font-size:12.5px">보유 보험 없음</div>'
    pct=f"{round(r['ratio']*100)}%" if r['total'] else '0%'
    cards.append(f'''<article class="card {gcls(r['fin'])}" data-g="{grade(r['fin'])}" data-t="{r['track']}" data-tags="{e(' '.join(r['tags']))}" data-q="{e(r['name'])} {phone}">
<div class="stripe"></div><div class="body">
<div class="head"><div><div class="who"><span class="cpn" title="클릭: 오늘날짜_고객명_생년월일 복사" data-n="{e(r['name'])}" data-r="{r['rrn']}">{e(r['name'])}</span> <span class="ph" title="클릭: 숫자만 복사">{phone}</span> <span class="rrn">{r['rrn']}</span></div><div class="meta">{r['age']}세 · {sex} · 보장성 월 {r['total']:,}원 ({pct})</div><div class="meta">신청 {e(rq[0])} · 배정 {e(r.get('asg',''))} · {e(rq[1])} · <b>{e(rq[2])}</b></div>{hist}<div class="logs">{lg}</div><div class="logs nt"><button type="button" class="nbtn">상담내용입력</button> <span class="ntb"></span></div></div>
<div class="score"><span class="pill {tc}">{ico} {r['track']}</span><b>{r['fin']}</b><span class="gr">{grade(r['fin'])}</span></div></div>
<div class="paid">기납입 {r['paid']:,}원 / 총납입 {r['tot']:,}원 (납입비율 {round(r['paid']/r['tot']*100) if r['tot'] else 0}%) · 보장성 잔여 {r['remq'] if r['remq'] is not None else '-'}%{' <span class="bo">+'+str(r['rembo'])+'</span>' if r['rembo'] else ''}</div>
<ul class="kps">{kps2}</ul>
<div class="dirs">{dirh}</div>
{lv}
<div class="logs ctl">{ct_html(r)}</div>
</div></article>''')
cnt={g:sum(1 for r in D if not r.get('na') and grade(r['fin'])==g) for g in ['🔥','🟢','🟡','⚪']}
NOTES_CSS='''
.nbtn{font:inherit;font-size:11.5px;padding:2px 9px;border-radius:999px;border:1px solid var(--hot);background:var(--card);color:var(--hot);cursor:pointer;font-weight:700}
.nbtn.has{background:var(--hot);color:#fff}
.ntb{font-size:12px;color:var(--mut);margin-left:6px}
.nt-tags{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 12px}
.nt-tag{font:inherit;font-size:13.5px;font-weight:700;padding:8px 16px;border-radius:999px;border:1.5px solid var(--line);background:var(--card);color:var(--fg);cursor:pointer}
.nt-tag.on{background:var(--fg);color:var(--bg);border-color:var(--fg)}
.nt-tag[data-t="차단/거절"].on{background:var(--hot);border-color:var(--hot);color:#fff}
.nt-tag[data-t="다음상담"].on{background:var(--ok);border-color:var(--ok);color:#fff}
.nt-memo{width:100%;min-height:150px;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:var(--card);color:var(--fg);font:inherit;font-size:14px;line-height:1.5;resize:vertical}
.nt-foot{display:flex;gap:8px;justify-content:flex-end;margin-top:12px;flex-wrap:wrap}
.nt-b{font:inherit;font-size:13.5px;font-weight:700;padding:9px 18px;border-radius:10px;border:1px solid var(--line);background:var(--card);color:var(--fg);cursor:pointer}
.nt-b.pri{background:var(--acc);border-color:var(--acc);color:#fff}
.nt-meta{font-size:12px;color:var(--mut);margin-top:4px}
.nt-list{width:100%;border-collapse:collapse;font-size:13px;margin-top:6px;table-layout:fixed}
.nt-list th,.nt-list td{padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top;white-space:normal}
.nt-list th{color:var(--mut);font-weight:500;text-align:left}
.nt-list tbody tr{cursor:pointer}.nt-list tbody tr:hover{background:var(--chip)}
.nt-list td.nt-d{white-space:nowrap;font-family:var(--mono);font-size:12px;color:var(--mut)}
.nt-list td.nt-m{white-space:pre-wrap}
.nt-pill{display:inline-block;font-size:11.5px;font-weight:700;padding:2px 8px;border-radius:999px;background:var(--chip);margin:0 4px 3px 0}
.nt-pill.r{background:var(--wtag);color:var(--wfg)}.nt-pill.g{background:var(--htag);color:var(--hfg)}
.nt-note{font-size:11.5px;color:var(--mut);margin-right:auto;align-self:center}
.nt-b.del{color:var(--hot);border-color:var(--hot)}
.nt-confirm{display:flex;align-items:center;gap:10px;justify-content:flex-end;margin-top:10px;padding:10px 12px;border:1px solid var(--hot);border-radius:10px;background:var(--wtag);color:var(--wfg);font-size:13.5px}.nt-confirm b{margin-right:auto}
.nt-list td.nt-c{text-align:center;padding-left:6px;padding-right:6px}.nt-ck,.nt-ckall{width:17px;height:17px;cursor:pointer;vertical-align:middle}
'''
NOTES_JS=r'''
<script>
(function(){
var TAGS=['다음상담','다시TA','부재','차단/거절'];
var M=document.getElementById('modal'),MB=document.getElementById('mbox'),MT=document.getElementById('mtitle'),MD=document.getElementById('mbody');
var DB=null,DBREADY=false,CACHE={},LS='ta_notes_v1',LOCAL={};
function esc(t){return String(t==null?'':t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;')}
function fmt(iso){var d=new Date(iso);if(isNaN(d))return '';var p=function(n){return ('0'+n).slice(-2)};return String(d.getFullYear()).slice(2)+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())}
function hsh(t){var h=0;for(var i=0;i<t.length;i++){h=(h*31+t.charCodeAt(i))>>>0}return 'n'+h.toString(36)}
function keyOf(card){var ph=(card.dataset.q||'').replace(/\D/g,'');return ph?'p'+ph:hsh(nameOf(card))}   // DB doc id = ASCII만 허용(한글 ❌)
function nameOf(card){return ((card.querySelector('.cpn')||{}).dataset||{}).n||''}
function phoneOf(card){return (card.dataset.q||'').replace(/\D/g,'')}
function lsAll(){try{return JSON.parse(localStorage.getItem(LS)||'{}')}catch(e){return {}}}
function lsPut(k,doc){try{var a=lsAll();a[k]=doc;localStorage.setItem(LS,JSON.stringify(a))}catch(e){}}
function pillCls(t){return t==='차단/거절'?'r':t==='다음상담'?'g':''}
function badge(card){var k=keyOf(card),d=CACHE[k],es=(d&&d.entries)||[];var b=card.querySelector('.nbtn'),sp=card.querySelector('.ntb');if(!b)return;b.classList.toggle('has',es.length>0);if(!es.length){sp.textContent='';return}var last=es[es.length-1];sp.textContent=es.length+'건 · '+fmt(last.at)+(last.tags&&last.tags.length?' · '+last.tags.join('/'):'')}
function badgeAll(){document.querySelectorAll('.card').forEach(badge)}
function load(){var a=lsAll();Object.keys(a).forEach(function(k){var nk=/^[\x00-\x7F]+$/.test(k)?k:(function(){var ph=k.split('_').pop().replace(/\D/g,'');return ph?'p'+ph:hsh(k.split('_')[0])})();CACHE[nk]=a[k];LOCAL[nk]=true});badgeAll();
 if(!window.claude||!claude.use)return;
 claude.use('db').then(function(db){if(!db)return;DB=db;var t=setTimeout(function(){},10000);
  db.collection('notes').onSnapshot(function(snap){clearTimeout(t);snap.docs.forEach(function(d){var v=d.data();if(v){CACHE[d.id]=v;delete LOCAL[d.id]}});DBREADY=true;badgeAll()},function(e){clearTimeout(t)});
 }).catch(function(){});}
function syncUp(card){var k=keyOf(card);if(DB&&DBREADY&&LOCAL[k]&&CACHE[k]&&(CACHE[k].entries||[]).length){var d=CACHE[k];d.name=d.name||nameOf(card);d.phone=d.phone||phoneOf(card);delete LOCAL[k];save(card,d).then(function(ok){if(ok)toast('이전 기록 서버 저장됨')})}}
function save(card,doc){var k=keyOf(card);CACHE[k]=doc;lsPut(k,doc);delete LOCAL[k];badge(card);
 if(DB){try{return DB.doc('notes/'+k).set(doc).then(function(){return true},function(e){toast('서버 저장 실패('+(e&&e.code||'')+') — 이 브라우저에만 저장됨');return false})}catch(e){toast('서버 저장 실패('+(e&&e.message||e)+')');return Promise.resolve(false)}}
 return Promise.resolve(false)}
function toast(s){var T=document.querySelector('.toast');if(!T)return;T.textContent=s;T.classList.add('on');clearTimeout(T._t);T._t=setTimeout(function(){T.classList.remove('on')},1800)}
function show(t,h){MT.textContent=t;MD.innerHTML=h;MB.classList.remove('wide');M.hidden=false}
var CUR=null,PEND=null; // {card,name,key}
function entries(){var d=CACHE[CUR.key];return (d&&d.entries)?d.entries.slice():[]}
function editor(entry){ // entry null = new
 var tg=(entry&&entry.tags)||[];
 var h='<div class="nt-tags">'+TAGS.map(function(t){return '<button type="button" class="nt-tag'+(tg.indexOf(t)>=0?' on':'')+'" data-t="'+esc(t)+'">'+esc(t)+'</button>'}).join('')+'</div>'
 +'<textarea class="nt-memo" id="ntMemo" placeholder="메모 입력">'+esc(entry?entry.memo:'')+'</textarea>'
 +(entry?'<div class="nt-meta">등록 '+fmt(entry.at)+(entry.up&&entry.up!==entry.at?' · 수정 '+fmt(entry.up):'')+'</div>':'')
 +'<div class="nt-foot">'+(DB?'':'<span class="nt-note">※ 서버 미연결 — 이 브라우저에만 저장</span>')
 +(entry?'<button type="button" class="nt-b" data-a="back">목록</button><button type="button" class="nt-b pri" data-a="edit" data-id="'+esc(entry.id)+'">수정/닫기</button><button type="button" class="nt-b" data-a="add">추가입력</button>'
        :'<button type="button" class="nt-b pri" data-a="new">입력</button>')+'</div>';
 show(CUR.name+' 상담내용 '+(entry?'수정':'입력'),h);
}
function list(){var es=entries();
 var rows=es.map(function(e,i){return '<tr data-id="'+esc(e.id)+'"><td class="nt-c"><input type="checkbox" class="nt-ck" data-id="'+esc(e.id)+'" aria-label="선택"></td><td class="nt-d">'+(i+1)+'</td><td class="nt-d">'+fmt(e.at)+'</td><td>'+(e.tags||[]).map(function(t){return '<span class="nt-pill '+pillCls(t)+'">'+esc(t)+'</span>'}).join('')+'</td><td class="nt-m">'+esc(e.memo)+'</td></tr>'}).join('');
 var h='<table class="nt-list"><colgroup><col style="width:36px"><col style="width:34px"><col style="width:110px"><col style="width:170px"><col></colgroup><thead><tr><th><input type="checkbox" class="nt-ckall" aria-label="전체선택"></th><th>#</th><th>일시</th><th>상태</th><th>메모</th></tr></thead><tbody>'+rows+'</tbody></table>'
 +'<div class="nt-foot"><button type="button" class="nt-b del" data-a="del">선택 삭제</button><span style="flex:1"></span><button type="button" class="nt-b" data-a="close">닫기</button><button type="button" class="nt-b" data-a="add">추가입력</button></div>';
 show(CUR.name+' 상담내용 '+es.length+'건',h);
}
function openFor(card){CUR={card:card,name:nameOf(card),key:keyOf(card)};var es=entries();if(es.length===0)editor(null);else list();syncUp(card)}
function readForm(){var tags=[].map.call(MD.querySelectorAll('.nt-tag.on'),function(b){return b.dataset.t});var memo=(MD.querySelector('#ntMemo')||{}).value||'';return {tags:tags,memo:memo.trim()}}
function docOf(es){return {name:CUR.name,phone:phoneOf(CUR.card),entries:es,up:new Date().toISOString()}}
document.addEventListener('click',function(ev){
 var b=ev.target.closest('.nbtn');if(b){ev.preventDefault();ev.stopPropagation();openFor(b.closest('.card'));return}
 if(!CUR||M.hidden)return;
 var t=ev.target.closest('.nt-tag');if(t){t.classList.toggle('on');return}
 var a=ev.target.closest('.nt-b');if(a){var act=a.dataset.a,es=entries(),now=new Date().toISOString();
  if(act==='new'){var f=readForm();if(!f.tags.length&&!f.memo){toast('상태 또는 메모를 입력하세요');return}es.push({id:'n'+Date.now(),tags:f.tags,memo:f.memo,at:now,up:now});save(CUR.card,docOf(es)).then(function(){toast('등록됨')});M.hidden=true;return}
  if(act==='edit'){var f=readForm(),id=a.dataset.id;es=es.map(function(e){return e.id===id?{id:e.id,tags:f.tags,memo:f.memo,at:e.at,up:now}:e});save(CUR.card,docOf(es)).then(function(){toast('수정됨')});M.hidden=true;return}
  if(act==='add'){editor(null);return}
  if(act==='back'){if(es.length)list();else M.hidden=true;return}
  if(act==='close'){M.hidden=true;return}
  if(act==='del'){var ids=[].map.call(MD.querySelectorAll('.nt-ck:checked'),function(c){return c.dataset.id});if(!ids.length){toast('삭제할 항목을 선택하세요');return}PEND=ids;var old=MD.querySelector('.nt-confirm');if(old)old.remove();var cf=document.createElement('div');cf.className='nt-confirm';cf.innerHTML='<b>'+ids.length+'건을 삭제할까요?</b><button type="button" class="nt-b del" data-a="delyes">예</button><button type="button" class="nt-b" data-a="delno">아니오</button>';MD.appendChild(cf);cf.scrollIntoView({block:'nearest'});return}
  if(act==='delno'){PEND=null;var c0=MD.querySelector('.nt-confirm');if(c0)c0.remove();return}
  if(act==='delyes'){var ids=PEND||[];PEND=null;if(!ids.length)return;es=es.filter(function(e){return ids.indexOf(e.id)<0});save(CUR.card,docOf(es)).then(function(){toast(ids.length+'건 삭제됨')});if(es.length)list();else M.hidden=true;return}
 }
 if(ev.target.closest('.nt-ckall')){var on=ev.target.checked;MD.querySelectorAll('.nt-ck').forEach(function(c){c.checked=on});return}
 if(ev.target.closest('.nt-ck'))return;
 var r=ev.target.closest('.nt-list tbody tr');if(r){var id=r.dataset.id,e=entries().filter(function(x){return x.id===id})[0];if(e)editor(e);return}
});
load();
})();
</script>
'''
CSS='''
/* layout: sticky filter bar + single column card stream; grade stripe on card edge */
:root{--bg:#f6f7f4;--card:#ffffff;--fg:#1c2120;--mut:#6a716d;--line:#dfe3df;--acc:#2f6f5e;--hot:#c8431f;--ok:#2d8a4e;--warn:#c98a12;--cool:#7a8389;--chip:#eef1ec;--wtag:#fbe9e4;--wfg:#9a2f14;--htag:#e6f1ec;--hfg:#1f5a49;--otag:#fdf1dc;--ofg:#7a4f05;
--display:'IBM Plex Sans KR',system-ui,sans-serif;--mono:'IBM Plex Mono',ui-monospace,monospace}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#151917;--card:#1e2422;--fg:#e8ebe8;--mut:#9aa39e;--line:#2e3633;--acc:#7fc1ad;--hot:#ff7a55;--ok:#6cc98a;--warn:#e6b14a;--cool:#8c959a;--chip:#28302d;--wtag:#4a2218;--wfg:#ffb9a3;--htag:#1f3a31;--hfg:#a9dcc9;--otag:#3d2f12;--ofg:#f0c97a;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#151917;--card:#1e2422;--fg:#e8ebe8;--mut:#9aa39e;--line:#2e3633;--acc:#7fc1ad;--hot:#ff7a55;--ok:#6cc98a;--warn:#e6b14a;--cool:#8c959a;--chip:#28302d;--wtag:#4a2218;--wfg:#ffb9a3;--htag:#1f3a31;--hfg:#a9dcc9;--otag:#3d2f12;--ofg:#f0c97a;color-scheme:dark}
body{background:var(--bg);color:var(--fg);font-family:var(--display);padding-block:0 40px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));line-height:1.5}
body::before{content:"";position:fixed;inset:0 0 auto;height:env(safe-area-inset-top,0px);z-index:10;background:var(--bg)}
.wrap{max-width:900px;margin:0 auto}
header.top{padding:22px 0 10px}
h1{font-size:22px;margin:0;letter-spacing:-.01em;text-wrap:balance}
.sub{color:var(--mut);font-size:13px;margin-top:4px}
.stats{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0 0}
.stat{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:6px 12px;font-size:13px}
.stat b{font-family:var(--mono);font-size:15px;margin-left:4px}
.bar{position:sticky;top:env(safe-area-inset-top,0px);z-index:5;background:var(--bg);padding:10px 0;border-bottom:1px solid var(--line);display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.bar input{flex:1 1 160px;min-width:0;padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--fg);font:inherit;font-size:14px}
.chips{display:flex;gap:6px;flex-wrap:wrap}
.chip{border:1px solid var(--line);background:var(--card);color:var(--fg);border-radius:999px;padding:4px 11px;font-size:13px;cursor:pointer;font-family:inherit}
.chip.on{background:var(--fg);color:var(--bg);border-color:var(--fg)}
.chip:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid var(--acc);outline-offset:2px}
.list{display:flex;flex-direction:column;gap:12px;margin-top:14px}
.card{display:flex;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
.stripe{width:6px;flex:none;background:var(--cool)}
.g4 .stripe{background:var(--hot)}.g3 .stripe{background:var(--ok)}.g2 .stripe{background:var(--warn)}
.body{padding:12px 14px 12px;flex:1;min-width:0}
.head{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}
.who{font-weight:700;font-size:18px}
.ph{font-family:var(--mono);font-weight:500;font-size:15px;color:var(--acc);margin-left:6px;user-select:all}
.meta{color:var(--mut);font-size:12.5px;font-variant-numeric:tabular-nums}
.score{display:flex;align-items:center;gap:8px;flex:none}
.score b{font-family:var(--mono);font-size:26px;line-height:1}
.gr{font-size:18px}
.pill{font-size:12px;padding:3px 9px;border-radius:999px;border:1px solid var(--line);white-space:nowrap}
.trk-a{background:var(--htag);color:var(--hfg);border-color:transparent}.trk-b{background:var(--chip);border-color:transparent}.trk-c{color:var(--mut)}
.tags{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 0}
.tag{font-size:11.5px;padding:2px 8px;border-radius:5px;background:var(--chip);color:var(--mut)}
.tag-hot{background:var(--htag);color:var(--hfg);font-weight:600}.tag-w{background:var(--wtag);color:var(--wfg);font-weight:600}
.lgbtn{background:none;border:0;padding:0;font:inherit;font-size:12.5px;font-weight:700;color:var(--hot);cursor:pointer;text-decoration:underline dotted}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:50;display:flex;align-items:center;justify-content:center;padding:16px}.mbox{background:var(--card);color:var(--fg);border-radius:12px;max-width:820px;width:100%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 10px 40px rgba(0,0,0,.3)}.mhead{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid var(--line)}.mbody{overflow:auto;padding:8px 16px 16px}.mt{font-size:12.5px;table-layout:fixed;width:100%;border-collapse:collapse;border-spacing:0}.mt tr{border-bottom:1px solid var(--line)}.mt th,.mt td{border:0}.mt th,.mt td{padding:6px 10px;font:inherit;color:var(--fg);vertical-align:top;white-space:normal}.mt th{color:var(--mut);font-weight:500}.mt td.c{white-space:pre-wrap}.mt td.d{white-space:nowrap}.mt col.w1{width:150px}.mt col.w2{width:120px}.mt col.w4{width:80px}
.logs{font-size:12px;color:var(--mut);margin-top:4px;line-height:1.5}.logs b{color:var(--fg)}.logs .sep{opacity:.4;margin:0 2px}.lg-r{color:var(--hot)}
.hist{font-size:12.5px;color:var(--acc);margin-top:3px;font-weight:500}.hist-r{color:var(--hot)}
.rrn{font-family:var(--mono);font-size:13px;color:var(--mut);margin-left:6px}.meta b{color:var(--fg);font-weight:600}.bo{color:var(--ok);font-weight:700}
.paid{font-size:12.5px;color:var(--mut);font-variant-numeric:tabular-nums;margin-top:4px;text-align:right}
.kps{margin:8px 0 0;padding:0;list-style:none;display:flex;flex-direction:column;gap:6px}
.kps li{font-size:14px;line-height:1.45}
.kps li:first-child{font-weight:600}
.dirs{display:flex;flex-direction:column;gap:3px;margin-top:10px;font-size:12.5px;color:var(--mut)}
.d{display:inline-block;font-size:11px;font-weight:700;padding:1px 6px;border-radius:4px;margin-right:6px;color:#fff}
.d-k{background:var(--ok)}.d-c{background:var(--warn)}.d-r{background:var(--hot)}
details{margin-top:10px}summary{cursor:pointer;font-size:12.5px;color:var(--acc);font-weight:500}
.tw{overflow-x:auto;margin-top:6px}
table{border-collapse:collapse;width:100%;font-size:12.5px;font-variant-numeric:tabular-nums}
th,td{text-align:left;padding:5px 6px;border-bottom:1px solid var(--line);white-space:nowrap;vertical-align:top}
th{color:var(--mut);font-weight:500}td.n,th.n{text-align:right}
td.nm{white-space:normal;min-width:200px}
tr.fam td{color:var(--mut)}
.dt{display:inline-block;font-size:11px;padding:1px 7px;border-radius:4px;margin-top:2px;background:var(--chip);color:var(--mut)}

.dd{font-size:11.5px;color:var(--mut);font-weight:600}.dd-r{color:var(--hot)}
.dt-r{background:var(--wtag);color:var(--wfg);font-weight:600}.dt-w{background:var(--wtag);color:var(--wfg);font-weight:700}.dt-o{background:var(--otag);color:var(--ofg)}.dt-g{background:var(--htag);color:var(--hfg)}
.note{margin-top:22px;font-size:12.5px;color:var(--mut);border-top:1px solid var(--line);padding-top:12px}
.note b{color:var(--fg)}
.empty{display:none;color:var(--mut);padding:30px 0;text-align:center}
@media (max-width:480px){.head{flex-direction:column}.score{align-self:flex-end}}

.tt{font-size:12.5px;font-weight:700;margin-top:8px}.mut{color:var(--mut);font-weight:400}
td.cw{white-space:normal;min-width:70px;font-size:12px}
.rbtn{font:inherit;font-size:11.5px;padding:2px 9px;border-radius:999px;border:1px solid var(--acc);background:var(--card);color:var(--acc);cursor:pointer;margin-left:8px}
.ctx{color:var(--fg)}
.rp{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px;margin-top:8px}
.rc{border:1px solid var(--line);border-radius:8px;padding:10px 12px;font-size:12.5px}
.rc .co{display:flex;justify-content:space-between;color:var(--mut)}.rc .co b{color:var(--fg);font-family:var(--mono);font-size:13px}
.rc .pn{font-weight:600;margin:3px 0 4px;line-height:1.35}
.rc .kv{color:var(--mut);font-size:12px;line-height:1.5}
.rlink{display:inline-block;margin:4px 0 2px;font-size:12.5px;color:var(--acc)}
.mbox.wide{max-width:min(1180px,96vw);height:92vh;max-height:92vh}
.mbox.wide .mbody{display:flex;flex-direction:column;flex:1;min-height:0}
.rbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:6px 0 8px}.rpos{font-family:var(--mono);font-size:13px}
.rfr{flex:1;width:100%;min-height:0;border:1px solid var(--line);border-radius:8px;background:#fff}
mark.hl-me{background:#fff3a8;color:#1c2120;padding:2px 8px;border-radius:4px;font-weight:800}
mark.hl-fam{background:#d6ecff;color:#1c2120;padding:2px 8px;border-radius:4px;font-weight:800}
.tt.hl-me,.tt.hl-fam{margin-top:12px;font-size:13.5px}
.ctl{margin-top:8px}
.modal[hidden]{display:none}
.cpn,.ph{cursor:pointer}.cpn:hover,.ph:hover{text-decoration:underline dotted}
.toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);background:var(--fg);color:var(--bg);padding:8px 14px;border-radius:8px;font-size:13px;z-index:60;pointer-events:none;opacity:0;transition:opacity .2s}.toast.on{opacity:1}
'''
page=f'''<title>{e(TITLE)}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+KR:wght@400;500;700&family=IBM+Plex+Mono:wght@500&display=swap">
<style>{CSS}{NOTES_CSS}</style>
<div class="wrap">
<header class="top">
<h1>1차 TA 킬포인트 보드</h1>
<div class="sub">{e(SUB)} · {len(D)}명 · 마이데이터 {e(MD)} 기준 · 정렬: 상담신청일 → 배정일 빠른순 · 점수·킬포인트는 보험데이터 + 연령만 반영</div>
<div class="stats"><span class="stat">🔥 65+<b>{cnt['🔥']}</b></span><span class="stat">🟢 50~64<b>{cnt['🟢']}</b></span><span class="stat">🟡 35~49<b>{cnt['🟡']}</b></span><span class="stat">⚪ &lt;35<b>{cnt['⚪']}</b></span></div>
</header>
<div class="bar">
<input id="q" type="search" placeholder="이름 · 전화번호 검색" aria-label="검색">
<div class="chips" id="fg"><button class="chip on" data-v="">전체</button><button class="chip" data-v="🔥">🔥</button><button class="chip" data-v="🟢">🟢</button><button class="chip" data-v="🟡">🟡</button><button class="chip" data-v="⚪">⚪</button></div>
<div class="chips" id="ft"><button class="chip on" data-v="">유형 전체</button><button class="chip" data-v="조정형">🔧 조정형</button><button class="chip" data-v="보강형">➕ 보강형</button><button class="chip" data-v="양호">✅ 양호</button></div>
<div class="chips" id="fx"><button class="chip" data-v="보장강화필요">보장강화필요</button><button class="chip" data-v="종신저축오인">종신저축오인</button><button class="chip" data-v="실손1세대 실손2세대">실손 1·2세대</button><button class="chip" data-v="갱신과다">갱신과다</button></div>
</div>
<div class="list" id="list">
{''.join(cards)}
</div>
<div class="empty" id="empty">조건에 맞는 고객이 없습니다.</div>
<div class="modal" id="modal" hidden><div class="mbox" id="mbox"><div class="mhead"><b id="mtitle"></b><button type="button" class="chip" id="mclose">닫기</button></div><div class="mbody" id="mbody"></div></div></div>
<div class="note">
<b>점수 룰 v3 (2트랙)</b> — 🔧조정형: 보험료 낭비(지출정도 + 갱신 가산, 적정 90%↑에서만) 45 + 보장공백 30 + 완벽보강해도절약 15 + 종신저축오인 20~30 · ➕보강형: 적정 90% 미만 + 핵심공백 2개↑ → 공백 항목당 12 + 보장성無 15 / 구형 10 · 높은 쪽 채택 × 연령 (30~40대 1.0 / 20대 0.85 / 50대 0.7 / 60대+ 0.5).<br>
<b>적정보험료</b> 20대 10만 / 30대 15만 / 40대 18만 / 50대 25만 / 60대+ 40만. <b>공백 기준</b> 암 5,000만↑(단일 상품) · 뇌혈관/허혈성 각 3,000만 · 1~5종 수술비 · 표적항암 등 고액치료비 · 간병(40대↑).<br>
<b>잔여비율 가산</b> 보장성(납입중) 잔여보험료 ÷ 총보험료 ≥90% +10 / 70~89% +7 / 50~69% +4 / 30~49% +2 / <30% 0 (× 연령, 100 상한). <b>종신보험</b> 납입 3·5·7년 → 저축으로 오인 · 10년↑ → 사망보장(상속세 재원), 단 보험료가 10만 단위로 딱 떨어지거나 100만↑이면 저축으로 오인.<br>
<b>보유보험 표</b> 본인보험(피보험자 = 고객) / 가족보험(피보험자별) 분리 · 정렬: 보장성(실손 우선) → 종신 → 연금/저축 → 기타(치아·운전자·화재·자동차) → 가입일 빠른순 → 보험료 높은순 · 자동차 등 분석제외 건은 보험료 합계·점수에 미반영. <b>레포트보기</b> = report-skill CRM 전체레포트(crm_lib.build_full)로 자동 생성 · 본인보험 → 가족보험(피보험자별) 순서로 넘김 · 보장완성도 = 암 3,000만·뇌·심장 각 2,000만·수술비·실손 5항목 × 20% 자동 산출(매니저 의견 공란).
</div>
</div>
<script>
var RAW={json.dumps(RAW,ensure_ascii=False)};
var RPT={json.dumps(RPT,ensure_ascii=False)};
var CT={json.dumps(CT,ensure_ascii=False)};
(function(){{var M=document.getElementById('modal'),MB=document.getElementById('mbox'),MT=document.getElementById('mtitle'),MD=document.getElementById('mbody');function esc(t){{return String(t==null?'':t).replace(/&/g,'&amp;').replace(/</g,'&lt;')}}function won(v){{return v?Number(v).toLocaleString('ko-KR')+'원':'-'}}
var CUR={{}};function showRpt(){{var R=RPT[CUR.n],g=R.g[CUR.i],nav=R.g.length>1?'<button type="button" class="chip rnav" data-d="-1">◀ 이전</button> <span class="rpos">'+(CUR.i+1)+' / '+R.g.length+'</span> <button type="button" class="chip rnav" data-d="1">다음 ▶</button>':'';open(CUR.n+' CRM 전체레포트 — '+g[0],'<div class="rbar">'+nav+'<a class="rlink" target="_blank" rel="noopener" href="https://crm.tossinsu.com/crm-v2/cover/'+R.id+'">↗ CRM 원본</a></div><iframe class="rfr" src="'+g[1]+'"></iframe>',true)}}
function open(t,h,w){{MT.textContent=t;MD.innerHTML=h;MB.classList.toggle('wide',!!w);M.hidden=false}}
document.addEventListener('click',function(ev){{var b=ev.target.closest('.lgbtn.ctbtn');if(b){{ev.preventDefault();var n=b.dataset.n,L=CT[n]||[];var H=[[0,'계약일'],[1,'계약상태'],[2,'보험사명'],[3,'상품명'],[7,'보험료'],[8,'납입주기'],[10,'계약자명'],[11,'피보험자명']];open(n+' 체결보험 '+L.length+'건 (토스 계약관리)','<table class="mt"><colgroup><col class="w2">'+L.map(function(){{return '<col>'}}).join('')+'</colgroup><thead><tr><th>항목</th>'+L.map(function(x,i){{return '<th>계약 '+(i+1)+'</th>'}}).join('')+'</tr></thead><tbody>'+H.map(function(h){{var i=h[0];return '<tr><th>'+h[1]+'</th>'+L.map(function(x){{return '<td class="c">'+(i==7?won(x[i]):esc(x[i]||'-'))+'</td>'}}).join('')+'</tr>'}}).join('')+'</tbody></table>',true);return}}
b=ev.target.closest('.rbtn');if(b){{ev.preventDefault();ev.stopPropagation();var n=b.dataset.n,R=RPT[n]||{{g:[]}};CUR={{n:n,i:0}};showRpt();return}}
b=ev.target.closest('.rnav');if(b){{var R=RPT[CUR.n];CUR.i=(CUR.i+(+b.dataset.d)+R.g.length)%R.g.length;showRpt();return}}
b=ev.target.closest('.lgbtn');if(b){{var n=b.dataset.n,L=RAW[n]||[];open(n+' 상담이력 '+L.length+'건','<table class="mt"><colgroup><col class="w1"><col class="w2"><col><col class="w4"></colgroup><thead><tr><th>상담 최초 등록</th><th>상태</th><th>내용</th><th>입력자</th></tr></thead><tbody>'+L.map(function(x){{return '<tr><td class="d">'+esc(x[0])+'</td><td>'+esc(x[1])+'</td><td class="c">'+esc(x[3])+'</td><td class="d">'+esc(x[2])+'</td></tr>'}}).join('')+'</tbody></table>');return}}
b=ev.target.closest('.cpn');if(b){{var d=new Date(),y=String(d.getFullYear()).slice(2),mo=('0'+(d.getMonth()+1)).slice(-2),da=('0'+d.getDate()).slice(-2);copy(y+mo+da+'_'+b.dataset.n+'_'+b.dataset.r);return}}
b=ev.target.closest('.ph');if(b){{copy(b.textContent.replace(/[^0-9]/g,''));return}}
if(ev.target.id==='mclose'||ev.target===M){{M.hidden=true}}}});
var T=document.createElement('div');T.className='toast';document.body.appendChild(T);var tt;function toast(s){{T.textContent=s;T.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){{T.classList.remove('on')}},1400)}}
function copy(s){{function ok(){{toast('복사됨: '+s)}}function fb(){{var ta=document.createElement('textarea');ta.value=s;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{{document.execCommand('copy');ok()}}catch(e){{toast('복사 실패')}}document.body.removeChild(ta)}}if(navigator.clipboard&&navigator.clipboard.writeText){{navigator.clipboard.writeText(s).then(ok,fb)}}else fb()}}document.addEventListener('keydown',function(ev){{if(ev.key==='Escape')M.hidden=true}});}})();
(function(){{
var q=document.getElementById('q'),cards=[].slice.call(document.querySelectorAll('.card')),empty=document.getElementById('empty');
var st={{g:'',t:'',x:[]}};
function apply(){{var n=0,s=(q.value||'').trim().replace(/-/g,'');cards.forEach(function(c){{var ok=true;if(st.g&&c.dataset.g!==st.g)ok=false;if(st.t&&c.dataset.t!==st.t)ok=false;if(st.x.length){{var tg=c.dataset.tags;ok=ok&&st.x.every(function(v){{return v.split(' ').some(function(w){{return tg.indexOf(w)>=0}})}})}}if(s&&c.dataset.q.replace(/-/g,'').indexOf(s)<0)ok=false;c.hidden=!ok;if(ok)n++}});empty.style.display=n?'none':'block';try{{localStorage.setItem('ta_f2',JSON.stringify(st))}}catch(e){{}}}}
function wire(id,key){{var box=document.getElementById(id);box.addEventListener('click',function(ev){{var b=ev.target.closest('.chip');if(!b)return;if(key==='x'){{b.classList.toggle('on');st.x=[].map.call(box.querySelectorAll('.on'),function(e){{return e.dataset.v}})}}else{{box.querySelectorAll('.chip').forEach(function(e){{e.classList.remove('on')}});b.classList.add('on');st[key]=b.dataset.v}}apply()}})}}
wire('fg','g');wire('ft','t');wire('fx','x');q.addEventListener('input',apply);
try{{var sv=JSON.parse(localStorage.getItem('ta_f2'));if(sv){{st=sv;['fg','ft'].forEach(function(id){{var k=id==='fg'?'g':'t';document.querySelectorAll('#'+id+' .chip').forEach(function(b){{b.classList.toggle('on',b.dataset.v===(st[k]||''))}})}});document.querySelectorAll('#fx .chip').forEach(function(b){{b.classList.toggle('on',(st.x||[]).indexOf(b.dataset.v)>=0)}})}}}}catch(e){{}}
apply();
}})();
</script>
{NOTES_JS}'''
open('ta_board.html','w').write(page)
json.dump(sorted(FILES),open('files.json','w'),ensure_ascii=False)
print(len(page),cnt,'files',len(FILES))
```

## §5. 검증 기준 (룰 변경 후 반드시 재현)
| 고객 | 기대 | 비고 |
|---|---|---|
| 박정무 (34세·경찰) | 조정형 **79** 🔥 | 보장성 271,652원(181%) · 2세대 실손 · 공백 4 |
| 이미연 | 조정형 **89** 🔥 | 변액종신 307,000원·20년 → 사망보장(오인 ✕) · 잔여 65% +4 |
| 정하진 | 조정형 **74** 🔥 | 806,709원·5년 오인 1건 · 잔여 78% +7 |
| 이재필 | 조정형 **100** 🔥 | 307% · 2세대 실손 · 종신오인(353,920원·7년) · 잔여 79% +7 |
| 박정무 | **79→(잔여 가산 적용 시 재확인)** | 잔여비율 가산은 v1.2부터 — 박정무 재채점값은 다음 회차에 기록 |
| 가입 전환 고객 15명 (김주애·홍창표·심은정·유혜린·김은영·성경모·이준근·이성훈·이정룡·나영완·육혜연·유금란·홍희정) | 🟢↑ 7 / 🟡 5 / ⚪ 1(홍희정=이미 완성형, 예외) | 2026-06 이후 토스 체결분 제외 기준 |

## §6. 보드 포맷 (고정)
- **정렬**: 상담신청일 빠른순 → 동일 시 배정일 빠른순 (점수순 ❌). 데이터없음(수기) 고객은 맨 뒤.
- **카드 머리**: `고객명(클릭 → 'YYMMDD_고객명_생년월일코드' 복사, 날짜=클릭 당일) 전화번호(클릭 → 숫자만 복사) 생년월일코드(YYMMDD-S, S=1900년대 남1 여2 / 2000년대 남3 여4)` / `나이·성별·보장성 월 N원 (지출%)` / `신청 일시 · 배정 일시 · 지역 · 카테고리`(최근 신청) / 특이사항 1~3줄(⛔ 거절·연락불가=빨강 / ⚠️ 기존·계약고객=빨강 / 📋) / **상담이력 O (N건)** 빨간 클릭 → 팝업(일시·상태·내용 원문·입력자, 행선 전체 폭·폰트 통일) 또는 **상담이력 X**(시스템 문구만이면 X) / 유형 pill + 점수 + 등급. 복사 시 하단 토스트 "복사됨: …".
- `기납입 / 총납입 (납입비율) · 보장성 잔여 % +가산` / **킬포인트 2줄** / 유지·전환·재구성.
- **보유보험** 기본 접힘, 제목 옆 **[레포트보기]** 버튼. 표 열: 보험사 · 계약자/피보험자 · 상품+진단태그→조정방향(빨강=상담 대상) · 월보험료 원 · 가입일 · 납입 · 갱신 · 기납입 · 잔여. **본인보험 / 가족보험(피보험자별 표)** 분리 — 기준은 **피보험자만**(계약자 무시). 피보험자가 본인·고객명·마스킹 일치·차량번호/주소/단체(공제회·회사·조합 등)이면 본인. 분리될 때 제목 형광펜(본인 노랑 `mark.hl-me` / 가족 파랑 `mark.hl-fam`). 정렬: 보장성(실손 최상단) → 종신 → 연금/저축 → 기타(치아·운전자·화재·자동차) → 가입일↑ → 보험료↓. 자동차·화재 등 분석제외 건도 표시(보험료 합계·점수 미반영).
- **레포트보기** → 팝업(iframe) = report-skill `crm_lib.build_full`로 만든 CRM 전체레포트(가입보험 상세정보 + 카테고리별 보장 정보). 가족보험 있으면 본인보험 레포트 먼저, `◀ 이전 / 다음 ▶`로 피보험자별 레포트 넘김, CRM 원본 링크(`/crm-v2/cover/{id}`) 병기. 담보 집계 = §0-6. 스킬 CRM레포트와의 차이(고정): 보장완성도는 mr.와이 지정값 대신 5항목(암 3,000만·뇌·심장 각 2,000만·수술비·실손)×20% 자동 / 보험 열 순서는 보드 정렬(CRM 화면 드래그 순서는 API 미제공) / 보험 개수는 정상 계약 전체(열 수와 연동), 월납·기납·잔여·총 합계는 자동차·휴대폰 제외 / 매니저 의견·코멘트 공란.
- **체결보험** = 보유보험 아래. `체결보험 O (N건)` 빨간 클릭 → 팝업(항목 세로형: 계약일·계약상태·보험사명·상품명·보험료·납입주기·계약자명·피보험자명 **8개만**) 또는 `체결보험 X`.
- **상담내용입력** = 상담이력 바로 아래 빨간 알약 버튼(기록 있으면 채움 + `N건 · 일시 · 마지막 상태` 요약). 클릭 → 0건: 입력창(상단 토글 [다음상담][다시TA][부재][차단/거절] 선택/해제·복수, 메모, 하단 [입력]) / **1건↑: 목록**(체크박스·#·일시·상태·메모 표, 줄 클릭 → 수정창(하단 [목록][수정/닫기][추가입력]), 하단 [선택 삭제]·[닫기][추가입력], 전체선택 체크박스, 삭제는 팝업 하단 인라인 확인 [예][아니오] 후 — 아티팩트 iframe에서 `confirm()`은 차단되므로 ❌). 저장 = 아티팩트 DB `notes/p{전화번호숫자}`(doc id는 ASCII만 허용 — 한글 키 ❌ · 전화 없으면 이름 해시) `{name,phone,entries:[{id,tags,memo,at,up}],up}` · DB 미연결 시 localStorage 폴백 + 창에 표시 · 브라우저에만 있던 기록은 DB 연결 후 해당 고객 팝업을 열 때 자동 서버 저장. CRM 상담노트에는 자동 반영 ❌(보드 자체 기록 · 다음 회차 선별 시 `ArtifactData`로 읽어 활용).
- 필터: 등급·유형·태그 칩 + 이름/번호 검색(localStorage 기억). 다크모드 대응. 모달 `hidden` 시 `display:none` 강제.

## §7. 토큰·시간 절약 규칙
- CRM 페이지 텍스트 읽기 ❌ (API fetch만). 고객당 상세 탭 열기 ❌.
- 반출은 `<pre>` 덤프 1회, 저장은 Write 1~3회. 중간 JSON 요약·확인 출력 ❌.
- 보고는 분포 + 🔥 명단 + 이슈 3줄. 설명 재서술 ❌.
- 100명 ≈ 추출 1분 · 전체 15분 · 컨텍스트 ~120k자 수준이 정상.

## §8. 알려진 한계 (고도화 후보)
1. 피보험자 본인 판정 = 마스킹 이름·차량/주소/단체 정규식 → 드물게 오분류 가능 (가족보험 표 제목으로 눈으로 확인)
2. "보장 빈약" 상품 태그는 단일 상품 기준 → 간편·간병·치아 등 단독 상품은 유형별 기준 분리 필요
3. 마이데이터 조회일 이후 신규 계약은 미반영 (조회일 부제 표기)
4. 등급 컷(65/50/35)은 분포 보고 조정 가능 — 🔥는 "2~3회 재컨택 가능한 수"에 맞춤
5. CRM 전체레포트: API 담보 목록이 비어 있는 상품은 CRM 화면과 달리 '-'로 표기될 수 있음(서현옥 뉴사랑나무 사례) · 열 순서 = CRM 드래그 순서 미반영
6. 작업시간 병목 = 반출(get_page_text)+저장(Write)에서 JSON이 컨텍스트를 두 번 통과(100명 ≈ 7~10분). 개선 순서: JSON 슬림화 → 브라우저 다운로드 후 채팅 첨부(개입 1회) → 로컬폴더 연결. 로드가 과하면 그때 적용

## §9. 스킬 업데이트 제안 프로토콜 (필수)
mr.와이가 다음 중 하나라도 바꾸면 **작업 반영 직후** 아래 문장으로 제안하고, "응/해줘/올려줘"면 `propose_skills`로 **전체 SKILL.md**(버전·날짜·변경 로그 갱신, 코드 전문 포함)를 올린다:
- 점수 배점·임계치·등급 컷 · 잔여비율 가산 · 적정보험료표 · 공백 기준 · 종신/실손/운전자 판정 · 태그·조정방향 문구 · 킬포인트 템플릿 · 보드 포맷(카드 머리·특이사항·팝업·보유보험 표·레포트보기·체결보험·복사 기능) · 고객/보험 정렬 · 본인/가족 분리 기준 · CRM 레포트 담보 집계 기준 · 트리거 · 선별 방식 · 미터치 등록 절차 · 상담내용입력(토글 항목·저장 구조)
> 📌 **전화자료 [바뀐 항목] 기준이 변경되었으니 스킬을 업데이트하세요.** 지금 올릴까요?
제안 없이 넘어가면 다음 대화에서 구버전 룰이 적용된다 — 이 프로토콜은 생략 불가. 사용자가 "컨펌하면 올려줘"라 하면 컨펌 후 즉시 올린다.

## §10. 변경 로그
- **v1.0 (2026-11-08) 확립본** — 아래 초안 v1.0~v1.5를 통합한 최초 확정 버전 + 상담내용입력 모듈(카드 버튼 → 팝업: 0건 입력창 / 1건↑ 목록 · 상태 토글 4종·메모·입력/수정·체크박스 선택삭제(인라인 예/아니오), 아티팩트 DB `notes/` 저장, build.py 내장, 발행 시 `capabilities={db:{}}`). 이후 변경은 v1.1부터.
- (초안 이력) 아래 v1.0~v1.5는 확립 전 작업 기록
- v1.5 (2026-11-06) 미터치 등록 = `POST /api/v3/counsel-note/{id}` fetch 일괄(payload 박제·검증, UI 조작은 폴백만 · 체크박스 폴백은 `left_click`) · 아티팩트 제목 `TA_YYMMDD`(수정 시 유지, build.py 3번째 인자) · 보고 = 이슈만 · build.py 레포트보기 경로 상대경로 수정(절대경로 → iframe 빈 화면 버그) · §8 작업시간 개선 순서 기록
- v1.4 (2026-11-06) §3 0번 **세션 확인** 단계 추가(CRM 로그인 상태 확인 → 미로그인 시 중단·대기 · 25분 공백 후 재확인) — 그 외 변경 없음
- v1.3 (2026-11-06) 고객명/전화 클릭 복사 · 체결보험(토스 계약관리) 보유보험 아래 + 8항목 팝업 · 레포트보기 = report-skill crm_lib CRM 전체레포트(본인→가족 페이지 넘김, CRM 소분류·최댓값·만원 절사 집계, 화면 대조 검증) · 보유보험 표 계약자/피보험자 열 + 본인/가족(피보험자 기준) 분리 + 형광펜 · 보험 정렬(보장성·실손 우선→종신→연금→기타→가입일↑→보험료↓) · 고객 정렬 신청일↑→배정일↑ · 배정일 표시 · 미터치 고객 상담노트 자동 등록 룰 · 4-B/4-C 코드 통합(data.json 단일 입력)
- v1.2 (2026-11-06) 잔여비율 가산(+10/7/4/2/0) · 생년월일코드 · 최근 신청(일시·지역·카테고리) · 상담이력 특이사항 요약(⛔/⚠️/📋) · 상담이력 O(팝업 원문)/X · 팝업 표 폰트·열간격·행선 통일
- v1.1 (2026-11-06) 기납입·잔여·납입비율 추가, 보유보험 기본 접힘
- v1.0 (2026-11-06) 최초 박제: 2트랙 점수 · 100 상한 · 종신 납입기간 룰 · 상품 진단태그+조정방향(빨강) · 킬포인트 2줄 · 이름/전화 식별 · 상담내용 선별 전용 · 검증셋(박정무 79, 가입 15명)