"""
pre_report_gen.py — 사전상담 자료 생성 스크립트 (v7 2026-05-06)

역할:
1. 고객 데이터 입력받아 → 변수 치환된 HTML 생성
2. HTML → PNG 변환 (Playwright, device_scale_factor=3, geometricPrecision)
3. message.txt 생성 (카드 ③ 5단계 라벨 기준 결론 본문 통일)
4. 다수 고객 → zip 패키징 (폴더 평탄화 + NN.고객명 파일명)

v7 핵심 룰:
- 카드 ③ "보험료&보장 기준 진단" 5단계 라벨 (매우과잉/높은편/보통/낮음/미확인)
- 5개 보장 카드: 실손/암(진단,치료)/뇌혈관(진단,치료)/심장(진단,치료)/수술보장
- 라벨 산출:
  · 암 = 일반암+통합암 진단비 / 암주요+암특정 치료비 합산
  · 뇌 = 뇌혈관진단비 + 뇌혈관 치료비 (뇌졸중·뇌출혈 제외)
  · 심 = 허혈성+부정맥 진단비 + 심장 치료비 (급성심근·심혈관특정·심근병증 제외)
  · 수술 = 질병수술 + 상해수술 합산
- 헤드라인 + 메시지 결론 = 카드 ③ 5단계 라벨 기준 통일 매핑

사용법:
  from pre_report_gen import generate_reports

  customers = [...]  # 고객 dict list
  generate_reports(customers, output_zip="report.zip")
"""

import os
import re
import zipfile
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright


# ===== 라벨 매핑 (v7 2026-05-06) =====

# 헤드라인 본문 — PNG 검정박스 + 메시지 결론 본문 통일 매핑
# 카드 ③ 5단계 라벨 기준 (매우과잉/높은편/보통/낮음/미확인 (또는 0원))
# 5개 보장 카드 5종 라벨도 매핑 가능 (가족 PNG 등)
# v7 2026-05-06 — 헤드라인 본문 매핑 (PNG 검정박스 + 메시지 결론 본문 통일)
# 카드 ③ 5단계 라벨 기준 + 5개 보장 카드 5종 라벨 호환
# v8 2026-05-09 — 5종 평균 라벨 기준 헤드라인 본문 통일 매핑
# (PNG 검정박스 + 노란박스 + 메시지 결론 본문 통일 — 단일 출처)
HEADLINE_BY_LEVEL = {
    "과잉": '<span class="accent">핵심 의료보장이 지나치게 과잉상태</span>입니다.',
    "적정": "핵심 의료보장이 완성된 상태입니다.",
    "보통": "핵심 의료보장이 완성되지 않았습니다.",
    "빈약": "핵심 의료보장이 빈약한 상태입니다.",
    "부재": "핵심 의료보장이 전무한 상태입니다.",
    "—":   "핵심 의료보장이 전무한 상태입니다.",
}

# v7 2026-05-06 — 메시지 결론 본문 (txt — accent 태그 ❌)
# v8 2026-05-09 — 메시지 결론 본문 (txt — accent 태그 ❌, 5종 평균 라벨 기준)
CONCLUSION_TEXT_BY_LEVEL = {
    "과잉":   "으로 핵심 의료보장이 지나치게 과잉상태입니다.",
    "적정":   "으로 핵심 의료보장이 완성된 상태입니다.",
    "보통":   "으로 핵심 의료보장이 완성되지 않았습니다.",
    "빈약":   "으로 핵심 의료보장이 빈약한 상태입니다.",
    "부재":   "으로 핵심 의료보장이 전무한 상태입니다.",
}

# 갱신형 감지 룰 (rules.json renewal_handling 박제)
RENEWAL_KEYWORD = "갱신"
# 메시지 ① 변수 본문 (트리거 3 룰 변경 — 2026-05-01 / v6 유지)
RENEWAL_MESSAGE_LINE_1 = "❌ 보험료가 계속 인상되는 갱신형보험이 구성되어 보험료가 낭비를 넘어 크게 새고 있습니다."
# 메시지 ② 변수 본문 (갱신 ❌ + 라벨 ∈ {과잉, 적정})
PREMIUM_OVERAGE_LINE = "❌ 기납입보험료 외에도 {amount:,}원이나 되는 보험료를 낭비하게 됩니다."
# 메시지 ③ 변수 본문 (갱신 ❌ + 라벨 ∈ {보통, 빈약, 부재})
PREMIUM_NORMAL_LINE = "⭕ 잔여보험료가 {amount:,}원으로 일반적인 수준입니다."
# 메시지 ④ 변수 본문 — v6 신설 (갱신 ✅ 시 라벨 무관 ① + ④ 무조건 노출)
RENEWAL_REMAINING_LINE = "❌ 이후 납입할 {amount:,}원에 더해 갱신형보험 인상분으로 보험료가 크게 낭비되게 됩니다."
# PNG 갱신형 버튼 본문 (빨간 배경 + 노란 굵은 글씨 — 2026-05-01 / v6 폰트 22px 갱신)
RENEWAL_REPORT_HTML = (
    '<div class="renewal-warning">'
    '진단결과와 별개로 갱신형보험 구성으로, 보험료 낭비 과다상태입니다!'
    '</div>'
)


def determine_conclusion_case(labels):
    """가족 5종 라벨 → 가족 표 헤드라인용 라벨 직접 산출 (v7 2026-05-06).

    가족 PNG 영역 한정 — 본인 케이스는 카드 ③ 5단계 라벨이 헤드라인 매핑 담당.
    본 함수는 가족 5종 라벨(부재/빈약/보통/적정/과잉)로 가족 표 헤드라인 라벨 산출.

    충분 = {과잉, 적정} / 부족 = {보통, 빈약, 부재}

    Args:
        labels: dict — {"실손": ..., "암": ..., "뇌": ..., "심장": ..., "수술": ...}

    Returns:
        5종 라벨 (str): "과잉" / "보통" / "빈약" / "부재"
    """
    SUFFICIENT = {"과잉", "적정"}

    cancer = labels.get("암", "부재")
    brain = labels.get("뇌", "부재")
    heart = labels.get("심장", "부재")
    surgery = labels.get("수술", "부재")

    # 4개 모두 부재 → 부재
    if all(l == "부재" for l in [cancer, brain, heart, surgery]):
        return "부재"

    # 암·뇌·심장 충분 개수 (수술 무관)
    sufficient_count = sum(1 for l in [cancer, brain, heart] if l in SUFFICIENT)

    if sufficient_count == 3:
        return "과잉"
    if sufficient_count == 2:
        return "보통"
    if sufficient_count == 1:
        return "빈약"
    return "부재"


def detect_renewal(raw_customer_text):
    """고객정보 원문 텍스트에 '실손이 아닌' 갱신형 보험·특약이 있는지 정확 검증.

    v5 룰 (2026-05-01) — 순수 실손보험 제외:
    - 모든 실손의료비보험은 본질적으로 갱신형 구조 (도메인 표준)
    - 메시지 ①·PNG 박스의 "갱신형보험" 경고는 '실손 외 보장성 갱신형'을 가리키는 영역
    - 따라서 갱신형 보험 중 보장 카테고리가 '실비' 단일이면 트리거에서 제외
    - 실비 + 다른 카테고리(3대진단·수술비·사망 등) 혼합 시 → 일반 갱신형보험으로 ✅
    - 갱신형 보험·특약이 1건이라도 실손 외 카테고리 보장 시 → 트리거 ✅

    알고리즘:
    1. "상품 별 보장 목록" 섹션에서 각 보험명 ↔ 갱신유무·보장카테고리 매핑
    2. 갱신형 보험·특약 중 — 실비 단일 보장이 아닌 보험이 1건 이상이면 ✅
    """
    if not raw_customer_text:
        return False

    # 1차 빠른 검증 — 텍스트에 갱신형 키워드 자체 ❌이면 즉시 ❌
    if not (("갱신형 특약" in raw_customer_text) or ("갱신형 보험" in raw_customer_text)):
        return False

    # 2차 정밀 검증 — 보험별 갱신유무·카테고리 매핑
    insurances = parse_insurances(raw_customer_text)

    for ins in insurances:
        if not ins["is_renewal"]:
            continue
        # 갱신형 보험·특약 — 보장 카테고리 검사
        cats = ins["categories"]
        # 실비 단일이면 순수 실손보험 → 트리거 제외
        if cats == {"실비"}:
            continue
        # 실비 외 카테고리 1개라도 있으면 → 일반 갱신형보험으로 ✅
        if cats - {"실비"}:
            return True
        # cats == set() (보장 카테고리 ❌, 빈 영역) → 보수적으로 ❌ 처리
        # (단체보험·반려동물 등 카테고리 매핑 ❌ 케이스. 펫퍼민트 등은 "기타"로 분류되어 cats에 포함됨)

    return False


def parse_insurances(raw_customer_text):
    """텍스트에서 보험별 (이름·갱신유무·보장카테고리) 추출.

    "가입보험 상세정보" 표 구조:
    - "보험명" 행 — 다음 N줄에 보험 N개의 이름
    - "갱신 유무" 행 — 다음 N줄에 갱신유무 (갱신형 특약 / 갱신형 보험 / 비갱신형)
    - "상품 별 보장 목록" 섹션 — 보험별 카테고리 표

    Returns:
        list of dict: [{"name": str, "is_renewal": bool, "categories": set}]
    """
    lines = raw_customer_text.split("\n")
    lines = [ln.rstrip() for ln in lines]  # 우측 공백만 제거 (좌측 indent 보존)

    # 1. "보험명" 행과 "갱신 유무" 행 영역 추출 (헤더 영역 — N개의 보험 이름·갱신유무 1:1 대응)
    name_idx = -1
    renewal_idx = -1
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s == "보험명" and name_idx == -1:
            name_idx = i
        elif s == "갱신 유무":
            renewal_idx = i
            break

    if name_idx == -1 or renewal_idx == -1:
        return []

    # "보험명" 다음 → "보험사명" 직전까지 = 보험 이름 N개
    insurance_names = []
    for i in range(name_idx + 1, len(lines)):
        s = lines[i].strip()
        if s == "보험사명":
            break
        if s:
            insurance_names.append(s)

    # "갱신 유무" 다음 → N개 = 각 보험의 갱신유무
    renewal_states = []
    count = 0
    for i in range(renewal_idx + 1, len(lines)):
        s = lines[i].strip()
        if not s:
            continue
        if s in ("갱신형 특약", "갱신형 보험", "비갱신형", "—", "-"):
            renewal_states.append(s)
            count += 1
            if count >= len(insurance_names):
                break
        else:
            # 다음 헤더 라벨 도달 (예: "계약자/피보험자")
            break

    if len(renewal_states) != len(insurance_names):
        # 영역 매핑 실패 — 보수적으로 빈 결과 반환
        return []

    # 2. "상품 별 보장 목록" 섹션에서 보험별 카테고리 매핑
    # 카테고리 매핑 룰: 표 구조 "대분류 / 소분류" 기반
    CATEGORIES = {
        "실비": {"질병입원의료비", "질병외래의료비", "질병처방조제료",
                "상해입원의료비", "상해외래의료비", "상해처방조제료"},
        "3대진단": {"일반암진단", "소액암(유사암)진단", "고액암진단",
                  "뇌혈관질환진단", "뇌졸중질환진단", "뇌출혈질환진단",
                  "허혈성심장질환진단", "급성심근경색진단"},
        "수술비": {"질병수술", "상해수술", "암수술", "뇌혈관질환수술", "허혈성심장질환수술"},
        "입원일당": {"질병입원", "상해입원"},
        "사망": {"질병사망", "상해사망"},
        "후유장해": {"질병80%이상후유장해", "질병80%미만후유장해",
                  "상해80%이상후유장해", "상해80%미만후유장해"},
        "골절화상": {"골절진단", "화상진단"},
        "생활배상책임": {"가족생활배상책임담보", "일상생활배상책임담보"},
        "운전자": {"교통사고처리지원금", "벌금(대물)", "벌금(대인)",
                "변호사선임비용", "자동차부상치료비"},
        "화재": {"화재벌금"},
        "치아": {"보존치료", "보철치료"},
    }
    # 소분류 → 대분류 역매핑
    SUB_TO_MAIN = {sub: main for main, subs in CATEGORIES.items() for sub in subs}

    # 보험별 카테고리 추출 — 표 데이터 영역 ("상품 별 보장 목록" 직전까지)
    # 카테고리별 상세정보 표는 [소분류] 다음 행에 [보험1값, 보험2값, ...] 순서로 N+1줄 (합계 + 보험별)
    section_end = -1
    for i, ln in enumerate(lines):
        if ln.strip() == "상품 별 보장 목록":
            section_end = i
            break

    if section_end == -1:
        section_end = len(lines)

    insurance_categories = [set() for _ in insurance_names]

    i = 0
    while i < section_end:
        s = lines[i].strip()
        if s in SUB_TO_MAIN:
            # 다음 줄부터 합계 + N개 보험값
            # 형식: [합계] [보험1] [보험2] ... [보험N] (총 N+1줄)
            values = []
            j = i + 1
            while j < section_end and len(values) < len(insurance_names) + 1:
                v = lines[j].strip()
                if not v:
                    j += 1
                    continue
                # 다음 소분류 라벨이면 break
                if v in SUB_TO_MAIN or v in ("실비", "3대진단", "수술비", "입원일당",
                                              "사망", "후유장해", "골절화상", "생활배상책임",
                                              "운전자", "화재", "치아"):
                    break
                values.append(v)
                j += 1

            # 첫 값 = 합계, 나머지 N개 = 보험별
            if len(values) >= len(insurance_names) + 1:
                main_cat = SUB_TO_MAIN[s]
                for ins_idx, val in enumerate(values[1:1 + len(insurance_names)]):
                    if val and val not in ("-", "—"):
                        insurance_categories[ins_idx].add(main_cat)
            i = j
        else:
            i += 1

    result = []
    for nm, st, cats in zip(insurance_names, renewal_states, insurance_categories):
        result.append({
            "name": nm,
            "is_renewal": st in ("갱신형 특약", "갱신형 보험"),
            "categories": cats,
        })
    return result

LEVEL_BAR_HTML = {
    # v7 2026-05-06 — 카드 ③ 5단계 라벨
    "매우과잉": '<div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div>',
    "높은편": '<div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg"></div>',
    "보통": '<div class="level-seg active-neutral"></div><div class="level-seg active-neutral"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "낮음": '<div class="level-seg active-warning"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "미확인 (또는 0원)": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "미확인": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div>',
    # 5종 라벨 (카드 ③ 라벨 ❌인 경우 매핑 — 가족 PNG 등)
    "부재": '<div class="level-seg active-danger"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "빈약": '<div class="level-seg active-warning"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div>',
    "적정": '<div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg active-good"></div><div class="level-seg"></div>',
    "과잉": '<div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div><div class="level-seg active-rich"></div>',
    "—": '<div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div><div class="level-seg"></div>',
}

# 라벨 → CSS class용
def label_to_class(label):
    """v7 2026-05-06 — 라벨 → CSS class 매핑.

    카드 ③ 5단계 라벨 / 5개 보장 카드 5종 라벨 모두 처리.
    """
    # 카드 ③ 5단계 → CSS 클래스 (5종 라벨 클래스 재사용)
    mapping = {
        "매우과잉": "과잉",
        "높은편": "적정",
        "보통": "보통",
        "낮음": "빈약",
        "미확인 (또는 0원)": "부재",
        "미확인": "부재",
    }
    if label in mapping:
        return mapping[label]
    # 5종 라벨은 그대로 반환 (CSS class와 동일)
    return label.replace(" ", "").replace("·", "").replace("(", "").replace(")", "")


# v8 2026-05-09 — 보장 완성도 % 매핑 (5종 라벨 적정+과잉 비율로 산출 — 외부 입력)
# 본 매핑은 5종 평균 라벨 fallback용으로만 사용
COMPLETION_PERCENT = {
    "과잉": 100,
    "적정": 100,
    "보통": 50,
    "빈약": 30,
    "부재": 0,
    "—":   0,
}


# v7 — 라벨 산출 함수 (새 기준)

def cancer_label_v7(amount_man):
    """암(진단비+치료비) 합산 → 라벨 (v7 — 박제 2026-05-04).

    과잉 15,000만↑ / 적정 10,000~14,999 / 보통 5,000~9,999 / 빈약 2,000~4,999 / 부재 <2,000 (또는 0)
    """
    if amount_man >= 15000:
        return "과잉"
    if amount_man >= 10000:
        return "적정"
    if amount_man >= 5000:
        return "보통"
    if amount_man >= 2000:
        return "빈약"
    return "부재"


def brain_heart_label_v7(amount_man):
    """뇌혈관·심장(진단+치료) 합산 → 라벨 (v7 — 박제 2026-05-04, 양쪽 동일).

    과잉 7,000만↑ / 적정 5,000~6,999 / 보통 3,000~4,999 / 빈약 1,000~2,999 / 부재 <1,000 (또는 0)
    """
    if amount_man >= 7000:
        return "과잉"
    if amount_man >= 5000:
        return "적정"
    if amount_man >= 3000:
        return "보통"
    if amount_man >= 1000:
        return "빈약"
    return "부재"


def surgery_label_v7(amount_man):
    """수술비(질병) → 라벨 (v6 그대로 유지).

    과잉 1,500↑ / 적정 1,000~1,499 / 보통 501~999 / 빈약 1~500 / 부재 0
    """
    if amount_man == 0:
        return "부재"
    if amount_man >= 1500:
        return "과잉"
    if amount_man >= 1000:
        return "적정"
    if amount_man >= 501:
        return "보통"
    return "빈약"


def silson_label_v7(in_hosp_man, out_hosp_man):
    """실손의료비 → 라벨 (v6 그대로). 입원 5,000+외래 25 이상 = 적정 / 부분 = 빈약 / 0 = 부재"""
    if in_hosp_man == 0 and out_hosp_man == 0:
        return "부재"
    if in_hosp_man >= 5000 and out_hosp_man >= 25:
        return "적정"
    return "빈약"


# v7 2026-05-06 — 카드 ③ "보험료 지출 정도" 5단계 라벨 산출
AGE_AVERAGE_PREMIUM = {
    "20대": 100000,
    "30대": 150000,
    "40대": 180000,
    "50대": 250000,
    "60대+": 400000,
}

def classify_premium_level_v7(monthly_premium_won, age):
    """본인 월보험료 + 나이 → 카드 ③ 5단계 라벨.

    공식: (현재 월보험료 / 연령대 적정 보험료) × 100 = N%
    - 매우과잉: ≥ 130%
    - 높은편:   90~129%
    - 보통:     51~89%
    - 낮음:     21~50% (기존 빈약+매우취약)
    - 미확인 (또는 0원): 0~20% (기존 사실상부재+부재)
    """
    if monthly_premium_won <= 0:
        return "미확인 (또는 0원)"
    # 연령대 매핑
    if age >= 60:
        age_key = "60대+"
    elif age >= 50:
        age_key = "50대"
    elif age >= 40:
        age_key = "40대"
    elif age >= 30:
        age_key = "30대"
    else:
        age_key = "20대"
    avg = AGE_AVERAGE_PREMIUM[age_key]
    pct = (monthly_premium_won / avg) * 100
    if pct >= 130:
        return "매우과잉"
    if pct >= 90:
        return "높은편"
    if pct >= 51:
        return "보통"
    if pct >= 21:
        return "낮음"
    return "미확인 (또는 0원)"

def render_html(template_path, customer):
    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    labels = customer["labels"]
    current = customer["current_values"]
    premium = customer["월보험료"]
    level = customer["연령대비"]
    is_family = customer.get("is_family", False)

    # v6 — 헤더 부제목 자체 분기
    # 일반 customer: "{성별} · 보험나이 {보험나이}세 · {거주}"
    # 가족 customer: "성별/나이 추가확인필요 · {거주}"  (보험나이 ❌, 한 줄 통합)
    if is_family:
        header_subtitle = f"{customer['성별']} · {customer['거주']}"
    else:
        header_subtitle = f"{customer['성별']} · 보험나이 {customer['보험나이']}세 · {customer['거주']}"

    # v8 2026-05-09 — 헤드라인 본문 = 5종 평균 라벨 기준 (외부 입력 우선)
    if customer.get("헤드라인_main"):
        headline_main = customer["헤드라인_main"]
    else:
        # 5종 평균 라벨 (customer["평균_라벨"]) 기준 매핑
        avg_label = customer.get("평균_라벨", "부재")
        headline_main = HEADLINE_BY_LEVEL.get(avg_label, HEADLINE_BY_LEVEL["부재"])

    replacements = {
        "{{CUSTOMER_NAME}}": customer["이름"],
        "{{HEADER_SUBTITLE}}": header_subtitle,

        "{{HEADLINE_MAIN}}": headline_main,
        "{{HEADLINE_SUB}}": customer.get("헤드라인_sub", ""),

        # 보장 라벨 (5종)
        "{{LABEL_실손}}": labels["실손"],
        "{{LABEL_실손_CLASS}}": label_to_class(labels["실손"]),
        "{{LABEL_암}}": labels["암"],
        "{{LABEL_암_CLASS}}": label_to_class(labels["암"]),
        "{{LABEL_뇌}}": labels["뇌"],
        "{{LABEL_뇌_CLASS}}": label_to_class(labels["뇌"]),
        "{{LABEL_심장}}": labels["심장"],
        "{{LABEL_심장_CLASS}}": label_to_class(labels["심장"]),
        "{{LABEL_수술}}": labels["수술"],
        "{{LABEL_수술_CLASS}}": label_to_class(labels["수술"]),

        # v7 — 5개 보장 카드 detail (진단비·치료비·세부 분리 표기)
        "{{DETAIL_실손}}": customer.get("detail_실손", current.get("실손", "—")),
        "{{DETAIL_암}}": customer.get("detail_암", current.get("암", "—")),
        "{{DETAIL_뇌}}": customer.get("detail_뇌", current.get("뇌", "—")),
        "{{DETAIL_심장}}": customer.get("detail_심장", current.get("심장", "—")),
        "{{DETAIL_수술}}": customer.get("detail_수술", current.get("수술", "—")),

        # 카드 ① — 보험 가입 요약
        "{{TOTAL_PREMIUM}}": premium["합계"],
        "{{INSURANCE_COUNT}}": str(customer.get("insurance_count", "—")),
        "{{PREMIUM_SELF}}": customer.get("premium_self", premium["합계"]),
        "{{PREMIUM_FAMILY}}": customer.get("premium_family", "0원"),

        # 카드 ③ — 보험료&보장 기준 진단 + 보장 완성도 %
        "{{LABEL_LEVEL}}": level["label"],
        "{{LABEL_LEVEL_CLASS}}": label_to_class(level["label"]),
        "{{LEVEL_BAR_HTML}}": LEVEL_BAR_HTML.get(level["label"], LEVEL_BAR_HTML["부재"]),
        # v8 — 보장 완성도 % = 외부 입력 (5종 라벨 적정+과잉 비율) 우선
        "{{COMPLETION_PERCENT}}": str(customer.get("완성도_pct", COMPLETION_PERCENT.get(customer.get("평균_라벨", "부재"), 0))),
        "{{COMPLETION_BAR_HTML}}": _completion_bar_html(customer.get("완성도_pct", COMPLETION_PERCENT.get(customer.get("평균_라벨", "부재"), 0))),

        # 갱신형 박스 + 가족 요약 표
        "{{RENEWAL_WARNING_BLOCK}}": RENEWAL_REPORT_HTML if customer.get("has_renewal") else "",
        "{{FAMILY_SUMMARY_BLOCK}}": _render_family_summary_block(customer.get("family_summaries", []), headline_main),
    }

    for key, val in replacements.items():
        html = html.replace(key, val)

    return html


def _completion_bar_html(percent):
    """보장 완성도 % → 게이지 5단 HTML (v8 정정 — 5종 라벨 적정+과잉 비율 1/5씩).

    100% (5/5) → 5칸 모두 active-good (녹색)
    80%  (4/5) → 4칸 active-good
    60%  (3/5) → 3칸 active-good
    40%  (2/5) → 2칸 active-good
    20%  (1/5) → 1칸 active-warning (오렌지)
    0%   (0/5) → 모두 비활성
    """
    if percent >= 100:
        active = ["active-good"] * 5
    elif percent >= 80:
        active = ["active-good"] * 4 + [""]
    elif percent >= 60:
        active = ["active-good"] * 3 + [""] * 2
    elif percent >= 40:
        active = ["active-good"] * 2 + [""] * 3
    elif percent >= 20:
        active = ["active-warning"] + [""] * 4
    else:
        active = [""] * 5
    segs = "".join(f'<span class="level-seg {a}"></span>' for a in active)
    return segs


def _render_family_summary_block(family_summaries, owner_headline_main):
    """v7 정정 2026-05-05 — 시안 B (파란 파스텔) + 가족 자체 결론 + 제목 + 라벨 %.

    - 가족 자체 라벨로 결론 자체 산출 (본인 헤드라인 ❌)
    - 라벨 뒤 % 매핑 — 부재(0%) / 빈약(30%) / 보통(50%) / 적정(100%) / 과잉(100%)
    - 제목: "가족분 보험도 보유하고 계시며, 가족{NN}({이름})님 보험 현황입니다."
    - 검토의견: "가족{NN}({이름})님의 보험은\\n{가족_헤드라인}"
    """
    if not family_summaries:
        return ""

    blocks = []
    for idx, fs in enumerate(family_summaries, start=1):
        name = fs.get("name", "—")
        premium = fs.get("premium", "0원")
        count = fs.get("count", 0)
        labels = fs.get("labels", {"실손":"부재","암":"부재","뇌":"부재","심장":"부재","수술":"부재"})

        # 가족 자체 결론 산출 (본인 헤드라인 ❌, 가족 5종 라벨 기반)
        # determine_conclusion_case는 5종 라벨 직접 산출 (v7)
        family_case_label = determine_conclusion_case(labels)
        family_headline = HEADLINE_BY_LEVEL.get(family_case_label, HEADLINE_BY_LEVEL["부재"])
        # accent span 평문화
        import re as _re
        family_headline_text = _re.sub(r'<[^>]+>', '', family_headline)

        items = [
            ("실손의료비", labels.get("실손", "부재")),
            ("암(진단,치료)", labels.get("암", "부재")),
            ("뇌(진단,치료)", labels.get("뇌", "부재")),
            ("심장(진단,치료)", labels.get("심장", "부재")),
            ("질병수술비", labels.get("수술", "부재")),
        ]
        labels_html = ""
        for k, v in items:
            cls = label_to_class(v)
            pct = COMPLETION_PERCENT.get(v, 0)
            labels_html += f'<div class="fam-line"><span class="fam-key">{k}</span><span class="fam-val val-{cls}">{v}({pct}%)</span></div>'

        block = f'''
<div class="family-block">
  <div class="family-block-title">가족분 보험도 보유하고 계시며, 가족{idx}({name})님 보험 현황입니다.</div>
  <div class="family-block-row">
    <div class="family-block-head">가입현황</div>
    <div class="family-block-count">
      <div class="family-block-count-num">{count}건</div>
      <div class="family-block-premium">{premium}</div>
    </div>
    <div class="family-block-labels">{labels_html}</div>
  </div>
  <div class="family-block-row family-block-row-review">
    <div class="family-block-head">검토의견</div>
    <div class="family-block-review">가족{idx}({name})님의 보험은<br>{family_headline_text}</div>
  </div>
</div>
'''
        blocks.append(block)

    return "\n".join(blocks)


# ===== 메시지 생성 =====

def render_message(customer):
    """메시지 본문 생성 — v7 (2026-05-06 박제).

    1번 항목 분기 (3가지 조합):
    - 갱신형 ✅ + 라벨 무관   → ① + ④ (라벨 분기 ❌, 무조건 ① + ④)
    - 갱신형 ❌ + 매우과잉·높은편  → ② "낭비"
    - 갱신형 ❌ + 보통·낮음 → ③ "일반적 수준"
    - 갱신형 ❌ + 미확인 (또는 0원) → ②·③ 둘 다 미노출 (잔여보험료 0원 추정)

    2번 항목 결론 본문 — 카드 ③ 5단계 라벨 기준 통일 매핑
    (CONCLUSION_TEXT_BY_LEVEL).

    ① 노출 시 ① 직전·④ 또는 ② 또는 ③ 직전에 빈 줄 1행 추가.
    """
    name = customer["이름"]
    labels = customer["labels"]
    has_renewal = customer.get("has_renewal", False)
    # 잔여보험료합계액 (정수 — 원 단위, 갱신형 포함/제외 영역 ❌ 단순 전체 합계)
    total_remaining = customer.get("total_remaining_premium", 0)

    # v8 2026-05-09 — 결론 본문 = 5종 평균 라벨 기준 (헤드라인과 통일)
    avg_label = customer.get("평균_라벨", "부재")
    headline_close = CONCLUSION_TEXT_BY_LEVEL.get(avg_label, CONCLUSION_TEXT_BY_LEVEL["부재"])

    # 1번 항목 분기 변수 조립 — 갱신 우선 분기 (카드 ③ 5단계 라벨 기준은 메시지 ①②③④에만 적용)
    level_label = customer.get("연령대비", {}).get("label", "미확인 (또는 0원)")
    sub_lines = []
    if has_renewal:
        # 갱신형 ✅ 시 라벨 무관 ① + ④ 무조건
        sub_lines.append(RENEWAL_MESSAGE_LINE_1)  # ①
        sub_lines.append(RENEWAL_REMAINING_LINE.format(amount=total_remaining))  # ④
    else:
        # 갱신형 ❌ 시 카드 ③ 5단계 라벨 분기
        if level_label in ("매우과잉", "높은편"):
            sub_lines.append(PREMIUM_OVERAGE_LINE.format(amount=total_remaining))
        elif level_label in ("보통", "낮음"):
            sub_lines.append(PREMIUM_NORMAL_LINE.format(amount=total_remaining))

    # 빈 줄 1행 추가 룰 — 각 sub_line 위에 빈 줄 삽입
    line_1_parts = [f"1. {name}님의 보험은,"]
    for sl in sub_lines:
        line_1_parts.append("")  # 빈 줄 1행
        line_1_parts.append(sl)
    line_1 = "\n".join(line_1_parts)

    msg = f"""{name}님 안녕하세요.
토스 보험분석 어드바이저입니다.

토스앱으로 보험 점검 신청을 주셔서 토스 본사 소속 상담사가 연락드렸습니다.

{line_1}

2. 필수보장을 기준으로,
- 실손의료비 : {labels["실손"]}
- 암보장 : {labels["암"]}
- 뇌혈관보장 : {labels["뇌"]}
- 심장보장 : {labels["심장"]}
- 수술보장 : {labels["수술"]}
{headline_close}

3. 보험은 치료/사고 후에는 효율적으로 가입하기 어렵습니다.
올바르게 준비되어 있는지 꼭 점검해 보시기를 바랍니다.

❗궁금하신점은 [보험검토요청] 등으로 남겨주세요.
❗본사 상담사가 순차적으로 안내드릴 예정입니다.

✅ 본사 상담사 재직정보 확인 > https://service.tossinsu.com/insulink/vO03jJGuLG
"""
    return msg


# ===== HTML → PNG 변환 =====

def html_to_png(html_content, png_path, work_dir):
    """work_dir에 임시 HTML + 로고 복사 → PNG 변환"""
    work_path = Path(work_dir)
    work_path.mkdir(parents=True, exist_ok=True)

    # 로고 복사
    logo_src = Path(__file__).parent / "toss_logo.png"
    logo_dst = work_path / "toss_logo.png"
    if not logo_dst.exists():
        shutil.copy(logo_src, logo_dst)

    # HTML 임시 저장
    html_path = work_path / "temp_report.html"
    html_path.write_text(html_content, encoding="utf-8")

    # PNG 변환
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 720, "height": 1280}, device_scale_factor=3)
        page.goto(f"file://{html_path.absolute()}")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(png_path), full_page=True, type="png")
        browser.close()


# ===== 가족 피보험자 헬퍼 =====

def build_family_summary(family_name, premium_str, count, labels, has_renewal=False):
    """가족 요약 데이터 (v7 — 본인 PNG 안 통합 표).

    별도 PNG ❌. 본인 PNG 5개 보장 카드 아래 "가족{NN}({이름})님 보험 요약" 표 통합.

    Args:
        family_name: 가족 피보험자 명칭 (예: "이*호")
        premium_str: 월보험료 표시 (예: "180,809원")
        count: 보험 건수 (int)
        labels: dict — {"실손": ..., "암": ..., "뇌": ..., "심장": ..., "수술": ...}
        has_renewal: 갱신형 포함 여부

    Returns:
        family_summary dict — render_html 가족 요약 표 영역 사용
    """
    return {
        "name": family_name,
        "premium": premium_str,
        "count": count,
        "labels": labels,
        "has_renewal": has_renewal,
    }


# v6 호환 (deprecated — v7에서는 build_family_summary 사용)
def build_family_member(premium_str, has_renewal=False, family_index=1):
    """가족 피보험자 PNG 데이터 생성 — v6 (deprecated, v7 호환만 유지)."""
    return {
        "이름": f"가족{family_index}",
        "성별": "성별/나이 추가확인필요",
        "보험나이": "",
        "거주": "—",
        "is_family": True,
        "labels": {"실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"},
        "current_values": {
            "실손": "없음 (0원)",
            "암": "없음 (0원)",
            "뇌": "없음 (0원)",
            "심장": "없음 (0원)",
            "수술": "없음 (0원)",
            "상해수술": "0원"
        },
        "월보험료": {"보장": premium_str, "저축": "0원", "합계": premium_str},
        "연령대비": {"label": "—", "percent": "—", "age_group": "—"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": (
            "<span class=\"yellow\">세부정보 확인필요</span> — 가족 피보험자별 "
            "<span class=\"yellow\">생년월일·성별·보장 상세 데이터</span>는<br>"
            "<span class=\"red\">별도 조회가 필요</span>합니다."
        ),
        "has_renewal": has_renewal,
    }


# ===== 메인 함수 =====

def generate_reports(customers, output_zip, template_path=None, work_root="/tmp/pre_report_work"):
    """
    v2 폴더 평탄화 + NN.고객명 파일명 (2026-05-01 박제 ㉑ 정합).

    customers: list of customer dicts.
        각 customer dict는 옵셔널 키 'family_members' (list of dict) 가질 수 있음.
        family_members 정렬은 호출자가 보험료 많은 순 → 건수 많은 순 → 랜덤 순으로 미리 정렬.
    output_zip: 결과 zip 파일 경로
    template_path: HTML 템플릿 경로 (기본: 같은 폴더의 pre_report_template.html)

    산출물 구조 (v2 — 폴더 평탄화):
        zip 안 모든 파일 평탄 저장 (고객별 폴더 ❌)
        본인 PNG : {NN}.{고객명}.png (NN = 입력 순서, zfill 2자리)
        본인 메시지 : {NN}.{고객명}.txt
        가족 PNG : {NN}.{고객명}{NN_가족}.png (본인과 동일 NN)
    """
    if template_path is None:
        template_path = Path(__file__).parent / "pre_report_template.html"

    work_root = Path(work_root)
    if work_root.exists():
        shutil.rmtree(work_root)
    work_root.mkdir(parents=True, exist_ok=True)

    # 각 고객별 처리 — 단일 폴더에 평탄 저장 (NN.고객명 파일명)
    for nn, customer in enumerate(customers, start=1):
        name = customer["이름"]
        nn_str = f"{nn:02d}"  # zfill 2자리

        # 본인 PNG : {NN}.{고객명}.png (v7 — 가족 요약 포함)
        html_content = render_html(template_path, customer)
        png_path = work_root / f"{nn_str}.{name}.png"
        html_to_png(html_content, png_path, work_root)

        # v7 — 가족 별도 PNG ❌. 본인 PNG 안 가족 요약 표로 통합 (render_html 처리)

        # 메시지 (본인 1개만 — 가족 메시지 ❌) : {NN}.{고객명}.txt
        msg = render_message(customer)
        msg_path = work_root / f"{nn_str}.{name}.txt"
        msg_path.write_text(msg, encoding="utf-8")

    # 임시 HTML·로고 정리
    for f in ["temp_report.html", "toss_logo.png"]:
        fp = work_root / f
        if fp.exists():
            fp.unlink()

    # zip 패키징 (Python zipfile — UTF-8 한글 호환, 디렉토리 엔트리 ❌, 평탄 저장)
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work_root.iterdir()):
            if f.is_file():
                zf.write(f, f.name)  # arcname = 파일명만 (폴더 ❌)

    return output_zip



if __name__ == "__main__":
    # 테스트: 유태수 케이스
    test_customer = {
        "이름": "유태수",
        "성별": "남",
        "보험나이": 45,
        "거주": "경기도 고양시",
        "labels": {
            "실손": "부재", "암": "부재", "뇌": "부재", "심장": "부재", "수술": "부재"
        },
        "current_values": {
            "실손": "없음 (0원)", "암": "없음 (0원)", "뇌": "없음 (0원)",
            "심장": "없음 (0원)", "수술": "없음 (0원)", "상해수술": "0원"
        },
        "월보험료": {"보장": "0원", "저축": "0원", "합계": "0원"},
        "연령대비": {"label": "부재", "percent": "0", "age_group": "40대"},
        "헤드라인_main": HEADLINE_BY_LEVEL["부재"],
        "헤드라인_sub": "가입된 보험은 <span class=\"yellow\">자동차보험 1건</span>이 전부이며,<br>실손·암·뇌·심장·수술비 등 핵심 의료보장은 <span class=\"red\">가입되어 있지 않습니다.</span>"
    }

    out = generate_reports([test_customer], "/tmp/test_report.zip")
    print(f"Generated: {out}")
