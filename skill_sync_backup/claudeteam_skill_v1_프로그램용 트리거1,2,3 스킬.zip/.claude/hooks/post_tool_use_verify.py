#!/usr/bin/env python3
"""
PostToolUse Hook — Bash 호출 후 산출물 정합 검증
exec/import/python3 호출 후 output/ 영역 산출물 자동 검증.

본 Hook은 본 클로드 자체 임의 양식 변경 (직전 결함) 사후 검출 본질.
"""
import json
import sys
import os
import re


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    tool_input = data.get("tool_input", {})
    command = tool_input.get("command", "")

    # python·python3·exec 호출 영역만 검증 대상
    if not re.search(r"\b(python|python3|exec)\b", command, re.IGNORECASE):
        sys.exit(0)

    # 본 영역의 트리거 본문 감지
    is_trigger_call = any(
        keyword in command
        for keyword in [
            "build_v8_main",
            "build_v8_table",
            "pre_report_gen",
            "replace_jeonansu_reference",
            "verify.py",
            "skin_preview_gen",
        ]
    )
    if not is_trigger_call:
        sys.exit(0)

    # 산출물 영역 검증
    output_dir = "output"
    if not os.path.isdir(output_dir):
        sys.exit(0)

    issues = []

    # 합의 양식 영역 정합 (PNG·HTML 영역만)
    for root, dirs, files in os.walk(output_dir):
        for f in files:
            full = os.path.join(root, f)
            if f.endswith(".html"):
                try:
                    with open(full, "r", encoding="utf-8", errors="ignore") as fp:
                        content = fp.read(200000)  # 처음 200KB
                    # 합의 양식 영역 — Nanum Gothic 폰트 검증
                    if "font-family" in content and "Nanum Gothic" not in content and "nanum" not in content.lower():
                        # base_template.html 영역 — Nanum Gothic 본문 의무
                        if "toss_insureport" in f.lower():
                            issues.append(f"WARNING: {f} — Nanum Gothic 폰트 ❌. 합의 양식 영역 검증 필요")
                except Exception:
                    pass

    if issues:
        msg = "POST-VERIFY 영역 결함 검출:\n" + "\n".join(issues)
        msg += "\n→ 합의 양식 정합 검증 의무 (절대 룰 4번)"
        print(msg, file=sys.stderr)
        # exit 2 ❌ — 경고만 (PostToolUse는 차단 ❌, 본 클로드 후속 영역 영향)

    sys.exit(0)


if __name__ == "__main__":
    main()
