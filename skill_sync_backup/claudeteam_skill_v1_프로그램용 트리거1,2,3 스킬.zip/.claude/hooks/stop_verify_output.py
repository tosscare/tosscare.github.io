#!/usr/bin/env python3
"""
Stop Hook — 본 클로드 "완료" 보고 시 산출물 영역 사용자 시점 검증 강제
output/ 영역의 합의 양식 정합 영역 자동 검증.

본 Hook은 본 클로드 자체 "데이터 정합 ✅" 종결 영역 차단 + 사용자 시점 검증 강제 본질 (절대 룰 4번).
"""
import json
import sys
import os
import re


def check_output_integrity():
    """output/ 영역 산출물 사용자 시점 검증."""
    output_dir = "output"
    if not os.path.isdir(output_dir):
        return []

    issues = []

    # 1. HTML 산출물 영역 — 합의 양식 영역 검증
    for root, dirs, files in os.walk(output_dir):
        for f in files:
            full = os.path.join(root, f)
            if f.endswith(".html") and "toss_insureport" in f.lower():
                try:
                    with open(full, "r", encoding="utf-8", errors="ignore") as fp:
                        content = fp.read(500000)
                    # 합의 양식 영역 검증
                    checks = {
                        "Nanum Gothic 폰트": "Nanum Gothic" in content or "nanum" in content.lower(),
                        "data-skin 영역": re.search(r'data-skin="[1-5]"', content) is not None,
                        "Google Fonts preconnect": "fonts.googleapis.com" in content or "nanum" in content.lower(),
                    }
                    for name, ok in checks.items():
                        if not ok:
                            issues.append(f"  - {f}: {name} ❌")
                except Exception as e:
                    issues.append(f"  - {f}: 읽기 ❌ ({e})")

    return issues


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)

    # 무한 루프 방지
    if data.get("stop_hook_active"):
        sys.exit(0)

    issues = check_output_integrity()

    if issues:
        msg = "STOP-VERIFY 사용자 시점 검증 영역 결함 검출:\n"
        msg += "\n".join(issues)
        msg += "\n\n→ 합의 양식 정합 의무 (절대 룰 4번). 정정 진행 의무."
        print(msg, file=sys.stderr)
        # exit 2 — 본 클로드 영역 재진행 (Stop 차단)
        sys.exit(2)

    sys.exit(0)


if __name__ == "__main__":
    main()
