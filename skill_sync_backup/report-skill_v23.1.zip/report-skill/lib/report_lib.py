# -*- coding: utf-8 -*-
"""
report_lib.py — 상담자료(toss_insureport) v23 빌더 라이브러리
================================================================

[용도]
    확정 베이스(templates/base_report_10yr.html)에 spec(dict) 1개를 적용해 상담자료 HTML을 산출한다.
    이 세션(조원오·홍희정·박정무·김형준)에서 확정된 산출물의 빌더를 함수로 추출한 것 — 레이아웃·CSS·문안은 산출물 그대로.
    고객 작업 = examples/spec_report_*.py 를 복사해 값만 교체 → `python3 spec_xxx.py` 1회 실행.

[주의 — 다른 클로드가 이 파일을 수정·실행할 때 반드시 확인]
    1. 라이브러리(import 전용). 실행은 spec 파일에서 build_report(spec) 호출.
    2. 모든 앵커 교체는 zr()의 count 검증을 거친다 — 실패 시 즉시 AssertionError (추측 교체 ❌).
    3. 함수 시그니처·spec 키 이름 변경 시 references/report_conditions.md 동시 갱신.
    4. 베이스 전체 view ❌ (9.5MB). 앵커 확인은 grep으로.

[spec 키 요약] (상세 = references/report_conditions.md)
    name, birth8, hero, product, tabs, chips, coverage, panels, modal_src, existing, adequacy,
    pcmp, sec3, hwang, modal_img, hl, driver, pdf_pages, residual, out
"""
import re, io, os, json, base64, subprocess
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
BASE_10YR = os.path.join(SKILL, 'templates', 'base_report_10yr.html')
B = '<b style="color:#E04848;font-weight:800;">'          # 전문가의견 강조 (상담자료)
BADGE = '<span class="cov-row-label cov-row-label-enhance" style="margin-right:6px;vertical-align:middle;">★강화</span>'
BLUE = '#3182F6'; RD = '#E04848'
TH = 'background:#F4F6F9;font-weight:700;padding:6px 6px;border:1px solid var(--gray-200);font-size:11px;text-align:center;'
TD = 'padding:6px 6px;border:1px solid var(--gray-200);font-size:11px;text-align:center;line-height:1.5;'
TDL = TD + 'text-align:left;'
CB = 'color:#1E7FD6;'; CP = 'color:#C2185B;'
CLS = {'실손의료비보장': 'cat-silson', '실손의료비보장 (3대 비급여)': 'cat-silson', '암관련보장': 'cat-cancer', '뇌혈관관련': 'cat-brain', '심장관련': 'cat-heart', '수술관련': 'cat-surgery', '상해/기타보장': 'cat-injury'}

# ─────────────────────────────── 공통 유틸 ───────────────────────────────
def cnt(z, old, n, label=''):
    c = z.count(old); assert c == n, f"[{label}] {c}!={n} :: {old[:70]!r}"
def zr(z, old, new, n=1, label=''):
    cnt(z, old, n, label); return z.replace(old, new)
def b64img(path, fmt='PNG'):
    im = Image.open(path).convert('RGB'); buf = io.BytesIO()
    im.save(buf, fmt, **({'optimize': True} if fmt == 'PNG' else {'quality': 88}))
    return f'data:image/{fmt.lower()};base64,' + base64.b64encode(buf.getvalue()).decode()
def b64jpg(im):
    buf = io.BytesIO(); im.convert('RGB').save(buf, 'JPEG', quality=82)
    return "'data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode() + "'"
def fn(h, name):
    a = h.find(f'function {name}('); b = h.find('\n}\n', a) + 3; return h[a:b]
def won(v): return f'{v:,}'

# ─────────────────────────────── 0. 식별 ───────────────────────────────
def apply_identity(s, name, birth8, hero):
    """hero = '남성 · 만 46세 (1980.04.09년생 · 보험나이 47세)<br>보험기간 ~2069-10-27 (90세 만기 · 20년납)'"""
    s = zr(s, '심은정', name, 16, 'name'); s = zr(s, '19890201', birth8, 2)
    s = zr(s, '여성 · 만 38세 (1989.02.01년생)<br>직업: 주부 (상해 1급)<br>보험기간 ~2079-02-01 (90세 만기)', hero)
    return s

# ─────────────────────────────── 1. 탭 ───────────────────────────────
def apply_tabs(s, tabs):
    """tabs = {'count':2|3, 'rec':'min'|'mid'|'max'|None, 'price':{'min':'38,380','mid':..,'max':..},
               'min_name':'기존보험동일', 'min_desc':..., 'cover':{'mid':'필요보장 70% 구성'}, 'fill':{'min':40,'mid':70,'max':100},
               'min_diff':'기존대비 −142,116원 (실손포함)'|None, 'discount_last':{'mid':'162,270','max':'194,540'}|None,
               'total':{'min':'24,631,200','mid':..,'max':..}, 'min_note':'월보험료 15만원 이상 절감'|None}
       base 원값: min 38,380 / mid 110,050 / max 135,270 · 완성도 20%미만/80%/100% · 추천 = max"""
    p = tabs['price']
    if tabs['count'] == 2:   # min 탭·패널 제거 → mid=탭1 / max=탭2
        tab_min = s[s.find('<button class="tab-btn ripple-host active" id="tab-min"'):s.find('<button class="tab-btn ripple-host" id="tab-mid"')]
        s = s.replace(tab_min, ''); s = zr(s, '<div class="tab-bar" data-tab-count="3">', '<div class="tab-bar" data-tab-count="2">')
        pa = s.find('<div class="panel active" id="panel-min">'); pa = s.rfind('<!--', 0, pa); pb = s.find('id="panel-mid"'); pb = s.rfind('<!--', 0, pb)
        assert 0 < pa < pb and (pb - pa) < 60000; s = s[:pa] + s[pb:]
        s = zr(s, '<div class="panel" id="panel-mid">', '<div class="panel active" id="panel-mid">')
        s = zr(s, '<button class="tab-btn ripple-host" id="tab-mid" onclick="go(\'mid\')">', '<button class="tab-btn ripple-host active" id="tab-mid" onclick="go(\'mid\')">')
        s = zr(s, "['min','mid','max'].forEach", "['mid','max'].forEach", 2)
        s = zr(s, "  var tabs = ['min', 'mid', 'max'];", "  var tabs = ['mid', 'max'];")
        s = zr(s, "    if (t === 'min') {\n      tDiff.textContent = '';\n      tDiff.className = 't-diff';\n    } else {", "    if (t === 'mid') {\n      tDiff.textContent = '';\n      tDiff.className = 't-diff';\n    } else {")
        s = zr(s, "    updateTabColors('min');", "    updateTabColors('mid');")
        s = zr(s, "    [['mid','min'],['max','mid']].forEach(function(pair){", "    [['max','mid']].forEach(function(pair){")
        s = zr(s, "  var colorMode = (plan === 'mid') ? 'v19_vs_min' : (plan === 'max' ? 'v19_vs_mid' : null);", "  var colorMode = (plan === 'max') ? 'v19_vs_mid' : null;")
        s = zr(s, '<div class="plan-label-title">기존보장동일 대비 보강된 항목</div>', '<div class="plan-label-title">기존보험 대비 보강된 항목</div>')
    else:
        s = zr(s, '기존보장동일', tabs.get('min_name', '기존보험동일'), 8)
        if tabs.get('min_desc'): s = zr(s, '기존보험과 동일한 보장 구성 / 보험료는 낮으나 보장 완성 X', tabs['min_desc'])
        s = zr(s, '38,380', p['min'], 5)
        if tabs.get('total'): s = zr(s, '9,211,200', tabs['total']['min'])
        if tabs.get('min_note'): s = zr(s, '월보험료 3만원 이상 절감', tabs['min_note'])
        if tabs.get('min_diff'):
            s = zr(s, "    if (t === 'min') {\n      tDiff.textContent = '';\n      tDiff.className = 't-diff';\n    } else {", f"    if (t === 'min') {{\n      tDiff.textContent = '{tabs['min_diff']}';\n      tDiff.className = 't-diff t-diff-down';\n    }} else {{")
        if tabs.get('fill', {}).get('min') is not None:
            s = zr(s, 'id="prog-fill-min" style="--target-w:20%"', f'id="prog-fill-min" style="--target-w:{tabs["fill"]["min"]}%"')
        if tabs.get('min_cover'): s = zr(s, '필요보장 20%미만 구성', tabs['min_cover']); s = zr(s, '필요보장 20% 미만', tabs['min_cover'])
    s = zr(s, '110,050', p['mid'], 5); s = zr(s, '135,270', p['max'], 5)
    if tabs['count'] == 2: s = zr(s, "var PLAN_LABELS = { min: '기존보장동일 (38,380원)',", "var PLAN_LABELS = { min: '',")
    if tabs.get('total'):
        s = zr(s, '26,412,000', tabs['total']['mid']); s = zr(s, '32,464,800', tabs['total']['max'])
    if tabs.get('cover', {}).get('mid'): s = zr(s, '필요보장 80% 구성', tabs['cover']['mid'], 2)
    if tabs.get('cover', {}).get('max'): s = zr(s, '필요한 보장 완성 (100%)', tabs['cover']['max'], 2)   # 예: '필요한 보장 완성 (90%)' (홍희정)
    fill = tabs.get('fill', {})
    if fill.get('mid') is not None: s = zr(s, 'id="prog-fill-mid" style="--target-w:70%"', f'id="prog-fill-mid" style="--target-w:{fill["mid"]}%"')
    if fill.get('max') is not None: s = zr(s, 'id="prog-fill-max" style="--target-w:90%"', f'id="prog-fill-max" style="--target-w:{fill["max"]}%"')
    # 추천 뱃지 (base = max)
    rec = tabs.get('rec')
    if rec != 'max':
        s = zr(s, '<button class="tab-btn ripple-host" id="tab-max" data-rec="1" onclick="go(\'max\')">', '<button class="tab-btn ripple-host" id="tab-max" onclick="go(\'max\')">')
        s = zr(s, '<div class="plan-card reveal rec" id="plan-card-max">', '<div class="plan-card reveal" id="plan-card-max">')
        s = zr(s, '<div><span class="rec-badge">★ 추천</span><div class="plan-name">full보장플랜</div>', '<div><div class="plan-name">full보장플랜</div>')
        if rec == 'mid':
            act = ' active' if tabs['count'] == 2 else ''
            s = zr(s, f'<button class="tab-btn ripple-host{act}" id="tab-mid" onclick="go(\'mid\')">', f'<button class="tab-btn ripple-host{act}" id="tab-mid" data-rec="1" onclick="go(\'mid\')">')
            s = zr(s, '<div class="plan-card reveal" id="plan-card-mid">', '<div class="plan-card reveal rec" id="plan-card-mid">')
            s = zr(s, '<div><div class="plan-name">안심보장플랜</div>', '<div><span class="rec-badge">★ 추천</span><div class="plan-name">안심보장플랜</div>')
    # 추가할인 문구 (추가할인 자료 첨부 시 — 마지막 해 보험료)
    dl = tabs.get('discount_last')
    if dl:
        for t, v in dl.items():
            cls = 't-diff t-diff-up' if t != 'min' else 't-diff'
            s = zr(s, f'<span class="{cls}" id="t-diff-{t}"></span>', f'<span class="{cls}" id="t-diff-{t}"></span>\n      <span class="t-diff t-diff-down" style="color:var(--toss-red);font-weight:700;">{v}원으로 추가할인</span>')
    return s

def apply_chips(s, chips):
    """chips = {'mid':[...], 'max':[...]} — mid = plan-label-add(+) / max = plan-label-enhance(★)"""
    for idname, cls, key in [('plan-label-chips-mid', 'plan-label-add', 'mid'), ('plan-label-chips-max', 'plan-label-enhance', 'max')]:
        if key not in chips: continue
        i = s.find(f'id="{idname}"'); i = s.find('>', i) + 1; j = s.find('</div>', i)
        s = s[:i] + '\n' + '\n'.join(f'<span class="plan-label {cls}">{t}</span>' for t in chips[key]) + '\n    ' + s[j:]
    return s

# ─────────────────────────────── 2. 담보 JSON (단일 소스) ───────────────────────────────
EMPTY_COV = {'cancer': [], 'brain': [], 'heart': [], 'surgery': [], 'injury': [], 'care': []}
def jsdump(C): return '{' + ', '.join(f'{k}:' + json.dumps(v, ensure_ascii=False) for k, v in C.items()) + '}'
def apply_coverage(s, cov):
    """cov = {'min': C|None, 'mid': C, 'max': C}  C = {'cancer':[[name, per, '', amt],...], ...}"""
    i0 = s.find('min: {cancer:'); i3 = s.find('care:[]}', s.find('max: {cancer:')) + len('care:[]}')
    g = lambda k: jsdump(cov.get(k) or EMPTY_COV)
    return s[:i0] + 'min: ' + g('min') + ', mid: ' + g('mid') + ', max: ' + g('max') + s[i3:]

# ─────────────────────────────── 3. 패널 cov-wrap ───────────────────────────────
def panel_bounds(h, name):
    a = h.find(f'id="panel-{name}"'); a = h.rfind('<div class="panel', 0, a)
    b = h.find('<!-- ══════════ COMMON NOTICES') if name == 'max' else h.rfind('<!--', 0, h.find(f'id="panel-{"mid" if name == "min" else "max"}"'))
    return a, b
def get_cov(h, name):
    a, b = panel_bounds(h, name); p = h[a:b]
    return a + p.find('<div class="cov-wrap">'), a + p.find('<div class="detail-btn-wrap">')
def set_cov(s, name, cov_html):
    c0, c1 = get_cov(s, name); return s[:c0] + cov_html + s[c1:]
def replace_cards(s, name, cards_html):
    """cov-wrap 내부 cov-card 전체를 cards_html로 교체 (헤더/접기버튼·꼬리 보존). cards_html 마지막 카드는 '</div></div>'로 닫힌 상태로 전달."""
    c0, c1 = get_cov(s, name); cov = s[c0:c1]
    k0 = cov.find('<div class="cov-card'); suf = cov[cov.rfind('data-cat="injury"></div>') + len('data-cat="injury"></div>'):]
    assert suf.startswith('</div></div>'), suf[:40]
    assert cards_html.endswith('</div></div>'); cards_html = cards_html[:-len('</div></div>')]
    return s[:c0] + cov[:k0] + cards_html + suf + s[c1:]

# 카드 빌더 (탭1 기존보험동일·KB라이프 등 커스텀 패널용)
def sc(t, a, d, grey=False):
    if grey: return f'<div class="sc-card" style="background:rgba(49,130,246,0.05);"><div class="sc-title" style="color:var(--gray-500);">{t}</div><div class="sc-detail">{d}</div></div>'
    return f'<div class="sc-card"><div class="sc-title">{t}</div><div class="sc-amt">{a}</div><div class="sc-detail">{d}</div></div>'
def gi(rows, key): return f'<div class="guarantee-info {key}-guarantee">' + ''.join(f'<div class="gi-row"><span class="gi-icon">{ic}</span><span class="gi-text">{t}</span></div>' for ic, t in rows) + '</div>'
ICON = {'cancer': ('ico-c', '🎗️'), 'brain': ('ico-b', '🧠'), 'heart': ('ico-h', '❤️'), 'surgery': ('ico-s', '🔬'), 'injury': ('ico-i', '🛡️')}
def card(key, cat, sub, maxv, maxl, scs, gis, plan, after='', badge=False):
    ico_cls, ico = ICON[key]
    h = f'<div class="cov-card reveal"><div class="cov-hd ripple-host" onclick="tog(this)"><div class="cov-ico {ico_cls}">{ico}</div><div class="cov-hd-info"><div class="cov-cat">{cat}</div><div class="cov-sub">{sub}</div></div><div class="cov-max"><div class="cov-max-v">{BADGE if badge else ""}{maxv}</div><span class="cov-max-l">{maxl}</span></div><div class="tog">▼</div></div><div class="cov-detail"><div class="sc-wrap">'
    h += ''.join(scs) + (gi(gis, key) if gis else '') + '</div>'
    h += f'<div class="items-title">담보 상세 내역</div><div class="rows-auto" data-plan="{plan}" data-cat="{key}"></div>' + after
    return h + '</div></div>'
def tongap_table(title, names, amt, note='※ 분류별 세부 대상 암은 약관 기준'):
    rows = ''.join(f'<tr class="surg-row-{(k % 5) + 1}"><td class="surg-type" style="white-space:nowrap;">{n}</td><td class="surg-ex" style="line-height:1.9;">{amt}</td></tr>' for k, n in enumerate(names))
    return f'<div class="surg-table-wrap" style="margin-top:18px;"><div class="surg-table-title">📋 {title}</div><table class="surg-table"><tbody>{rows}</tbody></table><div class="surg-note" style="margin-top:6px;font-size:11px;color:var(--gray-500);">{note}</div></div>'
def surg_tail(s):
    """베이스 수술 카드 꼬리(매회 지급 문구 + 1~5종 분류표) 추출 — 커스텀 수술 카드 after 용"""
    i = s.find('<div class="repeat-notice" style="margin-top:14px;">※ 질병·상해 수술 발생 시마다 매회 지급</div><div class="surg-table-wrap"')
    j = s.find('</table></div>', i) + len('</table></div>'); return s[i:j]

BASEV = {'mid': dict(tong='2,000만원', yus='400만원', ct2='4,000만원', circ='5,000만원', brain='2,000만원', heart='2,000만원'),
         'max': dict(tong='3,000만원', yus='600만원', ct2='1억원', circ='1억원', brain='2,000만원', heart='2,000만원')}
def patch_meritz_cov(s, plan, P, source='max'):
    """메리츠 5.10.5 계열 — 베이스 패널(source = 'max': 161 순환계 1억·암통합치료비Ⅱ 1억 / 'mid': 151 순환계 5,000만·암통합치료비Ⅱ 4,000만) 카드를 수치만 패치해 plan 패널로.
       P = {'tong','yus','brain','heart' (진단비), 'ct2': False(암 통합치료비Ⅱ 표 제거 · 2탭형) | True(유지), 'cancer_treat_detail', 'cancer_treat_amt'(ct2 False 시),
            'circ_amt'(순환계 한도 = 베이스값 유지 권장), 'badge':['brain','heart'], 'plus_surgery':bool, 'injury_detail':str|None, 'cancer_max_l'}
       ※ 베이스 패널 원형을 읽으므로 호출 순서 = mid → max (max 패널을 먼저 바꾸면 source 'max' 재사용 불가)"""
    c0, c1 = get_cov(s, source); cov = s[c0:c1]; BV = BASEV[source]
    tong, yus, brain, heart = P['tong'], P['yus'], P['brain'], P['heart']; circ = P.get('circ_amt', BV['circ'])
    if tong != BV['tong']:
        cov = zr(cov, f'분류별 각 {BV["tong"]}', f'분류별 각 {tong}', 2)
        cov = zr(cov, f'<td class="surg-ex" style="line-height:1.9;">{BV["tong"]}</td>', f'<td class="surg-ex" style="line-height:1.9;">{tong}</td>', 5, '분류표')
    if yus != BV['yus']: cov = zr(cov, f'5개 분류 각 지급 · 유사암 {BV["yus"]}', f'5개 분류 각 지급 · 유사암 {yus}')
    HD = f'<div class="cov-sub">진단비 + 통합·항암치료</div></div><div class="cov-max"><div class="cov-max-v">{BV["ct2"]}</div><span class="cov-max-l">암 통합치료비Ⅱ(연간 한도)</span>'
    SC = f'<div class="sc-amt">연간 최대 {BV["ct2"]}</div><div class="sc-detail">암 통합치료비Ⅱ(비급여·암중점치료기관) 연간 한도 + 비급여 암·항암 치료비(10년간) + 표적항암 5,000만원(비갱신) 등</div>'
    if P.get('ct2', True):
        cov = zr(cov, HD, f'<div class="cov-sub">진단비 + 통합·항암치료</div></div><div class="cov-max"><div class="cov-max-v">분류별 각 {tong}</div><span class="cov-max-l">통합암진단비 5분류(전이포함) + 치료비 연 {BV["ct2"]}</span>')
        cov = zr(cov, SC, f'<div class="sc-amt">연간 최대 {BV["ct2"]}</div><div class="sc-detail">{P["cancer_treat_detail"]}</div>')
    else:
        cov = zr(cov, HD, f'<div class="cov-sub">진단비 + 항암치료비</div></div><div class="cov-max"><div class="cov-max-v">분류별 각 {tong}</div><span class="cov-max-l">{P.get("cancer_max_l", "통합암진단비 5분류(전이포함) + 표적·면역항암 각 1억")}</span>')
        cov = zr(cov, SC, f'<div class="sc-amt">{P["cancer_treat_amt"]}</div><div class="sc-detail">{P["cancer_treat_detail"]}</div>')
        k0 = cov.find('<div class="surg-table-wrap" style="margin-top:18px;"><div class="surg-table-title">📋 암 통합치료비Ⅱ'); k1 = cov.find('세부내용은 약관 참조</div></div>', k0) + len('세부내용은 약관 참조</div></div>')
        assert 0 < k0 < k1 and (k1 - k0) < 6000; cov = cov[:k0] + cov[k1:]
    if brain != BV['brain']: cov = zr(cov, f'<div class="sc-title">뇌혈관질환 진단 시</div><div class="sc-amt">{BV["brain"]}</div>', f'<div class="sc-title">뇌혈관질환 진단 시</div><div class="sc-amt">{brain}</div>')
    if heart != BV['heart']: cov = zr(cov, f'<div class="sc-title">허혈성심장질환 진단 시</div><div class="sc-amt">{BV["heart"]}</div>', f'<div class="sc-title">허혈성심장질환 진단 시</div><div class="sc-amt">{heart}</div>')
    cov = zr(cov, '상급종합병원·권역심뇌혈관질환센터 특정순환계질환 통합치료비 + 혈전용해치료비 3,000만원', f'상급종합병원·권역심뇌혈관질환센터 특정순환계질환 통합치료비 연간 한도 {circ} + 혈전용해치료비 3,000만원 + 기계적혈전제거술치료비 500만원', 2)
    bd = P.get('badge', [])
    cov = zr(cov, f'<div class="cov-cat">뇌혈관 보장</div><div class="cov-sub">진단비 + 순환계 통합치료</div></div><div class="cov-max"><div class="cov-max-v">{BV["circ"]}</div><span class="cov-max-l">특정순환계질환 통합치료비(연간)</span>', f'<div class="cov-cat">뇌혈관 보장</div><div class="cov-sub">진단비 + 순환계 통합치료</div></div><div class="cov-max"><div class="cov-max-v">{BADGE if "brain" in bd else ""}{brain}</div><span class="cov-max-l">뇌혈관질환진단비 + 순환계 통합치료비 연 {circ}</span>')
    cov = zr(cov, f'<div class="cov-cat">심장질환 보장</div><div class="cov-sub">진단비 + 순환계 통합치료</div></div><div class="cov-max"><div class="cov-max-v">{BV["circ"]}</div><span class="cov-max-l">특정순환계질환 통합치료비(연간)</span>', f'<div class="cov-cat">심장질환 보장</div><div class="cov-sub">진단비 + 순환계 통합치료</div></div><div class="cov-max"><div class="cov-max-v">{BADGE if "heart" in bd else ""}{heart}</div><span class="cov-max-l">허혈성심장질환진단비 + 순환계 통합치료비 연 {circ}</span>')
    if circ != BV['circ']:
        cov = zr(cov, f'연간 최대 {BV["circ"]}</div><div class="sc-detail">상급종합병원', f'연간 최대 {circ}</div><div class="sc-detail">상급종합병원', 2)
        cov = zr(cov, f'특정순환계질환 통합치료비 ({BV["circ"]}) — 항목별 지급 구성', f'특정순환계질환 통합치료비 ({circ}) — 항목별 지급 구성', 2)
        cov = zr(cov, f'합산 연간 총 {BV["circ"]} 한도 지급', f'합산 연간 총 {circ} 한도 지급', 2)
    if P.get('plus_surgery'):
        cov = zr(cov, '<div class="cov-max-v">1,000만원</div><span class="cov-max-l">질병·상해 1~5종 수술비(5종)</span>', '<div class="cov-max-v">1,000만원</div><span class="cov-max-l">질병·상해 1~5종 수술비(5종) + 수술비·plus 수술비</span>')
        cov = zr(cov, '질병 1~5종 수술비 + 질병수술비 20만원 · 질병 plus 수술비(연간2회이상)', '질병 1~5종 수술비(1종 10만·2종 30만·3종 100만·4종 500만·5종 1,000만원) + 질병수술비 20만원 + 질병 plus 수술비(연간2회이상 시 10~300만원 추가)')
        cov = zr(cov, '상해 1~5종 수술비 + 상해수술비 100만원 · 상해 plus 수술비(연간2회이상)', '상해 1~5종 수술비(1종 20만·2종 30만·3종 100만·4종 500만·5종 1,000만원) + 상해수술비 100만원 + 상해 plus 수술비(연간2회이상 시 10~300만원 추가)')
    else:
        cov = zr(cov, '질병 1~5종 수술비 + 질병수술비 20만원 · 질병 plus 수술비(연간2회이상)', P.get('surg_d', '질병 1~5종 수술비(1종 20만·2종 30만·3종 100만·4종 500만·5종 1,000만원) + 질병수술비 20만원'))
        cov = zr(cov, '상해 1~5종 수술비 + 상해수술비 100만원 · 상해 plus 수술비(연간2회이상)', P.get('surg_i', '상해 1~5종 수술비(1종 20만·2종 30만·3종 100만·4종 500만·5종 1,000만원) + 상해수술비 100만원'))
    if P.get('injury_detail'):
        cov = zr(cov, '골절 진단·수술비 · 5대골절 · 화상 진단·수술비 · 중증화상및부식진단비 3,000만원 · 깁스치료비 · 중환자실입원일당 10만원', P['injury_detail'])
    tabid = {'min': 'cov-list-tab1', 'mid': 'cov-list-tab2', 'max': 'cov-list-tab3'}
    cov = cov.replace(f'data-plan="{source}"', f'data-plan="{plan}"').replace(tabid[source], tabid[plan])
    return cov

def apply_modal_from(s, src_html):
    """(v23 베이스에 내장됨 — 구 베이스 사용 시에만) 설계상세 모달 함수 이식 — src = 김주애님 산출본 경로."""
    K = open(src_html, encoding='utf-8').read()
    for name in ['buildPdfContent', 'buildTable']: s = s.replace(fn(s, name), fn(K, name))
    s = zr(s, "function parseAmt(s){ return parseInt(String(s||'').replace(/[^0-9]/g,''),10)||0; }", "function parseAmt(s){ s=String(s||''); var eok=s.match(/([0-9,\\.]+)\\s*억/); var man=s.match(/([0-9,\\.]+)\\s*만/); if(eok||man){ return (eok?parseFloat(eok[1].replace(/,/g,''))*10000:0)+(man?parseFloat(man[1].replace(/,/g,'')):0); } return (parseInt(s.replace(/[^0-9]/g,''),10)||0)/10000; }")
    return s

# ─────────────────────────────── 4. 기존보험현황 ───────────────────────────────
def op(items): return '<div class="exi-op"><div class="exi-op-t">[전문가의견]</div>' + ''.join(f'<div class="exi-op-item"><span class="exi-op-n">{k}.</span><span>{t.replace("<strong>", B).replace("</strong>", "</b>")}</span></div>' for k, t in enumerate(items, 1)) + '</div>'
def cov_row(name, amt, hl=False, blue=False): return '<div class="cov-row %s"%s><span class="cov-name">%s</span><span class="cov-amt">%s</span></div>' % ('cov-hl' if hl else '', ' style="color:#1E5FCC;"' if blue else '', name, amt)
def cat_block(cls, title, rows): return '<div class="cat-block %s"><div class="cat-title">%s</div>%s</div>' % (cls, title, ''.join(rows))
def ins(label, price, body): return '<div class="ins-row" data-ins-row><div class="ins-head" data-ins-toggle><div class="ins-label">%s</div><div class="ins-price-wrap"><span class="ins-price">%s</span><span class="ins-caret">▼</span></div></div><div class="ins-body">%s</div></div>' % (label, price, body)
def price_label(p):
    """CRM PAGES['pay'] → '85,240원 (월납)' / '72,400원 (월납 · 납입완료)' / '889원 (일시납)' / 자동차 '0원 (자동차보험)'"""
    if p.get('price_override'): return p['price_override']
    pay = p['pay']; amt_ = pay.split(' 원')[0]
    return amt_ + '원 (' + ('월납 · 납입완료' if '납입완료' in pay else ('일시납' if '일시납' in pay else '월납')) + ')'

def renew_block(name, title, rows, avg, foot_red='유효보장 : 암진단 3천', foot_blue='내는돈 &gt; 받는돈'):
    """갱신 예시표 — 전치형(기간 가로) · 해당 갱신형 보험 ins-body 하단(전문가의견 아래). rows=[('1~15년','19,257원','3,466,260원'),...] avg=('월평균 월보험료','월평균 누적')"""
    th = ''.join(f'<th style="text-align:center;">{r[0]}</th>' for r in rows)
    r1 = ''.join(f'<td style="text-align:center;">{r[1]}</td>' for r in rows); r2 = ''.join(f'<td style="text-align:center;">{r[2]}</td>' for r in rows)
    return ('<div class="renewal-wrap" style="margin:14px 2px 4px;border:1px solid var(--gray-200);border-radius:10px;overflow:hidden;background:#fff;"><div style="padding:12px 14px 3px;font-size:13.5px;font-weight:800;color:var(--gray-900);"># 기간경과에 따른 보험료 갱신(인상) 안내</div>'
            f'<div style="padding:0 14px 10px;font-size:11.5px;color:var(--gray-600);font-weight:600;">[{name}님] {title}</div><div style="overflow-x:auto;">'
            f'<table class="gp-table" style="border-left:none;border-right:none;border-radius:0;min-width:520px;"><thead><tr><th style="width:16%;">구분</th>{th}<th style="background:#F1F3F5;">월평균</th></tr></thead><tbody>'
            f'<tr><td style="font-weight:800;background:var(--gray-50);">월보험료</td>{r1}<td style="font-weight:700;background:var(--gray-50);">{avg[0]}</td></tr>'
            f'<tr><td style="font-weight:800;background:var(--gray-50);">누적보험료</td>{r2}<td style="color:var(--toss-red);font-weight:800;background:var(--gray-50);">{avg[1]}</td></tr></tbody></table></div>'
            f'<div style="padding:11px 14px;border-top:1px solid var(--gray-200);font-size:12.5px;line-height:1.8;text-align:center;"><span style="color:var(--toss-red);font-weight:800;">{foot_red}</span><br><span style="color:var(--toss-blue);font-weight:800;">{foot_blue}</span></div></div>')

def cancel_block(total, rows, asof):
    """실효/해지 계약 현황 — 리스트형(모바일 안전). rows = [NO,상태,회사,상품명,계약일,납입주기,납입기간,만기,월보험료] (CRM cancel_keep 형식)"""
    return ('<div class="cancel-block" style="margin:18px 2px 6px;padding:12px 14px 10px;border:1px solid var(--gray-200);border-radius:10px;background:#FFF8F6;">'
            f'<div style="font-size:12.5px;font-weight:800;color:#E04848;margin-bottom:8px;">실효/해지 계약 현황 — 총 {total}</div>'
            + ''.join(f'<div style="padding:7px 0;border-top:1px solid var(--gray-200);font-size:11.5px;line-height:1.6;"><div><span style="font-weight:800;color:var(--gray-700);">{r[2]}</span> <span style="font-weight:700;">{r[3]}</span></div><div style="color:var(--gray-600);">계약일 {r[4]} · 납입기간 {r[6]} · 만기 {r[7]} · 월 보험료 <span style="color:#E04848;font-weight:800;">{r[8]}</span> · <span style="display:inline-block;padding:0 6px;border-radius:8px;background:#FDE2E2;color:#C62828;font-weight:800;">{r[1]}</span></div></div>' for r in rows)
            + f'<div style="font-size:11px;color:var(--gray-500);margin-top:6px;border-top:1px solid var(--gray-200);padding-top:6px;">※ 실효/해지 계약은 납입 완료 및 납입 예정 보험료가 제공되지 않고 월납 보험료의 단순 합계 값만 제공됩니다. (보험조회 기준일 {asof})</div></div>')

def _sil_row(cells, sts=None): return '<tr>' + ''.join(f'<td style="{(sts[i] if sts else TD)}">{c}</td>' for i, c in enumerate(cells)) + '</tr>'
def _sil_row2(cells): return '<tr>' + ''.join(f'<td{" colspan=\"2\"" if i == 0 else ""} style="{TD}">{c}</td>' for i, c in enumerate(cells)) + '</tr>'
SIL_ROWS_5G = [('[갱신형] 실손의료비(상해급여형) : 20% or 2만', '5,000만원', 'background:#E8D5F5;'), ('[갱신형] 실손의료비(질병급여형) : 20% or 2만', '5,000만원', 'background:#E8D5F5;'),
 ('[갱신형] 실손의료비(중증,상해비급여형) : 30% or 3만', '5,000만원', 'background:#E8D5F5;'), ('[갱신형] 실손의료비(중증,질병비급여형) : 30% or 3만', '5,000만원', 'background:#E8D5F5;'),
 ('[갱신형] 실손의료비(중증,3대비급여형 : 도수,충격파,주사,MRI) : 30%', '350만원', 'background:#CDEFC4;'), ('[갱신형] 실손의료비(비중증,상해비급여형) : 50% or 5만', '1,000만원', 'background:#CFE2F3;'),
 ('[갱신형] 실손의료비(비중증,질병비급여형) : 50% or 5만', '1,000만원', 'background:#CFE2F3;'), ('[갱신형] 실손의료비(비중증,비급여자기공명영상진단) : 50% or 5만', '200만원', 'background:#CFE2F3;')]
def sil_block(S):
    """실손 전환 안내 블록 + HTML 표(5세대 표준형 · 출생전/후 열 ❌). 실손 포함 보험 ins-body 하단(전문가의견 아래).
       S = {'gen':'1세대','old_co':'삼성Super보험 포함','new_co':'삼성','old':'85,240','new':'20,452','diff':'64,788','save':'1년에 75~80만원','title_co':'삼성', 'rows':SIL_ROWS_5G(기본)}"""
    rows = S.get('rows', SIL_ROWS_5G)
    t1 = ('<div style="font-size:12px;font-weight:800;color:#E8731A;margin:12px 0 4px;">보장내용 및 가입금액</div><div style="font-size:11px;font-weight:700;margin:4px 0;">[<span style="' + CB + '">기본형</span> (급여 실손의료비)]</div>'
     '<table style="width:100%;border-collapse:collapse;"><thead><tr>' + ''.join(f'<th style="{TH}">{h}</th>' for h in ['종목', '보장내용', '가입금액(만원)']) + '</tr></thead><tbody>'
     + _sil_row([f'<span style="white-space:nowrap;">상해 <span style="{CB}">급여</span></span>', f'피보험자가 상해로 의료기관에 입원 또는 통원하여 <span style="{CB}">급여</span> 치료 또는 <span style="{CB}">급여</span> 처방조제를 받은 때', '입·통원 합산 연간 5천만원 한도<br>(단, 통원은 회당 20만원 한도)'])
     + _sil_row([f'<span style="white-space:nowrap;">질병 <span style="{CB}">급여</span></span>', f'피보험자가 질병으로 병원에 입원 또는 통원하여 <span style="{CB}">급여</span> 치료 또는 <span style="{CB}">급여</span> 처방조제를 받은 때', '입·통원 합산 연간 5천만원 한도<br>(단, 통원은 회당 20만원 한도)']) + '</tbody></table>'
     '<div style="font-size:11px;font-weight:700;margin:10px 0 4px;">[<span style="' + CP + '">특별약관</span> (비급여 실손의료비)]</div>'
     '<table style="width:100%;border-collapse:collapse;"><thead><tr>' + f'<th colspan="2" style="{TH}">종목</th>' + ''.join(f'<th style="{TH}">{h}</th>' for h in ['보장내용', '가입금액(만원)']) + '</tr></thead><tbody>'
     + _sil_row2([f'<span style="white-space:nowrap;">상해 <span style="{CP}">비급여</span></span>', f'피보험자가 상해로 의료기관에 입원 또는 통원하여 <span style="{CP}">비급여</span> 치료 또는 <span style="{CP}">비급여</span> 처방조제를 받은 때 <span style="{CP}">(3대비급여 제외)</span>', '입·통원 합산 연간 5천만원 한도<br>(단, 통원은 회당 20만원, 연간 100회 한도)'])
     + _sil_row2([f'<span style="white-space:nowrap;">질병 <span style="{CP}">비급여</span></span>', f'피보험자가 질병으로 의료기관에 입원 또는 통원하여 <span style="{CP}">비급여</span> 치료 또는 <span style="{CP}">비급여</span> 처방조제를 받은 때 <span style="{CP}">(3대비급여 제외)</span>', '입·통원 합산 연간 5천만원 한도<br>(단, 통원은 회당 20만원, 연간 100회 한도)'])
     + f'<tr><td rowspan="3" style="{TD}{CP}font-weight:700;">3대<br>비급여</td><td style="{TD}">도수·체외충격파<br>치료·증식치료</td><td rowspan="3" style="{TD}">피보험자가 상해 또는 질병으로 의료기관에 입원 또는 통원하여 <span style="{CP}">비급여</span> 치료를 받은 때</td><td style="{TD}">연간 350만원 (50회) 한도</td></tr>'
     + f'<tr><td style="{TD}">주사료</td><td style="{TD}white-space:nowrap;">연간 250만원 (50회) 한도</td></tr><tr><td style="{TD}">자기공명영상진단</td><td style="{TD}white-space:nowrap;">연간 300만원 한도</td></tr></tbody></table>')
    t2 = ('<div style="font-size:12px;font-weight:800;color:#E8731A;margin:14px 0 4px;">보장종목별 보험금 지급 기준</div><table style="width:100%;border-collapse:collapse;"><thead><tr>' + ''.join(f'<th style="{TH}">{h}</th>' for h in ['', '담보가입현황', '가입금액', '납입기간<br>보험기간']) + '</tr></thead><tbody>'
     + ''.join(_sil_row([str(k + 1), f'<span style="color:#1E40AF;font-weight:700;">{n.split(" : ")[0]}</span> : {n.split(" : ")[1]}', a, '1년갱신 5년만기<br>(최대100세)'], [TD, TDL, TD + bg + 'font-weight:700;white-space:nowrap;', TD + 'white-space:nowrap;']) for k, (n, a, bg) in enumerate(rows)) + '</tbody></table>')
    if S.get('mode') == 'new':   # 실손 신규가입 (기존 실손 없음)
        return ('<div class="pcmp-wrap" style="margin-top:14px;"><div class="pcmp-product"><div class="pcmp-product-name"><span class="pcmp-hl">| 실손보험 신규가입 안내</span></div>'
         '<div class="pcmp-product-plan">▶ 현재 기준(5세대) 실손보험 신규가입으로 실손 보장 완성</div><div class="pcmp-plan-list">'
         f'<div class="pcmp-plan-item"><span class="pcmp-plan-bul">*</span>보험료 : {S["new_co"]} 5세대 실손보험 월 <strong style="color:var(--toss-red);">{S["new"]}원</strong> (1년 단위 갱신 · 5년 후 재가입 · 최대 100세)</div>'
         '<div class="pcmp-plan-item"><span class="pcmp-plan-bul">*</span>구성 : 급여(기본형) + 비급여(특별약관) + 3대비급여(도수·주사·MRI) — 입·통원 합산 연간 5천만원 한도의 표준 구성</div></div></div></div>'
         '<div style="margin-top:10px;padding:12px 12px 10px;border:1px solid var(--gray-200);border-radius:8px;background:#fff;">'
         f'<div style="text-align:center;font-size:14px;font-weight:800;margin-bottom:6px;"><span style="color:#1E40AF;">[{S["title_co"]} 실손보험_신규]</span> 질병/상해/비급여치료 실손보상</div>'
         f'<div style="text-align:center;font-size:12.5px;line-height:1.7;">월보험료 <strong style="color:#E04848;font-size:14px;">{S["new"]}원</strong> (5세대실손보험 / 1년단위 갱신 / 5년후 재가입)</div>'
         '<div style="border-top:3px solid #222;margin:8px 0 2px;"></div>' + t1 + t2 + '</div>')
    return ('<div class="pcmp-wrap" style="margin-top:14px;"><div class="pcmp-product"><div class="pcmp-product-name"><span class="pcmp-hl">| 실손보험 전환 관련 안내</span></div>'
     '<div class="pcmp-product-plan">▶ 실손보험 전환으로 보험료 절약 및 보장효율성 향상</div><div class="pcmp-plan-list">'
     f'<div class="pcmp-plan-item"><span class="pcmp-plan-bul">*</span>보험료 비교 : 기존 {S["gen"]} 실손({S["old_co"]}) 월 <strong>{S["old"]}원</strong> → 현재 기준(5세대·{S["new_co"]}) 전환 시 월 <strong style="color:var(--toss-red);">{S["new"]}원</strong> (월 {S["diff"]}원 · {S["save"]} 절약)</div>'
     f'<div class="pcmp-plan-item"><span class="pcmp-plan-bul">*</span>향후 증가폭 절약 : 1년 단위 갱신 · 5년 후 재가입 구조의 최신 기준 실손으로 전환하여, {S["gen"]} 실손의 갱신 시 큰 보험료 인상 폭을 절약</div></div></div></div>'
     '<div style="margin-top:10px;padding:12px 12px 10px;border:1px solid var(--gray-200);border-radius:8px;background:#fff;">'
     f'<div style="text-align:center;font-size:14px;font-weight:800;margin-bottom:6px;"><span style="color:#1E40AF;">[{S["title_co"]} 실손보험 전환]</span> 질병/상해/비급여치료 실손보상</div>'
     f'<div style="text-align:center;font-size:12.5px;line-height:1.7;">월보험료 {S["old"]}원 &gt; <strong style="color:#E04848;font-size:14px;">{S["new"]}원</strong> (−{S["diff"]}원 / 1년단위 갱신 / 5년후 재가입)<br>※ {S["save"]} 보험료 절약</div>'
     '<div style="border-top:3px solid #222;margin:8px 0 2px;"></div>' + t1 + t2 + '</div>')

def existing_rows(pages, name, blocks):
    """CRM PAGES → 기존보험현황 ins-row 목록. blocks = {'1번.': [html, ...]} (실손 전환 블록·갱신 예시표 등 ins-body 하단 추가물)"""
    out = []
    for p in pages:
        date = p['info'][0][1]; body = ''
        for k, (cn, chl, rows) in enumerate(p['cats']):
            title = cn + (f' ({date} 가입)' if k == 0 else '')
            body += cat_block(CLS[cn], title, [cov_row(r[0], r[1].replace(' 만원', '만원'), bool(chl or r[4]), bool(len(r) > 5 and r[5])) for r in rows])
        body += op(p['opinion']) + ''.join(blocks.get(p['no'], []))
        out.append(ins(f"{p['co']} {p['name']}", price_label(p), body))
    return out

def need_row(cat_, catspan, name, imp, st, need, have, first=False):
    chip = {'ok': '<span class="st-chip st-ok">충분</span>', 'lack': '<span class="st-chip st-lack">부족</span>', 'none': '<span class="st-chip st-none">미가입</span>'}[st]
    impb = ' <span class="imp-badge">중요</span>' if imp else ''; cls = ' class="need-imp"' if imp else ''
    return f'<tr{cls}>{f"<td class=\"hwang-cat\" rowspan=\"{catspan}\">{cat_}</td>" if first else ""}<td class="hwang-sub" style="text-align:left;">{name}{impb}</td><td class="need-st">{chip}</td><td class="hwang-amt">{need}</td><td class="hwang-amt">{have}</td></tr>'
def apply_existing(s, grp_title, rows_html, tail_html, adequacy):
    """adequacy = {'rows': [(대분류, span, [(담보, imp, st, need, have),...]),...], 'note': '※ ...'}"""
    N = []
    for cat_, span, items in adequacy['rows']:
        for k, (nm, imp, st, need, have) in enumerate(items): N.append(need_row(cat_, span, nm, imp, st, need, have, k == 0))
    i = s.find('<section id="existing-insurance-section">'); j = s.find('</section>', i); sec = s[i:j]
    k = sec.find('<div class="hwang-section" style="margin:44px'); adeq = sec[k:]
    m = re.search(r'<tbody>.*?</tbody>', adeq, re.DOTALL); adeq = adeq[:m.start()] + '<tbody>' + ''.join(N) + '</tbody>' + adeq[m.end():]
    m2 = re.search(r'<span style="color:var\(--toss-red\);font-weight:700;">※ .*?</span>', adeq, re.DOTALL)
    adeq = adeq[:m2.start()] + f'<span style="color:var(--toss-red);font-weight:700;">{adequacy["note"]}</span>' + adeq[m2.end():]
    grp = f'<div class="grp-block"><div class="grp-title">{grp_title}</div>' + ''.join(rows_html) + tail_html + '</div>'
    return s[:i] + '<section id="existing-insurance-section">\n' + grp + '\n' + adeq + s[j:]

# ─────────────────────────────── 5. pcmp 비교표 + ③ 적용상품 + 추가할인 ───────────────────────────────
def pct(v, r): return won(int(int(v.replace(',', '')) * r + 0.5))   # 반올림(half-up)
def pcmp_rows(rows, first=None, ratio=1.0):
    """rows=[(보험사, 상품명, 이미지합계),...] → 1행은 first(지정값) / 2행부터 ×ratio"""
    return [(co, pr, (first if (k == 0 and first) else pct(v, ratio if k else 1.0))) for k, (co, pr, v) in enumerate(rows)]
def _tbl(rows, chosen):
    """비교표 — 적용 보험사(chosen) 행만 강조(pcmp-row-hl). 2순위 표에 적용사가 없으면 강조 없음(홍희정 KB라이프)."""
    return '<table class="pcmp-table"><thead><tr><th>보험사</th><th>보험상품명</th><th class="pcmp-col-price">보험료</th></tr></thead><tbody>' + ''.join(f'<tr{" class=\"pcmp-row-hl\"" if co == chosen else ""}><td>{co}</td><td>{pr}</td><td class="pcmp-col-price">{v}원</td></tr>' for co, pr, v in rows) + '</tbody></table>'
def _ni(lab, t, st=''): return f'<div class="pcmp-note-item"{(" style=\"" + st + "\"") if st else ""}><span class="pcmp-note-label">{lab}</span>{t}</div>'
GP_TYPES = [   # 간편보험 유형 비교 (고지 기준) — 이영욱님 산출본 원형 (행 텍스트·셀 그대로) · key = 적용 유형 코드
    (('3610',), '<strong>초경증 간편보험</strong>', '(3<span class="sil-red">6</span>10 · 당/지 없음 전략플랜)', '<span class="sil-red">6년</span> 이내', '10년 이내'),
    (('355', '345', '335'), '<strong>경증 간편보험</strong>', '(3<span class="sil-red">5</span>5 / 3<span class="sil-red">4</span>5 / 3<span class="sil-red">3</span>5)', '<span class="sil-red">5/4/3년</span> 이내', '5년 이내'),
    (('325',), '<strong>일반 간편보험</strong>', '(3<span class="sil-red">2</span>5)', '<span class="sil-red">2년</span> 이내', '5년 이내')]
GP_BADGE = ' <span style="display:inline-block;background:var(--toss-blue);color:#fff;font-size:9.5px;font-weight:800;padding:1px 7px;border-radius:8px;vertical-align:1px;">적용</span>'
def ganpyeon_type_block(applied):
    """간편보험 유형 비교표 블록(pcmp-block) — 비교표 2개 아래·③ 적용상품 직전. applied = '3610'|'355'|'345'|'335'|'325' (설계안 상품명의 간편 유형)"""
    assert any(applied in keys for keys, *_ in GP_TYPES), f'간편 유형 코드 미정의: {applied} (판정표 확인)'
    rows = ''
    for keys, nm, sub, c1, c2 in GP_TYPES:
        on = applied in keys
        rows += (f'<tr style="background:#FFF9C4;">' if on else '<tr>') + f'<td style="text-align:left;">{nm}{GP_BADGE if on else ""}<br>{sub}</td>' + (f'<td style="font-weight:800;">{c1}</td><td style="font-weight:800;">{c2}</td>' if on else f'<td>{c1}</td><td>{c2}</td>') + '</tr>'
    return ('<div class="pcmp-block"><div class="pcmp-block-title">간편보험 유형 비교 (고지 기준)</div><div class="pcmp-note" style="margin:0 0 8px;"><div class="pcmp-note-item"><span class="pcmp-note-label">※</span>공통 (3개월 이내) : 입원·수술·재검사 소견, 질병진단·질병의심소견 고지</div></div>'
            '<table class="gp-table"><thead><tr><th style="width:40%;">유형</th><th>입원/수술 고지</th><th>중대질병 고지</th></tr></thead><tbody>' + rows + '</tbody></table>'
            '<div class="pcmp-note"><div class="pcmp-note-item"><span class="pcmp-note-label">※</span>보험료 : 3<span class="sil-red">6</span>10 &lt; 3<span class="sil-red">5</span>5 &lt; 3<span class="sil-red">4</span>5 &lt; 3<span class="sil-red">3</span>5 &lt; 3<span class="sil-red">2</span>5 — 뒤로 갈수록 보험료가 높아집니다. (고지 기간이 짧을수록 보험료 상승)</div></div></div>')
def apply_pcmp(s, name, t1, t2, t1_title, t2_title, order_text, chosen='메리츠화재', note1='기타 치료이력 등을 포함하여 건강상의 아무 이슈가 없을 때 가입이 가능한 유형의 보험으로, 1차심사는 통과되었습니다.', extra_block=''):
    P = ('<div class="pcmp-block"><div class="pcmp-block-title">' + t1_title + '</div>' + _tbl(t1, chosen) + '<div class="pcmp-note">'
     + _ni('1.', f'위의 보험료 비교표는 {name}님께서 <span style="color:var(--toss-red);font-weight:800;">① 보장성보험을 구성하는데 있어 ② 동일한 보장을 구성하는데 ③ 보험료가 가장 낮은 보험 카테고리입니다.</span>')
     + _ni('-', note1) + _ni('-', '현재 기준 동일한 보장을 구성함에 있어 보험료가 가장 낮게 책정되는 유형의 보험으로, 심사결과에 따라 내용이 달라질 수 있습니다.')
     + _ni('-', f'보험료가 가장 낮은 순서는 {order_text} 순이며 <span style="font-weight:800;color:var(--toss-red);">동일기준에 있어 가장 효율적인 {chosen} 보험을 선택</span>하였습니다.')
     + _ni('※', '위의 내용은 최종심사를 통해 확정되며, 실제 심사 이후 100% 확정된 내용의 확인이 가능합니다.', 'color:var(--toss-red);font-weight:700;') + '</div></div>'
     + '<div class="pcmp-block"><div class="pcmp-block-title">' + t2_title + '</div>' + _tbl(t2, chosen) + '<div class="pcmp-note">' + _ni('2.', '만약 최종확정단계(심사)에서 다른 치료이력 이슈가 있는 경우, 보험의 유형이 변경될 수 있습니다.') + '</div></div>' + extra_block)   # extra_block = 간편 유형 비교표 등
    p0 = s.find('<div class="pcmp-block">'); p1 = s.find('<div class="pcmp-subtitle pcmp-subtitle-applied"'); assert s[p0:p1].count('<div class="pcmp-block">') == 2
    return s[:p0] + P + s[p1:]

def apply_sec3(s, product_hl, product_sub, plans, paren='(20년납 / 90세만기 / 비갱신형 구성)', discount=None, min_note=None, after_html='', before_product_html='', after_paren=None):
    """③ 적용상품. plans=[('안심보장플랜','216,060','171,343'|None,'41,122,212'),...]  discount={'title':'메리츠 보장성보험 (보험료 추가할인)','heads':['가입시점','1년후',...],'rows':[('안심보장플랜',[...],'총납입','평균')]}"""
    items = ''
    for k, (nm, m, avg, tot) in enumerate(plans):
        items += f'<div class="pcmp-plan-item"><span class="pcmp-plan-bul">·</span>{nm} - 월 {m}원' + (f' (평균 {avg}원)' if avg else '') + f' / 총 {tot}원</div>'
        if k == 0 and min_note: items += f'<div class="pcmp-plan-item" style="padding-left:18px;color:var(--toss-red);font-weight:700;">{min_note}</div>'
    H = (f'<div class="pcmp-subtitle pcmp-subtitle-applied" style="margin-top:64px;"><span class="sec-num">3</span>보험료 비교를 통해 적용된 보험상품</div>' + (f'<div style="margin:24px 0 56px;">{before_product_html}</div>' if before_product_html else '') + f'<div class="pcmp-product"><div class="pcmp-product-name"><span class="pcmp-hl">{product_hl}</span></div><div class="pcmp-product-sub">{product_sub}</div><div class="pcmp-product-plan">▶ 보장플랜별 보장항목,보험료 비교를 위한 {len(plans)}개 플랜 구성</div><div class="pcmp-plan-list">'
         + items + f'<div class="pcmp-plan-paren">{paren}</div>' + (f'<div class="pcmp-plan-item" style="margin-top:10px;padding-left:18px;color:var(--toss-red);font-weight:700;">{after_paren}</div>' if after_paren else '') + '</div></div></div>\n')   # after_paren = 플랜 목록 아래 빨간 안내(예: 실손 전환 요약 · 홍희정)
    if discount:
        d = discount
        H += (f'<div class="disc-wrap"><div class="disc-title">{d["title"]}</div><div class="disc-sub">본 플랜은 <b>일반고지형</b>으로, 가입 이후 <b>{len(d["heads"]) - 1}년 동안 1년마다 보험료가 추가 할인</b>되는 유형입니다. (아래 납입평균 = 전체 납입기간 평균 보험료)</div><div class="disc-scroll"><table class="disc-table"><colgroup><col style="width:13%">'
              + '<col>' * len(d['heads']) + '<col style="width:14%"><col style="width:12.5%"></colgroup><thead><tr><th></th>' + ''.join(f'<th>{h}</th>' for h in d['heads']) + '<th>총납입보험료</th><th class="disc-avg-h">납입평균</th></tr></thead><tbody>'
              + ''.join(f'<tr><td class="disc-name">{nm}</td>' + ''.join(f'<td>{v}원</td>' for v in vals) + f'<td>{tot}원</td><td class="disc-avg">{avg}원</td></tr>' for nm, vals, tot, avg in d['rows']) + '</tbody></table></div></div>\n')
    if after_html: H += '<div style="margin:64px 0 56px;">' + after_html + '</div>\n'   # ③ 다음 독립 블록(실손 신규 등) — 단락 여백 64/56px
    a3 = s.find('<div class="pcmp-subtitle pcmp-subtitle-applied"'); b3 = s.find('<!-- ──────────── 섹션 끝', a3); assert 0 < a3 < b3 and (b3 - a3) < 4000
    return s[:a3] + H + s[b3:]

# ─────────────────────────────── 6. 현황요약표 (hwang) ───────────────────────────────
def hc(v):
    if not v: return '<td></td>'
    t, col = (v, '') if isinstance(v, str) else v
    st = {'b': f'color:{BLUE};', 'r': f'color:{RD};', 'ru': f'color:{RD};text-decoration:underline;', 'y': 'background:#FFFF00;'}.get(col, '')   # b 파랑 / r 빨강 / ru 빨강+밑줄 / y 노랑 배경(빈 셀 강조)
    return f'<td class="hwang-amt"{f" style=\"{st}\"" if st else ""}>{t}</td>'
bl = lambda t: (t, 'b'); rd = lambda t: (t, 'r'); ru = lambda t: (t, 'ru'); yl = lambda: ('&nbsp;', 'y')
def apply_hwang(s, H, modal_img):
    """H = {'name', 'n_exi', 'n_plan', 'title': '…비효율에 대한 보험료/보장항목 현황 및 조정 안내', 'prod_html': 좌상단 요약 th 내용,
            'exi_head': '<th class="hwang-exi">..</th>…(기존 n_exi + 실손전환 포함)', 'plan_head': '<th class="hwang-p2">..', 'need_row', 'price_row', 'price2_row',
            'groups': [(대분류, [(소분류, red, *vals)...])], 'n_rows': 기대 행수}
       열 수 N = 2 + n_exi + n_plan. CSS는 N열 전용 클래스 자동 생성(폭 108/104px)."""
    n = 2 + H['n_exi'] + H['n_plan']; vals_n = n - 2
    rows = []
    for cat_, items in H['groups']:
        for k, (sub, red, *vals) in enumerate(items):
            assert len(vals) == vals_n, (sub, len(vals), vals_n)
            rows.append('<tr>' + (f'<td class="hwang-cat" rowspan="{len(items)}">{cat_}</td>' if k == 0 else '') + f'<td class="hwang-sub"{" style=\"color:#E04848;\"" if red else ""}>{sub}</td>' + ''.join(hc(v) for v in vals) + '</tr>')
    if H.get('n_rows'): assert len(rows) == H['n_rows'], len(rows)
    cls = f'hwang-table-{n}col'
    sect = H.get('sect_head'); title_row = H.get('title_full') or f'{H["name"]}님 보험 : {H["title"]}'
    HW = (f'<table class="hwang-table hwang-table-8col hwang-table-7col {cls}"><thead>'
     f'<tr><th colspan="{n}" style="background:#E7F1DF;color:#333;font-size:13px;font-weight:800;padding:10px 8px;text-align:center;letter-spacing:-0.2px;">{title_row}</th></tr>'
     + (f'<tr class="hwang-hd-plan"><th class="hwang-prod" colspan="2" rowspan="5">{H["prod_html"]}</th>' + sect + '</tr><tr class="hwang-hd-plan">' if sect else f'<tr class="hwang-hd-plan"><th class="hwang-prod" colspan="2" rowspan="4">{H["prod_html"]}</th>')
     + H['exi_head'] + H['plan_head'] + '</tr>'
     '<tr class="hwang-hd-need">' + H['need_row'] + '</tr>'
     '<tr class="hwang-hd-price">' + H['price_row'] + '</tr>'
     '<tr class="hwang-hd-price2">' + H['price2_row'] + '</tr>'
     '<tr class="hwang-hd-col"><th class="hwang-cat-h">대분류</th><th class="hwang-sub-h">소분류</th>' + '<th>보장금액</th>' * vals_n + '</tr></thead><tbody>' + ''.join(rows) + '</tbody></table>')
    OPEN = '<table class="hwang-table hwang-table-8col hwang-table-7col"><thead>'; cnt(s, OPEN, 1)
    t0 = s.find(OPEN); t1 = s.find('</table>', t0) + 8; s = s[:t0] + HW + s[t1:]
    w = 104 if n >= 12 else 108; mw = 400 + 100 * n   # 확정 산출 규격: 11열=1500px(박정무) · 12열=1600px(김형준)
    if n not in (6, 8): s = zr(s,   # 6열·8열 = 베이스 CSS 그대로(최신 산출 정우찬 기준 · 홍희정의 6col 900px 재정의는 구형) / 그 외 열수 = 전용 CSS 생성
 '.hwang-table-7col{min-width:1000px;}', f'.hwang-table-7col{{min-width:1000px;}}\n.{cls}{{min-width:{mw}px;}}\n.{cls} th,.{cls} td{{font-size:10.5px;padding:4px 5px;}}\n.{cls} tbody td:nth-last-child(-n+{vals_n + 1}){{width:auto;}}\n.{cls} tbody td:nth-last-child(-n+{vals_n}){{width:{w}px;}}\n.{cls} .hwang-sub{{min-width:230px;}}')
    i = s.find('<img class="hwang-modal-img" src="'); j = s.find('"', i + len('<img class="hwang-modal-img" src="'))
    s = s[:i] + '<img class="hwang-modal-img" src="' + b64img(modal_img) + s[j:]
    cnt(s, f'{H["name"]}님 기존보험 분석 및 효율적 보장 보강/보완을 위한 플랜별 보장 비교', 1)
    return s

# ─────────────────────────────── 7. 핵심 확인사항 / 운전자 / PDF ───────────────────────────────
HL_BASE = [('최대 3,000만원', '암 진단 시'), ('최대 6,000만원/년', '암 치료 시 (진단 후 10년간)'), ('최대 2,000만원', '뇌혈관·심장질환 진단 시'), ('최대 3,000만원', '순환계 정밀치료 시')]
def apply_hl(s, hl):
    """hl = [(val, sub), ...] 4개 — full 플랜 기준 (암 진단 / 암 치료 / 뇌·심 진단 / 순환계 치료)"""
    for (ov, osub), (nv, nsub) in zip(HL_BASE, hl):
        s = zr(s, f'<div class="hl-val">{ov}</div>\n      <div class="hl-sub">{osub}</div>', f'<div class="hl-val">{nv}</div>\n      <div class="hl-sub">{nsub}</div>')
    return s
def apply_waiver(s, items):
    """납입면제 사유 그리드 교체 — items = 문장 리스트 (KB라이프 등 상품별 납입면제 사유)"""
    i = s.find('<div class="waiver-grid reveal">'); j = s.find('</div>\n</div>', i); assert i > 0 and j > i
    return s[:i] + '<div class="waiver-grid reveal">\n' + '\n'.join(f'<div class="waiver-item"><div class="w-dot"></div>{t}</div>' for t in items) + '\n  ' + s[j:]
def delete_driver(s):
    i = s.find('<span class="sec-num">6</span>운전자보험 관련'); a8 = s.rfind('<div class="pcmp-wrap">', 0, i)
    j = s.find('꼭 확인하세요', i); b8 = s.rfind('<div class="ntc-section', 0, j)
    assert 0 < a8 < i < b8 and (b8 - a8) < 8000, (a8, b8)
    s = s[:a8] + s[b8:]; assert '운전자보험 관련' not in s and s.count('꼭 확인하세요') == 1
    return s
def driver_replace(s, D):
    """운전자 교체/조정 안내 섹션 (베이스 심은정 = KB손보 11,120원 → 메리츠 2604 12,500원) 앵커 교체.
       D = {'intro': 3항 전체 문장(HTML), 'old_price':'14,860원(1건)', 'new_price':'13,670원', 'product':'종합보험2608(3.0) (보험료 납입면제형)',
            'rev':'26.08', 'contract':'※ 계약사항 : ...', 'table_edits':[(old,new,n),...](담보표 셀 수정), 'grade': GR 급수별 표 데이터|None}"""
    s = zr(s, '심은정님은 현재 운전자보험 <strong style="color:var(--toss-red);">1건(KB손보)</strong>이 가입되어 있으나 최신기준 이전 버전으로 비효율 상태입니다. 최신기준 운전자보험 <strong>1건(1set)으로 교체</strong>를 안내드립니다.'.replace('심은정', D['name']), D['intro'])
    if D.get('mode') == 'new':   # 기존 운전자보험 없음 → 신규 가입 안내 (4번 = 신규 보험료만)
        s = zr(s, '보험료 : 기존 <strong style="color:var(--toss-red);">11,120원(1건)</strong> → 월 ', '보험료 : 월 ')
        s = zr(s, '▶ 메리츠화재 최신기준 운전자보험 1:1 교체 관련 안내', '▶ 메리츠화재 최신기준 운전자보험 신규 가입 관련 안내')
    else: s = zr(s, '11,120원(1건)', D['old_price'])
    s = zr(s, '12,500원', D['new_price'], 3)
    if D.get('mode') == 'new':
        s = zr(s, 'margin-left:6px;vertical-align:middle;">1:1 교체</span>', 'margin-left:6px;vertical-align:middle;">신규 가입</span>')
    if D.get('product'): s = zr(s, '종합보험2604 (보험료 납입면제형)', D['product'])
    if D.get('rev'):
        s = zr(s, '26.04월 개정된 최신기준 운전자보장', f'{D["rev"]}월 개정된 최신기준 운전자보장'); s = zr(s, '담보사항 (26.04 개정 신규·확대 담보 강조 표기)', f'담보사항 ({D["rev"]} 개정 신규·확대 담보 강조 표기)')
    if D.get('contract'): s = zr(s, '※ 계약사항 : 20년납 20년만기 · 월납 · 인수지침 적용 전 설계 기준 (확정 시 청약서 기준)', D['contract'])
    for old, new, n in D.get('table_edits', []): s = zr(s, old, new, n)
    if D.get('grade'):
        d0 = s.find('<table class="gp-table sil-pay-tbl drv-tbl">'); de = s.find('<div class="div8"></div>', d0)
        s = s[:de] + grade_table(D['grade']) + '\n' + s[de:]
    return s
GY = 'background:#FFF59D;font-weight:800;'; GK = 'background:#222;color:#fff;'; GW = ''
def grade_table(GR, cols=(('메리츠', 'background:#D32F2F;color:#fff;'), ('A사', 'background:#1565C0;color:#fff;'), ('B사', 'background:#2E7D32;color:#fff;'), ('C사', 'background:#F9A825;color:#333;'))):
    """보험사별 운전자보험 급수별 비교 HTML 표 (이미지 셀 단위). GR = [(대분류, rowspan, [(소분류|None, (text, style)|None x4), ...]), ...]
       style: GY(노랑 강조) / GK(검정) / GW / GK+'rowspan'(2행 병합 → 다음 행 None)"""
    gr = ''
    for cat_, span, items in GR:
        for k, (sub, *vals) in enumerate(items):
            tr = '<tr>' + (f'<td class="drv-grp" rowspan="{span}">{cat_}</td>' if (k == 0 and sub is not None) else '') + (f'<td style="text-align:left;">{sub}</td>' if sub is not None else f'<td class="drv-grp" colspan="2">{cat_}</td>')
            for v in vals:
                if v is None: continue
                t, st = v
                tr += f'<td rowspan="2" style="{st.replace("rowspan", "")}">{t}</td>' if 'rowspan' in st else f'<td style="{st}">{t}</td>'
            gr += tr + '</tr>'
    return ('<div class="hwang-section" style="margin-top:18px;"><div class="sil-card"><div class="sil-head"><div class="sil-sum-t"><span class="sil-hl">[보험사별 운전자보험 약관 참고내용]</span> 운전자보험 주요보장 급수별 비교</div></div><div class="sil-body">'
            '<table class="gp-table sil-pay-tbl drv-tbl"><thead><tr><th colspan="2" style="width:34%;">구분</th>' + ''.join(f'<th style="{st}">{t}</th>' for t, st in cols) + '</tr></thead><tbody>' + gr + '</tbody></table>'
            '<div style="font-size:10.5px;color:var(--gray-500);margin-top:6px;">※ 교통사고처리지원금 급수별(주수별) 한도 · 추가진단문구 약관반영 · 치아파절 골절진단비 · 상해수술비 임플란트 보장 기준 비교 (이미지 원본 기준)</div></div></div></div>')
def apply_pdf_pages(s, pdf_pages, workdir='pg'):
    """pdf_pages = {'min': ('pdf1.pdf', 2)|None, 'mid': (...), 'max': (...)} → PDF_PAGES (mutool 150dpi JPEG)"""
    os.makedirs(workdir, exist_ok=True); arr = {}
    for key in ['min', 'mid', 'max']:
        v = pdf_pages.get(key)
        if not v: arr[key] = '[]'; continue
        f, np_ = v; stem = os.path.splitext(os.path.basename(f))[0]; out = []
        for i in range(1, np_ + 1):
            png = f'{workdir}/{stem}-{i}.png'
            subprocess.run(['mutool', 'draw', '-r', '150', '-o', png, f, str(i)], capture_output=True)
            out.append(b64jpg(Image.open(png)))
        arr[key] = '[\n    ' + ',\n    '.join(out) + '\n  ]'
    i = s.find('var PDF_PAGES = {'); j = s.find('};', i) + 2
    return s[:i] + 'var PDF_PAGES = {\n  min: ' + arr['min'] + ',\n  mid: ' + arr['mid'] + ',\n  max: ' + arr['max'] + '\n};' + s[j:]

RESIDUAL_BASE = ['심은정', '19890201', 'KB손보실손', 'KB 플러스 운전자', '38,380', '110,050', '135,270', '11,120', '12,500원', '기존보장동일', '퍼펙트플러스', '심혈케어', '만 38세', '주부', '2607(3.0)']
def check_residual(s, extra, allow=()):
    """베이스(심은정) 고유값 + 이전 고객명 잔존 0 검증. allow = 이번 고객과 우연히 일치하는 베이스값(예: '만 38세')"""
    for k in RESIDUAL_BASE + list(extra):
        if k in allow: continue
        assert k not in s, f'잔존: {k}'

# ─────────────────────────────── 메인 ───────────────────────────────
def build_report(spec):
    """spec dict → HTML 산출 (파일명 toss_insureport_{name}님_{birth8}.html). 각 단계는 spec 키가 있을 때만 적용."""
    s = open(spec.get('base', BASE_10YR), encoding='utf-8').read()
    name, birth = spec['name'], spec['birth8']
    s = apply_identity(s, name, birth, spec['hero'])
    if spec.get('product_name_old'): s = zr(s, spec['product_name_old'], spec['product_name'], spec.get('product_name_n', 1))
    s = apply_tabs(s, spec['tabs'])
    s = apply_chips(s, spec.get('chips', {}))
    s = apply_coverage(s, spec['coverage'])
    for plan, cov_html in spec['panels'].items():   # 값 = cov-wrap HTML | f(s)→cov-wrap HTML | f(s)→전체 문서(replace_cards 등)
        r = cov_html(s) if callable(cov_html) else cov_html
        s = r if r.lstrip().startswith('<!DOCTYPE') else set_cov(s, plan, r)
    ex = spec['existing']
    rows_html = existing_rows(ex['pages'], name, ex.get('blocks', {}))
    s = apply_existing(s, ex['grp_title'], rows_html, ex.get('tail', ''), spec['adequacy'])
    pc = spec['pcmp']; s = apply_pcmp(s, name, pc['t1'], pc['t2'], pc['t1_title'], pc['t2_title'], pc['order_text'], pc.get('chosen', '메리츠화재'), pc.get('note1', '기타 치료이력 등을 포함하여 건강상의 아무 이슈가 없을 때 가입이 가능한 유형의 보험으로, 1차심사는 통과되었습니다.'),
                                  ganpyeon_type_block(spec['ganpyeon']['applied']) if spec.get('ganpyeon') else '')   # 간편보험: 유형 비교표 자동(판정표 §1-12)
    s3 = spec['sec3']; s = apply_sec3(s, s3['product_hl'], s3['product_sub'], s3['plans'], s3.get('paren', '(20년납 / 90세만기 / 비갱신형 구성)'), s3.get('discount'), s3.get('min_note'), s3.get('after_html', ''), s3.get('before_product_html', ''), s3.get('after_paren'))
    s = apply_hwang(s, spec['hwang'], spec['modal_img'])
    s = apply_hl(s, spec['hl'])
    if spec.get('hl5'): s = zr(s, '<div class="hl-sub">상해·골절·화상 시</div>', f'<div class="hl-sub">{spec["hl5"]}</div>')   # 핵심확인 5번 문구 (예: '재해·골절 수술 시')
    if spec.get('waiver'): s = apply_waiver(s, spec['waiver'])
    drv = spec.get('driver')
    if drv == 'delete': s = delete_driver(s)
    elif isinstance(drv, dict): s = driver_replace(s, dict(drv, name=name))
    elif callable(drv): s = drv(s)
    s = apply_pdf_pages(s, spec['pdf_pages'], spec.get('pg_dir', 'pg'))
    for old_, new_, n_ in spec.get('extra_zr', []): s = zr(s, old_, new_, n_)   # 고객 문구 추가 교체 (count 검증)
    for f_ in spec.get('post', []): s = f_(s)   # 고객 지시 강조 등 후처리 함수(전체 문서 → 전체 문서) · 내부 zr count 검증 전제
    check_residual(s, spec.get('residual', []), spec.get('residual_allow', ()))
    out = spec.get('out') or f'toss_insureport_{name}님_{birth}.html'
    open(out, 'w', encoding='utf-8').write(s); print('done', out, len(s)); return out
