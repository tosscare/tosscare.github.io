#!/usr/bin/env bash
# Pretendard 폰트 등록 (CRM레포트 PNG 렌더 필수 · crm_lib.shot()이 자동 호출) — 1) fc-list에 있으면 종료 2) 스킬 동봉 fonts/ 복사 3) 없으면 npm pretendard
set -e
if fc-list 2>/dev/null | grep -qi pretendard; then echo "pretendard: already installed"; exit 0; fi
HERE="$(cd "$(dirname "$0")/.." && pwd)"; DST=/usr/local/share/fonts/pretendard; mkdir -p "$DST"
if ls "$HERE"/fonts/Pretendard-*.otf >/dev/null 2>&1; then cp "$HERE"/fonts/Pretendard-*.otf "$DST"/; echo "pretendard: copied from skill fonts/"
else TMP=$(mktemp -d); (cd "$TMP" && npm install pretendard --silent) && cp "$TMP"/node_modules/pretendard/dist/public/static/Pretendard-*.otf "$DST"/ && echo "pretendard: installed via npm"; fi
fc-cache -f >/dev/null 2>&1 || true; fc-list | grep -ci pretendard
