# PNG색상.md — PNG 색상 룰 (트리거 3 한정)

## 5종 라벨 색상 (png레포트·png표레포트)

| 라벨 | Hex | CSS class | 본문 |
|---|---|---|---|
| 과잉 | #DB2777 | val-과잉·active-rich | 핑크 |
| 적정 | #15803D | val-적정·active-good | 녹색 |
| 보통 | #191F28 | val-보통·active-neutral | 검정 |
| 빈약 | #F97316 | val-빈약·active-warning | 오렌지 |
| 부재 | #F04452 | val-부재·active-danger | 빨간 |

## 카드 ③ 5단계 색상 매핑 (png레포트)

| 카드 ③ 라벨 | 5종 라벨 색상 매핑 | CSS class |
|---|---|---|
| 매우과잉 | 핑크 (과잉) | active-rich |
| 높은편 | 녹색 (적정) | active-good |
| 보통 | 검정 (보통) | active-neutral |
| 낮음 | 오렌지 (빈약) | active-warning |
| 미확인 (또는 0원) | 빨간 (부재) | active-danger |

## level-bar HTML (png레포트 카드 ③ 4단 게이지)

```html
<!-- 매우과잉 -->
<div class="level-seg active-rich"></div>×4
<!-- 높은편 -->
<div class="level-seg active-good"></div>×3 + <div class="level-seg"></div>×1
<!-- 보통 -->
<div class="level-seg active-neutral"></div>×2 + <div class="level-seg"></div>×2
<!-- 낮음 -->
<div class="level-seg active-warning"></div>×1 + <div class="level-seg"></div>×3
<!-- 미확인 (또는 0원) -->
<div class="level-seg active-danger"></div>×1 + <div class="level-seg"></div>×3
```

## completion-bar HTML (5단 게이지 — 5종 적정+과잉 비율)

| 비율 | 게이지 |
|---|---|
| 5/5 (100%) | active-good ×5 |
| 4/5 (80%) | active-good ×4 + 빈 ×1 |
| 3/5 (60%) | active-good ×3 + 빈 ×2 |
| 2/5 (40%) | active-good ×2 + 빈 ×3 |
| 1/5 (20%) | active-warning ×1 + 빈 ×4 |
| 0/5 (0%) | 빈 ×5 |

## 적용 영역
- 본 룰은 **트리거 3 (png레포트) 한정** (png표레포트도 색상 동일 적용)
- 매트릭스 색상은 png표레포트 양식 (SKILL.md §4.4 박스 룰)과 정합

## v9 추가 색상 (2026-05-10 신설 — 트리거 2 png표레포트 warning-row)

### warning-row 박스 양식 (입원일당 위 — 매우 비효율적인 보장항목 안내)

| 영역 | Hex | 본문 |
|---|---|---|
| 배경 | #4B5563 | 진한 회색 |
| 글씨 | #FCA5A5 | 밝은 빨간 (회색 배경에 잘 보이도록) |
| 폰트 | font-weight: 700, font-size: 11px | — |
| padding | 6px 8px | — |
| 위치 | 입원일당 cat 직전 row | 위 수술비 빨간선 정합 행간 조절 — warning-spacer 8px (transparent) |

### warning-spacer (수술비 빨간선 정합 행간 조절)

| 영역 | 본문 |
|---|---|
| height | 8px |
| background | transparent |
| border | 0 |
| 위치 | warning-row 직전 |

### CSS 본문

```css
.cov-matrix tr.warning-spacer td {
    height: 8px; padding: 0; border: 0 !important; background: transparent;
}
.cov-matrix tr.warning-row td {
    text-align: center;
    color: #FCA5A5;
    font-weight: 700;
    font-size: 11px;
    padding: 6px 8px;
    border: 0 !important;
    background: #4B5563;
}
```
