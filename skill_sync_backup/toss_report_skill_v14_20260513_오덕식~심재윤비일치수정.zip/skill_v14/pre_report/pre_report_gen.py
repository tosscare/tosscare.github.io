"""generate_final.py — 16명 트리거 3 산출 (정의된 기준 정합 본문 100%)

정정 영역 (본 클로드 직전 결함):
1. amounts["silson"]: "월 가입" → "{입원} / {외래} 만원" (첨부 html 정합)
2. avg_label: 보험료 라벨 변환 ❌ → 5종 점수 평균 (SKILL.md §v8 정합)
3. completion_pct: 보험료 라벨별 ❌ → 5종 적정+과잉 비율 (SKILL.md §v8 정합)

라벨 기준 본문 정합 (10가지):
- references/premium_label.md, silson.md, cancer.md, brain.md, heart.md, surgery.md
- references/renewal.md, png_color.md
- report_builder.py 상수 (HEADLINE·CONCLUSION·RENEWAL·PREMIUM)
- _build_conclusion_text, _build_advisor_bullets 함수
"""
import sys
import shutil
import zipfile
from pathlib import Path
from datetime import datetime

sys.path.insert(0, "/home/claude/skill_v11_new/skill_v11/pre_report")
from report_builder import (build_png_report_html, build_png_table_html,
                             build_txt_message, html_to_png)
from insurance_classifier import sort_by_insurance_order, stats_box_4classify
sys.path.insert(0, "/home/claude")
from parse import parse_customer, split_self_family


# ════════ 보장 5종 라벨 산출 (references 정합) ════════
def lbl_silson(dh, do, ih, io):
    """silson.md 정합 — 적정/빈약/부재"""
    h = max(dh, ih); o = max(do, io)
    if h == 0 and o == 0: return "부재", o, h
    if h >= 5000 and o >= 25: return "적정", o, h
    return "빈약", o, h

def lbl_cancer(d, t=0):
    """cancer.md 정합 — 진단비+치료비 합산 기준"""
    s = d + t
    if s >= 15000: return "과잉", d, t
    if s >= 10000: return "적정", d, t
    if s >= 5000: return "보통", d, t
    if s >= 2000: return "빈약", d, t
    return "부재", d, t

def lbl_bh(d, t=0):
    """brain.md·heart.md 정합 — 진단비+치료비 합산"""
    s = d + t
    if s >= 7000: return "과잉", d, t
    if s >= 5000: return "적정", d, t
    if s >= 3000: return "보통", d, t
    if s >= 1000: return "빈약", d, t
    return "부재", d, t

def lbl_surg(d, i):
    """surgery.md 정합 — 질병수술+상해수술 합산"""
    s = d + i
    if s >= 1500: return "과잉", d, i
    if s >= 1000: return "적정", d, i
    if s >= 501: return "보통", d, i
    if s >= 1: return "빈약", d, i
    return "부재", d, i


# ════════ 보험료 5단계 라벨 (premium_label.md 정합) ════════
def calc_premium_label(monthly, age):
    """본인 월보험료 / 연령대 적정 보험료 × 100% → 5단계 라벨"""
    if age >= 60: avg = 400000
    elif age >= 50: avg = 250000
    elif age >= 40: avg = 180000
    elif age >= 30: avg = 150000
    else: avg = 100000
    pct = (monthly / avg) * 100 if avg > 0 else 0
    if pct >= 130: return "매우과잉"
    if pct >= 90: return "높은편"
    if pct >= 51: return "보통"
    if pct >= 21: return "낮음"
    return "미확인 (또는 0원)"


# ════════ 5종 평균 라벨 (SKILL.md §v8 정합) ════════
SCORE = {"과잉": 5, "적정": 4, "보통": 3, "빈약": 2, "부재": 1}

def calc_avg_label(labels):
    """5종 점수 평균 → 반올림 → 라벨 (SKILL.md §v8 정합)"""
    scores = [SCORE.get(labels.get(k, "부재"), 1) for k in
              ("silson", "cancer", "brain", "heart", "surgery")]
    avg = sum(scores) / 5
    if avg >= 4.5: return "과잉"
    if avg >= 3.5: return "적정"
    if avg >= 2.5: return "보통"
    if avg >= 1.5: return "빈약"
    return "부재"


# ════════ completion_pct — 5종 적정+과잉 비율 (SKILL.md §v8 정합) ════════
def calc_completion_pct(labels):
    """5종 中 적정·과잉 카운트 × 20 (0/20/40/60/80/100%)"""
    cnt = sum(1 for k in ("silson", "cancer", "brain", "heart", "surgery")
              if labels.get(k, "부재") in ("과잉", "적정"))
    return cnt * 20


def fmt(v): return f"{v:,}만원" if v > 0 else "0만원"


def build_entry(p, j):
    """보험 entry — coverage_end br 자동 변환 (빌더 자체 적용)"""
    ins = p["ins"]
    return {
        "name": ins["names"][j], "company": ins["companies"][j],
        "contract_date": ins["contract_dates"][j],
        "is_renewal": ins["renewal"][j] in ("갱신형 특약", "갱신형 보험"),
        "contractor_insured": ins["contractor"][j],
        "payment_status": ins["payment_status"][j],
        "payment_period": ins["payment_period"][j],
        "coverage_end": ins["coverage_end"][j],
        "monthly_premium": f"{ins['monthly_won'][j]:,}",
        "paid_premium": f"{ins['paid_won'][j]:,}",
        "remaining_premium": f"{ins['remaining_won'][j]:,}",
        "total_premium": f"{ins['total_won'][j]:,}",
        "matrix": p["ins_matrix"][j],
    }


def build_customer(p, s, table_indices, is_family_pg=False, fam_name=None):
    """customer dict 산출 — 정의된 기준 100% 정합"""
    sorted_idx = sort_by_insurance_order(p, table_indices)
    entries = [build_entry(p, j) for j in sorted_idx]
    stats = stats_box_4classify(p, table_indices)

    # 보험료 합계 (본 영역)
    monthly = sum(p["ins"]["monthly_won"][j] for j in table_indices
                  if p["ins"]["payment_status"][j] == "납입중"
                  and p["ins"]["status"][j] == "정상"
                  and "일시납" not in p["ins"]["payment_period"][j])
    paid = sum(p["ins"]["paid_won"][j] for j in table_indices)
    rem = sum(p["ins"]["remaining_won"][j] for j in table_indices)
    grand = sum(p["ins"]["total_won"][j] for j in table_indices)

    # v12 본인/가족 보험료 합계 산출 (본인 페이지 시 사용)
    self_total = sum(p["ins"]["monthly_won"][j] for j in (s["self_indices"] + s["auto_indices"])
                     if p["ins"]["payment_status"][j] == "납입중"
                     and p["ins"]["status"][j] == "정상"
                     and "일시납" not in p["ins"]["payment_period"][j])
    family_total = sum(p["ins"]["monthly_won"][j]
                       for fname, idxs in s["family_groups"]
                       for j in idxs
                       if p["ins"]["payment_status"][j] == "납입중"
                       and p["ins"]["status"][j] == "정상"
                       and "일시납" not in p["ins"]["payment_period"][j])

    # 5종 라벨 — 본인 영역만 (가족 페이지는 부재)
    if is_family_pg:
        sl, so, sh = "부재", 0, 0
        cl, cd, ct = "부재", 0, 0
        bl, bd, bt = "부재", 0, 0
        hl, hd, ht = "부재", 0, 0
        sgl, sgd, sgi = "부재", 0, 0
    else:
        m = s["self_matrix"]
        sl, so, sh = lbl_silson(m.get("silson_disease_hosp", 0), m.get("silson_disease_out", 0),
                                 m.get("silson_injury_hosp", 0), m.get("silson_injury_out", 0))
        cl, cd, ct = lbl_cancer(m.get("cancer_general_diag", 0))
        bl, bd, bt = lbl_bh(m.get("brain_diag", 0))
        hl, hd, ht = lbl_bh(m.get("heart_diag", 0))
        sgl, sgd, sgi = lbl_surg(m.get("surgery_disease", 0), m.get("surgery_injury", 0))

    labels = {"silson": sl, "cancer": cl, "brain": bl, "heart": hl, "surgery": sgl}

    # 보험료 라벨 (카드 ③ — 매우과잉/높은편/보통/낮음/미확인)
    age = p["insurance_age"] if not is_family_pg else 0
    level_label = calc_premium_label(monthly, age)

    # 5종 평균 라벨 (SKILL.md §v8 정합)
    avg_label = calc_avg_label(labels)

    # completion_pct (5종 적정+과잉 비율 — SKILL.md §v8 정합)
    completion_pct = calc_completion_pct(labels)

    has_ren = any(p["ins"]["renewal"][j] in ("갱신형 특약", "갱신형 보험") for j in table_indices)

    # 실손 amt — 첨부 html 정합 본문 "5,000 / 30 만원" / 부재 시 "—"
    silson_amt = "—" if sl == "부재" else f"{sh:,} / {so} 만원"

    return {
        "name": fam_name if is_family_pg else p["name"],
        "gender": "—" if is_family_pg else p["gender"],
        "insurance_age": "—" if is_family_pg else p["insurance_age"],
        "location": "—", "is_family": is_family_pg,
        "labels": labels,
        "details": {
            "silson_out": f"{so}만" if so else "0만",
            "silson_hosp": f"{sh:,}만" if sh else "0만",
            "cancer_diag": fmt(cd), "cancer_treat": fmt(ct),
            "brain_diag": fmt(bd), "brain_treat": fmt(bt),
            "heart_diag": fmt(hd), "heart_treat": fmt(ht),
            "surgery_disease": fmt(sgd), "surgery_injury": fmt(sgi),
        },
        "amounts": {
            "silson": silson_amt,
            "cancer": fmt(cd + ct), "brain": fmt(bd + bt),
            "heart": fmt(hd + ht), "surgery": fmt(sgd + sgi),
        },
        "mssgs": {},  # 빌더 fallback → _build_conclusion_text 자동 적용
        "monthly_premium_total": f"{monthly:,}",
        "insurance_count": len(table_indices),
        "protection_count": stats["protection_count"],
        "protection_premium": f"{stats['protection_premium']:,}",
        "other_count": stats["other_count"],
        "other_premium": f"{stats['other_premium']:,}",
        "saving_count": stats["saving_count"],
        "saving_premium": f"{stats['saving_premium']:,}",
        "unconfirmed_count": stats["unconfirmed_count"],
        "self_premium": f"{self_total:,}",
        "family_premium": f"{family_total:,}",
        "self_name": p["name"],  # v12 — 가족 페이지에서 본인명 표시
        "total_paid_premium": f"{paid:,}",
        "total_remaining_premium": f"{rem:,}",
        "total_all_premium": f"{grand:,}",
        "level_label": level_label, "completion_pct": completion_pct,
        "has_renewal": has_ren, "avg_label": avg_label,
        "headline_sub_html": "", "insurances": entries,
        "family_summaries": [],
    }


def main():
    raw_dir = Path("/home/claude/raw")
    work_dir = Path("/home/claude/work_final")
    html_dir = Path("/home/claude/html_final")
    output_dir = Path("/mnt/user-data/outputs")
    output_dir.mkdir(parents=True, exist_ok=True)
    for d in (work_dir, html_dir):
        if d.exists(): shutil.rmtree(d)
        d.mkdir(parents=True, exist_ok=True)

    order = ["박상기", "배은주", "서수라", "양미향", "이육재", "정연식", "한옥화",
             "강선영", "김현경", "나호상", "배주현", "여준수", "이치영", "홍정표",
             "김윤아", "김효임"]

    log = []
    for nn, name in enumerate(order, start=1):
        nn_str = f"{nn:02d}"
        p = parse_customer(raw_dir / f"{name}.txt")
        s = split_self_family(p)
        table_indices = s["self_indices"] + s["auto_indices"]
        c = build_customer(p, s, table_indices, is_family_pg=False)

        # PNG 본인 (트리거 1 — self+common만 정합)
        png_indices = sort_by_insurance_order(p, s["self_indices"])
        c_png = dict(c)
        c_png["insurances"] = [build_entry(p, j) for j in png_indices]
        png_html = build_png_report_html(c_png)
        html_to_png(png_html, work_dir / f"{nn_str}.{name}.png", work_dir,
                    viewport_width=720, device_scale_factor=3)

        # html 본인 TABLE
        table_html = build_png_table_html(c)
        (html_dir / f"{nn_str}.{name}_table.html").write_text(table_html, encoding="utf-8")

        # PNG 본인 TABLE
        n_ins = len(c["insurances"])
        cols = max(5, n_ins) if n_ins <= 10 else n_ins
        body_w = 422 + 120 * cols
        html_to_png(table_html, work_dir / f"{nn_str}.{name}_table.png", work_dir,
                    viewport_width=body_w, device_scale_factor=2)

        # txt 본인
        (work_dir / f"{nn_str}.{name}.txt").write_text(
            build_txt_message(c_png), encoding="utf-8")

        # 가족 TABLE
        fam_cnt = 0
        for ff, (fname, idxs) in enumerate(s["family_groups"], start=1):
            ff_str = f"{ff:02d}"
            fc = build_customer(p, s, idxs, is_family_pg=True, fam_name=fname)
            fhtml = build_png_table_html(fc)
            (html_dir / f"{nn_str}.{name}{ff_str}_table.html").write_text(fhtml, encoding="utf-8")
            fam_n = len(fc["insurances"])
            fam_cols = max(5, fam_n) if fam_n <= 10 else fam_n
            fam_w = 422 + 120 * fam_cols
            html_to_png(fhtml, work_dir / f"{nn_str}.{name}{ff_str}_table.png", work_dir,
                        viewport_width=fam_w, device_scale_factor=2)
            fam_cnt += 1

        log.append({"nn": nn_str, "name": name,
                    "labels": c["labels"], "avg": c["avg_label"],
                    "level": c["level_label"], "pct": c["completion_pct"],
                    "silson_amt": c["amounts"]["silson"]})

    # 임시 파일 정리
    for f in ["temp_report.html", "toss_logo.png"]:
        fp = work_dir / f
        if fp.exists(): fp.unlink()

    # zip 패키징
    today = datetime.now().strftime("%Y%m%d")
    png_zip = output_dir / f"report_png_{today}.zip"
    html_zip = output_dir / f"report_html_{today}.zip"
    with zipfile.ZipFile(png_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work_dir.iterdir()):
            if f.is_file():
                zf.write(f, f.name)
    with zipfile.ZipFile(html_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(html_dir.iterdir()):
            if f.is_file():
                zf.write(f, f.name)

    print(f"\n═══ 산출 완료 ═══")
    print(f"PNG zip:  {png_zip}")
    print(f"html zip: {html_zip}")
    print(f"\n{'NN':<3} {'이름':<6} {'avg':<5} {'level':<11} {'pct':<5} {'실손amt':<20}")
    print("─" * 65)
    for l in log:
        print(f"{l['nn']:<3} {l['name']:<6} {l['avg']:<5} {l['level']:<11} {l['pct']:<5} {l['silson_amt']:<20}")
    return png_zip, html_zip


if __name__ == "__main__":
    main()
